import type { Piece } from "./caseApi";

// Small grid helpers for the drag preview (green = fits, red = blocked).
// They mirror the server's rules but never decide anything: the server
// checks every move again.

export interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}

// How many cells a piece covers. Piece.w/h are the item's own size; a turned
// piece swaps them. (If the server ever sends the already-turned size, this
// is the one place to change.)
export function footprint(p: { w: number; h: number }, rotated: boolean): { w: number; h: number } {
  return rotated ? { w: p.h, h: p.w } : { w: p.w, h: p.h };
}

export function boxOf(p: Piece): Box | null {
  if (p.x === null || p.y === null) return null;
  return { x: p.x, y: p.y, ...footprint(p, p.rotated) };
}

export function overlaps(a: Box, b: Box): boolean {
  return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
}

export function inside(b: Box, cols: number, rows: number): boolean {
  return b.x >= 0 && b.y >= 0 && b.x + b.w <= cols && b.y + b.h <= rows;
}

// Pieces (other than `ignoreId`) that sit in the way of `b`.
export function blockers(b: Box, pieces: Piece[], ignoreId: number): Piece[] {
  const out: Piece[] = [];
  for (const p of pieces) {
    if (p.id === ignoreId) continue;
    const pb = boxOf(p);
    if (pb && overlaps(b, pb)) out.push(p);
  }
  return out;
}

export function fits(b: Box, cols: number, rows: number, pieces: Piece[], ignoreId: number): boolean {
  return inside(b, cols, rows) && blockers(b, pieces, ignoreId).length === 0;
}

// The piece covering cell (cx, cy), if any.
export function pieceAt(pieces: Piece[], cx: number, cy: number, ignoreId = -1): Piece | undefined {
  return pieces.find((p) => {
    if (p.id === ignoreId) return false;
    const b = boxOf(p);
    return !!b && cx >= b.x && cx < b.x + b.w && cy >= b.y && cy < b.y + b.h;
  });
}

// Can `dragged` be poured into `target` (same item, target not full)?
export function canStack(target: Piece, dragged: Piece): boolean {
  return (
    target.id !== dragged.id &&
    target.itemId === dragged.itemId &&
    target.stackSize > 1 &&
    target.quantity < target.stackSize
  );
}

// The free spot closest to `near` for a piece (trying the given turns),
// e.g. to turn a piece in place when the cells it would need are taken.
export function nearestFit(
  p: Piece,
  cols: number,
  rows: number,
  pieces: Piece[],
  near: { x: number; y: number },
  turns: boolean[]
): { x: number; y: number; rotated: boolean } | null {
  let best: { x: number; y: number; rotated: boolean; d: number } | null = null;
  for (const rotated of turns) {
    const { w, h } = footprint(p, rotated);
    for (let y = 0; y + h <= rows; y++) {
      for (let x = 0; x + w <= cols; x++) {
        if (!fits({ x, y, w, h }, cols, rows, pieces, p.id)) continue;
        const d = Math.abs(x - near.x) + Math.abs(y - near.y) + (rotated === p.rotated ? 0 : 0.01);
        if (!best || d < best.d) best = { x, y, rotated, d };
      }
    }
  }
  return best && { x: best.x, y: best.y, rotated: best.rotated };
}

// Weapon slot numbers (1, 2, 3…) in reading order, like the reference case.
export function slotNumbers(pieces: Piece[]): Map<number, number> {
  const weapons = pieces
    .filter((p) => (p.kind === "gun" || p.kind === "knife") && p.x !== null && p.y !== null)
    .sort((a, b) => a.y! - b.y! || a.x! - b.x!);
  return new Map(weapons.map((p, i) => [p.id, i + 1]));
}

// The nearest piece from `from` in an arrow-key direction (keyboard use).
export function neighbour(
  pieces: Piece[],
  from: Piece,
  dir: "left" | "right" | "up" | "down"
): Piece | undefined {
  const fb = boxOf(from);
  if (!fb) return undefined;
  const fc = { x: fb.x + fb.w / 2, y: fb.y + fb.h / 2 };
  let best: { p: Piece; score: number } | undefined;
  for (const p of pieces) {
    const b = boxOf(p);
    if (!b || p.id === from.id) continue;
    const c = { x: b.x + b.w / 2, y: b.y + b.h / 2 };
    const dx = c.x - fc.x;
    const dy = c.y - fc.y;
    const along = dir === "left" ? -dx : dir === "right" ? dx : dir === "up" ? -dy : dy;
    const across = dir === "left" || dir === "right" ? Math.abs(dy) : Math.abs(dx);
    if (along <= 0.01) continue;
    const score = along + across * 2;
    if (!best || score < best.score) best = { p, score };
  }
  return best?.p;
}
