import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { requireRole } from "../auth/middleware";
import { HpLogKind, listHpLog } from "../database/health";

const KINDS: HpLogKind[] = ["HIT", "HEAL", "MAX_UP", "FULL", "SET", "REVIVE", "DEATH", "RESET"];
const LIMIT_DEFAULT = 100;
const LIMIT_MAX = 500;

// Admin: /api/admin/hits — the live "Hits" feed on the Game tab: recent HP
// history (voice hits with "heard by N phones", deaths, heals, Admin
// changes), newest first, with each player's name and number.
//
// GET ?limit=100 (1–500)
//     &kinds=HIT,DEATH    only these kinds (default: all)
//     &playerId=12        only one player
// → { hits: [{ id, playerId, playerNumber, playerName, kind, amount,
//      hpBefore, hpAfter, maxBefore, maxAfter, source, heardBy,
//      performedBy, performedByName, createdAt }] }
// Reload it on hp:changed. "heard by" can still grow for a few seconds
// after a voice hit (more phones report it), so reload once more then.
export function createHitsRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  router.get("/", (req, res) => {
    const q = req.query;

    let limit = LIMIT_DEFAULT;
    if (q.limit !== undefined) {
      limit = Number(q.limit);
      if (typeof q.limit !== "string" || !Number.isInteger(limit) || limit < 1 || limit > LIMIT_MAX) {
        res.status(400).json({ error: `Limit must be a whole number from 1 to ${LIMIT_MAX}.` });
        return;
      }
    }

    let kinds: HpLogKind[] | undefined;
    if (q.kinds !== undefined) {
      const list = typeof q.kinds === "string" ? q.kinds.split(",").map((k) => k.trim().toUpperCase()) : [];
      if (list.length === 0 || !list.every((k): k is HpLogKind => (KINDS as string[]).includes(k))) {
        res.status(400).json({ error: `Kinds must be a comma-separated list of: ${KINDS.join(", ")}.` });
        return;
      }
      kinds = list;
    }

    let playerId: number | undefined;
    if (q.playerId !== undefined) {
      playerId = Number(q.playerId);
      if (typeof q.playerId !== "string" || !Number.isInteger(playerId) || playerId < 1) {
        res.status(400).json({ error: "Choose a valid player." });
        return;
      }
    }

    res.json({ hits: listHpLog(db, { limit, kinds, playerId }) });
  });

  return router;
}
