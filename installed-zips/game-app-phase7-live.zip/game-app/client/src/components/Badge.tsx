import { ReactNode } from "react";

export function Badge({ tone, children }: { tone: "good" | "bad" | "neutral" | "warn"; children: ReactNode }) {
  const cls =
    tone === "good"
      ? "bg-pine-soft text-pine"
      : tone === "bad"
      ? "bg-alert/10 text-alert"
      : tone === "warn"
      ? "bg-sun/30 text-ink"
      : "bg-ink/5 text-ink/70";
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-sm font-bold ${cls}`}>{children}</span>
  );
}
