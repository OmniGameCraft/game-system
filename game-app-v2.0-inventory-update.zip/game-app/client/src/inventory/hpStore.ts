import { useEffect, useState } from "react";
import { onLive } from "../services/live";
import { playSfx } from "../audio/sfx";
import { vibrate } from "../audio/haptics";
import { toast } from "../components/Toast";
import { getHp, type HpState } from "./caseApi";

// The player's health, shared by every screen that shows it (top-bar pill,
// case screen, weapon screen). Keeping ONE copy means one request, and the
// hit / heal / death sound plays once per change instead of once per screen.

type Listener = (s: HpState | null) => void;
export type HpFlashKind = "hit" | "heal";

let current: HpState | null = null;
const listeners = new Set<Listener>();
const flashListeners = new Set<(k: HpFlashKind) => void>();
let detach: (() => void) | null = null;
let detachTimer: ReturnType<typeof setTimeout> | null = null;
let liveSeq = 0; // bumps when a live notice brings a value
let loadSeq = 0; // bumps on every request, so only the newest answer counts

function same(a: HpState, b: HpState): boolean {
  return a.hp === b.hp && a.maxHp === b.maxHp && a.dead === b.dead;
}

function flash(kind: HpFlashKind) {
  flashListeners.forEach((fn) => fn(kind));
}

// Something changed: tell the player with sound, a buzz and a screen flash.
function announce(prev: HpState, next: HpState, source?: string) {
  if (!prev.dead && next.dead) {
    playSfx("death");
    vibrate([140, 70, 380]);
    flash("hit");
    toast("You're down. The Admin can revive you.", "bad");
  } else if (prev.dead && !next.dead) {
    playSfx("heal");
    vibrate(40);
    flash("heal");
    toast("You're back in the game!", "good");
  } else if (next.hp < prev.hp) {
    playSfx("hit");
    vibrate([70, 40, 110]);
    flash("hit");
    const lost = prev.hp - next.hp;
    toast(source === "voice" || !source ? `Hit! −${lost} HP` : `−${lost} HP (${source})`, "bad");
  } else if (next.hp > prev.hp || next.maxHp > prev.maxHp) {
    // The action that healed (Use button, weapon screen) shows its own
    // message; here it's just the sound and the green glow.
    playSfx("heal");
    vibrate(25);
    flash("heal");
  }
}

// Put a new value in. `silent` skips the sounds (first load, catching up).
export function applyHp(next: HpState, opts: { silent?: boolean; source?: string } = {}): void {
  const prev = current;
  if (prev && same(prev, next)) return;
  current = { hp: next.hp, maxHp: next.maxHp, dead: next.dead };
  listeners.forEach((l) => l(current));
  if (prev && !opts.silent) announce(prev, current, opts.source);
}

export function getHpNow(): HpState | null {
  return current;
}

// Ask the server. An answer that started before a newer live notice is
// thrown away, so an old reading never flickers the bar back.
export function refreshHp(silent = false): Promise<void> {
  const mine = ++loadSeq;
  const seqAtStart = liveSeq;
  return getHp()
    .then((s) => {
      if (mine !== loadSeq || seqAtStart !== liveSeq) return;
      applyHp(s, { silent });
    })
    .catch(() => {
      // offline or not a player: keep what we have
    });
}

function attach() {
  const offs = [
    // The notice carries the new numbers, so the flash is instant.
    onLive(["hp:changed"], (p?: any) => {
      if (p && typeof p.hp === "number" && typeof p.maxHp === "number") {
        liveSeq++;
        applyHp({ hp: p.hp, maxHp: p.maxHp, dead: Boolean(p.dead) }, { source: typeof p.source === "string" ? p.source : undefined });
      } else {
        void refreshHp();
      }
    }),
    onLive(["me:changed", "reconnected"], () => void refreshHp()),
  ];
  detach = () => offs.forEach((off) => off());
}

export function useHp(): HpState | null {
  const [state, setState] = useState<HpState | null>(current);
  useEffect(() => {
    listeners.add(setState);
    if (detachTimer) {
      clearTimeout(detachTimer);
      detachTimer = null;
    }
    if (!detach) attach();
    // First screen to show HP (again): read it fresh. Silent, because what
    // changed while nobody was watching is old news (or another player's
    // HP from before a logout on this phone).
    if (listeners.size === 1) void refreshHp(true);
    setState(current);
    return () => {
      listeners.delete(setState);
      if (listeners.size === 0) {
        // Wait a moment: switching tabs unmounts one screen and mounts the next.
        detachTimer = setTimeout(() => {
          detachTimer = null;
          if (listeners.size > 0) return;
          detach?.();
          detach = null;
          current = null; // e.g. logged out: never show the last player's HP
        }, 1500);
      }
    };
  }, []);
  return state;
}

export function onHpFlash(fn: (k: HpFlashKind) => void): () => void {
  flashListeners.add(fn);
  return () => {
    flashListeners.delete(fn);
  };
}
