import { useEffect, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { listPlayers, Player } from "../../services/api";

export function PlayersList({
  onCreate,
  onOpen,
}: {
  onCreate: () => void;
  onOpen: (id: number) => void;
}) {
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  function load() {
    setError(null);
    listPlayers()
      .then(setPlayers)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load players."));
  }

  useEffect(load, []);

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-2xl font-bold text-pine">Players</h2>
      <ErrorBanner message={error} />

      {players === null && !error && <p className="text-ink/60">Loading…</p>}

      {players?.length === 0 && (
        <p className="rounded-xl bg-pine-soft px-4 py-4 text-ink/80">
          No players yet. Create the first one below.
        </p>
      )}

      <div className="flex flex-col gap-3">
        {players?.map((p) => (
          <button
            key={p.id}
            onClick={() => onOpen(p.id)}
            className="rounded-2xl border-2 border-ink/15 bg-white p-4 text-left"
          >
            <p className="text-lg font-semibold text-ink">{p.displayName || p.username}</p>
            <p
              className={`text-sm font-medium ${
                p.status === "active" ? "text-pine" : "text-alert"
              }`}
            >
              Status: {p.status === "active" ? "Active" : "Disabled"}
            </p>
          </button>
        ))}
      </div>

      <Button onClick={onCreate}>+ Create Player</Button>
    </div>
  );
}
