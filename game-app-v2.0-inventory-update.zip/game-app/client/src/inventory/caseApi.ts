import { notifyUnauthorized } from "../services/authEvents";
import type { GameStatus, ItemKind, TrackView, UseEffect } from "../services/api";

// Everything the case (grid inventory) screen sends to and reads from the
// server. The server is the only judge of what fits and what is allowed; the
// phone just shows previews and asks.

export type HerbCode = "G" | "R" | "Y" | "GG" | "GR" | "GY" | "GRY" | "GGY";

export interface HpState {
  hp: number;
  maxHp: number;
  dead: boolean;
}

// Gun feel numbers, computed on the server (fire-rate / reload upgrades).
export interface GunNumbers {
  reloadMs: number;
  shakeThreshold: number;
  cooldownMs: number;
  damagePct: number;
}

// One piece in the case: an item (or a stack of it) at a spot in the grid.
export interface Piece {
  id: number;
  itemId: number;
  name: string;
  kind: ItemKind;
  // Not in the original Piece contract; shown when the server sends them.
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  x: number | null; // null = in the "doesn't fit" tray
  y: number | null;
  w: number; // the item's own size, NOT turned (see layout.footprint)
  h: number;
  rotated: boolean;
  quantity: number; // units (rounds, for ammo)
  stackSize: number; // most units one piece can hold
  loaded: number; // guns: rounds in the magazine
  magazine: number | null; // guns: magazine size at the player's level
  ammoItemId: number | null; // guns: the ammo item that fits
  reserve: number; // guns: rounds of that ammo the player holds
  herbCode: HerbCode | null;
  healAmount: number | null;
  maxHpBonus: number | null;
  fullHeal: boolean;
  usable: boolean; // can be "used" for healing
  upgrades: TrackView[];
  gun: GunNumbers | null;
}

// Something lying in the drop box, ready for anyone to pick up.
export interface Drop {
  id: number;
  itemId: number;
  name: string;
  kind: ItemKind;
  imageUrl: string | null;
  quantity: number;
  loaded: number;
  w: number;
  h: number;
  ownerName: string;
  reason: "DROP" | "DEATH";
  createdAt: string;
}

export interface CaseState {
  cols: number;
  rows: number;
  expansions: number;
  pieces: Piece[]; // placed in the grid
  tray: Piece[]; // "doesn't fit — make room"
  drops: Drop[];
  hp: HpState | null;
  game: { status: GameStatus };
  rules: { practiceFire: boolean };
}

// ---- reading what the server sends (tolerant of 0/1 vs true/false etc.) ----

const num = (v: unknown, d = 0): number => (typeof v === "number" && Number.isFinite(v) ? v : d);
const numOrNull = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);
const str = (v: unknown): string | null => (typeof v === "string" ? v : null);

export function toPiece(r: any): Piece {
  const x = numOrNull(r?.x);
  const y = numOrNull(r?.y);
  const placed = x !== null && y !== null;
  return {
    id: num(r?.id),
    itemId: num(r?.itemId),
    name: str(r?.name) ?? "Item",
    kind: (str(r?.kind) as ItemKind) ?? "other",
    description: str(r?.description),
    category: str(r?.category),
    imageUrl: str(r?.imageUrl),
    modelUrl: str(r?.modelUrl),
    soundUrl: str(r?.soundUrl),
    useEffect: (str(r?.useEffect) as UseEffect) ?? "none",
    modelFlip: Boolean(r?.modelFlip),
    modelUpsideDown: Boolean(r?.modelUpsideDown),
    x: placed ? x : null,
    y: placed ? y : null,
    w: Math.max(1, num(r?.w, 1)),
    h: Math.max(1, num(r?.h, 1)),
    rotated: Boolean(r?.rotated),
    quantity: Math.max(0, num(r?.quantity, 1)),
    stackSize: Math.max(1, num(r?.stackSize, 1)),
    loaded: Math.max(0, num(r?.loaded)),
    magazine: numOrNull(r?.magazine),
    ammoItemId: numOrNull(r?.ammoItemId),
    reserve: Math.max(0, num(r?.reserve)),
    herbCode: (str(r?.herbCode) as HerbCode | null) ?? null,
    healAmount: numOrNull(r?.healAmount),
    maxHpBonus: numOrNull(r?.maxHpBonus),
    fullHeal: Boolean(r?.fullHeal),
    usable: Boolean(r?.usable),
    upgrades: Array.isArray(r?.upgrades) ? r.upgrades : [],
    gun: r?.gun && typeof r.gun === "object" ? (r.gun as GunNumbers) : null,
  };
}

function toDrop(r: any): Drop {
  return {
    id: num(r?.id),
    itemId: num(r?.itemId),
    name: str(r?.name) ?? "Item",
    kind: (str(r?.kind) as ItemKind) ?? "other",
    imageUrl: str(r?.imageUrl),
    quantity: Math.max(1, num(r?.quantity, 1)),
    loaded: Math.max(0, num(r?.loaded)),
    w: Math.max(1, num(r?.w, 1)),
    h: Math.max(1, num(r?.h, 1)),
    ownerName: str(r?.ownerName) ?? "someone",
    reason: r?.reason === "DEATH" ? "DEATH" : "DROP",
    createdAt: str(r?.createdAt) ?? "",
  };
}

export function toHp(r: any): HpState | null {
  if (!r || typeof r.hp !== "number") return null;
  return { hp: r.hp, maxHp: num(r.maxHp, r.hp), dead: Boolean(r.dead) };
}

export function toCaseState(r: any): CaseState {
  const all: Piece[] = (Array.isArray(r?.pieces) ? r.pieces : []).map(toPiece);
  const trayRaw: Piece[] = (Array.isArray(r?.tray) ? r.tray : []).map(toPiece);
  // A piece without a spot belongs in the tray, wherever the server listed it.
  const seen = new Set<number>();
  const pieces: Piece[] = [];
  const tray: Piece[] = [];
  for (const p of [...all, ...trayRaw]) {
    if (seen.has(p.id) || p.quantity <= 0) continue;
    seen.add(p.id);
    if (p.x === null) tray.push({ ...p, x: null, y: null });
    else pieces.push(p);
  }
  const status = str(r?.game?.status) as GameStatus | null;
  return {
    cols: Math.max(1, num(r?.cols, 8)),
    rows: Math.max(1, num(r?.rows, 4)),
    expansions: Math.max(0, num(r?.expansions)),
    pieces,
    tray,
    drops: (Array.isArray(r?.drops) ? r.drops : []).map(toDrop),
    hp: toHp(r?.hp),
    game: { status: status ?? "not_started" },
    rules: { practiceFire: r?.rules?.practiceFire !== false },
  };
}

// Some answers carry the whole new case; use it straight away when they do.
export function caseFrom(body: any): CaseState | null {
  if (body && Array.isArray(body.pieces) && typeof body.cols === "number") return toCaseState(body);
  if (body?.case && Array.isArray(body.case.pieces)) return toCaseState(body.case);
  return null;
}

// The new HP, when an answer includes it (e.g. after using a heal).
export function hpFrom(body: any): HpState | null {
  return toHp(body?.hp) ?? toHp(body);
}

// ---- calls ----

export class CaseError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

const OFFLINE = "Can't reach the server. Check your Wi-Fi and try again.";

async function request(method: "GET" | "POST", path: string, body?: unknown): Promise<any> {
  let res: Response;
  try {
    res = await fetch(path, {
      method,
      headers: body === undefined ? undefined : { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new CaseError(OFFLINE, 0);
  }
  if (res.status === 401) notifyUnauthorized();
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    // no JSON body
  }
  if (!res.ok) {
    const fallback =
      res.status === 404
        ? "That item isn't there anymore. The case has been refreshed."
        : "Something went wrong. Please try again.";
    throw new CaseError(data?.error || fallback, res.status);
  }
  return data ?? {};
}

export async function getCase(): Promise<CaseState> {
  return toCaseState(await request("GET", "/api/case"));
}

export async function getHp(): Promise<HpState> {
  const hp = toHp(await request("GET", "/api/case/hp"));
  if (!hp) throw new CaseError("Couldn't read your health.", 500);
  return hp;
}

// x/y null = put it aside in the tray. Dropping exactly onto a partial stack
// of the same item merges the two (the server decides).
export const movePiece = (pieceId: number, x: number | null, y: number | null, rotated: boolean) =>
  request("POST", "/api/case/move", { pieceId, x, y, rotated });

export const splitPiece = (pieceId: number, quantity: number) =>
  request("POST", "/api/case/split", { pieceId, quantity });

export const arrangeCase = () => request("POST", "/api/case/arrange", {});

export const combinePieces = (pieceId: number, withPieceId: number) =>
  request("POST", "/api/case/combine", { pieceId, withPieceId });

export const usePiece = (pieceId: number) => request("POST", "/api/case/use", { pieceId });

export const dropPiece = (pieceId: number, quantity?: number) =>
  request("POST", "/api/case/drop", quantity === undefined ? { pieceId } : { pieceId, quantity });

export const pickupDrop = (dropId: number, quantity?: number) =>
  request("POST", "/api/case/pickup", quantity === undefined ? { dropId } : { dropId, quantity });

// Loading a gun from the case frees the space its ammo took (owner's point 3).
export async function reloadGun(pieceId: number): Promise<{ loaded: number; reserve: number; reloadMs: number }> {
  const b = await request("POST", "/api/play/reload", { pieceId });
  return { loaded: num(b?.loaded), reserve: num(b?.reserve), reloadMs: num(b?.reloadMs, 1200) };
}
