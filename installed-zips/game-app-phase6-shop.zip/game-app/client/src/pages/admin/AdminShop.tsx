import { FormEvent, useEffect, useState } from "react";
import { BackButton } from "../../components/BackButton";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ConfirmCard } from "../../components/ConfirmCard";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls, TextField } from "../../components/Field";
import { Icon } from "../../components/Icon";
import { ItemImage } from "../../components/ItemImage";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import {
  addListing,
  AdminShop as AdminShopData,
  getAdminShop,
  Item,
  listItems,
  Listing,
  removeListing,
  setShopOpen,
  updateListing,
} from "../../services/api";
import { formatDateTime } from "../../utils/format";

type View = { name: "overview" } | { name: "add" } | { name: "edit"; id: number };

export function AdminShop() {
  const [data, setData] = useState<AdminShopData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<View>({ name: "overview" });

  function load() {
    setError(null);
    getAdminShop()
      .then(setData)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load the shop."));
  }
  useEffect(load, []);

  function back() {
    setView({ name: "overview" });
    window.scrollTo(0, 0);
    load();
  }

  if (view.name === "add") return <ListingForm onDone={back} />;
  if (view.name === "edit") {
    const listing = data?.listings.find((l) => l.id === view.id);
    if (listing) return <ListingForm listing={listing} onDone={back} />;
  }

  return (
    <>
      <ErrorBanner message={error} />
      {!data && !error && <p className="text-ink/60">Loading…</p>}
      {data && (
        <>
          <ShopStatus open={data.open} onChange={(open) => setData({ ...data, open })} />
          <Button onClick={() => setView({ name: "add" })}>+ Add item to shop</Button>
          <Section title={`In the shop (${data.listings.length})`} flush>
            {data.listings.length === 0 && (
              <p className="p-4 text-ink/70">Nothing for sale yet. Tap “Add item to shop” to put an item on sale.</p>
            )}
            <ul className="divide-y-2 divide-ink/5">
              {data.listings.map((l) => (
                <li key={l.id}>
                  <button
                    onClick={() => {
                      setView({ name: "edit", id: l.id });
                      window.scrollTo(0, 0);
                    }}
                    className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-pine-soft"
                  >
                    <ItemImage url={l.imageUrl} name={l.name} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <p className="truncate text-lg font-bold text-ink">{l.name}</p>
                        <p className="shrink-0 text-lg font-extrabold tabular-nums text-pine">
                          {l.price === 0 ? "Free" : `$${l.price}`}
                        </p>
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-1.5">
                        <StockBadge stock={l.stock} />
                        {l.maxPerPurchase !== null && <Badge tone="neutral">Max {l.maxPerPurchase} per buy</Badge>}
                        {!l.enabled && <Badge tone="bad">Hidden</Badge>}
                        {!l.itemEnabled && <Badge tone="bad">Item disabled</Badge>}
                      </div>
                    </div>
                    <Icon name="chevron" className="h-5 w-5 shrink-0 text-ink/30" />
                  </button>
                </li>
              ))}
            </ul>
          </Section>

          <Section title="Recent sales" flush>
            {data.sales.length === 0 ? (
              <p className="p-4 text-ink/60">No sales yet.</p>
            ) : (
              <ul className="divide-y-2 divide-ink/5">
                {data.sales.map((s) => (
                  <li key={s.id} className="flex items-center justify-between gap-3 px-4 py-3">
                    <div className="min-w-0">
                      <p className="font-semibold leading-snug">
                        {s.playerName} bought {s.quantity} × {s.itemName}
                      </p>
                      <p className="text-sm text-ink/55">{formatDateTime(s.createdAt)}</p>
                    </div>
                    <span className="shrink-0 text-lg font-extrabold tabular-nums text-pine">${s.total}</span>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        </>
      )}
    </>
  );
}

function StockBadge({ stock }: { stock: number | null }) {
  if (stock === null) return <Badge tone="neutral">Unlimited stock</Badge>;
  if (stock === 0) return <Badge tone="bad">Out of stock</Badge>;
  return <Badge tone={stock <= 3 ? "warn" : "neutral"}>{stock} in stock</Badge>;
}

function ShopStatus({ open, onChange }: { open: boolean; onChange: (open: boolean) => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function toggle() {
    setBusy(true);
    setError(null);
    try {
      onChange(await setShopOpen(!open));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not change the shop.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Section title="Shop status" tone={open ? "pine" : "alert"}>
      <ErrorBanner message={error} />
      <div
        className={`flex items-center justify-center gap-3 rounded-xl py-5 text-3xl font-extrabold tracking-wide ${
          open ? "bg-pine-soft text-pine" : "bg-alert/10 text-alert"
        }`}
      >
        <span className={`h-4 w-4 rounded-full ${open ? "bg-pine" : "bg-alert"}`} aria-hidden />
        {open ? "SHOP OPEN" : "SHOP CLOSED"}
      </div>
      <p className="text-ink/70">
        {open
          ? "Players can see prices and buy right now."
          : "Players see “Shop Closed” and can't buy anything."}
      </p>
      <Button variant={open ? "danger" : "primary"} loading={busy} onClick={toggle}>
        {open ? "Close the shop" : "Open the shop"}
      </Button>
    </Section>
  );
}

function toOptionalInt(v: string, min: number): number | null | Error {
  const t = v.trim();
  if (t === "") return null;
  const n = Number(t);
  if (!Number.isInteger(n) || n < min) return new Error("bad");
  return n;
}

function ListingForm({ listing, onDone }: { listing?: Listing; onDone: () => void }) {
  const isEdit = !!listing;
  const [items, setItems] = useState<Item[] | null>(null);
  const [listed, setListed] = useState<Set<number>>(new Set());
  const [itemId, setItemId] = useState("");
  const [price, setPrice] = useState(listing ? String(listing.price) : "");
  const [stock, setStock] = useState(listing?.stock != null ? String(listing.stock) : "");
  const [maxPer, setMaxPer] = useState(listing?.maxPerPurchase != null ? String(listing.maxPerPurchase) : "");
  const [enabled, setEnabled] = useState(listing?.enabled ?? true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [confirmRemove, setConfirmRemove] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [togglingVis, setTogglingVis] = useState(false);

  useEffect(() => {
    if (isEdit) return;
    Promise.all([listItems(), getAdminShop()])
      .then(([all, shop]) => {
        setItems(all);
        setListed(new Set(shop.listings.map((l) => l.itemId)));
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load items."));
  }, [isEdit]);

  function readFields(): { price: number; stock: number | null; maxPerPurchase: number | null } | null {
    const p = Number(price);
    if (price.trim() === "" || !Number.isInteger(p) || p < 0) {
      setError("Enter a price: a whole number, 0 or more.");
      return null;
    }
    const s = toOptionalInt(stock, 0);
    if (s instanceof Error) {
      setError("Stock must be a whole number, 0 or more. Leave it empty for unlimited.");
      return null;
    }
    const m = toOptionalInt(maxPer, 1);
    if (m instanceof Error) {
      setError("Limit per purchase must be 1 or more. Leave it empty for no limit.");
      return null;
    }
    return { price: p, stock: s, maxPerPurchase: m };
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    setError(null);
    setNotice(null);
    if (!isEdit && !itemId) {
      setError("Choose an item.");
      return;
    }
    const f = readFields();
    if (!f) return;
    setSaving(true);
    try {
      if (isEdit) {
        await updateListing(listing!.id, f);
        setNotice("Saved.");
      } else {
        await addListing({ itemId: Number(itemId), ...f, enabled });
        onDone();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save.");
    } finally {
      setSaving(false);
    }
  }

  async function toggleVisible() {
    setTogglingVis(true);
    setError(null);
    setNotice(null);
    try {
      const updated = await updateListing(listing!.id, { enabled: !enabled });
      setEnabled(updated.enabled);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not change it.");
    } finally {
      setTogglingVis(false);
    }
  }

  async function handleRemove() {
    setRemoving(true);
    setError(null);
    try {
      await removeListing(listing!.id);
      onDone();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not remove it.");
      setRemoving(false);
    }
  }

  const available = items?.filter((i) => !listed.has(i.id)) ?? [];

  return (
    <>
      <BackButton label="Shop" onClick={onDone} />
      <ErrorBanner message={error} />
      <Notice message={notice} />

      {isEdit && (
        <div className="flex items-center gap-4 rounded-2xl border-2 border-pine/20 bg-white p-4 shadow-sm">
          <ItemImage url={listing!.imageUrl} name={listing!.name} size="lg" />
          <div className="min-w-0">
            <p className="text-2xl font-extrabold">{listing!.name}</p>
            {listing!.category && <p className="text-ink/60">{listing!.category}</p>}
            {!listing!.itemEnabled && <Badge tone="bad">Item disabled in Items tab</Badge>}
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Section title={isEdit ? "Price and stock" : "Put an item on sale"}>
          {!isEdit && (
            <label htmlFor="shop-item" className="block">
              <span className="mb-1 block text-base font-semibold text-ink/80">Item</span>
              <select id="shop-item" value={itemId} onChange={(e) => setItemId(e.target.value)} className={inputCls}>
                <option value="">Choose an item…</option>
                {available.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.name}
                    {!i.enabled ? " (disabled)" : ""}
                  </option>
                ))}
              </select>
              {items && items.length === 0 && (
                <span className="mt-1 block text-sm text-ink/60">Create items in the Items tab first.</span>
              )}
              {items && items.length > 0 && available.length === 0 && (
                <span className="mt-1 block text-sm text-ink/60">Every item is already in the shop.</span>
              )}
            </label>
          )}
          <TextField
            id="shop-price"
            label="Price ($)"
            hint="0 makes it free."
            type="number"
            inputMode="numeric"
            min={0}
            step={1}
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
          <TextField
            id="shop-stock"
            label="Stock (optional)"
            hint="How many the shop has. Leave empty for unlimited."
            type="number"
            inputMode="numeric"
            min={0}
            step={1}
            value={stock}
            onChange={(e) => setStock(e.target.value)}
          />
          <TextField
            id="shop-max"
            label="Limit per purchase (optional)"
            hint="Most a player can buy in one go. Leave empty for no limit."
            type="number"
            inputMode="numeric"
            min={1}
            step={1}
            value={maxPer}
            onChange={(e) => setMaxPer(e.target.value)}
          />
        </Section>
        <Button type="submit" loading={saving}>
          {isEdit ? "Save changes" : "Add to shop"}
        </Button>
      </form>

      {isEdit && (
        <>
          <Section title="Visibility" tone={enabled ? "pine" : "alert"}>
            <div>
              <Badge tone={enabled ? "good" : "bad"}>{enabled ? "Shown to players" : "Hidden from players"}</Badge>
            </div>
            <p className="text-ink/70">Hiding keeps the price and stock saved, so you can show it again later.</p>
            <Button variant="ghost" loading={togglingVis} onClick={toggleVisible}>
              {enabled ? "Hide from shop" : "Show in shop"}
            </Button>
          </Section>

          <Section title="Remove from shop" tone="alert">
            {confirmRemove ? (
              <ConfirmCard
                title={`Remove ${listing!.name} from the shop?`}
                body="Players who already bought it keep it. You can add it back later."
                confirmLabel="Remove"
                onConfirm={handleRemove}
                onCancel={() => setConfirmRemove(false)}
                loading={removing}
              />
            ) : (
              <Button variant="dangerGhost" onClick={() => setConfirmRemove(true)}>
                Remove from shop
              </Button>
            )}
          </Section>
        </>
      )}
    </>
  );
}
