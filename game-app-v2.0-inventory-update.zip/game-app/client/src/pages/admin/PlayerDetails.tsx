import { FormEvent, useEffect, useState } from "react";
import { useLive } from "../../services/live";
import { BackButton } from "../../components/BackButton";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ConfirmCard } from "../../components/ConfirmCard";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls, PasswordField, TextField } from "../../components/Field";
import { Icon } from "../../components/Icon";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import { getPlayer, Player, resetPlayerPassword, setPlayerNumber, updatePlayer } from "../../services/api";
import { formatDate } from "../../utils/format";
import { CaseSection } from "./CaseSection";
import { HealthSection } from "./HealthSection";
import { InventorySection } from "./InventorySection";
import { HP_CHANGED } from "./liveEvents";
import { MoneySection } from "./MoneySection";
import { hpColor, HpMeter, hpOf, NumberPlate } from "./ui";

type Tab = "health" | "case" | "money" | "account";

export function PlayerDetails({ id, onBack }: { id: number; onBack: () => void }) {
  const [player, setPlayer] = useState<Player | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  // Mid-game the Admin mostly needs HP, so that's the first thing shown.
  const [tab, setTab] = useState<Tab>("health");

  const [editingNumber, setEditingNumber] = useState(false);
  const [numberText, setNumberText] = useState("");
  const [numberError, setNumberError] = useState<string | null>(null);
  const [savingNumber, setSavingNumber] = useState(false);

  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [editError, setEditError] = useState<string | null>(null);
  const [editNotice, setEditNotice] = useState<string | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);

  const [confirmingStatus, setConfirmingStatus] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);
  const [savingStatus, setSavingStatus] = useState(false);

  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetDone, setResetDone] = useState(false);
  const [savingReset, setSavingReset] = useState(false);

  useEffect(() => {
    getPlayer(id)
      .then((p) => {
        setPlayer(p);
        setUsername(p.username);
        setDisplayName(p.displayName || "");
      })
      .catch((err) => setLoadError(err instanceof Error ? err.message : "Failed to load player."));
  }, [id]);

  // Balance, HP and status update live (e.g. after the player buys something
  // or gets hit). Only `player` is refreshed, so fields being edited aren't
  // overwritten.
  useLive(["player:changed", HP_CHANGED], (payload) => {
    if (payload && payload.playerId !== id) return;
    getPlayer(id).then(setPlayer).catch(() => {});
  });

  async function handleSaveEdit(e: FormEvent) {
    e.preventDefault();
    if (!player || savingEdit) return;
    setEditError(null);
    setEditNotice(null);
    setSavingEdit(true);
    try {
      setPlayer(await updatePlayer(player.id, { username, displayName: displayName || null }));
      setEditNotice("Saved.");
    } catch (err) {
      setEditError(err instanceof Error ? err.message : "Could not save changes.");
    } finally {
      setSavingEdit(false);
    }
  }

  async function handleSaveNumber(e: FormEvent) {
    e.preventDefault();
    if (!player || savingNumber) return;
    setNumberError(null);
    const n = Number(numberText);
    if (numberText.trim() === "" || !Number.isInteger(n) || n < 1 || n > 99) {
      setNumberError("Choose a whole number from 1 to 99.");
      return;
    }
    if (n === player.playerNumber) {
      setEditingNumber(false);
      return;
    }
    setSavingNumber(true);
    try {
      setPlayer(await setPlayerNumber(player.id, n));
      setEditingNumber(false);
    } catch (err) {
      setNumberError(err instanceof Error ? err.message : "Could not change the number.");
    } finally {
      setSavingNumber(false);
    }
  }

  function startEditNumber() {
    setNumberText(player?.playerNumber ? String(player.playerNumber) : "");
    setNumberError(null);
    setEditingNumber(true);
  }

  async function handleToggleStatus() {
    if (!player) return;
    setStatusError(null);
    setSavingStatus(true);
    try {
      setPlayer(await updatePlayer(player.id, { status: player.status === "active" ? "disabled" : "active" }));
      setConfirmingStatus(false);
    } catch (err) {
      setStatusError(err instanceof Error ? err.message : "Could not update status.");
    } finally {
      setSavingStatus(false);
    }
  }

  async function handleResetPassword(e: FormEvent) {
    e.preventDefault();
    if (!player || savingReset) return;
    setResetError(null);
    setResetDone(false);
    if (newPassword !== confirmNewPassword) {
      setResetError("Passwords do not match.");
      return;
    }
    setSavingReset(true);
    try {
      await resetPlayerPassword(player.id, { password: newPassword, confirmPassword: confirmNewPassword });
      setResetDone(true);
      setNewPassword("");
      setConfirmNewPassword("");
    } catch (err) {
      setResetError(err instanceof Error ? err.message : "Could not reset password.");
    } finally {
      setSavingReset(false);
    }
  }

  if (loadError) {
    return (
      <>
        <BackButton label="Players" onClick={onBack} />
        <ErrorBanner message={loadError} />
      </>
    );
  }
  if (!player) return <p className="text-ink/60">Loading…</p>;

  const name = player.displayName || player.username;
  const active = player.status === "active";
  const hp = hpOf(player);

  return (
    <>
      <BackButton label="Players" onClick={onBack} />

      <div className={`flex flex-col gap-3 border-2 bg-panel p-4 shadow-sm ${player.dead ? "border-alert/40" : "border-pine/20"}`}>
        <div className="flex items-center gap-4">
          {/* The callout number, big like a slot number. Tap to change it. */}
          <button
            type="button"
            onClick={startEditNumber}
            className="flex shrink-0 flex-col items-center gap-1 active:scale-95"
            aria-label={`Player number ${player.playerNumber ?? "not set"}. Change`}
          >
            <NumberPlate n={player.playerNumber} size="lg" />
            <span className="text-xs font-bold uppercase tracking-wider text-pine">Change</span>
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-2xl font-bold text-ink">{name}</p>
            <p className="truncate text-ink/55">@{player.username}</p>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              <Badge tone={active ? "good" : "bad"}>{active ? "Active" : "Disabled"}</Badge>
              {player.dead && (
                <Badge tone="bad">
                  <Icon name="skull" className="mr-1 h-4 w-4" />
                  Down
                </Badge>
              )}
              <span className="font-display text-lg font-bold tabular-nums text-pine">${player.balance}</span>
            </div>
          </div>
        </div>
        {hp && (
          <div className="flex items-center gap-3">
            <Icon name="heart" className={`h-5 w-5 shrink-0 ${hpColor(hp).text}`} />
            <div className="flex-1">
              <HpMeter hp={hp} />
            </div>
            <span className={`shrink-0 font-display font-bold tabular-nums ${hpColor(hp).text}`}>
              {hp.hp}/{hp.maxHp}
            </span>
          </div>
        )}
        {editingNumber && (
          <form onSubmit={handleSaveNumber} className="flex flex-col gap-3 border-t border-panel-line pt-3">
            <label htmlFor="player-number" className="block">
              <span className="mb-1 block text-base font-semibold text-ink/75">Player number</span>
              <input
                id="player-number"
                type="number"
                inputMode="numeric"
                min={1}
                max={99}
                step={1}
                autoFocus
                value={numberText}
                onChange={(e) => setNumberText(e.target.value)}
                className={inputCls}
              />
              <span className="mt-1 block text-sm text-ink/55">
                Said first to call a hit: “{numberWords(Number(numberText) || 3)}, forty” = Player {Number(numberText) || 3} loses 40
                HP. 1 to 99, each player has their own. Once any number is 10 or more, single numbers are said with a zero first
                (“zero three”). Tell the player their new number.
              </span>
            </label>
            <ErrorBanner message={numberError} />
            <div className="grid grid-cols-2 gap-3">
              <Button type="button" variant="ghost" size="md" onClick={() => setEditingNumber(false)} disabled={savingNumber}>
                Cancel
              </Button>
              <Button type="submit" size="md" loading={savingNumber}>
                Save number
              </Button>
            </div>
          </form>
        )}
      </div>

      {/* Four clear parts instead of one long page */}
      <div className="grid grid-cols-4 gap-1 rounded-lg bg-pine-soft p-1" role="tablist">
        {(
          [
            ["health", "Health"],
            ["case", "Case"],
            ["money", "Money"],
            ["account", "Account"],
          ] as [Tab, string][]
        ).map(([k, label]) => (
          <button
            key={k}
            role="tab"
            aria-selected={tab === k}
            onClick={() => setTab(k)}
            className={`min-h-[3rem] rounded-md text-base font-bold transition-colors ${tab === k ? "bg-pine text-pine-ink shadow" : "text-pine"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "health" && (
        <HealthSection
          player={player}
          onChange={(next) => setPlayer((p) => (p ? { ...p, hp: next.hp, maxHp: next.maxHp, dead: next.dead } : p))}
        />
      )}

      {tab === "case" && (
        <>
          <CaseSection playerId={player.id} />
          <InventorySection playerId={player.id} />
        </>
      )}

      {tab === "money" && (
        <MoneySection
          playerId={player.id}
          balance={player.balance}
          onBalanceChange={(balance) => setPlayer((p) => (p ? { ...p, balance } : p))}
        />
      )}

      {tab === "account" && (
        <>
          <Section title="Profile">
            <form onSubmit={handleSaveEdit} className="flex flex-col gap-4">
              <ErrorBanner message={editError} />
              <Notice message={editNotice} />
              <TextField
                id="edit-username"
                label="Username"
                autoCapitalize="none"
                autoCorrect="off"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
              <TextField id="edit-display-name" label="Display name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
              <p className="text-sm text-ink/55">Account created {formatDate(player.createdAt)}</p>
              <Button type="submit" loading={savingEdit}>
                Save changes
              </Button>
            </form>
          </Section>

          <Section title="Reset password">
            <form onSubmit={handleResetPassword} className="flex flex-col gap-4">
              <ErrorBanner message={resetError} />
              <Notice message={resetDone ? "Password updated. Tell the player their new password." : null} />
              <PasswordField
                id="reset-password"
                label="New password"
                hint="At least 8 characters, with a letter and a number."
                autoComplete="new-password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
              <PasswordField
                id="reset-confirm-password"
                label="Confirm new password"
                autoComplete="new-password"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                required
              />
              <Button type="submit" variant="ghost" loading={savingReset}>
                Set new password
              </Button>
            </form>
          </Section>

          <Section title="Account status" tone={active ? "pine" : "alert"}>
            <ErrorBanner message={statusError} />
            <p className="text-ink/75">
              {active ? "This player can log in and play." : "This player is disabled and can't log in."}
            </p>
            {confirmingStatus ? (
              <ConfirmCard
                title={`${active ? "Disable" : "Enable"} ${name}?`}
                body={active ? `${name} will be logged out and won't be able to log in.` : `${name} will be able to log in again.`}
                confirmLabel={active ? "Disable" : "Enable"}
                tone={active ? "danger" : "primary"}
                onConfirm={handleToggleStatus}
                onCancel={() => setConfirmingStatus(false)}
                loading={savingStatus}
              />
            ) : (
              <Button variant={active ? "dangerGhost" : "primary"} onClick={() => setConfirmingStatus(true)}>
                {active ? "Disable player" : "Enable player"}
              </Button>
            )}
          </Section>
        </>
      )}
    </>
  );
}

// "three", "zero three" or "twelve" — how a player number is said, using the
// same digit-by-digit style players use for calls.
const DIGIT_WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];
function numberWords(n: number): string {
  const clean = Math.max(1, Math.min(99, Math.round(n)));
  return String(clean)
    .split("")
    .map((d) => DIGIT_WORDS[Number(d)])
    .join(" ");
}
