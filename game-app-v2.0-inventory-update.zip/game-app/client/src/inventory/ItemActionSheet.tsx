import { CSSProperties, ReactNode, useEffect, useRef, useState } from "react";
import { Icon } from "../components/Icon";
import { Stepper } from "../components/Stepper";
import { KIND_LABEL, type GameStatus, type TrackView } from "../services/api";
import type { HpState, Piece } from "./caseApi";
import { HERB_COLOR, healText } from "./herbs";
import { PieceArt } from "./PieceView";
import { Sheet, SheetButton } from "./Sheet";

// The menu for one piece: its picture, what it is, its numbers, and the
// buttons that make sense for it (Fire / Use / Reload / Combine / Split /
// Rotate / Drop). Opens when a piece is tapped or held.

export type ItemPanel = "main" | "split" | "drop";

export interface ItemSheetContext {
  status: GameStatus;
  dead: boolean;
  practiceFire: boolean;
  hp: HpState | null;
  everything: Piece[]; // all pieces (case + tray), to name the gun an ammo fits etc.
}

const isWeapon = (p: Piece) => p.kind === "gun" || p.kind === "knife";
const canTurn = (p: Piece) => p.w !== p.h;
const viewable = (p: Piece) => p.kind === "gun" || p.kind === "knife" || !!p.modelUrl || !!p.soundUrl || p.useEffect !== "none";

// Why an action can't happen right now (null = it can).
function blocked(ctx: ItemSheetContext, what: "use" | "drop" | "mix" | "reload" | "fire"): string | null {
  if (ctx.dead) return "You're down — wait for the Admin to revive you.";
  const { status } = ctx;
  if (what === "use" && status !== "active") {
    return status === "not_started" ? "Healing works once the game starts." : status === "paused" ? "Healing is off while the game is paused." : "The game is over.";
  }
  if (what === "drop" || what === "mix" || what === "reload") {
    if (status === "paused") return "Not while the game is paused. You can still arrange your case.";
    if (status === "ended") return "The game is over. You can still arrange your case.";
  }
  if (what === "reload" && status === "not_started" && !ctx.practiceFire) return "Reloading works once the game starts.";
  return null;
}

// What using a heal would do to your HP, e.g. 85 → 100.
export function healPreview(p: Piece, hp: HpState | null): { hp: [number, number]; max: [number, number] } | null {
  if (!hp) return null;
  const bonus = p.maxHpBonus ?? 0;
  const max = hp.maxHp + bonus;
  const after = p.fullHeal ? max : Math.min(max, hp.hp + (p.healAmount ?? 0) + bonus);
  return { hp: [hp.hp, after], max: [hp.maxHp, max] };
}

// Upgrade names and numbers as the spec describes them (§4). Kept here so
// the case reads well whatever the shop screens show.
const TRACK_NAME: Record<string, string> = {
  magazine: "Magazine",
  damage: "Damage",
  reload: "Reload speed",
  firerate: "Fire rate",
  sharpness: "Sharpness",
  length: "Length",
};
function trackLabel(t: TrackView): string {
  return TRACK_NAME[t.track] ?? t.track.charAt(0).toUpperCase() + t.track.slice(1);
}
function trackValue(t: TrackView): string | null {
  const v = t.value;
  if (v === null || v === undefined) return null;
  switch (t.track as string) {
    case "magazine":
      return `${v} rounds`;
    case "damage":
      return `${Math.round(v)}%`;
    case "reload":
      return v > 50 ? `${(v / 1000).toFixed(1)} s` : `${v} s`; // sent in ms
    case "firerate":
      return `shake ${Number(v).toFixed(1)}`; // how hard to shake to fire: lower = faster
    case "length":
      return `${v} cm`;
    default:
      return String(v);
  }
}

export function ItemActionSheet({
  open,
  piece: pieceNow,
  panel: startPanel,
  slot,
  ctx,
  busy,
  reload,
  onClose,
  onOpenWeapon,
  onReload,
  onUse,
  onCombine,
  onSplit,
  onRotate,
  onDrop,
}: {
  open: boolean;
  piece: Piece | null;
  panel: ItemPanel;
  slot?: number;
  ctx: ItemSheetContext;
  busy: string | null; // the action that's running ("use", "drop"…)
  reload: { id: number; ms: number; n: number } | null;
  onClose: () => void;
  onOpenWeapon: (p: Piece) => void;
  onReload: (p: Piece) => void;
  onUse: (p: Piece) => void;
  onCombine: (p: Piece) => void;
  onSplit: (p: Piece, quantity: number) => void;
  onRotate: (p: Piece) => void;
  onDrop: (p: Piece, quantity: number) => void;
}) {
  // Keep showing the last piece while the sheet slides away.
  const last = useRef<Piece | null>(pieceNow);
  if (pieceNow) last.current = pieceNow;
  const piece = pieceNow ?? last.current;

  const [panel, setPanel] = useState<ItemPanel>(startPanel);
  const [count, setCount] = useState(1);
  const [info, setInfo] = useState(false);

  // Every time the sheet opens (or opens on another piece), start fresh.
  const id = piece?.id;
  useEffect(() => {
    if (!open || !piece) return;
    setPanel(startPanel);
    setInfo(false);
    setCount(startPanel === "split" ? Math.max(1, Math.floor(piece.quantity / 2)) : piece.quantity);
  }, [open, id, startPanel]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!piece) return null;
  const p = piece;

  function goSplit() {
    setCount(Math.max(1, Math.floor(p.quantity / 2)));
    setPanel("split");
  }
  function goDrop() {
    setCount(p.quantity);
    if (p.quantity > 1 || isWeapon(p)) setPanel("drop");
    else onDrop(p, p.quantity);
  }

  const back = () => (startPanel === "main" ? setPanel("main") : onClose());

  let body: ReactNode;
  let footer: ReactNode;

  if (panel === "split") {
    const max = Math.max(1, p.quantity - 1);
    body = (
      <div className="flex flex-col gap-4">
        <SheetHeader p={p} slot={slot} />
        <p className="text-lg text-ink/85">
          Take some out into a new pile. It goes in the first free space.
        </p>
        <div className="flex items-center justify-between gap-3 rounded-sm border border-white/10 bg-black/30 px-3 py-3">
          <span className="font-semibold text-ink/70">How many</span>
          <Stepper value={Math.min(count, max)} onChange={setCount} min={1} max={max} label="How many to take out" />
        </div>
        <p className="text-center text-sm text-ink/60 tabular-nums">
          {p.quantity - Math.min(count, max)} stay · {Math.min(count, max)} in the new pile
        </p>
      </div>
    );
    footer = (
      <div className="grid grid-cols-2 gap-2">
        <SheetButton onClick={back} sound>
          Back
        </SheetButton>
        <SheetButton tone="primary" icon={<Icon name="split" className="h-5 w-5" />} busy={busy === "split"} disabled={ctx.dead || p.quantity < 2} onClick={() => onSplit(p, Math.min(count, max))}>
          Split
        </SheetButton>
      </div>
    );
  } else if (panel === "drop") {
    const why = blocked(ctx, "drop");
    body = (
      <div className="flex flex-col gap-4">
        <SheetHeader p={p} slot={slot} />
        <div className="rounded-sm border-l-4 border-sun bg-sun/10 px-3 py-3">
          <p className="font-display text-xl font-bold">Drop {p.name}?</p>
          <p className="text-ink/80">
            It goes into the drop box, where anyone can pick it up.
            {p.kind === "gun" && " Its upgrades and loaded rounds go with it."}
            {p.kind === "knife" && " Its upgrades go with it."}
          </p>
        </div>
        {p.quantity > 1 && (
          <div className="flex items-center justify-between gap-3 rounded-sm border border-white/10 bg-black/30 px-3 py-3">
            <span className="font-semibold text-ink/70">{p.kind === "ammo" ? "Rounds" : "How many"}</span>
            <Stepper value={Math.min(count, p.quantity)} onChange={setCount} min={1} max={p.quantity} label="How many to drop" />
          </div>
        )}
        {why && <Reason text={why} />}
      </div>
    );
    footer = (
      <div className="grid grid-cols-2 gap-2">
        <SheetButton onClick={back} sound>
          {startPanel === "drop" ? "Keep it" : "Back"}
        </SheetButton>
        <SheetButton tone="danger" icon={<Icon name="drop" className="h-5 w-5" />} busy={busy === "drop"} disabled={!!why} onClick={() => onDrop(p, Math.min(count, p.quantity))}>
          Drop{p.quantity > 1 ? ` ${Math.min(count, p.quantity)}` : ""}
        </SheetButton>
      </div>
    );
  } else {
    // ---- main panel ----
    const preview = p.usable ? healPreview(p, ctx.hp) : null;
    const fullAlready = !!preview && preview.hp[0] >= preview.hp[1] && preview.max[0] === preview.max[1];
    const useWhy = !p.usable
      ? p.herbCode === "R" || p.herbCode === "Y"
        ? "Mix it with a Green Herb first."
        : null
      : blocked(ctx, "use") ?? (fullAlready ? "You're already at full health." : null);
    const reloadWhy = blocked(ctx, "reload");
    const mixWhy = blocked(ctx, "mix");
    const canReload = p.kind === "gun" && p.reserve > 0 && p.magazine !== null && p.loaded < p.magazine;
    const reloadingNow = reload?.id === p.id;

    let primary: ReactNode = null;
    if (p.kind === "gun" || p.kind === "knife") {
      primary = (
        <SheetButton big tone="primary" icon={<Icon name="target" className="h-6 w-6" />} disabled={ctx.dead} onClick={() => onOpenWeapon(p)}>
          {p.kind === "gun" ? "Fire" : "Swing"}
        </SheetButton>
      );
    } else if (p.usable) {
      primary = (
        <SheetButton big tone="good" icon={<Icon name="heart" className="h-6 w-6" />} busy={busy === "use"} disabled={!!useWhy} onClick={() => onUse(p)}>
          Use{preview && !useWhy ? ` · ${preview.hp[0]} → ${preview.hp[1]} HP` : ""}
        </SheetButton>
      );
    } else if (p.herbCode) {
      primary = (
        <SheetButton big tone="primary" icon={<Icon name="combine" className="h-6 w-6" />} disabled={!!mixWhy} onClick={() => onCombine(p)}>
          Combine
        </SheetButton>
      );
    } else if (viewable(p)) {
      primary = (
        <SheetButton big tone="primary" icon={<Icon name="cube" className="h-6 w-6" />} disabled={ctx.dead} onClick={() => onOpenWeapon(p)}>
          View in 3D
        </SheetButton>
      );
    }

    const tiles: ReactNode[] = [];
    if (p.kind === "gun" && (canReload || reloadingNow)) {
      tiles.push(
        <SheetButton key="reload" icon={<Icon name="reload" className="h-5 w-5" />} busy={busy === "reload"} disabled={!!reloadWhy || reloadingNow} onClick={() => onReload(p)}>
          {reloadingNow ? "Reloading…" : "Reload"}
        </SheetButton>
      );
    }
    // "View in 3D" as a tile whenever the big button is something else (Use, Combine).
    const primaryIsView = p.kind !== "gun" && p.kind !== "knife" && !p.usable && !p.herbCode;
    if (p.kind !== "gun" && p.kind !== "knife" && viewable(p) && !primaryIsView) {
      tiles.push(
        <SheetButton key="view" icon={<Icon name="cube" className="h-5 w-5" />} disabled={ctx.dead} onClick={() => onOpenWeapon(p)}>
          View in 3D
        </SheetButton>
      );
    }
    if (p.herbCode && p.usable) {
      tiles.push(
        <SheetButton key="mix" icon={<Icon name="combine" className="h-5 w-5" />} disabled={!!mixWhy} onClick={() => onCombine(p)}>
          Combine
        </SheetButton>
      );
    }
    if (p.quantity > 1) {
      tiles.push(
        <SheetButton key="split" icon={<Icon name="split" className="h-5 w-5" />} disabled={ctx.dead} onClick={goSplit}>
          Split
        </SheetButton>
      );
    }
    if (canTurn(p) && p.x !== null) {
      tiles.push(
        <SheetButton key="rotate" icon={<Icon name="rotate" className="h-5 w-5" />} busy={busy === "rotate"} disabled={ctx.dead} onClick={() => onRotate(p)}>
          Rotate
        </SheetButton>
      );
    }
    tiles.push(
      <SheetButton key="drop" tone="danger" icon={<Icon name="drop" className="h-5 w-5" />} busy={busy === "drop"} disabled={!!blocked(ctx, "drop")} onClick={goDrop}>
        Drop
      </SheetButton>
    );

    body = (
      <div className="flex flex-col gap-4">
        <SheetHeader p={p} slot={slot} onInfo={() => setInfo((v) => !v)} infoOpen={info} />
        {info && <Tips p={p} />}
        {p.description && <p className="text-base leading-snug text-ink/80">{p.description}</p>}
        <Stats p={p} ctx={ctx} preview={preview} />
        {reloadingNow && reload && (
          <div className="cs-reload" aria-label="Reloading">
            <span key={reload.n} style={{ "--ms": `${reload.ms}ms` } as CSSProperties} />
          </div>
        )}
        {p.x === null && (
          <Reason text="This doesn't fit in your case right now. Make room, then drag it in." tone="sun" />
        )}
        {useWhy && (p.usable || p.herbCode) && <Reason text={useWhy} />}
        {!useWhy && mixWhy && p.herbCode && <Reason text={mixWhy} />}
        {p.kind === "gun" && reloadWhy && canReload && <Reason text={reloadWhy} />}
        {primary}
        <div className="grid grid-cols-2 gap-2 min-[400px]:grid-cols-3">{tiles}</div>
        {p.upgrades.length > 0 && <Upgrades list={p.upgrades} />}
      </div>
    );
    footer = (
      <SheetButton onClick={onClose} icon={<Icon name="close" className="h-5 w-5" />}>
        Close
      </SheetButton>
    );
  }

  return (
    <Sheet open={open} onClose={onClose} label={p.name} footer={footer}>
      {body}
    </Sheet>
  );
}

function SheetHeader({ p, slot, onInfo, infoOpen }: { p: Piece; slot?: number; onInfo?: () => void; infoOpen?: boolean }) {
  // Picture in the item's own shape, as big as the sheet allows. Long items
  // (shotgun, knife) get a row of their own above the name.
  const long = p.w >= 2 * p.h;
  const cell = long
    ? Math.max(20, Math.min(64, Math.floor(296 / p.w), Math.floor(104 / p.h)))
    : Math.max(24, Math.min(72, Math.floor(168 / p.w), Math.floor(112 / p.h)));
  const pic = (
    <div className={`cs-sheet-pic shrink-0 ${long ? "mx-auto" : ""}`} style={{ width: p.w * cell, height: p.h * cell }}>
      <PieceArt piece={p} cell={cell} rotated={false} numbers={false} />
    </div>
  );
  return (
    <div className="flex flex-col gap-3">
      {long && pic}
      <div className="flex items-start gap-3">
        {!long && pic}
        <div className="min-w-0 flex-1 pt-0.5">
          <p className="truncate text-xs font-bold uppercase tracking-[0.2em] text-white/45">
            {KIND_LABEL[p.kind] ?? "Item"}
            {p.category && p.category.toLowerCase() !== (KIND_LABEL[p.kind] ?? "").toLowerCase() ? ` · ${p.category}` : ""}
          </p>
          <h2 className="flex items-center gap-2 break-words font-display text-2xl font-bold leading-tight text-white">
            {slot ? (
              <span className="cs-slot !static shrink-0 text-sm" aria-label={`Slot ${slot}`}>
                {slot}
              </span>
            ) : null}
            <span className="min-w-0">{p.name}</span>
          </h2>
          {p.herbCode && (
            <span className="mt-1 flex gap-1" aria-label={`Herb mix ${p.herbCode.split("").join(" + ")}`}>
              {p.herbCode.split("").map((l, i) => (
                <span key={i} className="h-3 w-3 rounded-full border border-black/40" style={{ background: HERB_COLOR[l] }} />
              ))}
            </span>
          )}
        </div>
        {onInfo && (
          <button
            type="button"
            onClick={onInfo}
            aria-pressed={infoOpen}
            aria-label="How to use this"
            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full border ${
              infoOpen ? "border-pine bg-pine-soft text-pine" : "border-white/15 text-white/70"
            }`}
          >
            <Icon name="info" className="h-5 w-5" />
          </button>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: ReactNode; tone?: "good" | "bad" | "warn" }) {
  const color = tone === "good" ? "text-[#8BE36B]" : tone === "bad" ? "text-alert" : tone === "warn" ? "text-sun" : "text-white";
  return (
    <div className="cs-stat">
      <span className="text-xs font-bold uppercase tracking-[0.14em] text-white/45">{label}</span>
      <span className={`font-display text-xl font-bold leading-tight tabular-nums ${color}`}>{value}</span>
    </div>
  );
}

function Stats({ p, ctx, preview }: { p: Piece; ctx: ItemSheetContext; preview: ReturnType<typeof healPreview> }) {
  const out: ReactNode[] = [];
  if (p.kind === "gun") {
    const mag = p.magazine ?? 0;
    out.push(
      <Stat
        key="loaded"
        label="Loaded"
        tone={p.loaded === 0 ? "bad" : p.loaded >= mag && mag > 0 ? "good" : undefined}
        value={
          <>
            {p.loaded}
            <span className="text-base text-white/45"> / {mag || "?"}</span>
          </>
        }
      />
    );
    out.push(<Stat key="reserve" label="Spare rounds" value={p.reserve} tone={p.reserve === 0 ? "warn" : undefined} />);
    if (p.gun) {
      out.push(<Stat key="reload" label="Reload time" value={`${(p.gun.reloadMs / 1000).toFixed(1)} s`} />);
      out.push(<Stat key="dmg" label="Damage" value={`${Math.round(p.gun.damagePct)}%`} />);
    }
  } else if (p.kind === "ammo") {
    const gun = ctx.everything.find((g) => g.kind === "gun" && g.ammoItemId === p.itemId);
    out.push(
      <Stat
        key="rounds"
        label="Rounds"
        tone={p.quantity >= p.stackSize ? "good" : undefined}
        value={
          <>
            {p.quantity}
            <span className="text-base text-white/45"> / {p.stackSize}</span>
          </>
        }
      />
    );
    if (gun) out.push(<Stat key="fits" label="Fits" value={<span className="text-lg">{gun.name}</span>} />);
  } else {
    if (p.quantity > 1 || p.stackSize > 1) out.push(<Stat key="qty" label="How many" value={`×${p.quantity}`} />);
    if (p.usable || p.healAmount || p.maxHpBonus || p.fullHeal) {
      out.push(<Stat key="effect" label="Effect" tone="good" value={<span className="text-lg">{healText(p)}</span>} />);
    }
    if (preview) {
      out.push(
        <Stat
          key="after"
          label="Your HP after"
          tone="good"
          value={
            <>
              {preview.hp[0]} → {preview.hp[1]}
              {preview.max[1] !== preview.max[0] && <span className="block text-sm text-white/60">Max {preview.max[0]} → {preview.max[1]}</span>}
            </>
          }
        />
      );
    }
  }
  if (out.length === 0) return null;
  return <div className="grid grid-cols-2 gap-2">{out}</div>;
}

function Upgrades({ list }: { list: TrackView[] }) {
  return (
    <div className="flex flex-col gap-1">
      <p className="text-xs font-bold uppercase tracking-[0.14em] text-white/45">Upgrades</p>
      <ul className="divide-y divide-white/5 rounded-sm border border-white/10 bg-black/25">
        {list.map((t) => {
          const stat = trackValue(t);
          return (
            <li key={t.track} className="flex items-center gap-3 px-3 py-2">
              <span className="min-w-0 flex-1 truncate font-semibold text-white/85">{trackLabel(t)}</span>
              <span className="flex shrink-0 gap-0.5" aria-label={`Level ${t.level} of ${t.maxLevel}`}>
                {Array.from({ length: t.maxLevel }, (_, i) => (
                  <span key={i} className={`h-2.5 w-3 ${i < t.level ? "bg-pine" : "bg-white/15"}`} style={{ clipPath: "polygon(2px 0,100% 0,calc(100% - 2px) 100%,0 100%)" }} />
                ))}
              </span>
              <span className="w-[6.5rem] shrink-0 text-right text-sm tabular-nums text-white/60">
                Lv {t.level}
                {stat ? ` · ${stat}` : ""}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Tips({ p }: { p: Piece }) {
  const tips: string[] = [];
  if (p.kind === "gun") {
    tips.push("Fire opens the weapon screen: tap the screen or shake the phone to shoot.");
    tips.push("Swipe down on the weapon screen to reload. Reloading here also moves ammo out of your case and frees space.");
  } else if (p.kind === "knife") tips.push("Swing opens the weapon screen: tap or shake to swing.");
  else if (p.kind === "ammo") tips.push("Load it into its gun (Reload) to free case space. Drop a pile on another pile of the same ammo to join them.");
  if (p.herbCode) tips.push("Every mix needs a Green Herb. G+G heals more, G+R raises max HP, G+Y heals 1.5×, G+R+Y does both, G+G+Y restores everything.");
  else if (p.kind === "healing") tips.push("Use it while the game is on to get HP back.");
  tips.push("Drag pieces to arrange your case. Turn them with Rotate, or tap with a second finger while dragging.");
  return (
    <ul className="flex list-disc flex-col gap-1 rounded-sm border border-pine/30 bg-pine-soft py-2 pl-7 pr-3 text-sm text-ink/90">
      {tips.map((t) => (
        <li key={t}>{t}</li>
      ))}
    </ul>
  );
}

export function Reason({ text, tone = "alert" }: { text: string; tone?: "alert" | "sun" }) {
  return (
    <p className={`rounded-sm border-l-4 px-3 py-2 text-sm font-semibold ${tone === "sun" ? "border-sun bg-sun/10 text-ink" : "border-alert bg-alert/10 text-ink"}`}>
      {text}
    </p>
  );
}
