export function ErrorBanner({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="alert" className="rounded-xl border-2 border-alert bg-white px-4 py-3 text-alert">
      {message}
    </p>
  );
}
