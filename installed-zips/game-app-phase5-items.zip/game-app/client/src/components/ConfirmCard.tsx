import { Button } from "./Button";

export function ConfirmCard({
  title,
  body,
  confirmLabel,
  onConfirm,
  onCancel,
  loading,
}: {
  title: string;
  body: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
}) {
  return (
    <div className="flex flex-col gap-3 rounded-2xl border-2 border-alert bg-white p-5">
      <p className="text-xl font-bold text-ink">{title}</p>
      <p className="text-ink/70">{body}</p>
      <div className="flex gap-3">
        <Button variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button
          onClick={onConfirm}
          loading={loading}
          className="!bg-alert"
        >
          {confirmLabel}
        </Button>
      </div>
    </div>
  );
}
