import express, { NextFunction, Request, Response } from "express";
import fs from "fs";
import path from "path";
import { CLIENT_DIST, HOST, ITEM_IMAGE_DIR, PORT } from "./config";
import { openDatabase } from "./database/db";
import { getLanAddresses } from "./network";
import { attachUser } from "./auth/middleware";
import { createAuthRouter } from "./routes/auth";
import { createMeRouter } from "./routes/me";
import { createPlayersRouter } from "./routes/players";
import { createItemsRouter, IMAGE_UPLOAD_PATH } from "./routes/items";

const db = openDatabase();
const app = express();
// attachUser only reads the cookie, so it can run before any body parsing.
// The default 100 KB JSON parser runs for every route except the item
// picture upload, which parses its own (larger) body after checking the
// caller is the Admin — see routes/items.ts.
app.use(attachUser(db));
const defaultJson = express.json();
app.use((req, res, next) =>
  IMAGE_UPLOAD_PATH.test(req.path) ? next() : defaultJson(req, res, next)
);

app.get("/api/health", (_req, res) => {
  try {
    db.prepare("SELECT 1").get();
    res.json({ status: "ok", database: "ok", time: new Date().toISOString() });
  } catch {
    res.status(500).json({ status: "error", database: "error" });
  }
});

app.use("/api/auth", createAuthRouter(db));
app.use("/api/me", createMeRouter(db));
app.use("/api/admin/players", createPlayersRouter(db));
app.use("/api/admin/items", createItemsRouter(db));

// Item pictures uploaded by the Admin. fallthrough:false means a missing
// file is a plain 404, not the app's index.html.
fs.mkdirSync(ITEM_IMAGE_DIR, { recursive: true });
app.use(
  "/media/items",
  express.static(ITEM_IMAGE_DIR, {
    fallthrough: false,
    setHeaders: (res) => res.setHeader("X-Content-Type-Options", "nosniff"),
  })
);

// Serve the built React app (run `npm run build` first).
if (fs.existsSync(CLIENT_DIST)) {
  app.use(express.static(CLIENT_DIST));
  app.get(/^(?!\/api).*/, (_req, res) =>
    res.sendFile(path.join(CLIENT_DIST, "index.html"))
  );
} else {
  app.get("/", (_req, res) =>
    res.status(503).send("Client not built yet. Run: npm run build")
  );
}

// Turns body-parser/static errors (bad JSON, body too big, missing file)
// into the same friendly { error } shape every other endpoint uses.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = typeof err?.status === "number" ? err.status : 500;
  const message =
    err?.type === "entity.too.large"
      ? "That upload is too large."
      : err?.type === "entity.parse.failed"
      ? "Invalid request."
      : status === 404 || status === 403
      ? "Not found."
      : "Something went wrong. Please try again.";
  res.status(status).json({ error: message });
});

app.listen(PORT, HOST, () => {
  console.log("\nServer running\n");
  console.log(`Local:\n  http://localhost:${PORT}\n`);
  const lan = getLanAddresses();
  console.log("LAN (give this to players):");
  if (lan.length === 0) console.log("  No network found. Connect to Wi-Fi first.");
  for (const ip of lan) console.log(`  http://${ip}:${PORT}`);
  console.log("");
});
