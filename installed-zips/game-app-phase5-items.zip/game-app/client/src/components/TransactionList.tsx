import { Transaction } from "../services/api";
import { formatDateTime } from "../utils/format";

export function TransactionList({ transactions }: { transactions: Transaction[] }) {
  if (transactions.length === 0) {
    return <p className="text-ink/60">No transactions yet.</p>;
  }
  return (
    <ul className="flex flex-col gap-2">
      {transactions.map((t) => (
        <li
          key={t.id}
          className="flex items-center justify-between rounded-xl border-2 border-ink/10 bg-white px-4 py-3"
        >
          <span className="text-sm text-ink/60">{formatDateTime(t.createdAt)}</span>
          <span className={`text-lg font-bold ${t.type === "ADD" ? "text-pine" : "text-alert"}`}>
            {t.type === "ADD" ? "+" : "-"}
            {t.amount}
          </span>
        </li>
      ))}
    </ul>
  );
}
