import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { hashPassword, isPasswordStrongEnough, isUsernameValid } from "../auth/passwords";
import { requireRole } from "../auth/middleware";
import { revokeSessionsForUser } from "../auth/sessions";
import {
  adjustBalance,
  InsufficientFundsError,
  listTransactionsForPlayer,
  MAX_TRANSACTION_AMOUNT,
  toPublicTransaction,
} from "../database/money";
import {
  changeInventory,
  InventoryRuleError,
  ItemNotFoundError,
  listInventoryForPlayer,
  listInventoryLog,
  MAX_ITEM_QUANTITY,
} from "../database/inventory";
import {
  createUser,
  findById,
  findByUsername,
  listByRole,
  setPasswordHash,
  toPublicUser,
  updateUser,
} from "../database/users";

// Every route here is Admin-only. requireRole('admin') runs on the server
// for each request — a Player (or anyone unauthenticated) sending these
// requests directly is rejected before the handler ever runs.
export function createPlayersRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  function getPlayerOr404(id: number) {
    const user = findById(db, id);
    if (!user || user.role !== "player") return null;
    return user;
  }

  router.get("/", (_req, res) => {
    const players = listByRole(db, "player").map(toPublicUser);
    res.json({ players });
  });

  router.post("/", (req, res) => {
    const { username, password, confirmPassword, displayName } = req.body ?? {};
    if (typeof username !== "string" || typeof password !== "string") {
      res.status(400).json({ error: "Username and password are required." });
      return;
    }
    if (!isUsernameValid(username)) {
      res.status(400).json({
        error: "Username must be 3-32 characters: letters, numbers, dots, - or _.",
      });
      return;
    }
    if (password !== confirmPassword) {
      res.status(400).json({ error: "Passwords do not match." });
      return;
    }
    if (!isPasswordStrongEnough(password)) {
      res.status(400).json({
        error: "Password must be at least 8 characters and include a letter and a number.",
      });
      return;
    }
    if (displayName !== undefined && displayName !== null && typeof displayName !== "string") {
      res.status(400).json({ error: "Invalid display name." });
      return;
    }
    if (findByUsername(db, username)) {
      res.status(409).json({ error: "That username is already taken." });
      return;
    }

    const player = createUser(db, {
      role: "player",
      username,
      displayName: displayName || null,
      passwordHash: hashPassword(password),
    });
    res.status(201).json({ player: toPublicUser(player) });
  });

  router.get("/:id", (req, res) => {
    const player = getPlayerOr404(Number(req.params.id));
    if (!player) {
      res.status(404).json({ error: "Player not found." });
      return;
    }
    res.json({ player: toPublicUser(player) });
  });

  router.patch("/:id", (req, res) => {
    const id = Number(req.params.id);
    const player = getPlayerOr404(id);
    if (!player) {
      res.status(404).json({ error: "Player not found." });
      return;
    }

    const { username, displayName, status } = req.body ?? {};
    const updates: { username?: string; displayName?: string | null; status?: "active" | "disabled" } = {};

    if (username !== undefined) {
      if (typeof username !== "string" || !isUsernameValid(username)) {
        res.status(400).json({
          error: "Username must be 3-32 characters: letters, numbers, dots, - or _.",
        });
        return;
      }
      const existing = findByUsername(db, username);
      if (existing && existing.id !== id) {
        res.status(409).json({ error: "That username is already taken." });
        return;
      }
      updates.username = username;
    }

    if (displayName !== undefined) {
      if (displayName !== null && typeof displayName !== "string") {
        res.status(400).json({ error: "Invalid display name." });
        return;
      }
      updates.displayName = displayName;
    }

    if (status !== undefined) {
      if (status !== "active" && status !== "disabled") {
        res.status(400).json({ error: "Invalid status." });
        return;
      }
      updates.status = status;
    }

    const updated = updateUser(db, id, updates);
    if (updates.status === "disabled") revokeSessionsForUser(id);
    res.json({ player: toPublicUser(updated) });
  });

  router.post("/:id/reset-password", (req, res) => {
    const id = Number(req.params.id);
    const player = getPlayerOr404(id);
    if (!player) {
      res.status(404).json({ error: "Player not found." });
      return;
    }

    const { password, confirmPassword } = req.body ?? {};
    if (typeof password !== "string") {
      res.status(400).json({ error: "Password is required." });
      return;
    }
    if (password !== confirmPassword) {
      res.status(400).json({ error: "Passwords do not match." });
      return;
    }
    if (!isPasswordStrongEnough(password)) {
      res.status(400).json({
        error: "Password must be at least 8 characters and include a letter and a number.",
      });
      return;
    }

    setPasswordHash(db, id, hashPassword(password));
    revokeSessionsForUser(id);
    res.status(204).end();
  });

  router.post("/:id/money", (req, res) => {
    const id = Number(req.params.id);
    const player = getPlayerOr404(id);
    if (!player) {
      res.status(404).json({ error: "Player not found." });
      return;
    }

    const { type, amount } = req.body ?? {};
    if (type !== "ADD" && type !== "REMOVE") {
      res.status(400).json({ error: "Type must be ADD or REMOVE." });
      return;
    }
    if (
      typeof amount !== "number" ||
      !Number.isInteger(amount) ||
      amount <= 0 ||
      amount > MAX_TRANSACTION_AMOUNT
    ) {
      res.status(400).json({
        error: `Amount must be a whole number between 1 and ${MAX_TRANSACTION_AMOUNT}.`,
      });
      return;
    }

    try {
      const { balance, transaction } = adjustBalance(db, {
        playerId: id,
        type,
        amount,
        performedBy: req.user!.id,
      });
      res.json({ balance, transaction: toPublicTransaction(transaction) });
    } catch (err) {
      if (err instanceof InsufficientFundsError) {
        res.status(400).json({ error: err.message });
        return;
      }
      res.status(500).json({ error: "Could not complete the transaction. Please try again." });
    }
  });

  router.get("/:id/transactions", (req, res) => {
    const id = Number(req.params.id);
    const player = getPlayerOr404(id);
    if (!player) {
      res.status(404).json({ error: "Player not found." });
      return;
    }
    const transactions = listTransactionsForPlayer(db, id).map(toPublicTransaction);
    res.json({ transactions });
  });

  router.get("/:id/inventory", (req, res) => {
    const id = Number(req.params.id);
    if (!getPlayerOr404(id)) {
      res.status(404).json({ error: "Player not found." });
      return;
    }
    res.json({
      inventory: listInventoryForPlayer(db, id),
      log: listInventoryLog(db, id),
    });
  });

  // Body: { itemId, action: "GIVE" | "REMOVE" | "SET", quantity }
  // GIVE/REMOVE change the count by `quantity`; SET makes it exactly
  // `quantity` (0 removes the item from the player entirely).
  router.post("/:id/inventory", (req, res) => {
    const id = Number(req.params.id);
    if (!getPlayerOr404(id)) {
      res.status(404).json({ error: "Player not found." });
      return;
    }

    const { itemId, action, quantity } = req.body ?? {};
    if (typeof itemId !== "number" || !Number.isInteger(itemId) || itemId <= 0) {
      res.status(400).json({ error: "Choose an item." });
      return;
    }
    if (action !== "GIVE" && action !== "REMOVE" && action !== "SET") {
      // PURCHASE is deliberately not accepted here: only the shop writes it.
      res.status(400).json({ error: "Action must be GIVE, REMOVE or SET." });
      return;
    }
    const min = action === "SET" ? 0 : 1;
    if (
      typeof quantity !== "number" ||
      !Number.isInteger(quantity) ||
      quantity < min ||
      quantity > MAX_ITEM_QUANTITY
    ) {
      res.status(400).json({
        error: `Quantity must be a whole number between ${min} and ${MAX_ITEM_QUANTITY}.`,
      });
      return;
    }

    try {
      changeInventory(db, { playerId: id, itemId, action, quantity, performedBy: req.user!.id });
      res.json({
        inventory: listInventoryForPlayer(db, id),
        log: listInventoryLog(db, id),
      });
    } catch (err) {
      if (err instanceof ItemNotFoundError) {
        res.status(404).json({ error: err.message });
        return;
      }
      if (err instanceof InventoryRuleError) {
        res.status(400).json({ error: err.message });
        return;
      }
      res.status(500).json({ error: "Could not update the inventory. Please try again." });
    }
  });

  return router;
}
