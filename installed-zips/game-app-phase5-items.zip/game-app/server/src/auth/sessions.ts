import { randomBytes } from "crypto";
import type { Request, Response } from "express";
import type { PublicUser } from "../database/users";

const COOKIE_NAME = "session";
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

interface SessionRecord {
  user: PublicUser;
  expiresAt: number;
}

// In-memory: simplest option for a single-process LAN server. Sessions are
// cleared if the server restarts, so everyone just logs in again — no
// account data is lost.
const sessions = new Map<string, SessionRecord>();

function serializeCookie(name: string, value: string, maxAgeSeconds: number): string {
  // No "Secure" flag: this app is served over plain http on the LAN, and
  // Secure would make browsers refuse to send the cookie at all.
  // SameSite=Lax stops the cookie being sent on cross-site requests, which
  // covers the app's CSRF risk since every state-changing call here is a
  // same-origin fetch, not a cross-site form post.
  return `${name}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSeconds}`;
}

function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(";")) {
    const eq = part.indexOf("=");
    if (eq === -1) continue;
    const name = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    if (name) out[name] = decodeURIComponent(value);
  }
  return out;
}

export function createSession(res: Response, user: PublicUser): string {
  const token = randomBytes(32).toString("hex");
  sessions.set(token, { user, expiresAt: Date.now() + SESSION_TTL_MS });
  res.setHeader("Set-Cookie", serializeCookie(COOKIE_NAME, token, SESSION_TTL_MS / 1000));
  return token;
}

// Only used server-side (e.g. to compare against the account's
// active_session_token) — never sent back to a client in a response body.
export function getToken(req: Request): string | null {
  return parseCookies(req.headers.cookie)[COOKIE_NAME] ?? null;
}

export function destroySession(req: Request, res: Response): void {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (token) sessions.delete(token);
  res.setHeader("Set-Cookie", serializeCookie(COOKIE_NAME, "", 0));
}

export function getSessionUser(req: Request): PublicUser | null {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (!token) return null;
  const record = sessions.get(token);
  if (!record) return null;
  if (record.expiresAt < Date.now()) {
    sessions.delete(token);
    return null;
  }
  return record.user;
}

// Used when the Admin disables a player or resets their password: any
// session already issued to that account stops working immediately, rather
// than waiting for it to expire on its own.
export function revokeSessionsForUser(userId: number): void {
  for (const [token, record] of sessions) {
    if (record.user.id === userId) sessions.delete(token);
  }
}
