// Makes the 3D models of the five mixed herbs, entirely in code — no 3D
// program, no downloaded files, no libraries. Each one is a small clay pot
// with leaf clusters coloured by the herbs in the mix (green, red, yellow).
//
// Run it once from the server folder:
//     npx tsx scripts/make-herb-models.ts
// It (re)writes asset-packs/weapons/mixed-herb-*.glb and checks each file it
// wrote by reading it back. The output is always the same (fixed random
// seeds), so running it again changes nothing unless this file changed.
//
// The files are glTF 2.0 binary (.glb): one JSON part that describes the
// model, then one binary part with the raw numbers (vertex positions,
// normals, colours and the triangle list).

import fs from "fs";
import path from "path";

type V3 = [number, number, number];
type RGB = [number, number, number];

const OUT_DIR = path.resolve(__dirname, "../asset-packs/weapons");

// ---- Colours -----------------------------------------------------------------

function hex(h: string): RGB {
  const n = parseInt(h.replace("#", ""), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => v / 255) as RGB;
}

// glTF stores colours in linear light; picked colours are sRGB.
function toLinear(c: RGB): RGB {
  return c.map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)) as RGB;
}

function shade(c: RGB, k: number): RGB {
  return c.map((v) => Math.min(1, Math.max(0, v * k))) as RGB;
}

const HERB_COLOUR: Record<string, RGB> = {
  G: hex("#3f9b3a"),
  R: hex("#c7362f"),
  Y: hex("#e7c83a"),
};
const POT = hex("#d9976a"); // terracotta, a little lighter than raw clay
const POT_RIM = hex("#e8b48a");
const POT_INSIDE = hex("#a9663f");
const SOIL = hex("#4a3324");

// ---- Small vector helpers ---------------------------------------------------------

const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const mul = (a: V3, k: number): V3 => [a[0] * k, a[1] * k, a[2] * k];
const dot = (a: V3, b: V3): number => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a: V3, b: V3): V3 => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const len = (a: V3): number => Math.hypot(a[0], a[1], a[2]);
const norm = (a: V3): V3 => {
  const l = len(a);
  return l > 1e-12 ? mul(a, 1 / l) : [0, 1, 0];
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const mix = (a: RGB, b: RGB, t: number): RGB => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

// Same numbers every run, so the files don't change for no reason.
function seededRandom(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---- Mesh building ------------------------------------------------------------------

// One closed piece of surface (a leaf, a stem, the pot). Triangles go
// counter-clockwise seen from outside, as glTF expects.
class Part {
  pos: V3[] = [];
  col: RGB[] = [];
  idx: number[] = [];

  vertex(p: V3, c: RGB): number {
    this.pos.push(p);
    this.col.push(c);
    return this.pos.length - 1;
  }

  tri(a: number, b: number, c: number) {
    this.idx.push(a, b, c);
  }

  // a, b, c, d counter-clockwise from outside
  quad(a: number, b: number, c: number, d: number) {
    this.tri(a, b, c);
    this.tri(a, c, d);
  }

  // A flat face with its own corners, so it gets a sharp edge (the pot).
  flat(points: V3[], c: RGB) {
    const first = this.pos.length;
    for (const p of points) this.vertex(p, c);
    for (let i = 1; i < points.length - 1; i++) this.tri(first, first + i, first + i + 1);
  }

  // For a closed surface the signed volume is positive when the triangles
  // face outwards. If this part came out inside-out, turn it around.
  orientOutward() {
    let v = 0;
    for (let i = 0; i < this.idx.length; i += 3) {
      const [a, b, c] = [this.pos[this.idx[i]], this.pos[this.idx[i + 1]], this.pos[this.idx[i + 2]]];
      v += dot(a, cross(b, c));
    }
    if (v < 0) {
      for (let i = 0; i < this.idx.length; i += 3) {
        const t = this.idx[i + 1];
        this.idx[i + 1] = this.idx[i + 2];
        this.idx[i + 2] = t;
      }
    }
  }
}

interface Primitive {
  positions: V3[];
  normals: V3[];
  colors: RGB[];
  indices: number[];
  material: number;
}

// Joins parts into one primitive and gives every vertex a smooth normal
// (the average of the faces around it, weighted by their size). Vertices
// that aren't shared (the pot's flat faces) simply get their face's normal.
function toPrimitive(parts: Part[], material: number): Primitive {
  const positions: V3[] = [];
  const colors: RGB[] = [];
  const indices: number[] = [];
  for (const part of parts) {
    part.orientOutward();
    const base = positions.length;
    positions.push(...part.pos);
    colors.push(...part.col);
    for (const i of part.idx) indices.push(base + i);
  }
  const acc: V3[] = positions.map(() => [0, 0, 0]);
  for (let i = 0; i < indices.length; i += 3) {
    const [a, b, c] = [indices[i], indices[i + 1], indices[i + 2]];
    const n = cross(sub(positions[b], positions[a]), sub(positions[c], positions[a])); // length = 2 × area
    for (const v of [a, b, c]) acc[v] = add(acc[v], n);
  }
  return { positions, normals: acc.map(norm), colors: colors.map(toLinear), indices, material };
}

// A frame (forward, up, side) for placing a leaf pointing along `dir`.
function frameAlong(dir: V3): { f: V3; u: V3; s: V3 } {
  const f = norm(dir);
  const ref: V3 = Math.abs(f[1]) > 0.95 ? [1, 0, 0] : [0, 1, 0];
  const s = norm(cross(f, ref));
  const u = norm(cross(s, f));
  return { f, u, s };
}

// A leaf: a thin, rounded blade, widest past its middle (like a clover
// leaf), a little cupped and drooping at the tip. Closed, so it looks
// right from both sides.
function leaf(base: V3, dir: V3, length: number, width: number, colour: RGB, rnd: () => number): Part {
  const part = new Part();
  const { f, u, s } = frameAlong(dir);
  const N = 11; // steps along the leaf
  const M = 8; // steps around its edge
  const thick = width * 0.12;
  const droop = 0.22 + rnd() * 0.12;
  const dark = shade(colour, 0.72);
  const light = shade(colour, 1.12 + rnd() * 0.06);
  const place = (x: number, y: number, z: number): V3 => add(base, add(mul(f, x), add(mul(u, y), mul(s, z))));

  const root = part.vertex(place(0, 0, 0), dark);
  const rings: number[][] = [];
  for (let i = 1; i < N; i++) {
    const t = i / N;
    const halfW = (width / 2) * Math.sin(Math.PI * t) ** 0.7 * (0.55 + 0.45 * t);
    const halfT = (thick / 2) * Math.sin(Math.PI * t) ** 0.5;
    const x = length * t;
    const bend = -droop * length * t * t; // tip hangs down a little
    const ring: number[] = [];
    for (let j = 0; j < M; j++) {
      const a = (2 * Math.PI * j) / M;
      const z = halfW * Math.cos(a);
      const cup = 0.18 * width * (z / (width / 2)) ** 2; // edges curl up
      const y = halfT * Math.sin(a) + bend + cup;
      ring.push(part.vertex(place(x, y, z), mix(dark, light, t)));
    }
    rings.push(ring);
  }
  const tip = part.vertex(place(length, -droop * length, 0), light);

  for (let j = 0; j < M; j++) part.tri(root, rings[0][(j + 1) % M], rings[0][j]);
  for (let i = 0; i < rings.length - 1; i++) {
    for (let j = 0; j < M; j++) {
      const k = (j + 1) % M;
      part.quad(rings[i][j], rings[i][k], rings[i + 1][k], rings[i + 1][j]);
    }
  }
  const last = rings[rings.length - 1];
  for (let j = 0; j < M; j++) part.tri(tip, last[j], last[(j + 1) % M]);
  return part;
}

// A stem: a thin tube along a gentle curve (quadratic Bézier), darker at
// the soil, closed at both ends.
function stem(p0: V3, p1: V3, p2: V3, r0: number, r1: number, c0: RGB, c1: RGB): Part {
  const part = new Part();
  const STEPS = 8;
  const SIDES = 6;
  const at = (t: number): V3 => add(add(mul(p0, (1 - t) ** 2), mul(p1, 2 * (1 - t) * t)), mul(p2, t * t));
  const tangent = (t: number): V3 => norm(add(mul(sub(p1, p0), 2 * (1 - t)), mul(sub(p2, p1), 2 * t)));
  const rings: number[][] = [];
  for (let i = 0; i <= STEPS; i++) {
    const t = i / STEPS;
    const c = at(t);
    const { u, s } = frameAlong(tangent(t));
    const r = lerp(r0, r1, t);
    const ring: number[] = [];
    for (let j = 0; j < SIDES; j++) {
      const a = (2 * Math.PI * j) / SIDES;
      ring.push(part.vertex(add(c, add(mul(u, r * Math.cos(a)), mul(s, r * Math.sin(a)))), mix(c0, c1, t)));
    }
    rings.push(ring);
  }
  const bottom = part.vertex(p0, c0);
  const top = part.vertex(p2, c1);
  for (let j = 0; j < SIDES; j++) {
    const k = (j + 1) % SIDES;
    part.tri(bottom, rings[0][k], rings[0][j]);
    part.tri(top, rings[STEPS][j], rings[STEPS][k]);
    for (let i = 0; i < STEPS; i++) part.quad(rings[i][j], rings[i][k], rings[i + 1][k], rings[i + 1][j]);
  }
  return part;
}

// The pot: six-sided, wider at the top, with a flat rim, an inner wall and
// soil. Built from flat faces so its edges stay crisp.
const POT_SIDES = 6;
const POT_H = 0.064; // height of the rim
const SOIL_Y = 0.056; // soil sits a little below the rim
const R_BOTTOM = 0.037;
const R_TOP = 0.053;
const R_INNER = 0.044;
const R_SOIL = 0.041;

function pot(): Part {
  const part = new Part();
  const ring = (r: number, y: number): V3[] =>
    Array.from({ length: POT_SIDES }, (_, i) => {
      const a = (2 * Math.PI * i) / POT_SIDES + Math.PI / 6;
      return [r * Math.cos(a), y, r * Math.sin(a)] as V3;
    });
  const bottom = ring(R_BOTTOM, 0);
  const top = ring(R_TOP, POT_H);
  const inner = ring(R_INNER, POT_H);
  const soil = ring(R_SOIL, SOIL_Y);
  // Corners go around counter-clockwise seen from above (+Y).
  part.flat([...bottom], shade(POT, 0.8)); // underside (faces down)
  part.flat([...soil].reverse(), SOIL); // soil (faces up)
  for (let i = 0; i < POT_SIDES; i++) {
    const j = (i + 1) % POT_SIDES;
    part.flat([bottom[i], top[i], top[j], bottom[j]], POT); // outside wall
    part.flat([top[i], inner[i], inner[j], top[j]], POT_RIM); // rim
    part.flat([inner[i], soil[i], soil[j], inner[j]], POT_INSIDE); // inside wall
  }
  return part;
}

// ---- One mixed herb ---------------------------------------------------------------------

// letters: e.g. "GGY" → two green clusters and one yellow one.
function herbModel(letters: string): Primitive[] {
  const rnd = seededRandom([...letters].reduce((h, ch) => h * 31 + ch.charCodeAt(0), 7));
  const plants: Part[] = [];
  const n = letters.length;
  const spread = n === 3 ? 0.017 : 0.014;
  for (let k = 0; k < n; k++) {
    // Two herbs of the same colour get slightly different shades, so a
    // G+G mix reads as two plants rather than one big one.
    const twin = k > 0 && letters[k] === letters[k - 1];
    const colour = shade(HERB_COLOUR[letters[k]], twin ? 1.15 : 1);
    const angle = (2 * Math.PI * k) / n + Math.PI / 5;
    const out: V3 = [Math.cos(angle), 0, Math.sin(angle)];
    const centre: V3 = [out[0] * spread, SOIL_Y - 0.004, out[2] * spread];
    const stems = 3;
    for (let m = 0; m < stems; m++) {
      // Each stem leans outwards a bit differently.
      const a = angle + (m - 1) * 0.55 + (rnd() - 0.5) * 0.3;
      const lean: V3 = [Math.cos(a), 0, Math.sin(a)];
      const height = 0.092 + rnd() * 0.036;
      const reach = 0.028 + rnd() * 0.022;
      const p0 = add(centre, [(rnd() - 0.5) * 0.008, 0, (rnd() - 0.5) * 0.008]);
      const p2 = add(p0, add(mul(lean, reach), [0, height, 0]));
      const p1 = add(p0, add(mul(lean, reach * 0.15), [0, height * 0.55, 0]));
      plants.push(stem(p0, p1, p2, 0.002, 0.0013, shade(colour, 0.42), shade(colour, 0.8)));

      // Three rounded leaves at the top, like a clover.
      const phase = rnd() * Math.PI * 2;
      for (let l = 0; l < 3; l++) {
        const b = phase + (2 * Math.PI * l) / 3;
        const tilt = 0.25 + rnd() * 0.3; // how much the leaf points up
        const dir: V3 = [Math.cos(b), tilt, Math.sin(b)];
        plants.push(leaf(p2, dir, 0.032 + rnd() * 0.006, 0.027 + rnd() * 0.004, colour, rnd));
      }
      // A couple of small leaves along the stem.
      for (const t of [0.45, 0.68]) {
        const q = add(add(mul(p0, (1 - t) ** 2), mul(p1, 2 * (1 - t) * t)), mul(p2, t * t));
        const side = a + (t < 0.5 ? 1.4 : -1.4);
        const dir: V3 = [Math.cos(side), 0.45, Math.sin(side)];
        plants.push(leaf(q, dir, 0.018 + rnd() * 0.004, 0.012, colour, rnd));
      }
    }
  }
  return [toPrimitive([pot()], 0), toPrimitive(plants, 1)];
}

// ---- GLB writer --------------------------------------------------------------------------

const FLOAT = 5126;
const UNSIGNED_SHORT = 5123;
const UNSIGNED_INT = 5125;
const ARRAY_BUFFER = 34962;
const ELEMENT_ARRAY_BUFFER = 34963;

function writeGlb(name: string, prims: Primitive[]): Buffer {
  const chunks: Buffer[] = [];
  let offset = 0;
  const bufferViews: object[] = [];
  const accessors: object[] = [];

  // Adds one block of numbers to the binary part (kept 4-byte aligned).
  function view(data: Buffer, target: number): number {
    bufferViews.push({ buffer: 0, byteOffset: offset, byteLength: data.length, target });
    chunks.push(data);
    offset += data.length;
    const pad = (4 - (offset % 4)) % 4;
    if (pad) {
      chunks.push(Buffer.alloc(pad));
      offset += pad;
    }
    return bufferViews.length - 1;
  }

  function floats(list: number[][], type: "VEC3", withRange = false): number {
    const data = Buffer.alloc(list.length * 12);
    list.forEach((v, i) => v.forEach((x, k) => data.writeFloatLE(x, i * 12 + k * 4)));
    const acc: Record<string, unknown> = {
      bufferView: view(data, ARRAY_BUFFER),
      componentType: FLOAT,
      count: list.length,
      type,
    };
    if (withRange) {
      // min/max must match the stored (32-bit) numbers exactly.
      const f32 = list.map((v) => v.map((x) => Math.fround(x)));
      acc.min = [0, 1, 2].map((k) => Math.min(...f32.map((v) => v[k])));
      acc.max = [0, 1, 2].map((k) => Math.max(...f32.map((v) => v[k])));
    }
    accessors.push(acc);
    return accessors.length - 1;
  }

  function indexAccessor(indices: number[], vertexCount: number): number {
    const big = vertexCount > 65535;
    const size = big ? 4 : 2;
    const data = Buffer.alloc(indices.length * size);
    indices.forEach((v, i) => (big ? data.writeUInt32LE(v, i * 4) : data.writeUInt16LE(v, i * 2)));
    accessors.push({
      bufferView: view(data, ELEMENT_ARRAY_BUFFER),
      componentType: big ? UNSIGNED_INT : UNSIGNED_SHORT,
      count: indices.length,
      type: "SCALAR",
    });
    return accessors.length - 1;
  }

  const primitives = prims.map((p) => ({
    attributes: {
      POSITION: floats(p.positions, "VEC3", true),
      NORMAL: floats(p.normals, "VEC3"),
      COLOR_0: floats(p.colors, "VEC3"),
    },
    indices: indexAccessor(p.indices, p.positions.length),
    material: p.material,
    mode: 4, // triangles
  }));

  const gltf = {
    asset: {
      version: "2.0",
      generator: "Game System make-herb-models.ts",
      copyright: "OmniGameCraft",
    },
    scene: 0,
    scenes: [{ name, nodes: [0] }],
    nodes: [{ name, mesh: 0 }],
    meshes: [{ name, primitives }],
    // Vertex colours carry the colour; the materials only set how shiny.
    materials: [
      { name: "Clay", pbrMetallicRoughness: { baseColorFactor: [1, 1, 1, 1], metallicFactor: 0, roughnessFactor: 0.9 } },
      {
        name: "Leaf",
        pbrMetallicRoughness: { baseColorFactor: [1, 1, 1, 1], metallicFactor: 0, roughnessFactor: 0.55 },
        doubleSided: true,
      },
    ],
    buffers: [{ byteLength: offset }],
    bufferViews,
    accessors,
  };

  const bin = Buffer.concat(chunks); // already a multiple of 4 bytes
  let json = Buffer.from(JSON.stringify(gltf), "utf8");
  const jsonPad = (4 - (json.length % 4)) % 4;
  json = Buffer.concat([json, Buffer.alloc(jsonPad, 0x20)]); // JSON pads with spaces

  const header = Buffer.alloc(12);
  const total = 12 + 8 + json.length + 8 + bin.length;
  header.writeUInt32LE(0x46546c67, 0); // "glTF"
  header.writeUInt32LE(2, 4);
  header.writeUInt32LE(total, 8);
  const chunkHead = (length: number, type: number) => {
    const b = Buffer.alloc(8);
    b.writeUInt32LE(length, 0);
    b.writeUInt32LE(type, 4);
    return b;
  };
  return Buffer.concat([header, chunkHead(json.length, 0x4e4f534a), json, chunkHead(bin.length, 0x004e4942), bin]);
}

// ---- Self-check ----------------------------------------------------------------------------

// Reads a written file back and checks it is a well-formed .glb: header,
// chunk sizes and types, every accessor inside its buffer view, every view
// inside the buffer, indices pointing at real vertices, unit normals and
// POSITION min/max matching the data. Throws with the first problem found.
function checkGlb(buf: Buffer): { triangles: number; vertices: number; size: V3 } {
  const fail = (m: string): never => {
    throw new Error(m);
  };
  if (buf.toString("ascii", 0, 4) !== "glTF") fail("bad magic");
  if (buf.readUInt32LE(4) !== 2) fail("not version 2");
  if (buf.readUInt32LE(8) !== buf.length) fail("length in header doesn't match the file");
  const jsonLen = buf.readUInt32LE(12);
  if (buf.readUInt32LE(16) !== 0x4e4f534a) fail("first chunk isn't JSON");
  if (jsonLen % 4 !== 0) fail("JSON chunk not 4-byte aligned");
  const gltf = JSON.parse(buf.toString("utf8", 20, 20 + jsonLen));
  const binStart = 20 + jsonLen;
  const binLen = buf.readUInt32LE(binStart);
  if (buf.readUInt32LE(binStart + 4) !== 0x004e4942) fail("second chunk isn't BIN");
  if (binLen % 4 !== 0 || binStart + 8 + binLen !== buf.length) fail("BIN chunk size is wrong");
  if (gltf.buffers[0].byteLength > binLen) fail("buffer bigger than the BIN chunk");
  const bin = buf.subarray(binStart + 8, binStart + 8 + binLen);

  const compSize: Record<number, number> = { [FLOAT]: 4, [UNSIGNED_SHORT]: 2, [UNSIGNED_INT]: 4 };
  const typeCount: Record<string, number> = { SCALAR: 1, VEC3: 3 };
  const read = (a: number): number[] => {
    const acc = gltf.accessors[a];
    const bv = gltf.bufferViews[acc.bufferView];
    if (bv.byteOffset % 4 !== 0) fail("buffer view not aligned");
    if (bv.byteOffset + bv.byteLength > gltf.buffers[0].byteLength) fail("buffer view outside the buffer");
    const size = compSize[acc.componentType];
    const n = acc.count * typeCount[acc.type];
    if (n * size > bv.byteLength) fail("accessor outside its buffer view");
    const out: number[] = [];
    for (let i = 0; i < n; i++) {
      const at = bv.byteOffset + i * size;
      out.push(
        acc.componentType === FLOAT
          ? bin.readFloatLE(at)
          : acc.componentType === UNSIGNED_SHORT
          ? bin.readUInt16LE(at)
          : bin.readUInt32LE(at)
      );
    }
    return out;
  };

  let triangles = 0;
  let vertices = 0;
  const lo: V3 = [Infinity, Infinity, Infinity];
  const hi: V3 = [-Infinity, -Infinity, -Infinity];
  for (const prim of gltf.meshes[0].primitives) {
    const posAcc = gltf.accessors[prim.attributes.POSITION];
    const pos = read(prim.attributes.POSITION);
    const nrm = read(prim.attributes.NORMAL);
    read(prim.attributes.COLOR_0);
    const idx = read(prim.indices);
    if (idx.length % 3 !== 0) fail("index count isn't a multiple of 3");
    if (idx.some((i) => i >= posAcc.count)) fail("index points past the last vertex");
    for (let k = 0; k < 3; k++) {
      const vals = pos.filter((_, i) => i % 3 === k);
      if (Math.min(...vals) !== posAcc.min[k] || Math.max(...vals) !== posAcc.max[k]) fail("POSITION min/max wrong");
      lo[k] = Math.min(lo[k], posAcc.min[k]);
      hi[k] = Math.max(hi[k], posAcc.max[k]);
    }
    for (let i = 0; i < nrm.length; i += 3) {
      if (Math.abs(Math.hypot(nrm[i], nrm[i + 1], nrm[i + 2]) - 1) > 0.005) fail("normal isn't unit length");
    }
    triangles += idx.length / 3;
    vertices += posAcc.count;
  }
  return { triangles, vertices, size: [hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]] };
}

// ---- Main -------------------------------------------------------------------------------------

const MIXES = ["GG", "GR", "GY", "GRY", "GGY"];
for (const code of MIXES) {
  const name = `Mixed Herb (${code.split("").join("+")})`;
  const file = path.join(OUT_DIR, `mixed-herb-${code.toLowerCase()}.glb`);
  fs.writeFileSync(file, writeGlb(name, herbModel(code)));
  const info = checkGlb(fs.readFileSync(file));
  const kb = (fs.statSync(file).size / 1024).toFixed(0);
  const size = info.size.map((v) => v.toFixed(3)).join(" × ");
  console.log(`${path.basename(file)}: ${info.triangles} triangles, ${info.vertices} vertices, ${size} m, ${kb} KB — OK`);
}
