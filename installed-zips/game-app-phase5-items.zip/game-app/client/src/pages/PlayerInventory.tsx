import { useEffect, useState } from "react";
import { ErrorBanner } from "../components/ErrorBanner";
import { ItemImage } from "../components/ItemImage";
import { getMyInventory, InventoryEntry } from "../services/api";

export function PlayerInventory() {
  const [inventory, setInventory] = useState<InventoryEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function load() {
    setError(null);
    setLoading(true);
    getMyInventory()
      .then(setInventory)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load."))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-pine">Bag</h2>
        <button
          onClick={load}
          disabled={loading}
          className="rounded-lg px-2 py-2 text-base font-semibold text-pine underline disabled:opacity-50"
        >
          {loading ? "Refreshing…" : "Refresh"}
        </button>
      </div>
      <ErrorBanner message={error} />
      {inventory === null && !error && <p className="text-ink/60">Loading…</p>}
      {inventory?.length === 0 && (
        <p className="rounded-xl bg-pine-soft px-4 py-6 text-center text-lg text-ink/80">Your bag is empty.</p>
      )}
      <ul className="flex flex-col gap-3">
        {inventory?.map((e) => (
          <li key={e.itemId} className="flex gap-4 rounded-2xl border-2 border-ink/10 bg-white p-3">
            <ItemImage url={e.imageUrl} name={e.name} />
            <div className="min-w-0 flex-1">
              <div className="flex items-start justify-between gap-2">
                <p className="text-lg font-bold leading-tight text-ink">{e.name}</p>
                <span className="shrink-0 rounded-lg bg-pine px-2 py-1 text-lg font-extrabold leading-none text-white">
                  ×{e.quantity}
                </span>
              </div>
              {e.category && <p className="text-sm font-medium text-ink/60">{e.category}</p>}
              {e.description && <p className="mt-1 text-sm text-ink/80">{e.description}</p>}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
