// Who made this and which release it is. Shown in Settings › About and on the
// start screen. The server has the same version number (server/src/version.ts),
// so the Admin can check that the phones and the server are on the same release.
export const APP_NAME = "Game System";
export const APP_VERSION = "2.0.0";
export const APP_EDITION = "Inventory Update";
export const COMPANY = "OmniGameCraft";
export const CREATORS = ["Abdul Hadi", "Sheheryar Azam"];
export const COPYRIGHT_YEAR = 2026;
