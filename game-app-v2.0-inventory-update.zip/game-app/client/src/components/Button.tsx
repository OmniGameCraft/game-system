import { ButtonHTMLAttributes, MouseEvent } from "react";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  variant?: "primary" | "ghost" | "danger" | "dangerGhost";
  size?: "lg" | "md";
}

// Main actions are solid amber with a lit top edge and a darker lip below,
// like a physical key; secondary ones are dark steel. They sink a little when
// pressed. Same height everywhere so thumbs always find them.
const LOOK = {
  primary:
    "bg-gradient-to-b from-pine-light to-pine text-pine-ink shadow-[inset_0_1px_0_rgba(255,255,255,0.5),inset_0_-2px_0_rgba(0,0,0,0.18),0_2px_0_#8a560a,0_8px_18px_-8px_rgba(245,165,36,0.55)] active:translate-y-[2px] active:shadow-[inset_0_1px_0_rgba(255,255,255,0.35),0_0_0_#8a560a] disabled:border disabled:border-pine/20 disabled:from-[#2b261d] disabled:to-[#221e17] disabled:text-pine/45 disabled:shadow-none",
  ghost:
    "border border-panel-line bg-gradient-to-b from-[#25282c] to-[#1a1c1f] text-ink shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_2px_0_#08090a] active:translate-y-[2px] active:shadow-[inset_0_1px_0_rgba(255,255,255,0.05)] disabled:opacity-50",
  danger:
    "bg-gradient-to-b from-[#ff7c72] to-alert text-[#2A0707] shadow-[inset_0_1px_0_rgba(255,255,255,0.45),0_2px_0_#8f241d,0_8px_18px_-8px_rgba(255,90,79,0.5)] active:translate-y-[2px] active:shadow-none disabled:border disabled:border-alert/20 disabled:from-[#2d1a19] disabled:to-[#241514] disabled:text-alert/45 disabled:shadow-none",
  dangerGhost:
    "border border-alert/55 bg-alert/[0.06] text-alert shadow-[inset_0_1px_0_rgba(255,255,255,0.04)] active:translate-y-[1px] active:bg-alert/15 disabled:opacity-50",
};

export function Button({
  loading,
  variant = "primary",
  size = "lg",
  disabled,
  children,
  className = "",
  onClick,
  ...rest
}: Props) {
  const sz = size === "lg" ? "min-h-[3.5rem] px-4 py-3 text-xl" : "min-h-[3rem] px-3 py-2 text-lg";
  // While loading the button keeps its colour (with a spinner) but ignores
  // taps, including the "press Enter" submit of a form.
  function click(e: MouseEvent<HTMLButtonElement>) {
    if (loading) {
      e.preventDefault();
      return;
    }
    onClick?.(e);
  }
  return (
    <button
      disabled={disabled}
      aria-disabled={loading || undefined}
      aria-busy={loading || undefined}
      data-sound={loading ? "none" : undefined}
      onClick={click}
      className={`flex w-full items-center justify-center gap-2 rounded-md font-display font-semibold tracking-wide transition-[transform,box-shadow,background-color] duration-100 disabled:cursor-default disabled:active:translate-y-0 ${
        loading ? "pointer-events-none cursor-progress opacity-90" : ""
      } ${sz} ${LOOK[variant]} ${className}`}
      {...rest}
    >
      {loading ? (
        <>
          <span
            className="h-5 w-5 shrink-0 animate-spin rounded-full border-2 border-current border-r-transparent opacity-70"
            aria-hidden
          />
          Please wait…
        </>
      ) : (
        children
      )}
    </button>
  );
}
