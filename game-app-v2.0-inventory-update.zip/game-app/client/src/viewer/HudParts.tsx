import { ReactNode, useEffect, useRef, useState } from "react";
import { Icon, IconName } from "../components/Icon";

// The pieces of the weapon screen's heads-up display, styled like the
// attaché case: dark gunmetal panels with a thin light frame, white bold
// numbers, amber for "do this now", red for "empty".

// Animations used only by the weapon screen. Kept here (not in the global
// stylesheet) so this screen looks the same whatever theme is around it.
// Every animation ends on the element's normal look, so "reduce motion"
// (which shortens animations to nothing) never hides anything important.
const CSS = `
.wv-frame{background:linear-gradient(180deg,rgba(40,43,48,.86),rgba(17,19,22,.9));border:1px solid rgba(255,255,255,.14);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.07),inset 0 -1px 0 rgba(0,0,0,.55),0 8px 22px rgba(0,0,0,.45);border-radius:5px}
.wv-round{display:flex;align-items:center;justify-content:center;width:2.75rem;height:2.75rem;border-radius:9999px;color:#fff;
  background:radial-gradient(circle at 50% 30%,#3a3e44 0%,#1b1d20 70%);border:1px solid rgba(255,255,255,.2);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.12),0 4px 14px rgba(0,0,0,.55);transition:transform 90ms ease,background 120ms ease}
.wv-round:active{transform:scale(.9);background:radial-gradient(circle at 50% 30%,#4a4f56 0%,#24272b 70%)}
.wv-press{transition:transform 90ms ease}.wv-press:active{transform:scale(.96)}
@keyframes wv-flash{from{opacity:.24}to{opacity:0}}
@keyframes wv-tick{0%{transform:scale(1.22)}100%{transform:scale(1)}}
@keyframes wv-blink{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes wv-pop{0%{opacity:0;transform:scale(.85)}60%{opacity:1;transform:scale(1.05)}100%{opacity:1;transform:scale(1)}}
@keyframes wv-fade{from{opacity:0}to{opacity:1}}
@keyframes wv-fade-out{from{opacity:1}to{opacity:0}}
@keyframes wv-up{from{transform:translateY(100%)}to{transform:translateY(0)}}
@keyframes wv-down{from{transform:translateY(0)}to{transform:translateY(100%)}}
@keyframes wv-glow{0%{opacity:0}20%{opacity:1}100%{opacity:0}}
@keyframes wv-nudge{0%,100%{transform:translateX(0)}20%{transform:translateX(-7px)}60%{transform:translateX(7px)}}
@keyframes wv-hint{0%{opacity:0;transform:translateY(6px)}100%{opacity:1;transform:translateY(0)}}
.wv-tick{display:inline-block;animation:wv-tick 170ms ease-out}
.wv-blink{animation:wv-blink 1s ease-in-out infinite}
.wv-pop{animation:wv-pop 220ms ease-out}
.wv-fade{animation:wv-fade 160ms ease-out}
.wv-nudge{animation:wv-nudge 280ms ease-in-out}
.wv-hint{animation:wv-hint 260ms ease-out}
.wv-calm *,.wv-calm *::before,.wv-calm *::after{animation-duration:1ms!important;animation-iteration-count:1!important;transition-duration:1ms!important}
`;

export function ViewerStyles() {
  return <style>{CSS}</style>;
}

// Small round button for the top corners (Back, Case).
export function RoundButton({
  icon,
  label,
  onClick,
  sound = true,
}: {
  icon: IconName;
  label: string;
  onClick: () => void;
  sound?: boolean; // false when the action plays its own sound
}) {
  return (
    <button
      type="button"
      data-no-use
      data-sound={sound ? undefined : "none"}
      onClick={onClick}
      aria-label={label}
      title={label}
      className="wv-round pointer-events-auto shrink-0"
    >
      <Icon name={icon} className="h-[1.35rem] w-[1.35rem]" />
    </button>
  );
}

// "12 / 48" with a strip of magazine pips. Red with a reload hint when empty.
// Tapping it reloads too (handy with a mouse, or for anyone who can't swipe).
export function AmmoCounter({
  loaded,
  reserve,
  magazine,
  reloading,
  practice,
  onReload,
}: {
  loaded: number;
  reserve: number;
  magazine: number | null;
  reloading: boolean;
  practice: boolean;
  onReload: () => void;
}) {
  const empty = loaded <= 0;
  const canReload = practice || reserve > 0;
  let hint: ReactNode = null;
  if (reloading) hint = <span className="text-[#F5A524]">Reloading…</span>;
  else if (empty) {
    hint = canReload ? (
      <span className="wv-blink text-[#FF5D5D]">Reload ↓</span>
    ) : (
      <span className="text-[#FF5D5D]">No ammo</span>
    );
  }
  return (
    <div className="pointer-events-auto flex flex-col items-end gap-1.5">
      <button
        type="button"
        data-no-use
        data-sound="none"
        onClick={onReload}
        aria-label={`Ammo: ${loaded} in the magazine, ${reserve} spare. Tap to reload.`}
        className={`wv-frame wv-press min-w-[7.75rem] px-3 pb-2 pt-1 text-right ${empty ? "!border-[#FF5D5D]/60" : ""}`}
      >
        <span className="block text-[10px] font-semibold uppercase tracking-[0.2em] text-white/45">Ammo</span>
        <span className="flex items-baseline justify-end gap-1.5 font-display font-bold leading-none tabular-nums">
          <span
            key={loaded}
            className={`wv-tick text-[2.6rem] ${empty ? "text-[#FF5D5D]" : "text-white"}`}
            style={{ textShadow: "0 2px 6px rgba(0,0,0,.6)" }}
          >
            {loaded}
          </span>
          <span className="text-lg text-white/55">/ {reserve}</span>
        </span>
        <Pips loaded={loaded} magazine={magazine} />
        {hint && <span className="mt-1 block text-[11px] font-bold uppercase tracking-wider">{hint}</span>}
      </button>
      {practice && (
        <span
          className="flex flex-col items-end rounded-sm border border-[#F5A524]/50 bg-[#F5A524]/10 px-2 py-1 text-right leading-tight text-[#F5A524]"
          aria-label="Practice — ammo not used"
        >
          <span className="text-[11px] font-bold uppercase tracking-[0.2em]">Practice</span>
          <span className="whitespace-nowrap text-[11px] font-semibold opacity-85">ammo not used</span>
        </span>
      )}
    </div>
  );
}

function Pips({ loaded, magazine }: { loaded: number; magazine: number | null }) {
  if (!magazine || magazine <= 0) return null;
  const empty = loaded <= 0;
  if (magazine > 40) {
    // Big magazines: one bar instead of 100 tiny pips.
    return (
      <span className="mt-1.5 block h-1.5 w-full overflow-hidden rounded-[1px] bg-white/10">
        <span
          className="block h-full bg-white transition-[width] duration-150"
          style={{ width: `${Math.min(100, (loaded / magazine) * 100)}%` }}
        />
      </span>
    );
  }
  return (
    <span className="mt-1.5 flex h-1.5 w-full gap-[2px]" aria-hidden>
      {Array.from({ length: magazine }, (_, i) => (
        <span
          key={i}
          className={`h-full flex-1 rounded-[1px] transition-colors duration-100 ${
            i < loaded ? "bg-white" : empty ? "bg-[#FF5D5D]/35" : "bg-white/15"
          }`}
        />
      ))}
    </span>
  );
}

// Progress ring in the middle of the screen while reloading. Driven by the
// clock (not React renders) so it stays smooth on slow phones; if the end
// time moves (the server's reload time), it simply follows.
export function ReloadRing({ start, end }: { start: number; end: number }) {
  const ring = useRef<SVGCircleElement>(null);
  const R = 34;
  const C = 2 * Math.PI * R;
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      const p = Math.min(1, Math.max(0, (performance.now() - start) / Math.max(1, end - start)));
      if (ring.current) ring.current.style.strokeDashoffset = String(C * (1 - p));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    tick();
    return () => cancelAnimationFrame(raf);
  }, [start, end, C]);
  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center" role="status" aria-label="Reloading">
      <div className="wv-fade flex flex-col items-center gap-2">
        <div className="relative h-[84px] w-[84px]">
          <svg viewBox="0 0 84 84" className="h-full w-full -rotate-90">
            <circle cx="42" cy="42" r={R} fill="rgba(10,11,13,.55)" stroke="rgba(255,255,255,.12)" strokeWidth="6" />
            <circle
              ref={ring}
              cx="42"
              cy="42"
              r={R}
              fill="none"
              stroke="#F5A524"
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={C}
              strokeDashoffset={C}
            />
          </svg>
          <Icon name="reload" className="absolute inset-0 m-auto h-8 w-8 text-white/85" />
        </div>
        <span className="font-display text-sm font-bold uppercase tracking-[0.25em] text-white/80">Reloading</span>
      </div>
    </div>
  );
}

// Big centred message over the gun: "Game paused", "You're down"…
export function StatusCard({
  icon,
  title,
  text,
  tone,
  nudge,
}: {
  icon: IconName;
  title: string;
  text: string;
  tone: "red" | "amber" | "grey";
  nudge: number; // changes when a tap was blocked, to shake the card
}) {
  const color = tone === "red" ? "text-[#FF5D5D]" : tone === "amber" ? "text-[#F5A524]" : "text-white/80";
  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center bg-black/55 p-6" role="status">
      <div key={nudge} className={`wv-frame flex max-w-xs flex-col items-center gap-1.5 px-6 py-5 text-center ${nudge ? "wv-nudge" : "wv-pop"}`}>
        <Icon name={icon} className={`h-10 w-10 ${color}`} />
        <p className={`font-display text-2xl font-bold ${color}`}>{title}</p>
        <p className="text-sm leading-snug text-white/70">{text}</p>
      </div>
    </div>
  );
}

// The case, slid up over the weapon screen. Closing it shows the gun again.
export function CaseSheet({ onClose, children }: { onClose: () => void; children: ReactNode }) {
  const [leaving, setLeaving] = useState(false);
  const close = () => {
    if (leaving) return;
    setLeaving(true);
    window.setTimeout(onClose, 170);
  };
  return (
    <div data-no-use className="absolute inset-0 z-40" role="dialog" aria-modal="true" aria-label="Your case">
      <div
        className="absolute inset-0 bg-black/65"
        style={{ animation: `${leaving ? "wv-fade-out" : "wv-fade"} 170ms ease-out forwards` }}
        onClick={close}
      />
      <div
        className="absolute inset-x-0 bottom-0 mx-auto flex h-[94%] max-w-3xl flex-col overflow-hidden rounded-t-xl border-x border-t border-white/15 bg-[#121417] shadow-[0_-12px_40px_rgba(0,0,0,.6)]"
        style={{ animation: `${leaving ? "wv-down" : "wv-up"} 190ms cubic-bezier(.2,.8,.2,1) forwards` }}
      >
        <div className="relative flex items-center justify-center border-b border-white/10 bg-gradient-to-b from-[#24272b] to-[#17191c] px-4 py-2.5">
          <span className="absolute left-1/2 top-1 h-1 w-10 -translate-x-1/2 rounded-full bg-white/20" aria-hidden />
          <p className="font-display text-sm font-bold uppercase tracking-[0.3em] text-white/85">Case</p>
          <button
            type="button"
            data-sound="none"
            onClick={close}
            aria-label="Close the case"
            className="absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full text-white/80 active:bg-white/10"
          >
            <Icon name="close" className="h-6 w-6" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-3" style={{ touchAction: "pan-y" }}>
          {children}
        </div>
      </div>
    </div>
  );
}

// The big "Use" button for healing items.
export function UseButton({
  label,
  detail,
  disabled,
  busy,
  onUse,
}: {
  label: string;
  detail: string;
  disabled: boolean;
  busy: boolean;
  onUse: () => void;
}) {
  return (
    <button
      type="button"
      data-no-use
      data-sound="none"
      disabled={disabled || busy}
      onClick={onUse}
      className="chamfer wv-press flex min-h-[3.75rem] w-full max-w-[22rem] items-center justify-center gap-3 bg-[#9DC35B] px-5 py-3 font-display text-[#0f1a05] shadow-[0_8px_24px_rgba(0,0,0,.45)] disabled:bg-white/10 disabled:text-white/40"
    >
      <Icon name="heart" className="h-7 w-7" />
      <span className="flex flex-col items-start leading-tight">
        <span className="text-2xl font-bold uppercase tracking-wide">{busy ? "Using…" : label}</span>
        <span className="text-sm font-semibold opacity-80">{detail}</span>
      </span>
    </button>
  );
}
