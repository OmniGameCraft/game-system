// Square picture for an item, or the item's first letter when there's no
// picture yet.
export function ItemImage({
  url,
  name,
  size = "md",
}: {
  url: string | null;
  name: string;
  size?: "sm" | "md" | "lg";
}) {
  const box = size === "lg" ? "h-28 w-28 text-4xl" : size === "sm" ? "h-12 w-12 text-lg" : "h-16 w-16 text-2xl";
  if (url) {
    return (
      <img
        src={url}
        alt=""
        className={`${box} shrink-0 rounded-sm border border-panel-line bg-[radial-gradient(circle,#3a4652_0%,#222b34_75%)] object-contain p-0.5`}
      />
    );
  }
  return (
    <div
      aria-hidden
      className={`${box} flex shrink-0 items-center justify-center rounded-sm border border-panel-line bg-panel-raised font-display font-bold text-pine`}
    >
      {name.trim().charAt(0).toUpperCase() || "?"}
    </div>
  );
}
