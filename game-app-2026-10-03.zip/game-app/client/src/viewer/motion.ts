// Shake detection. Phones only send motion data to secure (https) pages,
// and iPhones also ask the player's permission once, from a tap.

export type MotionState = "granted" | "denied" | "insecure" | "unsupported";

let state: MotionState | null = null;

// Call from inside a tap handler (iPhone requirement).
export function requestMotionPermission(): Promise<MotionState> {
  if (!window.isSecureContext) return Promise.resolve((state = "insecure"));
  const DME = (window as any).DeviceMotionEvent;
  if (!DME) return Promise.resolve((state = "unsupported"));
  if (typeof DME.requestPermission === "function") {
    return DME.requestPermission()
      .then((r: string) => (state = r === "granted" ? "granted" : "denied"))
      .catch(() => (state = "denied"));
  }
  return Promise.resolve((state = "granted"));
}

export function motionState(): MotionState | null {
  return state;
}

// Calls onShake for each sharp movement (like jerking a gun up to fire).
// Returns a function that stops listening.
export function listenForShake(onShake: () => void): () => void {
  let last = 0;
  let prev: { x: number; y: number; z: number } | null = null;
  const THRESHOLD = 14; // m/s² of sudden change
  const COOLDOWN = 280; // ms between shots

  const handler = (e: DeviceMotionEvent) => {
    const a = e.acceleration;
    let strength = 0;
    if (a && a.x !== null && a.y !== null && a.z !== null) {
      // gravity already removed
      strength = Math.hypot(a.x!, a.y!, a.z!);
    } else {
      // only "including gravity" available: use change between readings
      const g = e.accelerationIncludingGravity;
      if (!g || g.x === null || g.y === null || g.z === null) return;
      const cur = { x: g.x!, y: g.y!, z: g.z! };
      if (prev) strength = Math.hypot(cur.x - prev.x, cur.y - prev.y, cur.z - prev.z);
      prev = cur;
    }
    const now = performance.now();
    if (strength > THRESHOLD && now - last > COOLDOWN) {
      last = now;
      onShake();
    }
  };
  window.addEventListener("devicemotion", handler);
  return () => window.removeEventListener("devicemotion", handler);
}
