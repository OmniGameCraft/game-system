import { ReactNode } from "react";

// A dark steel panel with its own title strip (like the "ITEMS" label on the
// case), so every part of a screen is clearly separated and labelled. The
// coloured notch marks the heading at a glance; tone changes it for warnings
// and danger.
export function Section({
  title,
  action,
  children,
  tone = "pine",
  flush = false,
}: {
  title: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  tone?: "pine" | "alert" | "sun";
  flush?: boolean; // no padding around the body (for full-width lists)
}) {
  const notch =
    tone === "alert"
      ? "bg-alert shadow-[0_0_8px_rgba(255,90,79,0.7)]"
      : tone === "sun"
      ? "bg-sun shadow-[0_0_8px_rgba(233,200,74,0.6)]"
      : "bg-pine shadow-[0_0_8px_rgba(245,165,36,0.6)]";
  const titleColor = tone === "alert" ? "text-alert" : "text-ink/90";
  return (
    <section className="panel-steel overflow-hidden rounded-[10px] animate-fade-in">
      <header className="flex min-h-[3rem] items-center justify-between gap-3 border-b border-black/70 bg-gradient-to-b from-[#272a2f] to-[#1b1d21] py-1.5 pl-4 pr-2.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.09)]">
        <h2
          className={`flex min-w-0 items-center gap-2.5 font-display text-[0.95rem] font-semibold uppercase leading-tight tracking-[0.12em] ${titleColor}`}
        >
          <span className={`h-4 w-1 shrink-0 rounded-full ${notch}`} aria-hidden />
          <span className="min-w-0">{title}</span>
        </h2>
        {action}
      </header>
      <div className={flush ? "" : "flex flex-col gap-4 p-4"}>{children}</div>
    </section>
  );
}

// Small button that sits in a Section's title strip.
export function SectionAction({
  children,
  onClick,
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="press flex min-h-[2.5rem] shrink-0 items-center gap-1.5 rounded-md border border-panel-line bg-panel-deep/60 px-3 text-sm font-semibold text-pine shadow-bevel active:bg-pine-soft disabled:opacity-50"
    >
      {children}
    </button>
  );
}
