// A tiny pub/sub so any API call can report "the server just told me I'm not
// logged in anymore" without importing React or the whole App component.
// App.tsx registers one handler on mount that clears the signed-in user and
// sends the screen back to the login flow.

type Handler = () => void;

let handler: Handler | null = null;

export function setUnauthorizedHandler(fn: Handler | null): void {
  handler = fn;
}

export function notifyUnauthorized(): void {
  handler?.();
}
