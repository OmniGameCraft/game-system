import type { HerbCode, Piece } from "./caseApi";

// Herb mixing, for previews only ("Mixed Herb (G+Y) — heals 45 HP"). The
// server applies the same rules and has the final word.

const ORDER: Record<string, number> = { G: 0, R: 1, Y: 2 };
const VALID: HerbCode[] = ["GG", "GR", "GY", "GRY", "GGY"];

export const HERB_NAME: Record<HerbCode, string> = {
  G: "Green Herb",
  R: "Red Herb",
  Y: "Yellow Herb",
  GG: "Mixed Herb (G+G)",
  GR: "Mixed Herb (G+R)",
  GY: "Mixed Herb (G+Y)",
  GRY: "Mixed Herb (G+R+Y)",
  GGY: "Mixed Herb (G+G+Y)",
};

// The pack's starting values; the Admin can change them per item.
const DEFAULT_EFFECT: Record<HerbCode, Heal> = {
  G: { healAmount: 30, maxHpBonus: null, fullHeal: false },
  R: { healAmount: 0, maxHpBonus: null, fullHeal: false },
  Y: { healAmount: 0, maxHpBonus: null, fullHeal: false },
  GG: { healAmount: 60, maxHpBonus: null, fullHeal: false },
  GR: { healAmount: 20, maxHpBonus: 20, fullHeal: false },
  GY: { healAmount: 45, maxHpBonus: null, fullHeal: false },
  GRY: { healAmount: 50, maxHpBonus: 15, fullHeal: false },
  GGY: { healAmount: null, maxHpBonus: null, fullHeal: true },
};

export interface Heal {
  healAmount: number | null;
  maxHpBonus: number | null;
  fullHeal: boolean;
}

export type MixResult = { ok: true; code: HerbCode; name: string } | { ok: false; reason: string };

export function mixOf(a: HerbCode, b: HerbCode): MixResult {
  const letters = (a + b)
    .split("")
    .sort((p, q) => ORDER[p] - ORDER[q])
    .join("");
  if ((VALID as string[]).includes(letters)) {
    const code = letters as HerbCode;
    return { ok: true, code, name: HERB_NAME[code] };
  }
  if (letters === "RY") return { ok: false, reason: "Red and Yellow need a Green Herb to mix." };
  return { ok: false, reason: "These herbs don't mix. Every mix needs a Green Herb." };
}

// What a herb code does: the real item's numbers when the player already
// holds one, otherwise the pack's defaults.
export function effectOfCode(code: HerbCode, known: Piece[]): Heal {
  const p = known.find((k) => k.herbCode === code);
  return p ? { healAmount: p.healAmount, maxHpBonus: p.maxHpBonus, fullHeal: p.fullHeal } : DEFAULT_EFFECT[code];
}

// "Heals 30 HP", "Heals 20 HP · Max HP +20", "Restores all HP"…
export function healText(e: Heal): string {
  const parts: string[] = [];
  if (e.fullHeal) parts.push("Restores all HP");
  else if ((e.healAmount ?? 0) > 0) parts.push(`Heals ${e.healAmount} HP`);
  if ((e.maxHpBonus ?? 0) > 0) parts.push(`Max HP +${e.maxHpBonus}`);
  return parts.length ? parts.join(" · ") : "Can't be used alone";
}

// Leaf colours used for herb pictures without an image and for little dots.
export const HERB_COLOR: Record<string, string> = { G: "#5BC45A", R: "#E5484D", Y: "#F2C94C" };
