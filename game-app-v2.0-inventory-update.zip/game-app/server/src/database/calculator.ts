import { DatabaseSync } from "node:sqlite";
import { randomBytes } from "crypto";
import { transaction } from "./db";
import { findItemById, imageUrlFor, Item, updateItem } from "./items";
import { damagePct, DEFAULT_BASE, DEFAULT_DAMAGE_PER_LEVEL, getDamagePerLevel, MAX_LEVEL } from "./weapons";

// The Admin's calculator (Admin › Calc). It answers "how strong is each gun,
// what should the referee call for a hit, and does the team have enough ammo
// for the boss?" — all in HANDGUN ROUNDS, the common unit:
//   - each gun's hre: 1 round of it = hre handgun rounds (pistol 1,
//     shotgun 5). Stored on the item (items.hre), edited here or on the
//     item's page.
//   - hpPerHandgunRound: HP one handgun round takes, so a hit's voice call
//     = round(hre × hpPerHandgunRound × damage %).
//   - damagePerLevel: % extra damage per damage-upgrade level. The game
//     really uses it (weapons.ts reads it) for every gun's damage %.
//   - bosses: each absorbs `handgunRounds` before he gets stronger, has
//     1–5 phases, and each phase is `scalePerPhase` times the one before.
//
// The settings are one JSON value in game_state (key 'calculator'). A
// missing or damaged value falls back to the defaults, so it can never stop
// the game. "Start a new game" keeps it.

export interface Boss {
  id: string;
  name: string;
  handgunRounds: number; // rounds before he gets stronger (phase 1)
  phases: number; // 1–5
  scalePerPhase: number; // each phase is this many times the one before
}

export interface CalculatorConfig {
  hpPerHandgunRound: number;
  damagePerLevel: number; // % per level
  bosses: Boss[];
}

const KEY = "calculator";
const ID_PATTERN = /^[A-Za-z0-9_-]{1,40}$/;

export const CALC_DEFAULTS = Object.freeze({
  hpPerHandgunRound: 10,
  damagePerLevel: DEFAULT_DAMAGE_PER_LEVEL, // 15
});
// What a new boss starts with.
export const DEFAULT_BOSS = Object.freeze({ name: "Boss", handgunRounds: 100, phases: 3, scalePerPhase: 1.5 });
export const DEFAULT_HRE = 1; // a gun with no value set counts like a handgun

// The allowed range of every number (sent to the form too).
export const CALC_LIMITS = Object.freeze({
  hpPerHandgunRound: { min: 0.1, max: 1000 },
  damagePerLevel: { min: 0, max: 100 },
  handgunRounds: { min: 1, max: 1_000_000 },
  phases: { min: 1, max: 5 },
  scalePerPhase: { min: 1, max: 10 },
  hre: { min: 0.01, max: 1000 },
  bosses: { max: 20 },
  bossName: { max: 40 },
});

// A change the Admin asked for that isn't allowed. Safe to show as-is.
export class CalculatorError extends Error {}

const round = (n: number, places: number) => Math.round(n * 10 ** places) / 10 ** places;
const inRange = (n: unknown, min: number, max: number): n is number =>
  typeof n === "number" && Number.isFinite(n) && n >= min && n <= max;
const wholeIn = (n: unknown, min: number, max: number): n is number => Number.isInteger(n) && inRange(n, min, max);
const newBossId = () => `boss-${randomBytes(4).toString("hex")}`;

// ---- Reading ------------------------------------------------------------------

// A stored boss, cleaned up; anything unreadable gets its default.
function readBoss(raw: unknown, index: number, seen: Set<string>): Boss | null {
  if (raw === null || typeof raw !== "object" || Array.isArray(raw)) return null;
  const b = raw as Record<string, unknown>;
  const L = CALC_LIMITS;
  // Same answer on every read, so a row on screen keeps its id.
  let id = typeof b.id === "string" && ID_PATTERN.test(b.id) ? b.id : `boss-${index + 1}`;
  for (let n = 2; seen.has(id); n++) id = `boss-${index + 1}-${n}`;
  seen.add(id);
  const name = typeof b.name === "string" ? b.name.trim().slice(0, L.bossName.max) : "";
  return {
    id,
    name: name || `Boss ${index + 1}`,
    handgunRounds: wholeIn(b.handgunRounds, L.handgunRounds.min, L.handgunRounds.max)
      ? b.handgunRounds
      : DEFAULT_BOSS.handgunRounds,
    phases: wholeIn(b.phases, L.phases.min, L.phases.max) ? b.phases : DEFAULT_BOSS.phases,
    scalePerPhase: inRange(b.scalePerPhase, L.scalePerPhase.min, L.scalePerPhase.max)
      ? round(b.scalePerPhase, 2)
      : DEFAULT_BOSS.scalePerPhase,
  };
}

function readStored(db: DatabaseSync): Record<string, unknown> | null {
  const row = db.prepare("SELECT value FROM game_state WHERE key = ?").get(KEY) as { value: string } | undefined;
  if (!row) return null;
  try {
    const v = JSON.parse(row.value) as unknown;
    return v !== null && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

export function getCalculator(db: DatabaseSync): CalculatorConfig {
  const stored = readStored(db);
  const L = CALC_LIMITS;
  const hp = stored?.hpPerHandgunRound;
  const seen = new Set<string>();
  // Never set yet: start with one example boss so the tab is useful at once.
  const rawBosses = Array.isArray(stored?.bosses)
    ? (stored!.bosses as unknown[])
    : stored
    ? []
    : [{ id: "boss-1", ...DEFAULT_BOSS }];
  return {
    hpPerHandgunRound: inRange(hp, L.hpPerHandgunRound.min, L.hpPerHandgunRound.max)
      ? round(hp, 2)
      : CALC_DEFAULTS.hpPerHandgunRound,
    // Exactly the value the game uses for damage upgrades.
    damagePerLevel: getDamagePerLevel(db),
    bosses: rawBosses
      .slice(0, L.bosses.max)
      .map((b, i) => readBoss(b, i, seen))
      .filter((b): b is Boss => b !== null),
  };
}

// ---- Saving -------------------------------------------------------------------

// Checks one boss from the Admin's form. Missing numbers get the new-boss
// defaults (so { name: "Ogre" } is a fine new boss); wrong ones are refused.
function checkBoss(raw: unknown, index: number, seen: Set<string>): Boss {
  if (raw === null || typeof raw !== "object" || Array.isArray(raw)) throw new CalculatorError("Invalid boss.");
  const b = raw as Record<string, unknown>;
  const L = CALC_LIMITS;

  if (b.name !== undefined && b.name !== null && typeof b.name !== "string") {
    throw new CalculatorError("Boss names must be text.");
  }
  const name = typeof b.name === "string" ? b.name.trim() : "";
  if (name.length > L.bossName.max) {
    throw new CalculatorError(`Boss names can be at most ${L.bossName.max} characters.`);
  }
  const label = name || `Boss ${index + 1}`;

  const handgunRounds = b.handgunRounds ?? DEFAULT_BOSS.handgunRounds;
  if (!wholeIn(handgunRounds, L.handgunRounds.min, L.handgunRounds.max)) {
    throw new CalculatorError(
      `${label}: the handgun rounds he takes before getting stronger must be a whole number ` +
        `from ${L.handgunRounds.min} to ${L.handgunRounds.max.toLocaleString("en-US")}.`
    );
  }
  const phases = b.phases ?? DEFAULT_BOSS.phases;
  if (!wholeIn(phases, L.phases.min, L.phases.max)) {
    throw new CalculatorError(`${label}: phases must be a whole number from ${L.phases.min} to ${L.phases.max}.`);
  }
  const scale = b.scalePerPhase ?? DEFAULT_BOSS.scalePerPhase;
  if (!inRange(scale, L.scalePerPhase.min, L.scalePerPhase.max)) {
    throw new CalculatorError(
      `${label}: strength per phase must be a number from ${L.scalePerPhase.min} to ${L.scalePerPhase.max} (like 1.5).`
    );
  }

  // Keep the form's id (it names the row on screen) unless it is unusable.
  let id = typeof b.id === "string" && ID_PATTERN.test(b.id) && !seen.has(b.id) ? b.id : newBossId();
  while (seen.has(id)) id = newBossId();
  seen.add(id);
  return { id, name: label, handgunRounds, phases, scalePerPhase: round(scale, 2) };
}

export interface CalculatorUpdate {
  config: CalculatorConfig;
  hreChanged: boolean; // a gun's handgun-round value changed (items changed)
  damagePerLevelChanged: boolean; // every gun's damage % changed
}

// Body from the Admin (never trusted): any of hpPerHandgunRound,
// damagePerLevel, bosses (the whole list — it replaces the old one) and
// hre: { [gun item id]: number | null } (null = back to the default, 1).
// Other keys are ignored, so the form may send back what GET gave it.
// Everything is checked first, then saved in ONE transaction: all or
// nothing. Throws CalculatorError with a friendly message.
export function updateCalculator(db: DatabaseSync, body: unknown): CalculatorUpdate {
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    throw new CalculatorError("Send the calculator settings to save.");
  }
  const b = body as Record<string, unknown>;
  const L = CALC_LIMITS;
  const current = getCalculator(db);
  const next: CalculatorConfig = { ...current };

  if (b.hpPerHandgunRound !== undefined) {
    if (!inRange(b.hpPerHandgunRound, L.hpPerHandgunRound.min, L.hpPerHandgunRound.max)) {
      throw new CalculatorError(
        `HP per handgun round must be a number from ${L.hpPerHandgunRound.min} to ${L.hpPerHandgunRound.max}.`
      );
    }
    next.hpPerHandgunRound = round(b.hpPerHandgunRound, 2);
  }
  if (b.damagePerLevel !== undefined) {
    if (!inRange(b.damagePerLevel, L.damagePerLevel.min, L.damagePerLevel.max)) {
      throw new CalculatorError(
        `Extra damage per upgrade level must be a number from ${L.damagePerLevel.min} to ${L.damagePerLevel.max} (percent).`
      );
    }
    next.damagePerLevel = round(b.damagePerLevel, 1);
  }
  if (b.bosses !== undefined) {
    if (!Array.isArray(b.bosses)) throw new CalculatorError("Invalid boss list.");
    if (b.bosses.length > L.bosses.max) throw new CalculatorError(`You can have at most ${L.bosses.max} bosses.`);
    const seen = new Set<string>();
    next.bosses = b.bosses.map((raw, i) => checkBoss(raw, i, seen));
  }

  // Gun values: check every one before anything is saved.
  const hreChanges: Array<{ item: Item; hre: number | null }> = [];
  if (b.hre !== undefined) {
    if (b.hre === null || typeof b.hre !== "object" || Array.isArray(b.hre)) {
      throw new CalculatorError("Invalid handgun round values.");
    }
    for (const [key, value] of Object.entries(b.hre as Record<string, unknown>)) {
      const id = Number(key);
      const item = Number.isInteger(id) && id > 0 ? findItemById(db, id) : undefined;
      if (!item) throw new CalculatorError("One of these guns no longer exists. Refresh and try again.");
      if (item.kind !== "gun") throw new CalculatorError(`${item.name} isn't a gun.`);
      if (value !== null && !inRange(value, L.hre.min, L.hre.max)) {
        throw new CalculatorError(
          `${item.name}: 1 round must be worth a number of handgun rounds above 0 (like 1, 1.5 or 5), up to ${L.hre.max}.`
        );
      }
      // Two decimals, same as the item form.
      const hre = value === null ? null : round(value as number, 2) || L.hre.min;
      if (hre !== item.hre) hreChanges.push({ item, hre });
    }
  }

  transaction(db, () => {
    db.prepare(
      `INSERT INTO game_state (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`
    ).run(KEY, JSON.stringify(next));
    // Through updateItem, so anything watching item changes hears about it.
    for (const { item, hre } of hreChanges) updateItem(db, item.id, { hre });
  });

  return {
    config: getCalculator(db),
    hreChanged: hreChanges.length > 0,
    damagePerLevelChanged: next.damagePerLevel !== current.damagePerLevel,
  };
}

// ---- What the calculator shows ----------------------------------------------------

// One gun in the "Gun power" table. damagePct / callDamage are per upgrade
// level (index 0 = level 1), worked out with the saved settings.
export interface CalcGun {
  itemId: number;
  name: string;
  imageUrl: string | null;
  enabled: boolean;
  hre: number; // the value used (the default 1 when not set)
  hreSet: boolean; // false = not set on the item yet (using the default)
  magazineBase: number; // rounds in the magazine at level 1
  ammo: Array<{ itemId: number; name: string }>; // ammo items that fit it
  damagePct: number[]; // damage % at levels 1–5 (100, 115, …)
  callDamage: number[]; // HP to call for a hit at levels 1–5
}

// What the team carries right now, in handgun rounds.
export interface GunFirepower {
  itemId: number;
  name: string;
  hre: number;
  roundsHeld: number; // matching ammo in players' cases
  loaded: number; // rounds inside their guns' magazines
  rounds: number; // roundsHeld + loaded
  handgunRounds: number; // rounds × hre
  dropBoxRounds: number; // in the drop box (not counted: nobody holds them)
  dropBoxHandgunRounds: number;
}

export interface Firepower {
  guns: GunFirepower[];
  totalRounds: number;
  totalHandgunRounds: number;
  dropBoxHandgunRounds: number;
  unlinkedRounds: number; // ammo not linked to any gun (can't be counted)
  playersCounted: number; // players who can play: account on and not down
  playersNotCounted: number; // down or switched off
  vsBosses: Array<{
    bossId: string;
    name: string;
    phaseHandgunRounds: number[]; // per phase: handgunRounds × scale^(phase − 1), rounded
    totalHandgunRounds: number;
    enough: boolean;
    shortBy: number; // handgun rounds still needed (0 when enough)
  }>;
}

const hreOf = (item: Pick<Item, "hre">) => item.hre ?? DEFAULT_HRE;

// Handgun rounds a boss absorbs in each phase.
export function bossPhases(boss: Boss): number[] {
  const out: number[] = [];
  for (let p = 1; p <= boss.phases; p++) out.push(Math.round(boss.handgunRounds * boss.scalePerPhase ** (p - 1)));
  return out;
}

function listGunItems(db: DatabaseSync): Item[] {
  return db.prepare("SELECT * FROM items WHERE kind = 'gun' ORDER BY name COLLATE NOCASE").all() as unknown as Item[];
}

function ammoByGun(db: DatabaseSync): Map<number, Array<{ id: number; name: string }>> {
  const rows = db
    .prepare(
      `SELECT id, name, ammo_for_item_id AS gun FROM items
        WHERE kind = 'ammo' AND ammo_for_item_id IS NOT NULL ORDER BY name COLLATE NOCASE`
    )
    .all() as unknown as Array<{ id: number; name: string; gun: number }>;
  const out = new Map<number, Array<{ id: number; name: string }>>();
  for (const r of rows) out.set(r.gun, [...(out.get(r.gun) ?? []), { id: r.id, name: r.name }]);
  return out;
}

export function listCalcGuns(db: DatabaseSync, config: CalculatorConfig): CalcGun[] {
  const ammo = ammoByGun(db);
  return listGunItems(db).map((g) => {
    const hre = hreOf(g);
    const levels = Array.from({ length: MAX_LEVEL }, (_, i) => i + 1);
    const pct = levels.map((l) => damagePct(config.damagePerLevel, l));
    return {
      itemId: g.id,
      name: g.name,
      imageUrl: imageUrlFor(g.image_file),
      enabled: g.enabled === 1,
      hre,
      hreSet: g.hre !== null,
      magazineBase: g.base_magazine ?? DEFAULT_BASE.magazine,
      ammo: (ammo.get(g.id) ?? []).map((a) => ({ itemId: a.id, name: a.name })),
      damagePct: pct,
      callDamage: pct.map((p) => Math.round((hre * config.hpPerHandgunRound * p) / 100)),
    };
  });
}

// Counts the team's ammo, live. Only players who can play right now count
// (account switched on, not down): a downed player can't shoot until the
// Admin revives them. Rounds in the drop box are shown apart, because
// nobody holds them until someone picks them up.
export function computeFirepower(db: DatabaseSync, config: CalculatorConfig): Firepower {
  const counts = db
    .prepare(
      `SELECT SUM(CASE WHEN status = 'active' AND dead = 0 THEN 1 ELSE 0 END) AS counted,
              COUNT(*) AS total
         FROM users WHERE role = 'player'`
    )
    .get() as { counted: number | null; total: number };
  const playing = "u.role = 'player' AND u.status = 'active' AND u.dead = 0";

  // Units held of each item (ammo: one unit = one round).
  const held = new Map<number, number>();
  for (const r of db
    .prepare(
      `SELECT inv.item_id AS id, SUM(inv.quantity) AS n FROM inventory inv
         JOIN users u ON u.id = inv.player_id WHERE ${playing} GROUP BY inv.item_id`
    )
    .all() as unknown as Array<{ id: number; n: number }>) {
    held.set(r.id, r.n);
  }
  // Rounds loaded in each gun's magazines (not part of inventory counts).
  const loaded = new Map<number, number>();
  for (const r of db
    .prepare(
      `SELECT p.item_id AS id, SUM(p.loaded) AS n FROM inventory_pieces p
         JOIN users u ON u.id = p.player_id WHERE ${playing} GROUP BY p.item_id`
    )
    .all() as unknown as Array<{ id: number; n: number }>) {
    loaded.set(r.id, r.n);
  }
  // The drop box: ammo lying there, and rounds inside dropped guns.
  const dropped = new Map<number, { quantity: number; loaded: number }>();
  for (const r of db
    .prepare("SELECT item_id AS id, SUM(quantity) AS q, SUM(loaded) AS l FROM dropped_items GROUP BY item_id")
    .all() as unknown as Array<{ id: number; q: number; l: number }>) {
    dropped.set(r.id, { quantity: r.q, loaded: r.l });
  }

  const ammo = ammoByGun(db);
  const guns: GunFirepower[] = listGunItems(db).map((g) => {
    const hre = hreOf(g);
    const myAmmo = ammo.get(g.id) ?? [];
    const roundsHeld = myAmmo.reduce((sum, a) => sum + (held.get(a.id) ?? 0), 0);
    const inGuns = loaded.get(g.id) ?? 0;
    const dropBoxRounds =
      myAmmo.reduce((sum, a) => sum + (dropped.get(a.id)?.quantity ?? 0), 0) + (dropped.get(g.id)?.loaded ?? 0);
    const rounds = roundsHeld + inGuns;
    return {
      itemId: g.id,
      name: g.name,
      hre,
      roundsHeld,
      loaded: inGuns,
      rounds,
      handgunRounds: round(rounds * hre, 2),
      dropBoxRounds,
      dropBoxHandgunRounds: round(dropBoxRounds * hre, 2),
    };
  });

  // Ammo whose gun isn't set (or isn't a gun any more) can't be converted.
  const gunIds = new Set(guns.map((g) => g.itemId));
  const ammoRows = db
    .prepare("SELECT id, ammo_for_item_id AS gun FROM items WHERE kind = 'ammo'")
    .all() as unknown as Array<{ id: number; gun: number | null }>;
  const unlinkedRounds = ammoRows
    .filter((a) => a.gun === null || !gunIds.has(a.gun))
    .reduce((sum, a) => sum + (held.get(a.id) ?? 0), 0);

  const totalHandgunRounds = round(
    guns.reduce((sum, g) => sum + g.handgunRounds, 0),
    2
  );
  return {
    guns,
    totalRounds: guns.reduce((sum, g) => sum + g.rounds, 0),
    totalHandgunRounds,
    dropBoxHandgunRounds: round(
      guns.reduce((sum, g) => sum + g.dropBoxHandgunRounds, 0),
      2
    ),
    unlinkedRounds,
    playersCounted: counts.counted ?? 0,
    playersNotCounted: counts.total - (counts.counted ?? 0),
    vsBosses: config.bosses.map((boss) => {
      const phaseHandgunRounds = bossPhases(boss);
      const total = phaseHandgunRounds.reduce((a, b) => a + b, 0);
      return {
        bossId: boss.id,
        name: boss.name,
        phaseHandgunRounds,
        totalHandgunRounds: total,
        enough: totalHandgunRounds >= total,
        shortBy: Math.max(0, round(total - totalHandgunRounds, 2)),
      };
    }),
  };
}

// Everything GET /api/admin/calculator answers with.
export function calculatorSnapshot(db: DatabaseSync) {
  const config = getCalculator(db);
  return {
    config,
    defaults: { ...CALC_DEFAULTS, boss: DEFAULT_BOSS, hre: DEFAULT_HRE },
    limits: CALC_LIMITS,
    maxLevel: MAX_LEVEL,
    guns: listCalcGuns(db, config),
    firepower: computeFirepower(db, config),
  };
}
