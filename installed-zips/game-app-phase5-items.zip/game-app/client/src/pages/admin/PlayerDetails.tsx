import { FormEvent, useEffect, useState } from "react";
import { Button } from "../../components/Button";
import { ConfirmCard } from "../../components/ConfirmCard";
import { ErrorBanner } from "../../components/ErrorBanner";
import { PasswordField, TextField } from "../../components/Field";
import { getPlayer, Player, resetPlayerPassword, updatePlayer } from "../../services/api";
import { formatDate } from "../../utils/format";
import { MoneySection } from "./MoneySection";
import { InventorySection } from "./InventorySection";

export function PlayerDetails({ id, onBack }: { id: number; onBack: () => void }) {
  const [player, setPlayer] = useState<Player | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [editError, setEditError] = useState<string | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);

  const [confirmingStatus, setConfirmingStatus] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);
  const [savingStatus, setSavingStatus] = useState(false);

  const [showReset, setShowReset] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetDone, setResetDone] = useState(false);
  const [savingReset, setSavingReset] = useState(false);

  useEffect(() => {
    getPlayer(id)
      .then((p) => {
        setPlayer(p);
        setUsername(p.username);
        setDisplayName(p.displayName || "");
      })
      .catch((err) => setLoadError(err instanceof Error ? err.message : "Failed to load player."));
  }, [id]);

  async function handleSaveEdit(e: FormEvent) {
    e.preventDefault();
    if (!player || savingEdit) return;
    setEditError(null);
    setSavingEdit(true);
    try {
      const updated = await updatePlayer(player.id, {
        username,
        displayName: displayName || null,
      });
      setPlayer(updated);
    } catch (err) {
      setEditError(err instanceof Error ? err.message : "Could not save changes.");
    } finally {
      setSavingEdit(false);
    }
  }

  async function handleToggleStatus() {
    if (!player) return;
    setStatusError(null);
    setSavingStatus(true);
    try {
      const nextStatus = player.status === "active" ? "disabled" : "active";
      const updated = await updatePlayer(player.id, { status: nextStatus });
      setPlayer(updated);
      setConfirmingStatus(false);
    } catch (err) {
      setStatusError(err instanceof Error ? err.message : "Could not update status.");
    } finally {
      setSavingStatus(false);
    }
  }

  async function handleResetPassword(e: FormEvent) {
    e.preventDefault();
    if (!player || savingReset) return;
    setResetError(null);
    if (newPassword !== confirmNewPassword) {
      setResetError("Passwords do not match.");
      return;
    }
    setSavingReset(true);
    try {
      await resetPlayerPassword(player.id, {
        password: newPassword,
        confirmPassword: confirmNewPassword,
      });
      setResetDone(true);
      setNewPassword("");
      setConfirmNewPassword("");
    } catch (err) {
      setResetError(err instanceof Error ? err.message : "Could not reset password.");
    } finally {
      setSavingReset(false);
    }
  }

  if (loadError) {
    return (
      <div className="flex flex-col gap-4">
        <ErrorBanner message={loadError} />
        <Button variant="ghost" onClick={onBack}>
          Back to Players
        </Button>
      </div>
    );
  }

  if (!player) {
    return <p className="text-ink/60">Loading…</p>;
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="text-lg text-ink/60">Player</p>
        <h2 className="text-3xl font-bold text-pine">{player.displayName || player.username}</h2>
        <p className={`font-medium ${player.status === "active" ? "text-pine" : "text-alert"}`}>
          Status: {player.status === "active" ? "Active" : "Disabled"}
        </p>
        <p className="text-sm text-ink/50">Created: {formatDate(player.createdAt)}</p>
      </div>

      <MoneySection
        playerId={player.id}
        balance={player.balance}
        onBalanceChange={(balance) => setPlayer((p) => (p ? { ...p, balance } : p))}
      />

      <InventorySection playerId={player.id} />

      <form onSubmit={handleSaveEdit} className="flex flex-col gap-4 rounded-2xl border-2 border-ink/15 bg-white p-4">
        <ErrorBanner message={editError} />
        <TextField
          id="edit-username"
          label="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <TextField
          id="edit-display-name"
          label="Display name"
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
        />
        <Button type="submit" loading={savingEdit}>
          Save changes
        </Button>
      </form>

      <div className="flex flex-col gap-3">
        <ErrorBanner message={statusError} />
        {confirmingStatus ? (
          <ConfirmCard
            title={`${player.status === "active" ? "Disable" : "Enable"} ${player.displayName || player.username}?`}
            body={
              player.status === "active"
                ? `${player.displayName || player.username} will no longer be able to log in.`
                : `${player.displayName || player.username} will be able to log in again.`
            }
            confirmLabel={player.status === "active" ? "Disable" : "Enable"}
            onConfirm={handleToggleStatus}
            onCancel={() => setConfirmingStatus(false)}
            loading={savingStatus}
          />
        ) : (
          <Button variant="ghost" onClick={() => setConfirmingStatus(true)}>
            {player.status === "active" ? "Disable player" : "Enable player"}
          </Button>
        )}
      </div>

      <div className="flex flex-col gap-3 rounded-2xl border-2 border-ink/15 bg-white p-4">
        <button
          type="button"
          onClick={() => {
            setShowReset((v) => !v);
            setResetDone(false);
          }}
          className="text-left text-lg font-semibold text-pine"
        >
          Reset password {showReset ? "▲" : "▼"}
        </button>
        {showReset && (
          <form onSubmit={handleResetPassword} className="flex flex-col gap-4">
            <ErrorBanner message={resetError} />
            {resetDone && (
              <p className="rounded-xl bg-pine-soft px-4 py-3 text-ink/80">
                Password updated. Tell the player their new password.
              </p>
            )}
            <PasswordField
              id="reset-password"
              label="New password"
              autoComplete="new-password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
            />
            <PasswordField
              id="reset-confirm-password"
              label="Confirm new password"
              autoComplete="new-password"
              value={confirmNewPassword}
              onChange={(e) => setConfirmNewPassword(e.target.value)}
              required
            />
            <Button type="submit" loading={savingReset}>
              Set new password
            </Button>
          </form>
        )}
      </div>

      <Button variant="ghost" onClick={onBack}>
        Back to Players
      </Button>
    </div>
  );
}
