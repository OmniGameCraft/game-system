import { Icon } from "./Icon";

export function BackButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="press -ml-2 flex min-h-[2.75rem] w-fit items-center gap-1 rounded-md px-2 pr-3 text-base font-bold text-pine active:bg-pine-soft"
    >
      <Icon name="back" className="h-5 w-5" />
      {label}
    </button>
  );
}
