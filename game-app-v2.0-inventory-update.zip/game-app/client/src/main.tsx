import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { applyDocumentSettings } from "./audio/settings";
import { installClickSounds } from "./audio/clicks";
import { ToastHost } from "./components/Toast";
import "./index.css";

// Text size / reduce-motion classes before the first paint, and one global
// listener that gives every button its click sound.
applyDocumentSettings();
installClickSounds();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
    <ToastHost />
  </React.StrictMode>
);
