import { useEffect, useState } from "react";
import { ErrorBanner } from "../components/ErrorBanner";
import { Icon } from "../components/Icon";
import { ItemImage } from "../components/ItemImage";
import { Section, SectionAction } from "../components/Section";
import { getMyInventory, InventoryEntry } from "../services/api";

export function PlayerInventory() {
  const [inventory, setInventory] = useState<InventoryEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function load() {
    setError(null);
    setLoading(true);
    getMyInventory()
      .then(setInventory)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load."))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  const refresh = (
    <SectionAction onClick={load} disabled={loading}>
      <Icon name="refresh" className="h-4 w-4" />
      {loading ? "…" : "Refresh"}
    </SectionAction>
  );

  return (
    <>
      <ErrorBanner message={error} />
      <Section title={`My items${inventory ? ` (${inventory.length})` : ""}`} action={refresh} flush>
        {inventory === null && !error && <p className="p-4 text-ink/60">Loading…</p>}
        {inventory?.length === 0 && <p className="px-4 py-8 text-center text-lg text-ink/70">Your bag is empty.</p>}
        <ul className="divide-y-2 divide-ink/5">
          {inventory?.map((e) => (
            <li key={e.itemId} className="flex gap-4 px-4 py-3">
              <ItemImage url={e.imageUrl} name={e.name} />
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-lg font-bold leading-tight text-ink">{e.name}</p>
                  <span className="shrink-0 rounded-lg bg-pine px-2.5 py-1 text-lg font-extrabold leading-none text-white">
                    ×{e.quantity}
                  </span>
                </div>
                {e.category && <p className="text-sm font-semibold text-ink/55">{e.category}</p>}
                {e.description && <p className="mt-1 text-sm text-ink/80">{e.description}</p>}
              </div>
            </li>
          ))}
        </ul>
      </Section>
    </>
  );
}
