import { Button } from "./Button";

// "Are you sure?" card that appears in place, with Cancel and the action.
export function ConfirmCard({
  title,
  body,
  confirmLabel,
  onConfirm,
  onCancel,
  loading,
  tone = "danger",
}: {
  title: string;
  body: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
  tone?: "danger" | "primary";
}) {
  const danger = tone === "danger";
  return (
    <div
      role="alertdialog"
      aria-label={title}
      className={`flex animate-pop flex-col gap-3 rounded-lg border p-4 shadow-lift ${
        danger
          ? "border-alert/60 bg-[linear-gradient(180deg,rgba(255,90,79,0.12),rgba(255,90,79,0.04))]"
          : "border-pine/60 bg-[linear-gradient(180deg,rgba(245,165,36,0.14),rgba(245,165,36,0.04))]"
      }`}
    >
      <div className="flex items-start gap-3">
        <span
          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
            danger ? "bg-alert/20 text-alert" : "bg-pine-soft text-pine"
          }`}
          aria-hidden
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
            {danger ? (
              <>
                <path d="M12 3.5L2.5 20h19L12 3.5z" />
                <path d="M12 10v4.5M12 17.2h.01" />
              </>
            ) : (
              <>
                <circle cx="12" cy="12" r="9.5" />
                <path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14M12 17.5h.01" />
              </>
            )}
          </svg>
        </span>
        <div className="min-w-0">
          <p className="text-xl font-bold leading-tight text-ink">{title}</p>
          <p className="mt-1 text-ink/75">{body}</p>
        </div>
      </div>
      <div className="flex gap-3">
        <Button variant="ghost" size="md" onClick={onCancel} disabled={loading}>
          Cancel
        </Button>
        <Button variant={danger ? "danger" : "primary"} size="md" onClick={onConfirm} loading={loading}>
          {confirmLabel}
        </Button>
      </div>
    </div>
  );
}
