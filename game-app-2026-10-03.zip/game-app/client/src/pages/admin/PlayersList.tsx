import { useEffect, useState } from "react";
import { useLive } from "../../services/live";
import { Avatar } from "../../components/Avatar";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { Section } from "../../components/Section";
import { listPlayers, Player } from "../../services/api";

export function PlayersList({ onCreate, onOpen }: { onCreate: () => void; onOpen: (id: number) => void }) {
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [tick, setTick] = useState(0);
  useLive(["players:changed"], () => setTick((t) => t + 1));

  useEffect(() => {
    listPlayers()
      .then(setPlayers)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load players."));
  }, [tick]);

  return (
    <>
      <Button onClick={onCreate}>+ Create Player</Button>
      <ErrorBanner message={error} />
      <Section title={`All players${players ? ` (${players.length})` : ""}`} flush>
        {players === null && !error && <p className="p-4 text-ink/60">Loading…</p>}
        {players?.length === 0 && <p className="p-4 text-ink/70">No players yet. Tap “Create Player” to add the first one.</p>}
        <ul className="divide-y-2 divide-ink/5">
          {players?.map((p) => (
            <li key={p.id}>
              <button onClick={() => onOpen(p.id)} className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-pine-soft">
                <Avatar name={p.displayName || p.username} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-lg font-bold text-ink">{p.displayName || p.username}</p>
                  <p className="truncate text-sm text-ink/55">@{p.username}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-2">
                    <Badge tone={p.status === "active" ? "good" : "bad"}>{p.status === "active" ? "Active" : "Disabled"}</Badge>
                    <span className="text-sm font-bold text-ink/70">${p.balance}</span>
                  </div>
                </div>
                <Icon name="chevron" className="h-5 w-5 shrink-0 text-ink/30" />
              </button>
            </li>
          ))}
        </ul>
      </Section>
    </>
  );
}
