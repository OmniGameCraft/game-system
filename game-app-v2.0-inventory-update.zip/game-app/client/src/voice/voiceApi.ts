import { useEffect, useState } from "react";
import { useLive } from "../services/live";

// Server calls for voice hit calls.

export interface VoiceInfo {
  digits: number; // how many digits of a call are the player number (1 or 2)
  enabled: boolean; // the Admin's "voice hits" rule
  active: boolean; // the game is running (calls only count then)
  windowMs: number; // the same call heard by several phones within this time counts once
  myNumber: number | null; // this player's own number (null for the Admin)
}

export interface VoiceHitResult {
  applied: boolean; // this phone's call took the HP off
  duplicate: boolean; // another phone already reported the same call
  playerNumber: number;
  damage: number;
}

// Error with the server's friendly message and the HTTP status.
export class VoiceApiError extends Error {
  constructor(message: string, public status: number) {
    super(message);
  }
}

async function readJson(res: Response): Promise<any> {
  let body: any = null;
  try {
    body = await res.json();
  } catch {
    // no JSON body
  }
  if (!res.ok) throw new VoiceApiError(body?.error || "Something went wrong. Please try again.", res.status);
  return body;
}

export async function getVoiceInfo(): Promise<VoiceInfo> {
  const body = await readJson(await fetch("/api/voice/info"));
  return {
    digits: body?.digits === 2 ? 2 : 1,
    enabled: body?.enabled !== false,
    active: Boolean(body?.active),
    windowMs: typeof body?.windowMs === "number" ? body.windowMs : 4000,
    myNumber: typeof body?.myNumber === "number" ? body.myNumber : null,
  };
}

export async function sendVoiceHit(input: { target: number; damage: number; heard: string }): Promise<VoiceHitResult> {
  const res = await fetch("/api/voice/hit", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...input, heard: input.heard.slice(0, 200) }),
  });
  return readJson(res);
}

// Keeps the voice info fresh: it changes when the game starts/stops, when
// the Admin changes the rules, and when a player number above 9 appears.
// Returns null until the first answer.
export function useVoiceInfo(): VoiceInfo | null {
  const [info, setInfo] = useState<VoiceInfo | null>(null);
  const load = () => {
    getVoiceInfo()
      .then(setInfo)
      .catch(() => {
        // offline for a moment: keep what we had, the next notice retries
      });
  };
  useEffect(() => {
    load();
    // A slow safety refresh: a new player numbered 10+ changes the digit
    // count, and not every phone gets a notice for that.
    const t = window.setInterval(load, 60_000);
    return () => window.clearInterval(t);
  }, []);
  // "rules:changed" is added to LiveEvent by the case update; the cast keeps
  // this file compiling on its own.
  useLive(["game:changed", "me:changed", "players:changed", "rules:changed" as never], load);
  return info;
}
