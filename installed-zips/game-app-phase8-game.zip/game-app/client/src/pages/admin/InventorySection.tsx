import { useEffect, useState } from "react";
import { useLive } from "../../services/live";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls } from "../../components/Field";
import { ItemImage } from "../../components/ItemImage";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import {
  AdminInventory,
  AdminInventoryAction,
  changePlayerInventory,
  getPlayerInventory,
  InventoryLogEntry,
  Item,
  listItems,
} from "../../services/api";
import { formatDateTime } from "../../utils/format";

function describeLog(l: InventoryLogEntry): { text: string; up: boolean } {
  const diff = l.quantityAfter - l.quantityBefore;
  const up = diff > 0;
  if (l.action === "SET") return { text: `${l.itemName} set to ${l.quantityAfter}`, up };
  if (l.action === "PURCHASE") return { text: `Bought ${diff} ${l.itemName}`, up: true };
  return { text: `${up ? "Given" : "Removed"} ${Math.abs(diff)} ${l.itemName}`, up };
}

export function InventorySection({ playerId }: { playerId: number }) {
  const [data, setData] = useState<AdminInventory | null>(null);
  const [items, setItems] = useState<Item[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [itemId, setItemId] = useState<string>("");
  const [quantity, setQuantity] = useState("1");
  const [pending, setPending] = useState<AdminInventoryAction | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [tick, setTick] = useState(0);
  useLive(["player:changed", "items:changed"], (payload) => {
    if (!payload || payload.playerId === undefined || payload.playerId === playerId) setTick((t) => t + 1);
  });

  useEffect(() => {
    Promise.all([getPlayerInventory(playerId), listItems()])
      .then(([inv, all]) => {
        setData(inv);
        setItems(all);
      })
      .catch((err) => setLoadError(err instanceof Error ? err.message : "Failed to load inventory."));
  }, [playerId, tick]);

  const selected = items?.find((i) => i.id === Number(itemId));
  const owned = data?.inventory.find((e) => e.itemId === Number(itemId));

  async function handleChange(action: AdminInventoryAction) {
    setError(null);
    setNotice(null);
    const id = Number(itemId);
    if (!id) {
      setError("Choose an item first.");
      return;
    }
    const q = Number(quantity);
    const min = action === "SET" ? 0 : 1;
    if (!Number.isInteger(q) || q < min) {
      setError(action === "SET" ? "Enter a whole number, 0 or more." : "Enter a whole number greater than 0.");
      return;
    }
    setPending(action);
    try {
      const next = await changePlayerInventory(playerId, { itemId: id, action, quantity: q });
      setData(next);
      const now = next.inventory.find((e) => e.itemId === id)?.quantity ?? 0;
      setNotice(`${selected?.name ?? "Item"}: now has ${now}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update the inventory.");
    } finally {
      setPending(null);
    }
  }

  return (
    <>
      <Section title={`Inventory${data ? ` (${data.inventory.length})` : ""}`} flush>
        <ErrorBanner message={loadError} />
        {!data && !loadError && <p className="p-4 text-ink/60">Loading…</p>}
        {data?.inventory.length === 0 && <p className="p-4 text-ink/60">This player has no items.</p>}
        {data && data.inventory.length > 0 && (
          <ul className="divide-y-2 divide-ink/5">
            {data.inventory.map((e) => (
              <li key={e.itemId}>
                <button
                  type="button"
                  onClick={() => setItemId(String(e.itemId))}
                  className={`flex w-full items-center gap-3 px-4 py-2 text-left ${
                    String(e.itemId) === itemId ? "bg-pine-soft" : "active:bg-pine-soft"
                  }`}
                >
                  <ItemImage url={e.imageUrl} name={e.name} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-bold">{e.name}</p>
                    {e.enabled === false && <p className="text-xs font-bold text-alert">Item disabled</p>}
                  </div>
                  <span className="text-xl font-display font-bold tabular-nums text-pine">×{e.quantity}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="Give or remove items">
        {items && items.length === 0 ? (
          <p className="text-ink/70">Create items in the Items tab first, then you can give them to players.</p>
        ) : (
          <>
            <ErrorBanner message={error} />
            <Notice message={notice} />
            <label htmlFor="inv-item" className="block">
              <span className="mb-1 block text-base font-semibold text-ink/80">Item</span>
              <select id="inv-item" value={itemId} onChange={(e) => setItemId(e.target.value)} className={inputCls}>
                <option value="">Choose an item…</option>
                {items?.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.name}
                    {!i.enabled ? " (disabled)" : ""}
                  </option>
                ))}
              </select>
              {selected && (
                <span className="mt-1 block text-sm text-ink/60">
                  Has {owned?.quantity ?? 0}
                  {selected.maxStack !== null && ` · max ${selected.maxStack} per player`}
                  {!selected.enabled && " · disabled, can only be removed"}
                </span>
              )}
            </label>
            <label htmlFor="inv-qty" className="block">
              <span className="mb-1 block text-base font-semibold text-ink/80">Quantity</span>
              <input
                id="inv-qty"
                type="number"
                inputMode="numeric"
                min={0}
                step={1}
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className={inputCls}
              />
            </label>
            <div className="grid grid-cols-2 gap-3">
              <Button onClick={() => handleChange("GIVE")} loading={pending === "GIVE"} disabled={pending !== null}>
                + Give
              </Button>
              <Button variant="danger" onClick={() => handleChange("REMOVE")} loading={pending === "REMOVE"} disabled={pending !== null}>
                − Remove
              </Button>
            </div>
            <Button variant="ghost" size="md" onClick={() => handleChange("SET")} loading={pending === "SET"} disabled={pending !== null}>
              Set to exactly {quantity || "…"}
            </Button>
          </>
        )}
      </Section>

      <Section title="Item history" flush>
        {data && data.log.length === 0 && <p className="p-4 text-ink/60">No item changes yet.</p>}
        {data && data.log.length > 0 && (
          <ul className="divide-y-2 divide-ink/5">
            {data.log.map((l) => {
              const d = describeLog(l);
              return (
                <li key={l.id} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="font-semibold">{d.text}</p>
                    <p className="text-sm text-ink/55">
                      {formatDateTime(l.createdAt)} · now {l.quantityAfter}
                    </p>
                  </div>
                  <span className={`shrink-0 text-lg font-display font-bold ${d.up ? "text-pine" : "text-alert"}`}>
                    {d.up ? "+" : "−"}
                    {Math.abs(l.quantityAfter - l.quantityBefore)}
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </Section>
    </>
  );
}
