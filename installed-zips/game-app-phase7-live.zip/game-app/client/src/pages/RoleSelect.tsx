import { Icon } from "../components/Icon";
import { Role } from "../services/api";

export function RoleSelect({ onSelect }: { onSelect: (role: Role) => void }) {
  return (
    <div className="flex flex-col gap-4">
      <p className="text-center text-lg font-semibold text-ink/60">Who are you?</p>
      <button
        onClick={() => onSelect("player")}
        className="flex items-center gap-4 rounded-2xl border-2 border-pine bg-pine px-5 py-5 text-left text-white shadow"
      >
        <Icon name="users" className="h-9 w-9 shrink-0" />
        <span>
          <span className="block text-2xl font-extrabold">Player</span>
          <span className="text-base text-white/80">Join the game</span>
        </span>
      </button>
      <button
        onClick={() => onSelect("admin")}
        className="flex items-center gap-4 rounded-2xl border-2 border-pine/30 bg-white px-5 py-5 text-left text-ink shadow-sm"
      >
        <Icon name="box" className="h-9 w-9 shrink-0 text-pine" />
        <span>
          <span className="block text-2xl font-extrabold">Admin</span>
          <span className="text-base text-ink/60">Run the game</span>
        </span>
      </button>
    </div>
  );
}
