import { useEffect, useState } from "react";
import { Badge } from "../components/Badge";
import { Button } from "../components/Button";
import { ErrorBanner } from "../components/ErrorBanner";
import { Icon } from "../components/Icon";
import { ItemImage } from "../components/ItemImage";
import { Notice } from "../components/Notice";
import { Section, SectionAction } from "../components/Section";
import { Stepper } from "../components/Stepper";
import { buy, getShop, PlayerListing } from "../services/api";

export function PlayerShop({ balance, onBalanceChanged }: { balance: number; onBalanceChanged: () => Promise<void> }) {
  const [open, setOpen] = useState<boolean | null>(null);
  const [listings, setListings] = useState<PlayerListing[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function load() {
    setError(null);
    setLoading(true);
    return getShop()
      .then((s) => {
        setOpen(s.open);
        setListings(s.listings);
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load the shop."))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, []);

  async function afterPurchase(message: string) {
    setNotice(message);
    window.scrollTo({ top: 0, behavior: "smooth" });
    await Promise.all([load(), onBalanceChanged()]);
  }

  const refresh = (
    <SectionAction onClick={() => void load()} disabled={loading}>
      <Icon name="refresh" className="h-4 w-4" />
      {loading ? "…" : "Refresh"}
    </SectionAction>
  );

  if (open === null) {
    return error ? <ErrorBanner message={error} /> : <p className="text-ink/60">Loading…</p>;
  }

  if (!open) {
    return (
      <Section title="Shop" tone="alert" action={refresh}>
        <ErrorBanner message={error} />
        <div className="flex flex-col items-center gap-2 py-8 text-center">
          <Icon name="store" className="h-14 w-14 text-alert" />
          <p className="text-3xl font-extrabold text-alert">Shop Closed</p>
          <p className="text-ink/70">The Admin will open the shop during the game. Tap Refresh to check again.</p>
        </div>
      </Section>
    );
  }

  const groups = new Map<string, PlayerListing[]>();
  for (const l of listings) {
    const k = l.category || "Other";
    groups.set(k, [...(groups.get(k) ?? []), l]);
  }

  return (
    <>
      <div className="flex items-center justify-between gap-3 rounded-2xl border-2 border-pine bg-pine-soft px-4 py-3">
        <span className="flex items-center gap-2 text-lg font-extrabold text-pine">
          <span className="h-3 w-3 rounded-full bg-pine" aria-hidden />
          SHOP OPEN
        </span>
        <button onClick={() => void load()} disabled={loading} className="flex min-h-[2.5rem] items-center gap-1 rounded-lg px-2 font-bold text-pine">
          <Icon name="refresh" className="h-4 w-4" />
          {loading ? "…" : "Refresh"}
        </button>
      </div>
      <ErrorBanner message={error} />
      <Notice message={notice} />
      {listings.length === 0 && (
        <Section title="Nothing for sale">
          <p className="text-ink/70">The shop is open but empty right now.</p>
        </Section>
      )}
      {[...groups.entries()]
        .sort(([a], [b]) => (a === "Other" ? 1 : b === "Other" ? -1 : a.localeCompare(b)))
        .map(([g, ls]) => (
        <Section key={g} title={g} flush>
          <ul className="divide-y-2 divide-ink/5">
            {ls.map((l) => (
              <ShopCard key={l.id} listing={l} balance={balance} onBought={afterPurchase} onClearNotice={() => setNotice(null)} />
            ))}
          </ul>
        </Section>
      ))}
    </>
  );
}

function ShopCard({
  listing: l,
  balance,
  onBought,
  onClearNotice,
}: {
  listing: PlayerListing;
  balance: number;
  onBought: (message: string) => Promise<void>;
  onClearNotice: () => void;
}) {
  const [qty, setQty] = useState(1);
  const [confirming, setConfirming] = useState(false);
  const [buying, setBuying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const limits = [l.stock, l.maxPerPurchase, l.maxStack !== null ? l.maxStack - l.owned : null].filter(
    (n): n is number => n !== null
  );
  const max = limits.length ? Math.min(...limits) : 999;
  const outOfStock = l.stock === 0;
  const full = l.maxStack !== null && l.owned >= l.maxStack;
  const total = l.price * qty;
  const tooExpensive = total > balance;
  const canBuy = !outOfStock && !full && max >= 1 && !tooExpensive;

  useEffect(() => {
    if (qty > Math.max(1, max)) setQty(Math.max(1, max));
  }, [max]);

  async function handleBuy() {
    setBuying(true);
    setError(null);
    try {
      const r = await buy({ shopItemId: l.id, quantity: qty, expectedPrice: l.price });
      setConfirming(false);
      setQty(1);
      await onBought(`Bought ${r.quantity} × ${r.itemName} for $${r.total}. It's in your bag.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to complete purchase. Please try again.");
      setConfirming(false);
    } finally {
      setBuying(false);
    }
  }

  return (
    <li className="flex flex-col gap-3 p-4">
      <div className="flex gap-4">
        <ItemImage url={l.imageUrl} name={l.name} size="lg" />
        <div className="min-w-0 flex-1">
          <p className="text-xl font-extrabold leading-tight text-ink">{l.name}</p>
          <p className="text-2xl font-extrabold tabular-nums text-pine">{l.price === 0 ? "Free" : `$${l.price}`}</p>
          <div className="mt-1 flex flex-wrap gap-1.5">
            {l.stock === null ? null : outOfStock ? (
              <Badge tone="bad">Out of stock</Badge>
            ) : (
              <Badge tone={l.stock <= 3 ? "warn" : "neutral"}>{l.stock} left</Badge>
            )}
            {l.owned > 0 && <Badge tone="good">You have {l.owned}</Badge>}
          </div>
        </div>
      </div>
      {l.description && <p className="text-ink/75">{l.description}</p>}

      <ErrorBanner message={error} />

      {outOfStock ? (
        <p className="rounded-xl bg-ink/5 px-4 py-3 text-center font-bold text-ink/60">Out of stock</p>
      ) : full ? (
        <p className="rounded-xl bg-ink/5 px-4 py-3 text-center font-bold text-ink/60">
          You're carrying the most allowed ({l.maxStack})
        </p>
      ) : confirming ? (
        <div className="flex flex-col gap-3 rounded-2xl border-2 border-pine bg-pine-soft p-4">
          <p className="text-lg font-bold">
            Buy {qty} × {l.name} for ${total}?
          </p>
          <p className="text-ink/70">You'll have ${balance - total} left.</p>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="ghost" size="md" onClick={() => setConfirming(false)} disabled={buying}>
              Cancel
            </Button>
            <Button size="md" onClick={handleBuy} loading={buying}>
              Confirm
            </Button>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between gap-3">
            <Stepper label={`How many ${l.name}`} value={qty} onChange={setQty} min={1} max={max} />
            <div className="text-right">
              <p className="text-sm font-semibold text-ink/55">Total</p>
              <p className={`text-2xl font-extrabold tabular-nums ${tooExpensive ? "text-alert" : "text-ink"}`}>${total}</p>
            </div>
          </div>
          {tooExpensive && <p className="text-sm font-bold text-alert">You don't have enough money for this.</p>}
          <Button
            disabled={!canBuy}
            onClick={() => {
              onClearNotice();
              setError(null);
              setConfirming(true);
            }}
          >
            Buy
          </Button>
        </>
      )}
    </li>
  );
}
