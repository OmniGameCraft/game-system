import { useEffect, useRef, useState } from "react";
import { getSettings } from "../audio/settings";

// A number that counts smoothly to its new value and gives a small bump when
// it changes (money, HP, ammo), like a game HUD. With "Reduce animations" on
// it just shows the new number.
export function TickNumber({
  value,
  duration = 350,
  className = "",
  format = (n: number) => String(n),
}: {
  value: number;
  duration?: number;
  className?: string;
  format?: (n: number) => string;
}) {
  const [shown, setShown] = useState(value);
  const [bump, setBump] = useState(0);
  const from = useRef(value);
  const frame = useRef<number | null>(null);

  useEffect(() => {
    if (value === from.current) return;
    const start = from.current;
    from.current = value;
    if (frame.current !== null) cancelAnimationFrame(frame.current);
    setBump((b) => b + 1);
    if (getSettings().reduceMotion || Math.abs(value - start) < 2) {
      setShown(value);
      return;
    }
    const t0 = performance.now();
    const step = (now: number) => {
      const k = Math.min(1, (now - t0) / duration);
      const eased = 1 - Math.pow(1 - k, 3);
      setShown(Math.round(start + (value - start) * eased));
      frame.current = k < 1 ? requestAnimationFrame(step) : null;
    };
    frame.current = requestAnimationFrame(step);
    return () => {
      if (frame.current !== null) cancelAnimationFrame(frame.current);
      frame.current = null;
      setShown(value);
    };
  }, [value, duration]);

  return (
    <span key={bump} className={`inline-block tabular-nums ${bump > 0 ? "animate-tick" : ""} ${className}`}>
      {format(shown)}
    </span>
  );
}
