import { DatabaseSync } from "node:sqlite";
import { fullHealAll, resetAllHp } from "./health";

export type GameStatus = "not_started" | "active" | "paused" | "ended";
export const GAME_STATUSES: GameStatus[] = ["not_started", "active", "paused", "ended"];
export const ANNOUNCEMENT_MAX = 300;

export function getGameStatus(db: DatabaseSync): { status: GameStatus; changedAt: string | null } {
  const row = db.prepare("SELECT value FROM game_state WHERE key = 'game_status'").get() as
    | { value: string }
    | undefined;
  const at = db.prepare("SELECT value FROM game_state WHERE key = 'game_status_at'").get() as
    | { value: string }
    | undefined;
  const status = GAME_STATUSES.includes(row?.value as GameStatus) ? (row!.value as GameStatus) : "not_started";
  return { status, changedAt: at?.value ?? null };
}

// Purchases are allowed before the game and while it runs, not while it is
// paused or after it has ended.
export function gameAllowsPlay(db: DatabaseSync): { ok: true } | { ok: false; reason: string } {
  const { status } = getGameStatus(db);
  if (status === "paused") return { ok: false, reason: "The game is paused." };
  if (status === "ended") return { ok: false, reason: "The game is over." };
  return { ok: true };
}

function setState(db: DatabaseSync, key: string, value: string) {
  db.prepare(
    `INSERT INTO game_state (key, value) VALUES (?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  ).run(key, value);
}

// ---- Hooks -------------------------------------------------------------------

// Other parts of the game that must react to the game starting, pausing or
// ending register here — e.g. the drop box gives unclaimed drops back to
// their owners when the game ends. Hooks run INSIDE the same database
// transaction as the status change: if one fails, nothing changes.
// `by` = the Admin who changed it (for audit rows the hook writes).
export type GameStatusHook = (db: DatabaseSync, from: GameStatus, to: GameStatus, by: number) => void;
const statusHooks: GameStatusHook[] = [];

export function onGameStatusChange(fn: GameStatusHook): () => void {
  statusHooks.push(fn);
  return () => {
    const i = statusHooks.indexOf(fn);
    if (i >= 0) statusHooks.splice(i, 1);
  };
}

// Same idea for "Start a new game" (e.g. forget recent voice calls).
export type RoundResetHook = (db: DatabaseSync) => void;
const resetHooks: RoundResetHook[] = [];

export function onRoundReset(fn: RoundResetHook): () => void {
  resetHooks.push(fn);
  return () => {
    const i = resetHooks.indexOf(fn);
    if (i >= 0) resetHooks.splice(i, 1);
  };
}

// One transaction: the new status, its history row, everything that comes
// with it (starting the game puts every player at full HP, alive) and the
// registered hooks. Returns the status it changed from.
export function setGameStatus(db: DatabaseSync, status: GameStatus, adminId: number): GameStatus {
  db.exec("BEGIN");
  try {
    const from = getGameStatus(db).status;
    setState(db, "game_status", status);
    setState(db, "game_status_at", new Date().toISOString());
    db.prepare("INSERT INTO game_events (type, status, created_by) VALUES ('STATUS', ?, ?)").run(status, adminId);
    if (from === "not_started" && status === "active") {
      fullHealAll(db, { source: "game start", performedBy: adminId });
    }
    for (const hook of statusHooks) hook(db, from, status, adminId);
    db.exec("COMMIT");
    return from;
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

export function addAnnouncement(db: DatabaseSync, message: string, playerId: number | null, adminId: number): void {
  db.prepare("INSERT INTO game_events (type, message, player_id, created_by) VALUES ('ANNOUNCEMENT', ?, ?, ?)").run(
    message,
    playerId,
    adminId
  );
}

export interface GameEvent {
  id: number;
  type: "STATUS" | "ANNOUNCEMENT";
  status: GameStatus | null;
  message: string | null;
  playerId: number | null;
  playerName: string | null;
  createdAt: string;
}

interface EventRow {
  id: number;
  type: "STATUS" | "ANNOUNCEMENT";
  status: GameStatus | null;
  message: string | null;
  player_id: number | null;
  player_name: string | null;
  created_at: string;
}

const toEvent = (r: EventRow): GameEvent => ({
  id: r.id,
  type: r.type,
  status: r.status,
  message: r.message,
  playerId: r.player_id,
  playerName: r.player_name,
  createdAt: r.created_at,
});

export function listEventsForAdmin(db: DatabaseSync, limit = 50): GameEvent[] {
  return (
    db
      .prepare(
        `SELECT e.*, COALESCE(u.display_name, u.username) AS player_name
           FROM game_events e LEFT JOIN users u ON u.id = e.player_id
          ORDER BY e.id DESC LIMIT ?`
      )
      .all(limit) as unknown as EventRow[]
  ).map(toEvent);
}

// A player sees announcements sent to everyone, plus ones sent to them.
// Never another player's private messages.
export function listAnnouncementsForPlayer(db: DatabaseSync, playerId: number, limit = 20): GameEvent[] {
  return (
    db
      .prepare(
        `SELECT e.*, NULL AS player_name FROM game_events e
          WHERE e.type = 'ANNOUNCEMENT' AND (e.player_id IS NULL OR e.player_id = ?)
          ORDER BY e.id DESC LIMIT ?`
      )
      .all(playerId, limit) as unknown as EventRow[]
  ).map(toEvent);
}

// "Start a new game": clear everything that happened in a round, keep the
// set-up. Player accounts (and their player numbers), items (with
// pictures/models/sounds), the shop's listings, the game rules and the
// calculator stay; money, cases, the drop box, HP, all histories,
// announcements and stock counts sold go back to the start. One
// transaction: all or nothing.
export function resetRound(db: DatabaseSync): void {
  db.exec("BEGIN");
  try {
    db.exec(`
      DELETE FROM inventory_pieces;
      DELETE FROM dropped_items;
      DELETE FROM inventory;
      DELETE FROM weapon_upgrades;
      DELETE FROM inventory_log;
      DELETE FROM transactions;
      DELETE FROM game_events;
      DELETE FROM hp_log;
      UPDATE users SET balance = 0 WHERE role = 'player';
      DELETE FROM game_state WHERE key IN ('game_status', 'game_status_at', 'shop_open');
    `);
    resetAllHp(db);
    for (const hook of resetHooks) hook(db);
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
