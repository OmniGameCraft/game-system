import { DatabaseSync } from "node:sqlite";
import { DEFAULT_GRID, findItemById, GRID_MAX, Item } from "../database/items";
import { GameRules, getRules } from "../database/settings";

// The case: each player's attaché-case grid (like the reference picture).
//
// The `inventory` table stays the source of truth for HOW MANY of each item
// a player holds (the shop, the Admin and selling all use it). This file
// decides WHERE those units sit: every unit lives in exactly one "piece" —
// a stack of one item occupying a w×h block of cells, or waiting in the
// "doesn't fit" tray (x/y NULL). For every item except backpacks:
//   SUM(pieces.quantity) == inventory.quantity
// applyInventoryChange (database/inventory.ts) calls syncItem below in the
// same transaction, so the two can never drift apart.
//
// Nothing here opens a transaction of its own: callers already run inside
// one (and everything is synchronous, so no other request can interleave).

// A rule the player broke, or a piece that isn't theirs. The message is
// written for the player and is safe to show as-is.
export class CaseError extends Error {
  constructor(message: string, public status: 400 | 404 | 409 = 400) {
    super(message);
  }
}

// ---- Sizes and stacks -------------------------------------------------------

// The item columns the layout needs.
export type SizedItem = Pick<Item, "kind" | "grid_w" | "grid_h" | "stack_size" | "ammo_per_pack">;

function dim(v: number | null | undefined, fallback: number): number {
  return typeof v === "number" && Number.isInteger(v) && v >= 1 ? Math.min(GRID_MAX, v) : fallback;
}

// Cells an item takes, unrotated. Every item has its own grid_w × grid_h
// (new items get their kind's size: gun 3×2, knife 2×1, the rest 1×1).
export function sizeOf(item: Pick<Item, "kind" | "grid_w" | "grid_h">): { w: number; h: number } {
  const def = DEFAULT_GRID[item.kind] ?? { w: 1, h: 1 };
  return { w: dim(item.grid_w, def.w), h: dim(item.grid_h, def.h) };
}

// How many units one piece holds. Ammo: the Admin's stack size, else one
// pack's worth of rounds, else 30. Everything else: the stack size, else 1.
// Guns are always 1 per piece, because each gun has its own magazine.
export function stackSizeOf(item: Pick<Item, "kind" | "stack_size" | "ammo_per_pack">): number {
  if (item.kind === "gun") return 1;
  if (item.kind === "ammo") return item.stack_size ?? item.ammo_per_pack ?? 30;
  return item.stack_size ?? 1;
}

// Cells a piece covers as it lies (a rotated piece swaps width and height).
export function footprint(item: Pick<Item, "kind" | "grid_w" | "grid_h">, rotated: boolean | number) {
  const { w, h } = sizeOf(item);
  return rotated ? { w: h, h: w } : { w, h };
}

export interface CaseSize {
  cols: number;
  rows: number;
  expansions: number; // backpack expansions held
}

// cols = the caseCols rule; rows = caseRows + rows added by backpacks held,
// never more than caseMaxRows. Backpacks never take a cell: they are
// "used up" into the case the moment they arrive.
export function caseSize(db: DatabaseSync, playerId: number, rules: GameRules = getRules(db)): CaseSize {
  const r = db
    .prepare(
      `SELECT COALESCE(SUM(inv.quantity), 0) AS n,
              COALESCE(SUM(inv.quantity * COALESCE(i.expand_rows, 1)), 0) AS extra
         FROM inventory inv JOIN items i ON i.id = inv.item_id
        WHERE inv.player_id = ? AND i.kind = 'backpack'`
    )
    .get(playerId) as { n: number; extra: number };
  return {
    cols: rules.caseCols,
    rows: Math.min(rules.caseMaxRows, rules.caseRows + r.extra),
    expansions: r.n,
  };
}

// ---- The board (which cell holds what) ------------------------------------

export interface Spot {
  x: number;
  y: number;
  rotated: boolean;
}

// An in-memory picture of the case: each cell holds the id of the piece on
// it, or 0 when free. Used both to change the real case and to try things
// out ("would this fit?") without writing anything.
export class Board {
  private cells: Int32Array;

  constructor(readonly cols: number, readonly rows: number) {
    this.cells = new Int32Array(cols * rows);
  }

  clone(): Board {
    const b = new Board(this.cols, this.rows);
    b.cells.set(this.cells);
    return b;
  }

  inBounds(x: number, y: number, w: number, h: number): boolean {
    return Number.isInteger(x) && Number.isInteger(y) && x >= 0 && y >= 0 && x + w <= this.cols && y + h <= this.rows;
  }

  // The piece on a cell (0 = free), or null outside the case.
  at(x: number, y: number): number | null {
    return this.inBounds(x, y, 1, 1) ? this.cells[y * this.cols + x] : null;
  }

  // Inside the case and nothing else there (`ignore` = the piece being moved).
  isFree(x: number, y: number, w: number, h: number, ignore = 0): boolean {
    if (!this.inBounds(x, y, w, h)) return false;
    for (let j = y; j < y + h; j++) {
      for (let i = x; i < x + w; i++) {
        const c = this.cells[j * this.cols + i];
        if (c !== 0 && c !== ignore) return false;
      }
    }
    return true;
  }

  fill(x: number, y: number, w: number, h: number, id: number): void {
    for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) this.cells[j * this.cols + i] = id;
  }

  remove(id: number): void {
    for (let k = 0; k < this.cells.length; k++) if (this.cells[k] === id) this.cells[k] = 0;
  }

  // Would a piece of base size w×h fit at x,y lying this way?
  fitsAt(x: number, y: number, w: number, h: number, rotated: boolean, ignore = 0): boolean {
    return rotated ? this.isFree(x, y, h, w, ignore) : this.isFree(x, y, w, h, ignore);
  }

  // The first free spot, scanning row by row from the top-left. The piece's
  // normal way round is tried everywhere first; only if that fits nowhere
  // is it turned 90°.
  firstFit(w: number, h: number, allowRotate = true): Spot | null {
    const a = this.scan(w, h);
    if (a) return { ...a, rotated: false };
    if (allowRotate && w !== h) {
      const b = this.scan(h, w);
      if (b) return { ...b, rotated: true };
    }
    return null;
  }

  private scan(w: number, h: number): { x: number; y: number } | null {
    for (let y = 0; y + h <= this.rows; y++) {
      for (let x = 0; x + w <= this.cols; x++) {
        if (this.isFree(x, y, w, h)) return { x, y };
      }
    }
    return null;
  }

  occupy(spot: Spot, w: number, h: number, id: number): void {
    if (spot.rotated) this.fill(spot.x, spot.y, h, w, id);
    else this.fill(spot.x, spot.y, w, h, id);
  }
}

// ---- Reading and writing pieces ---------------------------------------------

export interface PieceRow {
  id: number;
  player_id: number;
  item_id: number;
  x: number | null; // NULL = in the tray
  y: number | null;
  rotated: number;
  quantity: number;
  loaded: number; // guns: rounds in the magazine (not counted in inventory.quantity)
  created_at: string;
}

// A piece plus the item columns needed to lay it out.
export type LayoutPiece = PieceRow & SizedItem;

const LAYOUT_SELECT = `
  SELECT p.*, i.kind, i.grid_w, i.grid_h, i.stack_size, i.ammo_per_pack
    FROM inventory_pieces p JOIN items i ON i.id = p.item_id`;

export function layoutPieces(db: DatabaseSync, playerId: number): LayoutPiece[] {
  return db.prepare(`${LAYOUT_SELECT} WHERE p.player_id = ? ORDER BY p.id`).all(playerId) as unknown as LayoutPiece[];
}

function itemPieces(db: DatabaseSync, playerId: number, itemId: number): LayoutPiece[] {
  return db
    .prepare(`${LAYOUT_SELECT} WHERE p.player_id = ? AND p.item_id = ? ORDER BY p.id`)
    .all(playerId, itemId) as unknown as LayoutPiece[];
}

export function findPiece(db: DatabaseSync, pieceId: number): PieceRow | undefined {
  return db.prepare("SELECT * FROM inventory_pieces WHERE id = ?").get(pieceId) as PieceRow | undefined;
}

// The player's own piece and its item. Whose case it is comes only from the
// session, so a player can never touch someone else's piece.
export function ownPiece(db: DatabaseSync, playerId: number, pieceId: unknown): { piece: PieceRow; item: Item } {
  const piece =
    typeof pieceId === "number" && Number.isInteger(pieceId) && pieceId > 0 ? findPiece(db, pieceId) : undefined;
  const item = piece && piece.player_id === playerId ? findItemById(db, piece.item_id) : undefined;
  if (!piece || !item) throw new CaseError("That isn't in your case any more.", 404);
  return { piece, item };
}

function insertPiece(
  db: DatabaseSync,
  playerId: number,
  itemId: number,
  spot: Spot | null,
  quantity: number,
  loaded = 0
): number {
  const r = db
    .prepare(
      "INSERT INTO inventory_pieces (player_id, item_id, x, y, rotated, quantity, loaded) VALUES (?, ?, ?, ?, ?, ?, ?)"
    )
    .run(playerId, itemId, spot?.x ?? null, spot?.y ?? null, spot?.rotated ? 1 : 0, quantity, loaded);
  return Number(r.lastInsertRowid);
}

// null = into the tray (the piece keeps the way it was turned).
function setPlace(db: DatabaseSync, pieceId: number, spot: Spot | null): void {
  if (spot) {
    db.prepare("UPDATE inventory_pieces SET x = ?, y = ?, rotated = ? WHERE id = ?").run(
      spot.x,
      spot.y,
      spot.rotated ? 1 : 0,
      pieceId
    );
  } else {
    db.prepare("UPDATE inventory_pieces SET x = NULL, y = NULL WHERE id = ?").run(pieceId);
  }
}

function setQuantity(db: DatabaseSync, pieceId: number, quantity: number): void {
  db.prepare("UPDATE inventory_pieces SET quantity = ? WHERE id = ?").run(quantity, pieceId);
}

export function setLoaded(db: DatabaseSync, pieceId: number, loaded: number): void {
  db.prepare("UPDATE inventory_pieces SET loaded = ? WHERE id = ?").run(Math.max(0, Math.floor(loaded)), pieceId);
}

function deletePiece(db: DatabaseSync, pieceId: number): void {
  db.prepare("DELETE FROM inventory_pieces WHERE id = ?").run(pieceId);
}

function heldQuantity(db: DatabaseSync, playerId: number, itemId: number): number {
  const r = db.prepare("SELECT quantity FROM inventory WHERE player_id = ? AND item_id = ?").get(playerId, itemId) as
    | { quantity: number }
    | undefined;
  return r?.quantity ?? 0;
}

const isPlaced = (p: PieceRow) => p.x !== null && p.y !== null;
const area = (p: SizedItem) => sizeOf(p).w * sizeOf(p).h;

// Reading order: top row first, left to right.
function byPosition(a: PieceRow, b: PieceRow): number {
  return (a.y ?? 0) - (b.y ?? 0) || (a.x ?? 0) - (b.x ?? 0) || a.id - b.id;
}

// A board with every placed piece on it. Anything out of bounds or on top
// of another piece is left off (relayoutPlayer fixes those).
function boardFor(size: CaseSize, pieces: LayoutPiece[]): Board {
  const board = new Board(size.cols, size.rows);
  for (const p of pieces.filter(isPlaced).sort(byPosition)) {
    const { w, h } = footprint(p, p.rotated);
    if (board.isFree(p.x!, p.y!, w, h)) board.fill(p.x!, p.y!, w, h, p.id);
  }
  return board;
}

// Could all these tray pieces still be put in the case (biggest first)?
function trayFits(board: Board, tray: LayoutPiece[]): boolean {
  const b = board.clone();
  let tmp = -1;
  for (const p of [...tray].sort((a, c) => area(c) - area(a) || a.id - c.id)) {
    const { w, h } = sizeOf(p);
    const spot = b.firstFit(w, h);
    if (!spot) return false;
    b.occupy(spot, w, h, tmp--);
  }
  return true;
}

// ---- Keeping pieces in step with the inventory ------------------------------

export interface SyncOpts {
  // Take units from this piece first (the one the player tapped: use,
  // drop, mix). Otherwise units leave from the tray first, then the
  // smallest stacks, newest first.
  takeFrom?: number;
  // Put a new piece here if it fits (a mixed herb lands where the first
  // herb was). Otherwise: the first free spot.
  placeAt?: { x: number; y: number } | null;
  // Rounds inside a gun that leaves go with it (drop box) instead of back
  // into the player's ammo.
  keepRounds?: boolean;
  // Player actions (buying, picking up): every new unit must fit in the
  // case — and whatever already waits in the tray must still fit after —
  // otherwise CaseError(noRoom). Without it, what doesn't fit goes to the
  // tray (Admin gives, returns at the end of the game).
  mustFit?: boolean;
  noRoom?: string;
}

export interface SyncResult {
  created: number[]; // ids of new pieces
  trayed: number; // how many of the new pieces had to go to the tray
  freedRounds: number; // rounds from removed guns, for the caller to give back as ammo
}

const NO_ROOM = "Not enough room in your case. Make space first.";

// The plan for adding units of one item: top up part-full stacks (in the
// case first, then the tray), then new pieces in the first free spots.
// `board` is updated as the plan goes, so the same plan can be tried out
// (canFit) and then carried out (syncItem) with identical results.
interface AddPlan {
  topUps: Array<{ piece: LayoutPiece; add: number }>;
  news: Array<{ quantity: number; spot: Spot | null }>;
}

function planAdd(
  board: Board,
  pieces: LayoutPiece[],
  item: SizedItem,
  units: number,
  placeAt?: { x: number; y: number } | null
): AddPlan {
  const stack = stackSizeOf(item);
  const plan: AddPlan = { topUps: [], news: [] };
  let left = units;
  const partial = pieces
    .filter((p) => p.quantity < stack)
    .sort((a, b) => Number(isPlaced(b)) - Number(isPlaced(a)) || byPosition(a, b));
  for (const piece of partial) {
    if (left === 0) break;
    const add = Math.min(left, stack - piece.quantity);
    plan.topUps.push({ piece, add });
    left -= add;
  }
  const { w, h } = sizeOf(item);
  let wanted = placeAt ?? null;
  let tmp = -1;
  while (left > 0) {
    const quantity = Math.min(stack, left);
    let spot: Spot | null = null;
    if (wanted) {
      if (board.fitsAt(wanted.x, wanted.y, w, h, false)) spot = { ...wanted, rotated: false };
      else if (board.fitsAt(wanted.x, wanted.y, w, h, true)) spot = { ...wanted, rotated: true };
      wanted = null; // only the first new piece goes there
    }
    spot = spot ?? board.firstFit(w, h);
    if (spot) board.occupy(spot, w, h, tmp--);
    plan.news.push({ quantity, spot });
    left -= quantity;
  }
  return plan;
}

// Makes one player's pieces of one item match what the inventory says they
// hold. Called by applyInventoryChange after every change.
export function syncItem(db: DatabaseSync, playerId: number, itemId: number, opts: SyncOpts = {}): SyncResult {
  const result: SyncResult = { created: [], trayed: 0, freedRounds: 0 };
  const item = findItemById(db, itemId);
  const pieces = itemPieces(db, playerId, itemId);

  // Backpacks (or an item that no longer exists) never have pieces.
  if (!item || item.kind === "backpack") {
    for (const p of pieces) {
      if (!opts.keepRounds) result.freedRounds += p.loaded;
      deletePiece(db, p.id);
    }
    return result;
  }

  // A piece never holds more than a stack (e.g. the Admin made stacks
  // smaller): trim it; the rest is put back below as new pieces.
  const stack = stackSizeOf(item);
  let sum = 0;
  for (const p of pieces) {
    if (p.quantity > stack) {
      p.quantity = stack;
      setQuantity(db, p.id, stack);
    }
    sum += p.quantity;
  }
  const target = heldQuantity(db, playerId, itemId);

  if (sum > target) {
    // Units leave: the chosen piece first, then the tray, then the
    // smallest stacks (so a nearly-empty box frees its cell), newest first.
    const order = [...pieces].sort(
      (a, b) =>
        Number(b.id === opts.takeFrom) - Number(a.id === opts.takeFrom) ||
        Number(isPlaced(a)) - Number(isPlaced(b)) ||
        a.quantity - b.quantity ||
        b.id - a.id
    );
    let excess = sum - target;
    for (const p of order) {
      if (excess === 0) break;
      const take = Math.min(excess, p.quantity);
      if (take === p.quantity) {
        if (!opts.keepRounds) result.freedRounds += p.loaded;
        deletePiece(db, p.id);
      } else {
        setQuantity(db, p.id, p.quantity - take);
      }
      excess -= take;
    }
    return result;
  }

  if (sum < target) {
    const all = layoutPieces(db, playerId);
    const board = boardFor(caseSize(db, playerId), all);
    const plan = planAdd(board, pieces, item, target - sum, opts.placeAt);
    if (opts.mustFit) {
      const tray = all.filter((p) => !isPlaced(p));
      if (plan.news.some((n) => !n.spot) || !trayFits(board, tray)) {
        throw new CaseError(opts.noRoom ?? NO_ROOM);
      }
    }
    for (const t of plan.topUps) setQuantity(db, t.piece.id, t.piece.quantity + t.add);
    for (const n of plan.news) {
      result.created.push(insertPiece(db, playerId, itemId, n.spot, n.quantity));
      if (!n.spot) result.trayed++;
    }
  }
  return result;
}

// Would `units` more of an item fit in the player's case right now, with
// room left for anything waiting in the tray? (The shop asks before a sale.)
export function canFit(db: DatabaseSync, playerId: number, itemId: number, units: number): boolean {
  const item = findItemById(db, itemId);
  if (!item || item.kind === "backpack" || units <= 0) return true;
  const all = layoutPieces(db, playerId);
  const board = boardFor(caseSize(db, playerId), all);
  const plan = planAdd(
    board,
    all.filter((p) => p.item_id === itemId),
    item,
    units
  );
  if (plan.news.some((n) => !n.spot)) return false;
  return trayFits(
    board,
    all.filter((p) => !isPlaced(p))
  );
}

// ---- Re-checking a whole case --------------------------------------------------

// Makes sure every placed piece is inside the case and on its own cells
// (after the case got smaller, an item got bigger, or an old save). Pieces
// that don't fit where they are get the first free spot, else the tray.
// settle: also put tray pieces into free spots (the case grew).
// moveFirst: when two pieces clash, this item's pieces are the ones moved.
export function relayoutPlayer(
  db: DatabaseSync,
  playerId: number,
  opts: { settle?: boolean; moveFirst?: number } = {}
): { trayed: number; placed: number } {
  const size = caseSize(db, playerId);
  const pieces = layoutPieces(db, playerId);
  const board = new Board(size.cols, size.rows);
  const homeless: LayoutPiece[] = [];
  const placed = pieces
    .filter(isPlaced)
    .sort((a, b) => Number(a.item_id === opts.moveFirst) - Number(b.item_id === opts.moveFirst) || byPosition(a, b));
  for (const p of placed) {
    const { w, h } = footprint(p, p.rotated);
    if (board.isFree(p.x!, p.y!, w, h)) board.fill(p.x!, p.y!, w, h, p.id);
    else homeless.push(p);
  }
  let trayed = 0;
  let settled = 0;
  for (const p of homeless.sort((a, b) => area(b) - area(a) || a.id - b.id)) {
    const { w, h } = sizeOf(p);
    const spot = board.firstFit(w, h);
    if (spot) board.occupy(spot, w, h, p.id);
    else trayed++;
    setPlace(db, p.id, spot);
  }
  if (opts.settle) {
    for (const p of pieces.filter((q) => !isPlaced(q)).sort((a, b) => area(b) - area(a) || a.id - b.id)) {
      const { w, h } = sizeOf(p);
      const spot = board.firstFit(w, h);
      if (!spot) continue;
      board.occupy(spot, w, h, p.id);
      setPlace(db, p.id, spot);
      settled++;
    }
  }
  return { trayed, placed: settled };
}

// Every player's case, after the Admin changed the case-size rules.
export function relayoutAll(db: DatabaseSync): void {
  const players = db.prepare("SELECT DISTINCT player_id AS id FROM inventory_pieces").all() as unknown as Array<{
    id: number;
  }>;
  for (const p of players) relayoutPlayer(db, p.id, { settle: true });
}

// At server start: every inventory row gets its pieces (an old save from
// before the case existed is laid out neatly), and anything out of place is
// fixed. Returns rounds freed from guns that had to be removed (only if the
// data was edited by hand) so the caller can give them back as ammo.
export function syncAll(db: DatabaseSync): Array<{ playerId: number; itemId: number; rounds: number }> {
  const freed: Array<{ playerId: number; itemId: number; rounds: number }> = [];
  const hadPieces = new Set(
    (db.prepare("SELECT DISTINCT player_id AS id FROM inventory_pieces").all() as unknown as Array<{ id: number }>).map(
      (r) => r.id
    )
  );
  const pairs = db
    .prepare(
      `SELECT player_id, item_id FROM inventory
       UNION SELECT player_id, item_id FROM inventory_pieces`
    )
    .all() as unknown as Array<{ player_id: number; item_id: number }>;
  const players = new Set<number>();
  for (const pair of pairs) {
    players.add(pair.player_id);
    const r = syncItem(db, pair.player_id, pair.item_id);
    if (r.freedRounds > 0) freed.push({ playerId: pair.player_id, itemId: pair.item_id, rounds: r.freedRounds });
  }
  for (const playerId of players) {
    if (hadPieces.has(playerId)) relayoutPlayer(db, playerId);
    else arrange(db, playerId);
  }
  return freed;
}

// ---- Player actions: move, split, arrange ------------------------------------------

// Drag & drop. x/y null = put it in the tray. Dropping a stack exactly onto
// a part-full stack of the same item merges as much as fits.
export function movePiece(
  db: DatabaseSync,
  playerId: number,
  input: { pieceId: unknown; x: unknown; y: unknown; rotated: unknown }
): { merged: boolean; intoPieceId: number | null; moved: number } {
  const { piece, item } = ownPiece(db, playerId, input.pieceId);
  const rotated = input.rotated === undefined ? piece.rotated === 1 : input.rotated;
  if (typeof rotated !== "boolean") throw new CaseError("Invalid rotation.");

  if (input.x === null || input.y === null) {
    setPlace(db, piece.id, null);
    return { merged: false, intoPieceId: null, moved: 0 };
  }
  const x = input.x;
  const y = input.y;
  if (typeof x !== "number" || typeof y !== "number" || !Number.isInteger(x) || !Number.isInteger(y)) {
    throw new CaseError("Choose a square in your case.");
  }

  const pieces = layoutPieces(db, playerId);
  const board = boardFor(caseSize(db, playerId), pieces);

  // Merge onto a part-full stack of the same thing?
  const under = board.at(x, y);
  const target = under ? pieces.find((p) => p.id === under && p.id !== piece.id) : undefined;
  if (target && target.item_id === piece.item_id) {
    const stack = stackSizeOf(item);
    const room = stack - target.quantity;
    if (room <= 0) throw new CaseError(stack > 1 ? "That stack is full." : "That spot is taken.");
    const moved = Math.min(room, piece.quantity);
    setQuantity(db, target.id, target.quantity + moved);
    if (moved === piece.quantity) deletePiece(db, piece.id);
    else setQuantity(db, piece.id, piece.quantity - moved);
    return { merged: true, intoPieceId: target.id, moved };
  }

  const { w, h } = footprint(item, rotated);
  if (!board.inBounds(x, y, w, h)) throw new CaseError("That doesn't fit there.");
  if (!board.isFree(x, y, w, h, piece.id)) throw new CaseError("That spot is taken.");
  setPlace(db, piece.id, { x, y, rotated });
  return { merged: false, intoPieceId: null, moved: piece.quantity };
}

// Splits `quantity` units off a stack into a new piece in the first free spot.
export function splitPiece(
  db: DatabaseSync,
  playerId: number,
  input: { pieceId: unknown; quantity: unknown }
): { newPieceId: number } {
  const { piece, item } = ownPiece(db, playerId, input.pieceId);
  if (piece.quantity < 2) throw new CaseError("There's only one, so there's nothing to split.");
  const q = input.quantity;
  if (typeof q !== "number" || !Number.isInteger(q) || q < 1 || q >= piece.quantity) {
    throw new CaseError(`Choose how many to move to the new stack (1 to ${piece.quantity - 1}).`);
  }
  const board = boardFor(caseSize(db, playerId), layoutPieces(db, playerId));
  const { w, h } = sizeOf(item);
  const spot = board.firstFit(w, h);
  if (!spot) throw new CaseError("No room to split that. Make space first.");
  setQuantity(db, piece.id, piece.quantity - q);
  return { newPieceId: insertPiece(db, playerId, item.id, spot, q) };
}

// Part-full stacks of the same item are poured together (stacks in the case
// fill up first, tray stacks empty first). Guns never stack.
function mergeStacks(db: DatabaseSync, playerId: number): void {
  const groups = new Map<number, LayoutPiece[]>();
  for (const p of layoutPieces(db, playerId)) {
    const g = groups.get(p.item_id);
    if (g) g.push(p);
    else groups.set(p.item_id, [p]);
  }
  for (const group of groups.values()) {
    const stack = stackSizeOf(group[0]);
    if (stack <= 1 || group.length < 2) continue;
    group.sort((a, b) => Number(isPlaced(b)) - Number(isPlaced(a)) || byPosition(a, b));
    let left = group.reduce((n, p) => n + p.quantity, 0);
    for (const p of group) {
      const q = Math.min(stack, left);
      left -= q;
      if (q === 0) deletePiece(db, p.id);
      else if (q !== p.quantity) setQuantity(db, p.id, q);
    }
  }
}

// Weapons first, then healing, ammo and the rest; the same item together.
const KIND_ORDER: Record<string, number> = { gun: 0, knife: 1, healing: 2, ammo: 3, other: 4, backpack: 5 };

// "Arrange" button: merge part-full stacks, then lay everything out again,
// biggest first, row by row, turning pieces when that helps. Tray pieces
// come in if they fit. A few packing orders are tried and the one that
// leaves the least outside wins; if none beats the current layout, the
// current layout is kept (only tray pieces are fitted into free spots), so
// Arrange never makes things worse.
export function arrange(db: DatabaseSync, playerId: number): { trayed: number } {
  mergeStacks(db, playerId);
  const size = caseSize(db, playerId);
  const pieces = layoutPieces(db, playerId);
  if (pieces.length === 0) return { trayed: 0 };

  // How the current layout does once tray pieces are fitted in.
  const current = boardFor(size, pieces);
  let currentTray = 0;
  for (const p of pieces.filter((q) => !isPlaced(q)).sort((a, b) => area(b) - area(a))) {
    const { w, h } = sizeOf(p);
    const spot = current.firstFit(w, h);
    if (spot) current.occupy(spot, w, h, p.id);
    else currentTray++;
  }

  const dims = (p: LayoutPiece) => sizeOf(p);
  const tie = (a: LayoutPiece, b: LayoutPiece) =>
    (KIND_ORDER[a.kind] ?? 9) - (KIND_ORDER[b.kind] ?? 9) || a.item_id - b.item_id || a.id - b.id;
  const orders: Array<(a: LayoutPiece, b: LayoutPiece) => number> = [
    (a, b) => area(b) - area(a) || tie(a, b),
    (a, b) =>
      Math.max(dims(b).w, dims(b).h) - Math.max(dims(a).w, dims(a).h) || area(b) - area(a) || tie(a, b),
    (a, b) => dims(b).h - dims(a).h || dims(b).w - dims(a).w || tie(a, b),
    (a, b) => dims(b).w - dims(a).w || dims(b).h - dims(a).h || tie(a, b),
  ];

  let best: { spots: Map<number, Spot | null>; tray: number; trayArea: number } | null = null;
  for (const order of orders) {
    const board = new Board(size.cols, size.rows);
    const spots = new Map<number, Spot | null>();
    let tray = 0;
    let trayArea = 0;
    for (const p of [...pieces].sort(order)) {
      const { w, h } = sizeOf(p);
      const spot = board.firstFit(w, h);
      if (spot) board.occupy(spot, w, h, p.id);
      else {
        tray++;
        trayArea += w * h;
      }
      spots.set(p.id, spot);
    }
    if (!best || tray < best.tray || (tray === best.tray && trayArea < best.trayArea)) {
      best = { spots, tray, trayArea };
    }
  }

  if (!best || best.tray > currentTray) {
    relayoutPlayer(db, playerId, { settle: true });
    return { trayed: trayCount(db, playerId) };
  }
  for (const [id, spot] of best.spots) setPlace(db, id, spot);
  return { trayed: best.tray };
}

// How many pieces wait in the player's tray.
export function trayCount(db: DatabaseSync, playerId: number): number {
  const r = db
    .prepare("SELECT COUNT(*) AS n FROM inventory_pieces WHERE player_id = ? AND x IS NULL")
    .get(playerId) as { n: number };
  return r.n;
}
