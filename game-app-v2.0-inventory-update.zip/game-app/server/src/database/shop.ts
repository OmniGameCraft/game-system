import { DatabaseSync } from "node:sqlite";
import { applyBalanceChange, getTransaction, Transaction } from "./money";
import { applyInventoryChange, MAX_ITEM_QUANTITY } from "./inventory";
import { findItemById, imageUrlFor, ItemKind } from "./items";
import { addSpent, getHolding } from "./inventory";
import {
  basePriceFor,
  getDamagePerLevel,
  levelsFor,
  MAX_LEVEL,
  setLevel,
  statAt,
  Track,
  TRACK_LABEL,
  tracksFor,
  upgradeCost,
} from "./weapons";
import { gameAllowsPlay } from "./game";
import { getRules } from "./settings";
import { canFit, caseSize, trayCount } from "../inventory/grid";

// Highest price the Admin can set for one unit. price × quantity stays far
// inside JS's exact-integer range (1e9 × 1e6 = 1e15 < 9e15).
export const MAX_PRICE = 1_000_000_000;

export const NO_ROOM_TO_BUY = "Not enough room in your case for that. Make space or drop something.";

// ---- Shop open/closed -------------------------------------------------

export function isShopOpen(db: DatabaseSync): boolean {
  const row = db.prepare("SELECT value FROM game_state WHERE key = 'shop_open'").get() as
    | { value: string }
    | undefined;
  return row?.value === "1"; // no row yet = closed
}

export function setShopOpen(db: DatabaseSync, open: boolean): void {
  db.prepare(
    `INSERT INTO game_state (key, value) VALUES ('shop_open', ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  ).run(open ? "1" : "0");
}

// ---- Shop items -------------------------------------------------------

interface ShopRow {
  id: number;
  item_id: number;
  price: number;
  stock: number | null;
  max_per_purchase: number | null;
  enabled: number;
  created_at: string;
  name: string;
  description: string | null;
  category: string | null;
  image_file: string | null;
  item_enabled: number;
  max_stack: number | null;
  kind: ItemKind;
  ammo_per_pack: number | null;
}

// How many units of an item one "pack" in the shop is: ammo is sold in packs
// of ammo_per_pack rounds, everything else one at a time.
export function unitsPerPack(kind: ItemKind, ammoPerPack: number | null): number {
  return kind === "ammo" && ammoPerPack ? ammoPerPack : 1;
}

export interface AdminShopItem {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  price: number;
  stock: number | null;
  maxPerPurchase: number | null;
  enabled: boolean;
  itemEnabled: boolean;
  maxStack: number | null;
  soldCount: number;
  kind: ItemKind;
  ammoPerPack: number | null;
}

export interface PlayerShopItem {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  price: number;
  stock: number | null;
  maxPerPurchase: number | null;
  maxStack: number | null;
  owned: number; // units held (rounds, for ammo)
  kind: ItemKind;
  ammoPerPack: number | null;
}

const SHOP_SELECT = `
  SELECT s.*, i.name, i.description, i.category, i.image_file,
         i.enabled AS item_enabled, i.max_stack, i.kind, i.ammo_per_pack
    FROM shop_items s
    JOIN items i ON i.id = s.item_id`;

export function findShopItem(db: DatabaseSync, id: number): ShopRow | undefined {
  return db.prepare(`${SHOP_SELECT} WHERE s.id = ?`).get(id) as ShopRow | undefined;
}

export function findShopItemByItemId(db: DatabaseSync, itemId: number): ShopRow | undefined {
  return db.prepare(`${SHOP_SELECT} WHERE s.item_id = ?`).get(itemId) as ShopRow | undefined;
}

export function listShopForAdmin(db: DatabaseSync): AdminShopItem[] {
  const rows = db.prepare(`${SHOP_SELECT} ORDER BY i.name COLLATE NOCASE`).all() as unknown as ShopRow[];
  const sold = new Map<number, number>();
  for (const r of db
    .prepare("SELECT item_id, SUM(quantity) AS n FROM transactions WHERE type = 'PURCHASE' GROUP BY item_id")
    .all() as unknown as Array<{ item_id: number; n: number }>) {
    sold.set(r.item_id, r.n);
  }
  return rows.map((r) => ({
    id: r.id,
    itemId: r.item_id,
    name: r.name,
    description: r.description,
    category: r.category,
    imageUrl: imageUrlFor(r.image_file),
    price: r.price,
    stock: r.stock,
    maxPerPurchase: r.max_per_purchase,
    enabled: r.enabled === 1,
    itemEnabled: r.item_enabled === 1,
    maxStack: r.max_stack,
    soldCount: sold.get(r.item_id) ?? 0,
    kind: r.kind,
    ammoPerPack: r.ammo_per_pack,
  }));
}

// Only what a player may buy right now: shop entry enabled AND the item
// itself enabled. Sold-out entries are still listed (shown as "Sold out").
export function listShopForPlayer(db: DatabaseSync, playerId: number): PlayerShopItem[] {
  const rows = db
    .prepare(`${SHOP_SELECT} WHERE s.enabled = 1 AND i.enabled = 1 ORDER BY i.name COLLATE NOCASE`)
    .all() as unknown as ShopRow[];
  const owned = new Map<number, number>();
  for (const r of db
    .prepare("SELECT item_id, quantity FROM inventory WHERE player_id = ?")
    .all(playerId) as unknown as Array<{ item_id: number; quantity: number }>) {
    owned.set(r.item_id, r.quantity);
  }
  return rows.map((r) => ({
    id: r.id,
    itemId: r.item_id,
    name: r.name,
    description: r.description,
    category: r.category,
    imageUrl: imageUrlFor(r.image_file),
    price: r.price,
    stock: r.stock,
    maxPerPurchase: r.max_per_purchase,
    maxStack: r.max_stack,
    owned: owned.get(r.item_id) ?? 0,
    kind: r.kind,
    ammoPerPack: r.ammo_per_pack,
  }));
}

export interface ShopItemFields {
  price?: number;
  stock?: number | null;
  maxPerPurchase?: number | null;
  enabled?: boolean;
}

export function createShopItem(
  db: DatabaseSync,
  itemId: number,
  f: { price: number; stock: number | null; maxPerPurchase: number | null; enabled: boolean }
): number {
  const r = db
    .prepare(
      "INSERT INTO shop_items (item_id, price, stock, max_per_purchase, enabled) VALUES (?, ?, ?, ?, ?)"
    )
    .run(itemId, f.price, f.stock, f.maxPerPurchase, f.enabled ? 1 : 0);
  return Number(r.lastInsertRowid);
}

export function updateShopItem(db: DatabaseSync, id: number, f: ShopItemFields): void {
  if (f.price !== undefined) db.prepare("UPDATE shop_items SET price = ? WHERE id = ?").run(f.price, id);
  if (f.stock !== undefined) db.prepare("UPDATE shop_items SET stock = ? WHERE id = ?").run(f.stock, id);
  if (f.maxPerPurchase !== undefined)
    db.prepare("UPDATE shop_items SET max_per_purchase = ? WHERE id = ?").run(f.maxPerPurchase, id);
  if (f.enabled !== undefined)
    db.prepare("UPDATE shop_items SET enabled = ? WHERE id = ?").run(f.enabled ? 1 : 0, id);
}

export function deleteShopItem(db: DatabaseSync, id: number): void {
  db.prepare("DELETE FROM shop_items WHERE id = ?").run(id);
}

// ---- Sales list for the Admin -----------------------------------------

// Shop activity for the Admin: purchases, sell-backs and upgrades.
export interface Sale {
  id: number;
  type: "PURCHASE" | "SALE" | "UPGRADE";
  playerId: number;
  playerName: string;
  itemName: string;
  quantity: number | null;
  total: number;
  detail: string | null;
  createdAt: string;
}

export function listRecentSales(db: DatabaseSync, limit = 50): Sale[] {
  const rows = db
    .prepare(
      `SELECT t.id, t.type, t.player_id, COALESCE(u.display_name, u.username) AS player_name,
              i.name AS item_name, t.quantity, t.amount, t.detail, t.created_at
         FROM transactions t
         JOIN users u ON u.id = t.player_id
         JOIN items i ON i.id = t.item_id
        WHERE t.type IN ('PURCHASE', 'SALE', 'UPGRADE')
        ORDER BY t.id DESC
        LIMIT ?`
    )
    .all(limit) as unknown as Array<{
    id: number;
    type: "PURCHASE" | "SALE" | "UPGRADE";
    detail: string | null;
    player_id: number;
    player_name: string;
    item_name: string;
    quantity: number;
    amount: number;
    created_at: string;
  }>;
  return rows.map((r) => ({
    id: r.id,
    type: r.type,
    playerId: r.player_id,
    playerName: r.player_name,
    itemName: r.item_name,
    quantity: r.quantity,
    total: r.amount,
    detail: r.detail,
    createdAt: r.created_at,
  }));
}

// ---- Purchase ---------------------------------------------------------

// A rule the purchase broke; the message is written for the player.
export class PurchaseError extends Error {
  constructor(message: string, public code: "CLOSED" | "GONE" | "RULE" | "PRICE_CHANGED" = "RULE") {
    super(message);
  }
}

// Buying, selling and upgrading all need the shop open, the game not
// paused or over, and the player not down (0 HP).
function assertTrading(db: DatabaseSync, verb: string, playerId: number): void {
  const play = gameAllowsPlay(db);
  if (!play.ok) throw new PurchaseError(`${play.reason} ${verb} is off for now.`, "CLOSED");
  if (!isShopOpen(db)) throw new PurchaseError("The shop is closed.", "CLOSED");
  const me = db.prepare("SELECT dead FROM users WHERE id = ?").get(playerId) as { dead: number } | undefined;
  if (me?.dead === 1) throw new PurchaseError(`You're down. ${verb} is off until the Admin revives you.`);
}

// What's bought must fit in the player's case (with room left for anything
// waiting in their tray). A backpack takes no room — it makes the case
// bigger — but buying one that can't add a row would only waste money.
function assertRoom(db: DatabaseSync, playerId: number, itemId: number, kind: ItemKind, packs: number, units: number) {
  if (kind !== "backpack") {
    if (!canFit(db, playerId, itemId, units)) throw new PurchaseError(NO_ROOM_TO_BUY);
    return;
  }
  const rowsLeft = getRules(db).caseMaxRows - caseSize(db, playerId).rows;
  if (rowsLeft <= 0) throw new PurchaseError("Your case is already as big as it can get.");
  const perPack = Math.max(1, findItemById(db, itemId)?.expand_rows ?? 1);
  const useful = Math.ceil(rowsLeft / perPack);
  if (packs > useful) {
    throw new PurchaseError(
      `Your case can only grow ${rowsLeft} more row${rowsLeft === 1 ? "" : "s"}, so buy at most ${useful}.`
    );
  }
}

// Everything a purchase touches happens inside ONE database transaction:
//   money down + transaction row, item added + inventory_log row, stock down.
// If any check or write fails, ROLLBACK undoes all of it — a player can
// never lose money without getting the item, or get the item for free.
// The whole function is synchronous, so two players buying the last unit
// at the same moment are handled one after the other, never interleaved.
//
// The price charged always comes from the database. `expectedPrice` is only
// what the player's screen showed: if the Admin changed the price since, the
// purchase is refused so nobody pays a price they didn't see.
export function purchase(
  db: DatabaseSync,
  input: { playerId: number; shopItemId: number; quantity: number; expectedPrice?: number }
): { balance: number; transaction: Transaction; owned: number; stock: number | null } {
  const { playerId, shopItemId, quantity } = input;

  if (!Number.isInteger(quantity) || quantity < 1 || quantity > MAX_ITEM_QUANTITY) {
    throw new PurchaseError("Choose a valid quantity.");
  }

  db.exec("BEGIN");
  try {
    assertTrading(db, "Buying", playerId);

    const s = findShopItem(db, shopItemId);
    if (!s) throw new PurchaseError("This item is no longer in the shop.", "GONE");
    if (s.enabled !== 1 || s.item_enabled !== 1) {
      throw new PurchaseError(`${s.name} isn't available right now.`, "GONE");
    }
    if (input.expectedPrice !== undefined && input.expectedPrice !== s.price) {
      throw new PurchaseError(
        `The price of ${s.name} just changed to $${s.price}. Check it and try again.`,
        "PRICE_CHANGED"
      );
    }
    if (s.max_per_purchase !== null && quantity > s.max_per_purchase) {
      throw new PurchaseError(`You can buy at most ${s.max_per_purchase} ${s.name} at a time.`);
    }
    if (s.stock !== null) {
      if (s.stock === 0) throw new PurchaseError(`${s.name} is out of stock.`);
      if (quantity > s.stock) throw new PurchaseError(`Only ${s.stock} ${s.name} left in stock.`);
    }

    const total = s.price * quantity;
    // Ammo is bought in packs; the case holds rounds.
    const units = quantity * unitsPerPack(s.kind, s.ammo_per_pack);
    assertRoom(db, playerId, s.item_id, s.kind, quantity, units);
    const inv = applyInventoryChange(db, {
      playerId,
      itemId: s.item_id,
      action: "PURCHASE",
      quantity: units,
      performedBy: playerId,
      cost: total,
      pieces: { mustFit: true, noRoom: NO_ROOM_TO_BUY },
    });
    const money = applyBalanceChange(db, {
      playerId,
      type: "PURCHASE",
      amount: total,
      performedBy: playerId,
      itemId: s.item_id,
      quantity,
    });
    let stock = s.stock;
    if (stock !== null) {
      stock -= quantity;
      db.prepare("UPDATE shop_items SET stock = ? WHERE id = ?").run(stock, s.id);
    }

    db.exec("COMMIT");
    return {
      balance: money.balance,
      transaction: getTransaction(db, money.transactionId),
      owned: inv.quantity,
      stock,
    };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

// ---- Selling back -------------------------------------------------------

// What the shop pays for `packs` of an item the player holds: sell_percent %
// (50 unless the Admin changed it) of what the player spent on those units,
// upgrades included. Worked out on the server only; players see it after
// they choose to sell, never in the shop list.
function quoteSale(db: DatabaseSync, playerId: number, itemId: number, packs: number) {
  if (!Number.isInteger(packs) || packs < 1 || packs > MAX_ITEM_QUANTITY) {
    throw new PurchaseError("Choose how many to sell.");
  }
  const item = findItemById(db, itemId);
  if (!item) throw new PurchaseError("Item not found.", "GONE");
  if (item.sellable !== 1) throw new PurchaseError(`The shop doesn't buy ${item.name}.`);
  const held = getHolding(db, playerId, itemId);
  const perPack = unitsPerPack(item.kind, item.ammo_per_pack);
  const units = packs * perPack;
  if (!held || held.quantity < units) {
    const have = held ? Math.floor(held.quantity / perPack) : 0;
    throw new PurchaseError(
      perPack > 1
        ? `You only have ${have} full pack${have === 1 ? "" : "s"} of ${item.name}.`
        : `You only have ${held?.quantity ?? 0} ${item.name}.`
    );
  }
  const spentShare = units === held.quantity ? held.spent : Math.floor((held.spent * units) / held.quantity);
  const amount = Math.floor((spentShare * item.sell_percent) / 100);
  return { item, units, amount };
}

export function sellQuote(
  db: DatabaseSync,
  input: { playerId: number; itemId: number; quantity: number }
): { amount: number; itemName: string; quantity: number } {
  const q = quoteSale(db, input.playerId, input.itemId, input.quantity);
  return { amount: q.amount, itemName: q.item.name, quantity: input.quantity };
}

// One transaction: item out of the bag (+ log), money in (+ transaction).
// `expectedAmount` is what the confirm screen showed; if it no longer
// matches, nothing happens and the player is asked to check again.
export function sell(
  db: DatabaseSync,
  input: { playerId: number; itemId: number; quantity: number; expectedAmount?: number }
): { balance: number; amount: number; itemName: string; owned: number; transaction: Transaction } {
  db.exec("BEGIN");
  try {
    assertTrading(db, "Selling", input.playerId);
    const q = quoteSale(db, input.playerId, input.itemId, input.quantity);
    if (input.expectedAmount !== undefined && input.expectedAmount !== q.amount) {
      throw new PurchaseError(`The offer for ${q.item.name} changed to $${q.amount}. Check it and try again.`, "PRICE_CHANGED");
    }
    const trayBefore = trayCount(db, input.playerId);
    const inv = applyInventoryChange(db, {
      playerId: input.playerId,
      itemId: q.item.id,
      action: "SELL",
      quantity: q.units,
      performedBy: input.playerId,
    });
    // Selling a backpack makes the case smaller: refuse if that would push
    // things out into the tray (ROLLBACK below undoes the sale).
    if (q.item.kind === "backpack" && trayCount(db, input.playerId) > trayBefore) {
      throw new PurchaseError("Your things wouldn't fit in a smaller case. Make room first, then sell it.");
    }
    const amount = Math.floor((inv.spentRemoved * q.item.sell_percent) / 100);
    const money = applyBalanceChange(db, {
      playerId: input.playerId,
      type: "SALE",
      amount,
      performedBy: input.playerId,
      itemId: q.item.id,
      quantity: input.quantity,
    });
    db.exec("COMMIT");
    return {
      balance: money.balance,
      amount,
      itemName: q.item.name,
      owned: inv.quantity,
      transaction: getTransaction(db, money.transactionId),
    };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

// ---- Weapon upgrades ------------------------------------------------------

// One transaction: money out (+ transaction), level up, and the cost added
// to what the player has spent on this weapon (so it counts when selling).
export function upgradeWeapon(
  db: DatabaseSync,
  input: { playerId: number; itemId: number; track: Track; expectedCost?: number }
): { balance: number; level: number; value: number | null; cost: number; itemName: string } {
  db.exec("BEGIN");
  try {
    assertTrading(db, "Upgrading", input.playerId);
    const item = findItemById(db, input.itemId);
    if (!item) throw new PurchaseError("Item not found.", "GONE");
    if (!tracksFor(item.kind).includes(input.track)) {
      throw new PurchaseError(`${item.name} doesn't have that upgrade.`);
    }
    const held = getHolding(db, input.playerId, item.id);
    if (!held || held.quantity < 1) throw new PurchaseError(`You don't have a ${item.name}.`);
    const level = levelsFor(db, input.playerId, item.id)[input.track];
    if (level >= MAX_LEVEL) {
      throw new PurchaseError(`${TRACK_LABEL[input.track]} is already at the top level.`);
    }
    const base = basePriceFor(item, input.track);
    if (base === null) throw new PurchaseError(`This upgrade isn't for sale yet.`);
    const cost = upgradeCost(base, level);
    if (input.expectedCost !== undefined && input.expectedCost !== cost) {
      throw new PurchaseError(`This upgrade now costs $${cost}. Check it and try again.`, "PRICE_CHANGED");
    }
    const next = level + 1;
    const money = applyBalanceChange(db, {
      playerId: input.playerId,
      type: "UPGRADE",
      amount: cost,
      performedBy: input.playerId,
      itemId: item.id,
      detail: `${TRACK_LABEL[input.track]} level ${next}`,
    });
    setLevel(db, input.playerId, item.id, input.track, next);
    addSpent(db, input.playerId, item.id, cost);
    db.exec("COMMIT");
    return {
      balance: money.balance,
      level: next,
      value: statAt(item, input.track, next, getDamagePerLevel(db)),
      cost,
      itemName: item.name,
    };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
