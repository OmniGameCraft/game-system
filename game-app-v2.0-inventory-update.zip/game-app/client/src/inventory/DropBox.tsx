import { useState } from "react";
import { Icon } from "../components/Icon";
import { Stepper } from "../components/Stepper";
import { toPiece, type Drop } from "./caseApi";
import { PieceArt } from "./PieceView";
import { Reason } from "./ItemActionSheet";
import { Sheet, SheetButton } from "./Sheet";

// The drop box: things players dropped (or lost when they went down) that
// anyone can pick up. Updates live as others drop and pick things up.

// "just now", "3 min ago", "1 h ago" (server times are UTC).
function ago(iso: string): string {
  const t = new Date(iso.replace(" ", "T") + (iso.endsWith("Z") ? "" : "Z")).getTime();
  if (!Number.isFinite(t)) return "";
  const s = Math.max(0, Math.round((Date.now() - t) / 1000));
  if (s < 45) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  return `${Math.round(m / 60)} h ago`;
}

function amountText(d: Drop): string | null {
  if (d.kind === "ammo") return `${d.quantity} round${d.quantity === 1 ? "" : "s"}`;
  if (d.kind === "gun") return d.loaded > 0 ? `${d.loaded} loaded` : "empty";
  return d.quantity > 1 ? `×${d.quantity}` : null;
}

export function DropBox({
  open,
  drops,
  blockedReason,
  busyId,
  onPickup,
  onClose,
}: {
  open: boolean;
  drops: Drop[];
  blockedReason: string | null; // dead / paused / ended
  busyId: number | null;
  onPickup: (d: Drop, quantity: number) => void;
  onClose: () => void;
}) {
  const [choosing, setChoosing] = useState<{ id: number; n: number } | null>(null);

  return (
    <Sheet
      open={open}
      onClose={onClose}
      label="Drop box"
      footer={
        <SheetButton onClick={onClose} icon={<Icon name="close" className="h-5 w-5" />}>
          Close
        </SheetButton>
      }
    >
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-sm border border-white/15 bg-black/40 text-pine">
            <Icon name="drop" className="h-7 w-7" />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-2xl font-bold leading-tight">Drop box</h2>
            <p className="text-sm text-ink/65">Items on the ground. Anyone can pick them up.</p>
          </div>
        </div>

        {blockedReason && <Reason text={blockedReason} />}

        {drops.length === 0 ? (
          <div className="flex flex-col items-center gap-2 rounded-sm border border-dashed border-white/15 px-4 py-8 text-center">
            <Icon name="box" className="h-10 w-10 text-white/25" />
            <p className="font-display text-lg font-bold">Nothing here</p>
            <p className="max-w-xs text-sm text-ink/65">
              Drop items here for your team (drag a piece onto “Drop box”). When a player goes down, their gear lands here too.
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {drops.map((d, i) => {
              const amount = amountText(d);
              const art = toPiece({ ...d, rotated: false, stackSize: d.quantity });
              // Picture keeps the item's shape but fits a small box.
              const cell = Math.max(12, Math.min(40, Math.floor(80 / d.w), Math.floor(56 / d.h)));
              const isChoosing = choosing?.id === d.id;
              return (
                <li key={d.id} className="cs-drop-row cs-stagger" style={{ animationDelay: `${Math.min(i, 8) * 35}ms` }}>
                  <div className="flex items-center gap-3">
                    <span className="flex h-14 w-20 shrink-0 items-center justify-center">
                      <span className="cs-sheet-pic" style={{ width: d.w * cell, height: d.h * cell }}>
                        <PieceArt piece={art} cell={cell} rotated={false} numbers={false} />
                      </span>
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="break-words font-semibold leading-tight text-white">
                        {d.name}
                        {amount && <span className="font-normal text-white/60"> · {amount}</span>}
                      </p>
                      <p className={`mt-0.5 text-sm ${d.reason === "DEATH" ? "text-alert/90" : "text-ink/60"}`}>
                        {d.reason === "DEATH" && <Icon name="skull" className="mr-1 inline h-3.5 w-3.5 align-[-2px]" />}
                        From {d.ownerName}
                        {d.reason === "DEATH" ? " (fell)" : ""}
                        {d.createdAt && <span className="text-ink/45"> · {ago(d.createdAt)}</span>}
                      </p>
                    </div>
                  </div>
                  {isChoosing && choosing ? (
                    <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                      <Stepper value={choosing.n} onChange={(n) => setChoosing({ id: d.id, n })} min={1} max={d.quantity} label="How many to pick up" />
                      <div className="flex gap-2">
                        <button type="button" className="cs-btn cs-btn-plain !min-h-[2.75rem] !w-auto !px-3" onClick={() => setChoosing(null)}>
                          Cancel
                        </button>
                        <button
                          type="button"
                          data-sound="none"
                          disabled={busyId !== null}
                          className="cs-btn cs-btn-primary !min-h-[2.75rem] !w-auto !px-3"
                          onClick={() => {
                            onPickup(d, choosing.n);
                            setChoosing(null);
                          }}
                        >
                          Take {choosing.n}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-2 flex items-center justify-end gap-3">
                      {d.quantity > 1 && !blockedReason && (
                        <button
                          type="button"
                          className="mr-auto min-h-[2.75rem] text-sm font-semibold text-pine"
                          onClick={() => setChoosing({ id: d.id, n: Math.max(1, Math.floor(d.quantity / 2)) })}
                        >
                          Take only some…
                        </button>
                      )}
                      <button
                        type="button"
                        data-sound="none"
                        disabled={!!blockedReason || busyId !== null}
                        onClick={() => onPickup(d, d.quantity)}
                        className="cs-btn cs-btn-primary !min-h-[2.75rem] !w-auto shrink-0 !px-4"
                      >
                        <Icon name="pickup" className="h-5 w-5" />
                        {busyId === d.id ? "Picking up…" : "Pick up"}
                      </button>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </Sheet>
  );
}
