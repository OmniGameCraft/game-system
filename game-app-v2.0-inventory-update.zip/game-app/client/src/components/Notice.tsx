// Good news ("Saved.", "Player created."): green, slides in gently.
export function Notice({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p
      key={message}
      role="status"
      className="flex animate-enter items-start gap-3 rounded-md border border-olive/25 border-l-4 border-l-olive bg-olive-soft px-4 py-3 font-medium text-ink"
    >
      <svg viewBox="0 0 24 24" className="mt-0.5 h-5 w-5 shrink-0 text-olive" fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <path d="M5 12.5l4.5 4.5L19 7.5" />
      </svg>
      <span className="min-w-0">{message}</span>
    </p>
  );
}
