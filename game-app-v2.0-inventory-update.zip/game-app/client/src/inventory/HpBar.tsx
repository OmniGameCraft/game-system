import { CSSProperties, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Icon } from "../components/Icon";
import { useSettings } from "../audio/settings";
import type { HpState } from "./caseApi";
import { onHpFlash, type HpFlashKind } from "./hpStore";
import "./case.css";

// Health shown three ways: a big animated bar (case + weapon screens), a
// small pill for the top bar, and a full-screen red/green flash when hit or
// healed. Exported to the rest of the app through services/hp.ts.

type RGB = [number, number, number];
const RED: RGB = [255, 77, 77];
const AMBER: RGB = [245, 165, 36];
const GREEN: RGB = [110, 212, 90];
// Full health is green, half is amber, low is red, blending in between.
const STOPS: Array<[number, RGB]> = [
  [0, RED],
  [0.25, RED],
  [0.5, AMBER],
  [0.78, GREEN],
  [1, GREEN],
];

function mix(a: RGB, b: RGB, t: number): RGB {
  return [0, 1, 2].map((i) => Math.round(a[i] + (b[i] - a[i]) * t)) as RGB;
}

export function hpRgb(pct: number): RGB {
  const p = Math.max(0, Math.min(1, pct));
  for (let i = 1; i < STOPS.length; i++) {
    const [p1, c1] = STOPS[i];
    const [p0, c0] = STOPS[i - 1];
    if (p <= p1) return mix(c0, c1, p1 === p0 ? 1 : (p - p0) / (p1 - p0));
  }
  return GREEN;
}

const rgba = (c: RGB, a = 1) => `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${a})`;

function ratio(s: HpState): number {
  return s.maxHp > 0 ? Math.max(0, Math.min(1, s.hp / s.maxHp)) : 0;
}

// Counts a number up/down instead of jumping (HP ticks like a game HUD).
function useTween(value: number, ms: number): number {
  const [shown, setShown] = useState(value);
  const shownRef = useRef(value);
  useEffect(() => {
    if (ms <= 0 || shownRef.current === value) {
      shownRef.current = value;
      setShown(value);
      return;
    }
    const from = shownRef.current;
    const start = performance.now();
    let raf = 0;
    const step = (t: number) => {
      const k = Math.min(1, (t - start) / ms);
      const eased = 1 - Math.pow(1 - k, 3);
      const v = Math.round(from + (value - from) * eased);
      shownRef.current = v;
      setShown(v);
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value, ms]);
  return shown;
}

// Watches HP and reports "hit" / "heal" moments so the bar can flash.
function useHpFx(hp: HpState): { kind: HpFlashKind; n: number } | null {
  const prev = useRef(hp);
  const [fx, setFx] = useState<{ kind: HpFlashKind; n: number } | null>(null);
  useEffect(() => {
    const before = prev.current;
    prev.current = hp;
    if (hp.hp < before.hp || (hp.dead && !before.dead)) setFx((f) => ({ kind: "hit", n: (f?.n ?? 0) + 1 }));
    else if (hp.hp > before.hp || hp.maxHp > before.maxHp) setFx((f) => ({ kind: "heal", n: (f?.n ?? 0) + 1 }));
  }, [hp.hp, hp.maxHp, hp.dead]);
  return fx;
}

export function HeartGlyph({ className = "h-5 w-5", style }: { className?: string; style?: CSSProperties }) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden>
      <path
        fill="currentColor"
        d="M12 21s-7-4.4-9.3-9A5.4 5.4 0 0 1 12 6.3 5.4 5.4 0 0 1 21.3 12C19 16.6 12 21 12 21z"
      />
      <path fill="rgba(255,255,255,0.35)" d="M7.2 8.4c-1.3.3-2.3 1.5-2.4 2.9-.1.5.7.6.8.1.2-1 .9-1.8 1.8-2.1.5-.1.3-1-.2-.9z" />
    </svg>
  );
}

export function HpBar({ hp, size = "md" }: { hp: HpState; size?: "sm" | "md" | "lg" }) {
  const [{ reduceMotion }] = useSettings();
  const pct = ratio(hp);
  const color = hpRgb(pct);
  const shown = useTween(hp.hp, reduceMotion ? 0 : 450);
  const fx = useHpFx(hp);

  // The "lost" piece of a hit lingers red for a moment, then drains away —
  // easy to read at a glance how hard the hit was.
  const prev = useRef(hp);
  const [trail, setTrail] = useState({ pct, tone: "loss" as "loss" | "gain", moving: false });
  const [fillMs, setFillMs] = useState(500);
  useEffect(() => {
    const before = prev.current;
    prev.current = hp;
    const was = ratio(before);
    if (was === pct) return;
    if (pct < was) {
      setFillMs(140);
      setTrail({ pct: was, tone: "loss", moving: false });
      const t = window.setTimeout(() => setTrail({ pct, tone: "loss", moving: true }), reduceMotion ? 0 : 420);
      return () => clearTimeout(t);
    }
    setFillMs(reduceMotion ? 0 : 700);
    setTrail({ pct, tone: "gain", moving: false });
  }, [pct, reduceMotion]); // eslint-disable-line react-hooks/exhaustive-deps

  const low = !hp.dead && pct <= 0.25;
  const track = size === "lg" ? "h-4" : size === "md" ? "h-3" : "h-2";
  const label = hp.dead ? "Health: down" : `Health ${hp.hp} of ${hp.maxHp}`;

  const number = hp.dead ? (
    <span className="flex items-center gap-1 font-display font-bold uppercase tracking-wider text-alert">
      <Icon name="skull" className={size === "lg" ? "h-6 w-6" : "h-4 w-4"} />
      Down
    </span>
  ) : (
    <span
      key={fx?.kind === "hit" ? `h${fx.n}` : "n"}
      className={`cs-hp-num font-display font-bold tabular-nums leading-none ${fx?.kind === "hit" && !reduceMotion ? "cs-shake" : ""} ${
        size === "lg" ? "text-2xl" : size === "md" ? "text-lg" : "text-sm"
      }`}
      style={{ color: size === "sm" ? undefined : "#fff" }}
    >
      {shown}
      <span className={`font-semibold text-white/50 ${size === "lg" ? "text-base" : "text-xs"}`}> / {hp.maxHp}</span>
    </span>
  );

  const bar = (
    <div
      className={`cs-hp-track relative ${track} ${size === "sm" ? "min-w-0 flex-1" : "w-full"} ${hp.dead ? "cs-hp-dead" : ""}`}
    >
      <span
        className="cs-hp-trail"
        style={{
          width: `${trail.pct * 100}%`,
          background: trail.tone === "loss" ? "rgba(255, 90, 80, 0.85)" : "rgba(200, 255, 190, 0.55)",
          transition: trail.moving && !reduceMotion ? "width 520ms cubic-bezier(.3,.7,.3,1)" : "none",
        }}
      />
      <span
        className={`cs-hp-fill ${low && !reduceMotion ? "cs-hp-low" : ""}`}
        style={
          {
            width: `${pct * 100}%`,
            transitionDuration: `${fillMs}ms`,
            "--hp-c": rgba(color),
            "--hp-c2": rgba(mix(color, [0, 0, 0], 0.35)),
          } as CSSProperties
        }
      />
      <span className="cs-hp-ticks" aria-hidden />
      {fx && !reduceMotion && <span key={fx.n} className={fx.kind === "hit" ? "cs-hp-fx-hit" : "cs-hp-fx-heal"} aria-hidden />}
    </div>
  );

  const heart = (
    <HeartGlyph
      className={`${size === "lg" ? "h-6 w-6" : size === "md" ? "h-5 w-5" : "h-4 w-4"} shrink-0 ${low && !reduceMotion ? "cs-heartbeat" : ""}`}
      style={{ color: hp.dead ? "#6b1f1f" : rgba(color) }}
    />
  );

  if (size === "sm") {
    return (
      <div className="flex w-full items-center gap-2" role="meter" aria-label={label} aria-valuemin={0} aria-valuemax={hp.maxHp} aria-valuenow={hp.hp}>
        {heart}
        {bar}
        <span className="shrink-0 text-white">{number}</span>
      </div>
    );
  }

  return (
    <div className="flex w-full flex-col gap-1.5" role="meter" aria-label={label} aria-valuemin={0} aria-valuemax={hp.maxHp} aria-valuenow={hp.hp}>
      <div className="flex items-end justify-between gap-3">
        <span className="flex items-center gap-1.5 font-display text-sm font-bold uppercase tracking-[0.18em] text-white/60">
          {heart}
          Health
        </span>
        {number}
      </div>
      {bar}
    </div>
  );
}

// Compact top-bar version: heart + "85/100", coloured by how healthy you are.
export function HpPill({ hp }: { hp: HpState }) {
  const [{ reduceMotion }] = useSettings();
  const pct = ratio(hp);
  const color = hp.dead ? RED : hpRgb(pct);
  const shown = useTween(hp.hp, reduceMotion ? 0 : 400);
  const fx = useHpFx(hp);
  const low = !hp.dead && pct <= 0.25;
  return (
    <span
      className="cs-hp-pill relative inline-flex shrink-0 items-center gap-1 font-display font-bold tabular-nums"
      style={{ color: rgba(color), borderColor: rgba(color, 0.55), background: rgba(color, 0.13) }}
      role="status"
      aria-label={hp.dead ? "Health: down" : `Health ${hp.hp} of ${hp.maxHp}`}
    >
      {hp.dead ? (
        <>
          <Icon name="skull" className="h-4 w-4" />
          <span className="text-sm uppercase tracking-wider">Down</span>
        </>
      ) : (
        <>
          <HeartGlyph className={`h-4 w-4 ${low && !reduceMotion ? "cs-heartbeat" : ""}`} />
          <span className="text-base leading-none">
            {shown}
            <span className="text-xs opacity-60">/{hp.maxHp}</span>
          </span>
        </>
      )}
      {fx && !reduceMotion && <span key={fx.n} className={fx.kind === "hit" ? "cs-pill-fx-hit" : "cs-pill-fx-heal"} aria-hidden />}
      <DamageFlash />
    </span>
  );
}

// Full-screen red (hit) or green (heal) edge flash. Any number of copies can
// be mounted; only the first one draws, so a hit never flashes twice.
const hosts: Array<(on: boolean) => void> = [];
function elect() {
  hosts.forEach((setHost, i) => setHost(i === 0));
}

export function DamageFlash() {
  const [host, setHost] = useState(false);
  const [flash, setFlash] = useState<{ kind: HpFlashKind; n: number } | null>(null);
  const [{ reduceMotion }] = useSettings();

  useEffect(() => {
    hosts.push(setHost);
    elect();
    const off = onHpFlash((kind) => setFlash((f) => ({ kind, n: (f?.n ?? 0) + 1 })));
    return () => {
      off();
      const i = hosts.indexOf(setHost);
      if (i >= 0) hosts.splice(i, 1);
      elect();
    };
  }, []);

  useEffect(() => {
    if (!flash) return;
    const t = setTimeout(() => setFlash(null), reduceMotion ? 350 : 900);
    return () => clearTimeout(t);
  }, [flash, reduceMotion]);

  if (!host || !flash || typeof document === "undefined") return null;
  return createPortal(
    <div
      key={flash.n}
      className={`cs-vignette ${flash.kind === "hit" ? "cs-vignette-hit" : "cs-vignette-heal"} ${reduceMotion ? "cs-vignette-still" : ""}`}
      aria-hidden
    />,
    document.body
  );
}
