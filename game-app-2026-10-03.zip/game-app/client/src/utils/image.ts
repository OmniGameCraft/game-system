// Shrinks a picture on the phone before upload, so a 4 MB camera photo
// becomes a small file that loads fast for every player over Wi-Fi.
// Uses the browser's own canvas — nothing downloaded from the internet.
const MAX_SIDE = 512;

export function resizeImageToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Please choose a picture file."));
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, MAX_SIDE / Math.max(img.width, img.height));
      const w = Math.max(1, Math.round(img.width * scale));
      const h = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      URL.revokeObjectURL(url);
      if (!ctx) {
        reject(new Error("Could not read that picture."));
        return;
      }
      ctx.drawImage(img, 0, 0, w, h);
      // WEBP keeps transparent backgrounds (handy for weapon cut-outs) and is
      // small. Browsers that can't make WEBP fall back to PNG automatically.
      resolve(canvas.toDataURL("image/webp", 0.85));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read that picture."));
    };
    img.src = url;
  });
}
