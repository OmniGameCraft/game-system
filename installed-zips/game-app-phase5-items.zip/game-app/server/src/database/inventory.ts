import { DatabaseSync } from "node:sqlite";
import { imageUrlFor } from "./items";

export type InventoryAction = "GIVE" | "REMOVE" | "SET";

// Sanity cap on how many of one item a single player can hold or be given in
// one go — guards against typos, well inside SQLite/JS integer range.
export const MAX_ITEM_QUANTITY = 1_000_000;

export interface InventoryEntry {
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  enabled: boolean;
  maxStack: number | null;
  quantity: number;
}

interface InventoryRow {
  item_id: number;
  name: string;
  description: string | null;
  category: string | null;
  image_file: string | null;
  enabled: number;
  max_stack: number | null;
  quantity: number;
}

export function listInventoryForPlayer(db: DatabaseSync, playerId: number): InventoryEntry[] {
  const rows = db
    .prepare(
      `SELECT inv.item_id, inv.quantity, i.name, i.description, i.category,
              i.image_file, i.enabled, i.max_stack
         FROM inventory inv
         JOIN items i ON i.id = inv.item_id
        WHERE inv.player_id = ?
        ORDER BY i.name COLLATE NOCASE`
    )
    .all(playerId) as unknown as InventoryRow[];
  return rows.map((r) => ({
    itemId: r.item_id,
    name: r.name,
    description: r.description,
    category: r.category,
    imageUrl: imageUrlFor(r.image_file),
    enabled: r.enabled === 1,
    maxStack: r.max_stack,
    quantity: r.quantity,
  }));
}

export interface InventoryLogEntry {
  id: number;
  itemId: number;
  itemName: string;
  action: InventoryAction;
  quantityBefore: number;
  quantityAfter: number;
  performedBy: number;
  createdAt: string;
}

export function listInventoryLog(db: DatabaseSync, playerId: number): InventoryLogEntry[] {
  const rows = db
    .prepare(
      `SELECT l.*, i.name AS item_name
         FROM inventory_log l
         JOIN items i ON i.id = l.item_id
        WHERE l.player_id = ?
        ORDER BY l.id DESC`
    )
    .all(playerId) as unknown as Array<{
    id: number;
    item_id: number;
    item_name: string;
    action: InventoryAction;
    quantity_before: number;
    quantity_after: number;
    performed_by: number;
    created_at: string;
  }>;
  return rows.map((r) => ({
    id: r.id,
    itemId: r.item_id,
    itemName: r.item_name,
    action: r.action,
    quantityBefore: r.quantity_before,
    quantityAfter: r.quantity_after,
    performedBy: r.performed_by,
    createdAt: r.created_at,
  }));
}

// A rule the request broke (message is safe to show the Admin as-is).
export class InventoryRuleError extends Error {}
export class ItemNotFoundError extends Error {}

// Changes how many of one item a player holds and writes the audit row, as
// one atomic step. Same reasoning as adjustBalance in money.ts: everything
// here is synchronous, so no other request can run between the read of the
// current quantity and the write — two quick taps can't both pass the
// max-per-player check and overshoot it.
export function changeInventory(
  db: DatabaseSync,
  input: {
    playerId: number;
    itemId: number;
    action: InventoryAction;
    quantity: number;
    performedBy: number;
  }
): { quantity: number } {
  const { playerId, itemId, action, quantity, performedBy } = input;

  db.exec("BEGIN");
  try {
    const item = db
      .prepare("SELECT name, enabled, max_stack FROM items WHERE id = ?")
      .get(itemId) as { name: string; enabled: number; max_stack: number | null } | undefined;
    if (!item) throw new ItemNotFoundError("Item not found.");

    const row = db
      .prepare("SELECT quantity FROM inventory WHERE player_id = ? AND item_id = ?")
      .get(playerId, itemId) as { quantity: number } | undefined;
    const before = row?.quantity ?? 0;
    const after =
      action === "GIVE" ? before + quantity : action === "REMOVE" ? before - quantity : quantity;

    if (after < 0) {
      throw new InventoryRuleError(
        before === 0
          ? `This player doesn't have any ${item.name}.`
          : `This player only has ${before} ${item.name}.`
      );
    }
    if (after === before) {
      throw new InventoryRuleError(`This player already has ${before} ${item.name}.`);
    }
    if (after > before) {
      // Anything that increases the count counts as giving.
      if (item.enabled !== 1) {
        throw new InventoryRuleError(`${item.name} is disabled. Enable it before giving it out.`);
      }
      if (item.max_stack !== null && after > item.max_stack) {
        throw new InventoryRuleError(
          `A player can hold at most ${item.max_stack} ${item.name}. This player has ${before}.`
        );
      }
      if (after > MAX_ITEM_QUANTITY) {
        throw new InventoryRuleError(`A player can hold at most ${MAX_ITEM_QUANTITY} of one item.`);
      }
    }

    if (after === 0) {
      db.prepare("DELETE FROM inventory WHERE player_id = ? AND item_id = ?").run(playerId, itemId);
    } else if (before === 0) {
      db.prepare("INSERT INTO inventory (player_id, item_id, quantity) VALUES (?, ?, ?)").run(
        playerId,
        itemId,
        after
      );
    } else {
      db.prepare("UPDATE inventory SET quantity = ? WHERE player_id = ? AND item_id = ?").run(
        after,
        playerId,
        itemId
      );
    }

    db.prepare(
      `INSERT INTO inventory_log
         (player_id, item_id, action, quantity_before, quantity_after, performed_by)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(playerId, itemId, action, before, after, performedBy);

    db.exec("COMMIT");
    return { quantity: after };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
