import { lazy, Suspense, useEffect, useState } from "react";
import { useLive } from "../services/live";
import { ErrorBanner } from "../components/ErrorBanner";
import { Icon } from "../components/Icon";
import { ItemImage } from "../components/ItemImage";
import { Section, SectionAction } from "../components/Section";
import { getMyInventory, InventoryEntry } from "../services/api";
import { isUsable, leaveViewer, prepareViewer } from "../viewer/open";

// three.js is big, so the viewer is only downloaded the first time a player
// opens an item — the rest of the app stays quick on phones.
const ItemViewer = lazy(() => import("../viewer/ItemViewer"));

const ACTION = {
  shot: { label: "Fire", icon: "target" as const },
  swing: { label: "Swing", icon: "target" as const },
  none: { label: "View in 3D", icon: "cube" as const },
};

export function PlayerInventory() {
  const [inventory, setInventory] = useState<InventoryEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [viewing, setViewing] = useState<InventoryEntry | null>(null);

  function load() {
    setError(null);
    setLoading(true);
    getMyInventory()
      .then((inv) => {
        setInventory(inv);
        // If the item being viewed was taken away, close the viewer.
        setViewing((v) => (v && !inv.some((e) => e.itemId === v.itemId) ? null : v));
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load."))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);
  useLive(["me:changed", "items:changed"], load);

  function open(e: InventoryEntry) {
    prepareViewer(e.useEffect); // sound, shake and full screen must start from this tap
    setViewing(e);
  }
  function close() {
    leaveViewer();
    setViewing(null);
  }

  const refresh = (
    <SectionAction onClick={load} disabled={loading}>
      <Icon name="refresh" className="h-4 w-4" />
      {loading ? "…" : "Refresh"}
    </SectionAction>
  );

  return (
    <>
      <ErrorBanner message={error} />
      <Section title={`My items${inventory ? ` (${inventory.length})` : ""}`} action={refresh} flush>
        {inventory === null && !error && <p className="p-4 text-ink/60">Loading…</p>}
        {inventory?.length === 0 && <p className="px-4 py-8 text-center text-lg text-ink/70">Your bag is empty.</p>}
        <ul className="divide-y-2 divide-ink/5">
          {inventory?.map((e) => {
            const usable = isUsable(e);
            const action = ACTION[e.useEffect] ?? ACTION.none;
            return (
              <li key={e.itemId} className="flex flex-col gap-3 px-4 py-3">
                <div className="flex gap-4">
                  <button
                    type="button"
                    disabled={!usable}
                    onClick={() => open(e)}
                    className="shrink-0 disabled:cursor-default"
                    aria-label={usable ? `${action.label} ${e.name}` : undefined}
                  >
                    <ItemImage url={e.imageUrl} name={e.name} />
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-lg font-bold leading-tight text-ink">{e.name}</p>
                      <span className="shrink-0 rounded-lg bg-pine px-2.5 py-1 text-lg font-extrabold leading-none text-white">
                        ×{e.quantity}
                      </span>
                    </div>
                    {e.category && <p className="text-sm font-semibold text-ink/55">{e.category}</p>}
                    {e.description && <p className="mt-1 text-sm text-ink/80">{e.description}</p>}
                  </div>
                </div>
                {usable && (
                  <button
                    type="button"
                    onClick={() => open(e)}
                    className={`flex min-h-[3.25rem] items-center justify-center gap-2 rounded-xl text-lg font-extrabold active:scale-[0.99] ${
                      e.useEffect === "none" ? "border-2 border-pine/30 text-pine" : "bg-ink text-white"
                    }`}
                  >
                    <Icon name={action.icon} className="h-6 w-6" />
                    {action.label}
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      </Section>

      {viewing && (
        <Suspense
          fallback={
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0b140f] text-white/70">
              Loading…
            </div>
          }
        >
          <ItemViewer item={viewing} onClose={close} />
        </Suspense>
      )}
    </>
  );
}
