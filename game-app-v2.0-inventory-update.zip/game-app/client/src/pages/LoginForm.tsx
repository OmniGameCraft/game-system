import { FormEvent, useState } from "react";
import { Button } from "../components/Button";
import { ErrorBanner } from "../components/ErrorBanner";
import { PasswordField, TextField } from "../components/Field";
import { BackButton } from "../components/BackButton";
import { BrandHeader } from "../components/Brand";
import { Section } from "../components/Section";
import { playSfx } from "../audio/sfx";
import { login, PublicUser, Role } from "../services/api";

interface Props {
  role: Role;
  hint?: string;
  onSuccess: (user: PublicUser) => void;
  onBack: () => void;
}

export function LoginForm({ role, hint, onSuccess, onBack }: Props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setLoading(true);
    try {
      const user = await login({ role, username, password });
      playSfx("success");
      onSuccess(user);
    } catch (err) {
      playSfx("error");
      setError(err instanceof Error ? err.message : "Login failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      <BrandHeader compact />
      <BackButton label="Back" onClick={onBack} />
      <Section title={role === "admin" ? "Admin login" : "Player login"}>
        {hint && <p className="rounded-md border border-pine/25 bg-pine-soft px-4 py-3 text-ink/85">{hint}</p>}
        <ErrorBanner message={error} />
        <TextField
          id="username"
          label="Username"
          autoComplete="username"
          autoCapitalize="none"
          autoCorrect="off"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <PasswordField
          id="password"
          label="Password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <Button type="submit" loading={loading}>
          Log in
        </Button>
      </Section>
    </form>
  );
}
