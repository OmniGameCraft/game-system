import { DatabaseSync } from "node:sqlite";
import { transaction } from "../database/db";
import { getGameStatus } from "../database/game";
import { applyHealing, getHp, healEffectOf, HpChange } from "../database/health";
import { applyInventoryChange, returnRounds } from "../database/inventory";
import { findItemById, Item } from "../database/items";
import { getRules } from "../database/settings";
import { gunNumbers } from "../database/weapons";
import { CaseError, ownPiece, PieceRow, setLoaded } from "./grid";

// Firing, reloading and using healing items — the weapon screen's server
// side. Every number (magazine size, reload time…) comes from
// database/weapons.ts; the phone never works them out itself.

// ---- When things are allowed ---------------------------------------------------

//   fire / reload   game running; before it starts only as practice (if the
//                   practiceFire rule is on — nothing is used up)
//   use (healing)   game running
//   mix, drop,      any time except paused or over (mixing isn't combat)
//   pick up
// A player who is down (0 HP) can do none of these.
export type CaseAct = "fire" | "use" | "mix" | "drop" | "pickup";

const DOWN = "You're down. Ask the Admin to revive you.";

export function gate(db: DatabaseSync, playerId: number, act: CaseAct): { practice: boolean } {
  const { status } = getGameStatus(db);
  if (status === "paused") throw new CaseError("The game is paused. Wait for the Admin to continue it.", 409);
  if (status === "ended") throw new CaseError("The game is over.", 409);
  let practice = false;
  if (status === "not_started") {
    if (act === "use") throw new CaseError("Healing works once the game starts.", 409);
    if (act === "fire") {
      if (!getRules(db).practiceFire) throw new CaseError("The game hasn't started yet.", 409);
      practice = true;
    }
  }
  if (getHp(db, playerId).dead) throw new CaseError(DOWN, 409);
  return { practice };
}

// ---- Ammo -----------------------------------------------------------------------

// The ammo items that fit a gun: the ones the player holds first.
export function ammoItemIdsFor(db: DatabaseSync, gunItemId: number): number[] {
  return (
    db
      .prepare("SELECT id FROM items WHERE ammo_for_item_id = ? AND kind = 'ammo' ORDER BY enabled DESC, id")
      .all(gunItemId) as unknown as Array<{ id: number }>
  ).map((r) => r.id);
}

// Rounds of matching ammo the player carries (not counting what's loaded).
export function reserveFor(db: DatabaseSync, playerId: number, gunItemId: number): number {
  const r = db
    .prepare(
      `SELECT COALESCE(SUM(inv.quantity), 0) AS n
         FROM inventory inv JOIN items i ON i.id = inv.item_id
        WHERE inv.player_id = ? AND i.ammo_for_item_id = ? AND i.kind = 'ammo'`
    )
    .get(playerId, gunItemId) as { n: number };
  return r.n;
}

// A magazine never holds more than it can (the Admin may have made it
// smaller): extra rounds go back into the player's ammo. Returns what's
// loaded now.
function clampOne(db: DatabaseSync, piece: PieceRow, item: Item, magazine: number): number {
  if (piece.loaded <= magazine) return piece.loaded;
  setLoaded(db, piece.id, magazine);
  returnRounds(db, piece.player_id, item.id, piece.loaded - magazine, piece.player_id);
  return magazine;
}

// Same for every gun piece of an item (or of a player): after the Admin
// changed a gun, or at server start. A piece that isn't a gun any more
// gives back everything it had loaded.
export function clampLoaded(db: DatabaseSync, filter: { itemId?: number; playerId?: number } = {}): void {
  const where = ["loaded > 0"];
  const args: number[] = [];
  if (filter.itemId !== undefined) {
    where.push("item_id = ?");
    args.push(filter.itemId);
  }
  if (filter.playerId !== undefined) {
    where.push("player_id = ?");
    args.push(filter.playerId);
  }
  const pieces = db
    .prepare(`SELECT * FROM inventory_pieces WHERE ${where.join(" AND ")} ORDER BY id`)
    .all(...args) as unknown as PieceRow[];
  for (const piece of pieces) {
    const item = findItemById(db, piece.item_id);
    if (!item) continue;
    clampOne(db, piece, item, item.kind === "gun" ? gunNumbers(db, piece.player_id, item).magazine : 0);
  }
}

// ---- Practice firing (before the game starts) --------------------------------------

// Practice never touches the real magazine (or a player could start the
// game with free rounds). Each gun gets a pretend magazine here, in memory
// only, forgotten whenever the game's status changes.
const practiceRounds = new Map<number, number>();

export function forgetPractice(): void {
  practiceRounds.clear();
}

// ---- Fire ---------------------------------------------------------------------------

export interface FireResult {
  loaded: number; // rounds left in the magazine
  reserve: number; // rounds of matching ammo carried
  magazine: number | null; // capacity (null for a knife)
  fired: number; // shots that actually went off
  empty: boolean; // asked for more shots than were loaded
  practice: boolean;
}

// `shots` arrive in small batches from the phone (1–10 at a time). Firing
// beyond what's loaded only fires what's there and reports empty. Knives
// just swing.
export function fire(db: DatabaseSync, playerId: number, pieceId: unknown, shots: number): FireResult {
  return transaction(db, () => {
    const { piece, item } = ownPiece(db, playerId, pieceId);
    if (item.kind !== "gun" && item.kind !== "knife") throw new CaseError(`${item.name} can't be fired.`);
    const { practice } = gate(db, playerId, "fire");
    if (item.kind === "knife") return { loaded: 0, reserve: 0, magazine: null, fired: 0, empty: false, practice };

    const { magazine } = gunNumbers(db, playerId, item);
    const reserve = reserveFor(db, playerId, item.id);
    if (practice) {
      const have = Math.min(magazine, practiceRounds.get(piece.id) ?? magazine);
      const fired = Math.min(shots, have);
      practiceRounds.set(piece.id, have - fired);
      return { loaded: have - fired, reserve, magazine, fired, empty: fired < shots, practice };
    }
    const have = clampOne(db, piece, item, magazine);
    const fired = Math.min(shots, have);
    if (fired > 0) setLoaded(db, piece.id, have - fired);
    return { loaded: have - fired, reserve, magazine, fired, empty: fired < shots, practice };
  });
}

// ---- Reload ---------------------------------------------------------------------------

export interface ReloadResult {
  loaded: number;
  reserve: number;
  magazine: number;
  reloadMs: number; // how long the phone shows the reload
  reloaded: number; // rounds moved in (0 = it was already full)
  practice: boolean;
}

// Fills the magazine from the player's ammo for this gun: from the tray
// first, then the smallest stacks (so a box with 1 round left is used up
// and its cell freed). Logged as RELOAD. Practice: free and instant.
export function reload(db: DatabaseSync, playerId: number, pieceId: unknown): ReloadResult {
  return transaction(db, () => {
    const { piece, item } = ownPiece(db, playerId, pieceId);
    if (item.kind !== "gun") throw new CaseError(`${item.name} doesn't need reloading.`);
    const { practice } = gate(db, playerId, "fire");
    const nums = gunNumbers(db, playerId, item);
    const reserve = reserveFor(db, playerId, item.id);
    const base = { magazine: nums.magazine, reloadMs: nums.reloadMs, practice };

    if (practice) {
      const before = Math.min(nums.magazine, practiceRounds.get(piece.id) ?? nums.magazine);
      practiceRounds.set(piece.id, nums.magazine);
      return { ...base, loaded: nums.magazine, reserve, reloaded: nums.magazine - before };
    }

    const loaded = clampOne(db, piece, item, nums.magazine);
    const need = nums.magazine - loaded;
    if (need <= 0) return { ...base, loaded, reserve, reloaded: 0 };
    if (reserve <= 0) throw new CaseError(`No ammo left for the ${item.name}.`);

    // Work out how much comes from each ammo item, piece by piece in the
    // order above, then take it item by item (applyInventoryChange removes
    // from the same pieces in the same order).
    const ammoPieces = db
      .prepare(
        `SELECT p.* FROM inventory_pieces p JOIN items i ON i.id = p.item_id
          WHERE p.player_id = ? AND i.ammo_for_item_id = ? AND i.kind = 'ammo'`
      )
      .all(playerId, item.id) as unknown as PieceRow[];
    ammoPieces.sort(
      (a, b) => Number(a.x !== null) - Number(b.x !== null) || a.quantity - b.quantity || b.id - a.id
    );
    const take = Math.min(need, reserve);
    const perItem = new Map<number, number>();
    let left = take;
    for (const p of ammoPieces) {
      if (left === 0) break;
      const t = Math.min(left, p.quantity);
      perItem.set(p.item_id, (perItem.get(p.item_id) ?? 0) + t);
      left -= t;
    }
    for (const [ammoId, n] of perItem) {
      applyInventoryChange(db, { playerId, itemId: ammoId, action: "RELOAD", quantity: n, performedBy: playerId });
    }
    const moved = take - left; // the same as take while the case and inventory agree
    setLoaded(db, piece.id, loaded + moved);
    return { ...base, loaded: loaded + moved, reserve: reserve - moved, reloaded: moved };
  });
}

// ---- Use (healing) ------------------------------------------------------------------------

// Uses one unit of a healing item: HP first (database/health.ts has the
// rules and the "already at full health" refusal), then the unit is gone
// (USE). The route sends live.hpChanged with the change.
export function useHealing(
  db: DatabaseSync,
  playerId: number,
  pieceId: unknown
): { change: HpChange; itemName: string } {
  return transaction(db, () => {
    const { piece, item } = ownPiece(db, playerId, pieceId);
    gate(db, playerId, "use");
    const effect = healEffectOf(item);
    if (!effect) {
      throw new CaseError(
        item.herb_code === "R" || item.herb_code === "Y"
          ? "Mix it with a Green Herb first."
          : `${item.name} can't be used for healing.`
      );
    }
    const change = applyHealing(db, playerId, { ...effect, source: item.name, performedBy: playerId });
    applyInventoryChange(db, {
      playerId,
      itemId: item.id,
      action: "USE",
      quantity: 1,
      performedBy: playerId,
      pieces: { takeFrom: piece.id },
    });
    return { change, itemName: item.name };
  });
}

// What the weapon screen needs to show its overlay ("Paused", "You're
// down"…) without trying to fire first.
export function playState(db: DatabaseSync, playerId: number) {
  const { status } = getGameStatus(db);
  const rules = getRules(db);
  const hp = getHp(db, playerId);
  let reason: string | null = null;
  let practice = false;
  try {
    practice = gate(db, playerId, "fire").practice;
  } catch (err) {
    reason = err instanceof CaseError ? err.message : "You can't fire right now.";
  }
  return { game: { status }, rules: { practiceFire: rules.practiceFire }, hp, canFire: reason === null, practice, reason };
}
