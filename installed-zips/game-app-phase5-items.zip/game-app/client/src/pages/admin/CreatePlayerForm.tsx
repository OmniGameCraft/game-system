import { FormEvent, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { PasswordField, TextField } from "../../components/Field";
import { createPlayer, Player } from "../../services/api";

export function CreatePlayerForm({
  onCreated,
  onBack,
}: {
  onCreated: (player: Player) => void;
  onBack: () => void;
}) {
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError(null);
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    try {
      const player = await createPlayer({
        username,
        password,
        confirmPassword,
        displayName: displayName || undefined,
      });
      onCreated(player);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create player.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <h2 className="text-2xl font-bold text-pine">Create Player</h2>
      <ErrorBanner message={error} />
      <TextField
        id="player-username"
        label="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
      />
      <TextField
        id="player-display-name"
        label="Display name (optional)"
        value={displayName}
        onChange={(e) => setDisplayName(e.target.value)}
      />
      <PasswordField
        id="player-password"
        label="Password"
        autoComplete="new-password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <PasswordField
        id="player-confirm-password"
        label="Confirm password"
        autoComplete="new-password"
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
        required
      />
      <p className="text-sm text-ink/60">At least 8 characters, with a letter and a number.</p>
      <Button type="submit" loading={loading}>
        Create Player
      </Button>
      <Button type="button" variant="ghost" onClick={onBack}>
        Back
      </Button>
    </form>
  );
}
