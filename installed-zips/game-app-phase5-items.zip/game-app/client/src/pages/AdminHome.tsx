import { useState } from "react";
import { Button } from "../components/Button";
import { PublicUser } from "../services/api";
import { CreatePlayerForm } from "./admin/CreatePlayerForm";
import { ItemForm } from "./admin/ItemForm";
import { ItemsList } from "./admin/ItemsList";
import { PlayerDetails } from "./admin/PlayerDetails";
import { PlayersList } from "./admin/PlayersList";

type Section = "players" | "items";
type View =
  | { name: "list" }
  | { name: "create" }
  | { name: "details"; id: number };

const SECTIONS: { key: Section; label: string }[] = [
  { key: "players", label: "Players" },
  { key: "items", label: "Items" },
];

export function AdminHome({ user, onLogout }: { user: PublicUser; onLogout: () => void }) {
  const [section, setSection] = useState<Section>("players");
  const [view, setView] = useState<View>({ name: "list" });

  function switchSection(s: Section) {
    setSection(s);
    setView({ name: "list" });
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="text-lg text-ink/60">Signed in as Admin</p>
        <h1 className="text-3xl font-bold text-pine">{user.username}</h1>
      </div>

      <nav className="grid grid-cols-2 gap-1 rounded-2xl bg-pine-soft p-1" aria-label="Admin sections">
        {SECTIONS.map((s) => (
          <button
            key={s.key}
            onClick={() => switchSection(s.key)}
            aria-current={section === s.key ? "page" : undefined}
            className={`rounded-xl py-3 text-lg font-semibold ${
              section === s.key ? "bg-pine text-white" : "text-pine"
            }`}
          >
            {s.label}
          </button>
        ))}
      </nav>

      {section === "players" && (
        <>
          {view.name === "list" && (
            <PlayersList onCreate={() => setView({ name: "create" })} onOpen={(id) => setView({ name: "details", id })} />
          )}
          {view.name === "create" && (
            <CreatePlayerForm
              onCreated={(player) => setView({ name: "details", id: player.id })}
              onBack={() => setView({ name: "list" })}
            />
          )}
          {view.name === "details" && <PlayerDetails id={view.id} onBack={() => setView({ name: "list" })} />}
        </>
      )}

      {section === "items" && (
        <>
          {view.name === "list" && (
            <ItemsList onCreate={() => setView({ name: "create" })} onOpen={(id) => setView({ name: "details", id })} />
          )}
          {view.name === "create" && (
            <ItemForm onSaved={(item) => setView({ name: "details", id: item.id })} onBack={() => setView({ name: "list" })} />
          )}
          {view.name === "details" && (
            <ItemForm key={view.id} id={view.id} onSaved={() => {}} onBack={() => setView({ name: "list" })} />
          )}
        </>
      )}

      <Button variant="ghost" onClick={onLogout}>
        Log out
      </Button>
    </div>
  );
}
