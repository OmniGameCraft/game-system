export function Notice({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="status" className="rounded-xl border-2 border-pine/30 bg-pine-soft px-4 py-3 font-medium text-pine">
      {message}
    </p>
  );
}
