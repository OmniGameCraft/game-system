import type { DatabaseSync } from "node:sqlite";
import { transaction } from "../database/db";
import { onGameStatusChange, onRoundReset } from "../database/game";
import { setDeathHandler } from "../database/health";
import { returnRounds } from "../database/inventory";
import { Item, onItemChanged } from "../database/items";
import { getRules, onRulesChanged } from "../database/settings";
import { dropAllOnDeath, returnAllToOwners } from "./drops";
import { relayoutAll, relayoutPlayer, sizeOf, stackSizeOf, syncAll, syncItem } from "./grid";
import { clampLoaded, forgetPractice } from "./play";

// The 2.0 "Inventory Update": the case (grid inventory), the drop box,
// herb mixing, firing / reloading / healing. See grid.ts for how the case
// works and routes.ts for the HTTP side.
export * from "./grid";
export * from "./drops";
export * from "./herbs";
export * from "./play";
export * from "./routes";

// An item's settings changed (Admin): the case follows. Runs inside the
// same transaction as the change.
//   - size or stack size changed → stacks re-split, pieces that now clash
//     move to a free spot (or the tray)
//   - became / stopped being a backpack → pieces go / appear, and the
//     holders' cases change size
//   - a gun's magazine got smaller (or it isn't a gun any more) → extra
//     loaded rounds go back into the ammo
function afterItemEdit(db: DatabaseSync, item: Item, previous: Item): void {
  const was = sizeOf(previous);
  const now = sizeOf(item);
  const kindChanged = item.kind !== previous.kind;
  const backpackRows =
    (item.kind === "backpack" || previous.kind === "backpack") &&
    (kindChanged || (item.expand_rows ?? 1) !== (previous.expand_rows ?? 1));
  const layout =
    kindChanged || backpackRows || was.w !== now.w || was.h !== now.h || stackSizeOf(item) !== stackSizeOf(previous);

  if (previous.kind === "gun" && item.kind !== "gun") clampLoaded(db, { itemId: item.id });
  if (layout) {
    const holders = db
      .prepare("SELECT player_id AS id FROM inventory WHERE item_id = ? UNION SELECT player_id FROM inventory_pieces WHERE item_id = ?")
      .all(item.id, item.id) as unknown as Array<{ id: number }>;
    for (const { id } of holders) {
      const r = syncItem(db, id, item.id);
      if (r.freedRounds > 0) returnRounds(db, id, item.id, r.freedRounds, id);
      relayoutPlayer(db, id, { settle: backpackRows, moveFirst: item.id });
    }
  }
  if (item.kind === "gun" && (kindChanged || item.base_magazine !== previous.base_magazine)) {
    clampLoaded(db, { itemId: item.id });
  }
}

let hooksRegistered = false;

// Call once at server start, right after the database opens: registers the
// case's part in deaths, the game ending, rule and item changes, and makes
// every player's case match what they hold (an old save gets its case laid
// out here).
export function initInventory(db: DatabaseSync): void {
  if (!hooksRegistered) {
    hooksRegistered = true;
    // A player who goes down drops everything (only while the deathDrops
    // rule is on — health.ts checks it).
    setDeathHandler((d, playerId) => {
      dropAllOnDeath(d, playerId);
    });
    onGameStatusChange((d, _from, to, by) => {
      forgetPractice();
      if (to === "ended" && getRules(d).returnDropsOnEnd) returnAllToOwners(d, by);
    });
    onRoundReset(() => forgetPractice());
    onRulesChanged((d, rules, previous) => {
      if (
        rules.caseCols !== previous.caseCols ||
        rules.caseRows !== previous.caseRows ||
        rules.caseMaxRows !== previous.caseMaxRows
      ) {
        relayoutAll(d);
      }
    });
    onItemChanged(afterItemEdit);
  }

  // If this ever fails (a save edited by hand), nothing is changed and the
  // server still starts: the case is re-checked item by item as players
  // play, and the next start tries again.
  try {
    transaction(db, () => {
      for (const f of syncAll(db)) returnRounds(db, f.playerId, f.itemId, f.rounds, f.playerId);
      clampLoaded(db);
    });
  } catch (err) {
    console.warn("Could not check every player's case at start-up:", (err as Error).message);
  }
}
