import { Response, Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { requireRole } from "../auth/middleware";
import { transaction } from "../database/db";
import { getGameStatus } from "../database/game";
import { getHp, healEffectOf, HpError } from "../database/health";
import { InventoryRuleError, ItemNotFoundError } from "../database/inventory";
import { findItemById, HerbCode, imageUrlFor, Item, ItemKind, UseEffect } from "../database/items";
import { getRules } from "../database/settings";
import { findById } from "../database/users";
import { gunNumbers, TrackView, weaponView } from "../database/weapons";
import { live } from "../realtime";
import { listDrops, listDropsForAdmin, pickup, dropPiece, returnAllToOwners, DropView } from "./drops";
import { arrange, CaseError, caseSize, movePiece, PieceRow, sizeOf, splitPiece, stackSizeOf } from "./grid";
import { combine, mixPreviews, MixPreview, mixResult } from "./herbs";
import { ammoItemIdsFor, fire, playState, reload, reserveFor, useHealing } from "./play";

// HTTP routes for the case, the drop box and the weapon screen.
//   /api/case          (player) the case: view, move, split, arrange,
//                      combine, use, drop, pick up
//   /api/play          (player) fire, reload, and what the weapon screen
//                      may do right now
//   /api/admin/drops   (Admin) the drop box, "Clear drop box"
//   /api/admin/players/:id/case   (Admin) a player's case, read-only
// Whose case it is always comes from the session, never from the request.

// ---- What a phone sees --------------------------------------------------------

export interface PieceView {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  kind: ItemKind;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  x: number | null; // top-left cell; null = in the tray
  y: number | null;
  w: number; // the item's own size in cells (NOT swapped); phones swap w/h when rotated
  h: number;
  rotated: boolean;
  quantity: number;
  stackSize: number;
  loaded: number; // guns: rounds in the magazine
  magazine: number | null; // guns: how many it holds at this player's level
  ammoItemId: number | null; // guns: the ammo that fits
  reserve: number; // guns: rounds of that ammo carried (0 for anything else)
  herbCode: HerbCode | null;
  healAmount: number | null;
  maxHpBonus: number | null;
  fullHeal: boolean;
  usable: boolean; // "Use" heals with it
  upgrades: TrackView[]; // guns and knives
  gun: { reloadMs: number; shakeThreshold: number; cooldownMs: number; damagePct: number } | null;
  slot: number | null; // weapons in the case: 1, 2, 3… in reading order (the badge)
  mixWith: Array<{ pieceId: number; result: HerbCode }>; // herbs: what it can be combined with
}

export interface CaseView {
  cols: number;
  rows: number;
  expansions: number;
  pieces: PieceView[]; // in the case, reading order
  tray: PieceView[]; // "doesn't fit — make room"
  drops: DropView[];
  hp: { hp: number; maxHp: number; dead: boolean };
  game: { status: string };
  rules: { practiceFire: boolean };
  mixes: Partial<Record<HerbCode, MixPreview>>; // what each possible mix gives
}

export function caseView(db: DatabaseSync, playerId: number, opts: { drops?: boolean } = {}): CaseView {
  const rules = getRules(db);
  const size = caseSize(db, playerId, rules);
  const rows = db
    .prepare("SELECT * FROM inventory_pieces WHERE player_id = ? ORDER BY x IS NULL, y, x, id")
    .all(playerId) as unknown as PieceRow[];

  const items = new Map<number, Item>();
  const itemOf = (id: number) => {
    let it = items.get(id);
    if (!it) {
      it = findItemById(db, id)!;
      items.set(id, it);
    }
    return it;
  };
  // Per weapon item: the numbers at this player's levels (worked out once).
  const weapons = new Map<number, { upgrades: TrackView[]; gun: ReturnType<typeof gunNumbers> | null; ammo: number | null; reserve: number }>();
  const weaponOf = (item: Item) => {
    let w = weapons.get(item.id);
    if (!w) {
      const isGun = item.kind === "gun";
      w = {
        upgrades: item.kind === "gun" || item.kind === "knife" ? weaponView(db, playerId, item) : [],
        gun: isGun ? gunNumbers(db, playerId, item) : null,
        ammo: isGun ? ammoItemIdsFor(db, item.id)[0] ?? null : null,
        reserve: isGun ? reserveFor(db, playerId, item.id) : 0,
      };
      weapons.set(item.id, w);
    }
    return w;
  };

  let slot = 0;
  const views: PieceView[] = rows.map((p) => {
    const item = itemOf(p.item_id);
    // The item's own (unturned) size; phones swap w/h themselves when rotated.
    const { w, h } = sizeOf(item);
    const wpn = weaponOf(item);
    const isWeapon = item.kind === "gun" || item.kind === "knife";
    return {
      id: p.id,
      itemId: item.id,
      name: item.name,
      description: item.description,
      kind: item.kind,
      imageUrl: imageUrlFor(item.image_file),
      modelUrl: imageUrlFor(item.model_file),
      soundUrl: imageUrlFor(item.sound_file),
      useEffect: item.use_effect,
      modelFlip: item.model_flip === 1,
      modelUpsideDown: item.model_upside_down === 1,
      x: p.x,
      y: p.y,
      w,
      h,
      rotated: p.rotated === 1,
      quantity: p.quantity,
      stackSize: stackSizeOf(item),
      loaded: wpn.gun ? Math.min(p.loaded, wpn.gun.magazine) : 0,
      magazine: wpn.gun ? wpn.gun.magazine : null,
      ammoItemId: wpn.ammo,
      reserve: wpn.reserve,
      herbCode: item.herb_code,
      healAmount: item.heal_amount,
      maxHpBonus: item.max_hp_bonus,
      fullHeal: item.full_heal === 1,
      usable: healEffectOf(item) !== null,
      upgrades: wpn.upgrades,
      gun: wpn.gun
        ? {
            reloadMs: wpn.gun.reloadMs,
            shakeThreshold: wpn.gun.shakeThreshold,
            cooldownMs: wpn.gun.cooldownMs,
            damagePct: wpn.gun.damagePct,
          }
        : null,
      slot: isWeapon && p.x !== null ? ++slot : null,
      mixWith: [],
    };
  });

  // Herbs: which other pieces each one can be mixed with, and what that makes.
  const herbs = views.filter((v) => v.herbCode !== null);
  const resultCodes = new Set<HerbCode>();
  for (const a of herbs) {
    for (const b of herbs) {
      if (a.id === b.id && a.quantity < 2) continue;
      const r = mixResult(a.herbCode!, b.herbCode!);
      if (r) resultCodes.add(r);
    }
  }
  const mixes = mixPreviews(db, resultCodes);
  for (const a of herbs) {
    for (const b of herbs) {
      if (a.id === b.id && a.quantity < 2) continue;
      const r = mixResult(a.herbCode!, b.herbCode!);
      if (r && mixes[r]) a.mixWith.push({ pieceId: b.id, result: r });
    }
  }

  return {
    cols: size.cols,
    rows: size.rows,
    expansions: size.expansions,
    pieces: views.filter((v) => v.x !== null),
    tray: views.filter((v) => v.x === null),
    drops: opts.drops === false ? [] : listDrops(db, playerId),
    hp: getHp(db, playerId),
    game: { status: getGameStatus(db).status },
    rules: { practiceFire: rules.practiceFire },
    mixes,
  };
}

// ---- Errors -----------------------------------------------------------------------

// Turns a failed action into the right status and a message the player
// (or Admin) can act on.
function sendError(res: Response, err: unknown, fallback: string): void {
  if (err instanceof CaseError) {
    res.status(err.status).json({ error: err.message });
  } else if (err instanceof HpError) {
    res.status(err.code === "NOT_FOUND" ? 404 : 400).json({ error: err.message });
  } else if (err instanceof InventoryRuleError) {
    res.status(400).json({ error: err.message });
  } else if (err instanceof ItemNotFoundError) {
    res.status(404).json({ error: err.message });
  } else {
    console.error("[case]", err);
    res.status(500).json({ error: fallback });
  }
}

function whole(v: unknown): v is number {
  return typeof v === "number" && Number.isInteger(v);
}

// ---- Player: /api/case -----------------------------------------------------------------

// Every successful POST answers with the fresh case as `case`, so the
// screen can redraw straight away (live notices still go out: see index.ts).
export function createCaseRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("player"));

  router.get("/", (req, res) => {
    res.json(caseView(db, req.user!.id));
  });

  router.get("/hp", (req, res) => {
    res.json(getHp(db, req.user!.id));
  });

  // { pieceId, x, y, rotated }  x/y null = to the tray.
  router.post("/move", (req, res) => {
    const me = req.user!.id;
    const b = req.body ?? {};
    try {
      const r = transaction(db, () => movePiece(db, me, { pieceId: b.pieceId, x: b.x, y: b.y, rotated: b.rotated }));
      res.json({ ...r, case: caseView(db, me) });
    } catch (err) {
      sendError(res, err, "Couldn't move that. Please try again.");
    }
  });

  // { pieceId, quantity }
  router.post("/split", (req, res) => {
    const me = req.user!.id;
    try {
      const r = transaction(db, () => splitPiece(db, me, { pieceId: req.body?.pieceId, quantity: req.body?.quantity }));
      res.json({ ...r, case: caseView(db, me) });
    } catch (err) {
      sendError(res, err, "Couldn't split that. Please try again.");
    }
  });

  router.post("/arrange", (req, res) => {
    const me = req.user!.id;
    try {
      const r = transaction(db, () => arrange(db, me));
      res.json({ ...r, case: caseView(db, me) });
    } catch (err) {
      sendError(res, err, "Couldn't arrange your case. Please try again.");
    }
  });

  // { pieceId, withPieceId }
  router.post("/combine", (req, res) => {
    const me = req.user!.id;
    try {
      const r = combine(db, me, { pieceId: req.body?.pieceId, withPieceId: req.body?.withPieceId });
      if (r.createdItem) live.itemsChanged(); // the mixed herb just joined the catalogue
      res.json({ ...r, case: caseView(db, me) });
    } catch (err) {
      sendError(res, err, "Couldn't mix those. Please try again.");
    }
  });

  // { pieceId }
  router.post("/use", (req, res) => {
    const me = req.user!.id;
    try {
      const { change, itemName } = useHealing(db, me, req.body?.pieceId);
      live.hpChanged(me, change); // also tells this player's screens and the Admin
      res.json({
        itemName,
        hp: { hp: change.hp, maxHp: change.maxHp, dead: change.dead },
        change: { delta: change.delta, maxDelta: change.maxDelta },
        case: caseView(db, me),
      });
    } catch (err) {
      sendError(res, err, "Couldn't use that. Please try again.");
    }
  });

  // { pieceId, quantity? }  quantity missing = the whole piece.
  router.post("/drop", (req, res) => {
    const me = req.user!.id;
    try {
      const r = dropPiece(db, me, { pieceId: req.body?.pieceId, quantity: req.body?.quantity });
      res.json({ ...r, case: caseView(db, me) });
    } catch (err) {
      sendError(res, err, "Couldn't drop that. Please try again.");
    }
  });

  // { dropId, quantity? }  quantity missing = all of it.
  router.post("/pickup", (req, res) => {
    const me = req.user!.id;
    try {
      const r = pickup(db, me, { dropId: req.body?.dropId, quantity: req.body?.quantity });
      res.json({ ...r, case: caseView(db, me) });
    } catch (err) {
      sendError(res, err, "Couldn't pick that up. Please try again.");
    }
  });

  return router;
}

// ---- Player: /api/play -------------------------------------------------------------------

export function createPlayRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("player"));

  // { game: {status}, rules: {practiceFire}, hp, canFire, practice, reason }
  router.get("/state", (req, res) => {
    res.json(playState(db, req.user!.id));
  });

  // { pieceId, shots? (1–10, default 1) }. Sends no live notice: shots come
  // several times a second and the shooter's screen already knows.
  router.post("/fire", (req, res) => {
    const shots = req.body?.shots ?? 1;
    if (!whole(shots) || shots < 1 || shots > 10) {
      res.status(400).json({ error: "Invalid number of shots." });
      return;
    }
    try {
      res.json(fire(db, req.user!.id, req.body?.pieceId, shots));
    } catch (err) {
      sendError(res, err, "Couldn't fire. Please try again.");
    }
  });

  // { pieceId }
  router.post("/reload", (req, res) => {
    const me = req.user!.id;
    try {
      const r = reload(db, me, req.body?.pieceId);
      if (!r.practice && r.reloaded > 0) live.playerChanged(me); // ammo left the case
      res.json(r);
    } catch (err) {
      sendError(res, err, "Couldn't reload. Please try again.");
    }
  });

  return router;
}

// ---- Admin -----------------------------------------------------------------------------------

// /api/admin/drops
export function createAdminDropsRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  router.get("/", (_req, res) => {
    res.json({ drops: listDropsForAdmin(db) });
  });

  // "Clear drop box": everything goes back to its owner.
  router.post("/clear", (req, res) => {
    try {
      const returned = returnAllToOwners(db, req.user!.id);
      res.json({ returned, drops: listDropsForAdmin(db) });
    } catch (err) {
      sendError(res, err, "Couldn't clear the drop box. Nothing was changed.");
    }
  });

  return router;
}

// /api/admin/players/:id/case — the same view the player gets (minus the
// drop box), for the player page's read-only mini case.
export function createAdminCaseRouter(db: DatabaseSync): Router {
  const router = Router();
  router.get("/:id/case", requireRole("admin"), (req, res) => {
    const player = findById(db, Number(req.params.id));
    if (!player || player.role !== "player") {
      res.status(404).json({ error: "Player not found." });
      return;
    }
    res.json(caseView(db, player.id, { drops: false }));
  });
  return router;
}
