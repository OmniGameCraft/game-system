import express, { NextFunction, Request, Response } from "express";
import fs from "fs";
import path from "path";
import http from "http";
import https from "https";
import { CLIENT_DIST, HOST, HTTPS_PORT, ITEM_IMAGE_DIR, PACKS_DIR, PORT } from "./config";
import { createPacksRouter } from "./routes/packs";
import { createAdminGameRouter, createPlayerGameRouter } from "./routes/game";
import { loadOrCreateCertificate } from "./https";
import { attachRealtime, live, notifyAfter } from "./realtime";
import { openDatabase } from "./database/db";
import { getLanAddresses, runtimeInfo } from "./network";
import { attachUser } from "./auth/middleware";
import { createAuthRouter } from "./routes/auth";
import { createMeRouter } from "./routes/me";
import { createPlayersRouter } from "./routes/players";
import { createItemsRouter, IMAGE_UPLOAD_PATH } from "./routes/items";
import { createAdminShopRouter, createPlayerShopRouter } from "./routes/shop";
import { createRulesRouter } from "./routes/rules";
import { createVoiceRouter } from "./routes/voice";
import { createCalculatorRouter } from "./routes/calculator";
import { createHitsRouter } from "./routes/hits";
import { APP_EDITION, APP_VERSION } from "./version";
import {
  createAdminCaseRouter,
  createAdminDropsRouter,
  createCaseRouter,
  createPlayRouter,
  initInventory,
} from "./inventory";

const db = openDatabase();
// The case: register its hooks and make every case match what players hold.
initInventory(db);
const app = express();
// attachUser only reads the cookie, so it can run before any body parsing.
// The default 100 KB JSON parser runs for every route except the item
// picture upload, which parses its own (larger) body after checking the
// caller is the Admin — see routes/items.ts.
app.use(attachUser(db));
const defaultJson = express.json();
app.use((req, res, next) =>
  IMAGE_UPLOAD_PATH.test(req.path) ? next() : defaultJson(req, res, next)
);

app.get("/api/health", (_req, res) => {
  try {
    db.prepare("SELECT 1").get();
    res.json({
      status: "ok",
      database: "ok",
      time: new Date().toISOString(),
      version: APP_VERSION,
      edition: APP_EDITION,
    });
  } catch {
    res.status(500).json({ status: "error", database: "error", version: APP_VERSION, edition: APP_EDITION });
  }
});

app.use("/api/auth", createAuthRouter(db));
app.use("/api/me", createMeRouter(db));
// Live-update notices (Phase 7) are sent after any successful change.
app.use(
  "/api/admin/players",
  notifyAfter((_req, path) => {
    live.playersChanged();
    const id = Number(path.split("/")[1]);
    if (Number.isInteger(id) && id > 0) live.playerChanged(id);
  }),
  createPlayersRouter(db)
);
app.use(
  "/api/admin/items",
  notifyAfter(() => {
    live.itemsChanged();
    live.shopChanged();
    live.allPlayersChanged(); // an item's size or stack size can rearrange cases
  }),
  createItemsRouter(db)
);
app.use("/api/admin/shop", notifyAfter(() => live.shopChanged()), createAdminShopRouter(db));
app.use("/api/admin/game", createAdminGameRouter(db));
app.use("/api/admin/rules", createRulesRouter(db)); // sends its own rules:changed notice
app.use("/api/admin/calculator", createCalculatorRouter(db)); // sends its own notices
app.use("/api/admin/hits", createHitsRouter(db));
// Voice hit calls: any logged-in phone reports what it heard (sends hp:changed itself).
app.use("/api/voice", createVoiceRouter(db));
app.use("/api/game", createPlayerGameRouter(db));
app.use("/api/admin/asset-packs", notifyAfter(() => live.itemsChanged()), createPacksRouter(db));
// The case (2.0). Each change tells the player's other screens and the
// Admin; dropping or picking up also refreshes everyone's drop box. /use
// sends its own hp:changed notice (which includes the same "me" notice).
app.use(
  "/api/case",
  notifyAfter((req, path) => {
    if (!req.user) return;
    if (path !== "/use") live.playerChanged(req.user.id);
    if (path === "/drop" || path === "/pickup") live.dropsChanged();
  }),
  createCaseRouter(db)
);
app.use("/api/play", createPlayRouter(db)); // sends its own notices (none per shot)
app.use(
  "/api/admin/drops",
  notifyAfter(() => {
    live.dropsChanged();
    live.allPlayersChanged();
  }),
  createAdminDropsRouter(db)
);
app.use("/api/admin/players", createAdminCaseRouter(db)); // GET /:id/case (read-only)
app.use(
  "/api/shop",
  notifyAfter((req, path) => {
    if (path === "/sell-quote") return; // only asks for an offer; nothing changed
    if (req.user) live.playerChanged(req.user.id);
    live.shopChanged();
  }),
  createPlayerShopRouter(db)
);

// Media files are only ever shown as pictures/models/sounds. nosniff stops
// a browser guessing a different type; an SVG picture (the mixed herbs) also
// gets a locked-down policy, so even if one is opened on its own nothing in
// it can run or load anything.
function mediaHeaders(res: Response, filePath: string) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  if (filePath.toLowerCase().endsWith(".svg")) {
    res.setHeader("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; sandbox");
  }
}

// Preview pictures of the ready-made item packs (free CC0 assets).
app.use("/packs", express.static(PACKS_DIR, { fallthrough: false, setHeaders: mediaHeaders }));

// Item pictures uploaded by the Admin. fallthrough:false means a missing
// file is a plain 404, not the app's index.html.
fs.mkdirSync(ITEM_IMAGE_DIR, { recursive: true });
app.use(
  "/media/items",
  express.static(ITEM_IMAGE_DIR, {
    fallthrough: false,
    setHeaders: mediaHeaders,
  })
);

// Serve the built React app (run `npm run build` first).
if (fs.existsSync(CLIENT_DIST)) {
  app.use(express.static(CLIENT_DIST));
  app.get(/^(?!\/api).*/, (_req, res) =>
    res.sendFile(path.join(CLIENT_DIST, "index.html"))
  );
} else {
  app.get("/", (_req, res) =>
    res.status(503).send("Client not built yet. Run: npm run build")
  );
}

// Turns body-parser/static errors (bad JSON, body too big, missing file)
// into the same friendly { error } shape every other endpoint uses.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = typeof err?.status === "number" ? err.status : 500;
  const message =
    err?.type === "entity.too.large"
      ? "That upload is too large."
      : err?.type === "entity.parse.failed"
      ? "Invalid request."
      : status === 404 || status === 403
      ? "Not found."
      : "Something went wrong. Please try again.";
  res.status(status).json({ error: message });
});

const lan = getLanAddresses();
const servers: http.Server[] = [];

const httpServer = http.createServer(app);
servers.push(httpServer);

let httpsServer: https.Server | null = null;
if (HTTPS_PORT > 0) {
  try {
    httpsServer = https.createServer(loadOrCreateCertificate(lan), app);
    servers.push(httpsServer);
  } catch (err) {
    console.warn("Secure (https) address not available:", (err as Error).message);
  }
}

attachRealtime(servers, db);

httpServer.listen(PORT, HOST, () => {
  console.log("\nServer running\n");
  console.log(`Local:\n  http://localhost:${PORT}\n`);
  console.log("LAN (give this to players):");
  if (lan.length === 0) console.log("  No network found. Connect to Wi-Fi first.");
  for (const ip of lan) console.log(`  http://${ip}:${PORT}`);
  if (httpsServer) {
    console.log("\nSecure LAN address (needed for shake-to-fire):");
    for (const ip of lan) console.log(`  https://${ip}:${HTTPS_PORT}`);
    console.log("  First visit shows a warning: tap Advanced, then Proceed.");
  }
  console.log("");
});
httpsServer?.listen(HTTPS_PORT, HOST, () => {
  runtimeInfo.httpsPort = HTTPS_PORT;
});
httpsServer?.on("error", (err) => console.warn("Secure (https) address not available:", err.message));
