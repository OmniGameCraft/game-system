import type { LiveEvent } from "../../services/live";

// Live notices added with the 2.0 server. services/live.ts lists them in
// LiveEvent once the case update is merged; spelling them through `string`
// keeps the admin screens compiling both before and after that.
export const HP_CHANGED = "hp:changed" as string as LiveEvent; // someone's HP changed
export const DROPS_CHANGED = "drops:changed" as string as LiveEvent; // the drop box changed
export const RULES_CHANGED = "rules:changed" as string as LiveEvent; // the Admin saved new game rules
