import { DatabaseSync } from "node:sqlite";

// ADD/REMOVE are Admin adjustments; PURCHASE is a player buying from the shop
// (see shop.ts) and also carries the item and quantity bought.
export type TransactionType = "ADD" | "REMOVE" | "PURCHASE";

export interface Transaction {
  id: number;
  player_id: number;
  type: TransactionType;
  amount: number;
  balance_before: number;
  balance_after: number;
  performed_by: number;
  item_id: number | null;
  quantity: number | null;
  created_at: string;
  item_name?: string | null;
}

export interface PublicTransaction {
  id: number;
  type: TransactionType;
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  performedBy: number;
  itemId: number | null;
  itemName: string | null;
  quantity: number | null;
  createdAt: string;
}

export function toPublicTransaction(t: Transaction): PublicTransaction {
  return {
    id: t.id,
    type: t.type,
    amount: t.amount,
    balanceBefore: t.balance_before,
    balanceAfter: t.balance_after,
    performedBy: t.performed_by,
    itemId: t.item_id ?? null,
    itemName: t.item_name ?? null,
    quantity: t.quantity ?? null,
    createdAt: t.created_at,
  };
}

export class InsufficientFundsError extends Error {}

// A cap on any single transaction, not a cap on total balance — just a
// sanity limit against typos, well inside what a 64-bit SQLite INTEGER and
// a JS safe integer can both hold without any precision loss.
export const MAX_TRANSACTION_AMOUNT = 1_000_000_000;

export function listTransactionsForPlayer(db: DatabaseSync, playerId: number): Transaction[] {
  return db
    .prepare(
      `SELECT t.*, i.name AS item_name
         FROM transactions t
         LEFT JOIN items i ON i.id = t.item_id
        WHERE t.player_id = ?
        ORDER BY t.id DESC`
    )
    .all(playerId) as unknown as Transaction[];
}

// The balance change + audit row, WITHOUT opening a transaction. Callers
// must already be inside BEGIN…COMMIT: adjustBalance below for Admin
// add/remove, and the shop purchase (database/shop.ts), which also changes
// inventory and stock in the same transaction.
export function applyBalanceChange(
  db: DatabaseSync,
  input: {
    playerId: number;
    type: TransactionType;
    amount: number;
    performedBy: number;
    itemId?: number;
    quantity?: number;
  }
): { balance: number; transactionId: number } {
  const { playerId, type, amount, performedBy } = input;
  const row = db.prepare("SELECT balance FROM users WHERE id = ?").get(playerId) as
    | { balance: number }
    | undefined;
  if (!row) {
    throw new Error("Player not found.");
  }
  const before = row.balance;
  const after = type === "ADD" ? before + amount : before - amount;

  if (after < 0) {
    throw new InsufficientFundsError(
      type === "PURCHASE" ? "You don't have enough money." : "This player doesn't have enough money."
    );
  }

  db.prepare("UPDATE users SET balance = ? WHERE id = ?").run(after, playerId);
  const result = db
    .prepare(
      `INSERT INTO transactions
         (player_id, type, amount, balance_before, balance_after, performed_by, item_id, quantity)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(playerId, type, amount, before, after, performedBy, input.itemId ?? null, input.quantity ?? null);
  return { balance: after, transactionId: Number(result.lastInsertRowid) };
}

export function getTransaction(db: DatabaseSync, id: number): Transaction {
  return db
    .prepare(
      `SELECT t.*, i.name AS item_name FROM transactions t
         LEFT JOIN items i ON i.id = t.item_id WHERE t.id = ?`
    )
    .get(id) as unknown as Transaction;
}

// Admin add/remove money: balance change and transaction record in one
// atomic step. Every call here is synchronous (node:sqlite has no awaits),
// so Node's single JS thread can never interleave a second request between
// the balance check and the write — two simultaneous requests for the same
// player can't double-spend or leave a balance that doesn't match the log.
export function adjustBalance(
  db: DatabaseSync,
  input: { playerId: number; type: "ADD" | "REMOVE"; amount: number; performedBy: number }
): { balance: number; transaction: Transaction } {
  db.exec("BEGIN");
  try {
    const { balance, transactionId } = applyBalanceChange(db, input);
    db.exec("COMMIT");
    return { balance, transaction: getTransaction(db, transactionId) };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
