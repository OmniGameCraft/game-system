import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { hashPassword, isPasswordStrongEnough, isUsernameValid, verifyPassword } from "../auth/passwords";
import { createSession, destroySession, revokeSessionsForUser } from "../auth/sessions";
import { requireAuth } from "../auth/middleware";
import { runtimeInfo } from "../network";
import {
  countByRole,
  createUser,
  findById,
  findByUsername,
  setActiveSessionToken,
  toPublicUser,
} from "../database/users";

export function createAuthRouter(db: DatabaseSync): Router {
  const router = Router();

  // Tells the login screen what to show: an admin-setup form, or a login
  // form, and whether to explain that no players exist yet.
  router.get("/status", (_req, res) => {
    res.json({
      hasAdmin: countByRole(db, "admin") > 0,
      hasPlayers: countByRole(db, "player") > 0,
      httpsPort: runtimeInfo.httpsPort, // 0 = no secure address running
    });
  });

  // One-time first-Admin setup. This whole handler runs synchronously (the
  // database and password hashing calls are both synchronous) and Node only
  // has one thread of JavaScript execution, so a second request can never
  // interleave between the "does an admin exist" check and the insert below
  // — that's what makes this safe against two people submitting the setup
  // form at the same moment, with no extra locking needed.
  router.post("/admin-setup", (req, res) => {
    if (countByRole(db, "admin") > 0) {
      res.status(403).json({ error: "An admin account already exists." });
      return;
    }

    const { username, password, confirmPassword } = req.body ?? {};
    if (typeof username !== "string" || typeof password !== "string") {
      res.status(400).json({ error: "Username and password are required." });
      return;
    }
    if (!isUsernameValid(username)) {
      res.status(400).json({
        error: "Username must be 3-32 characters: letters, numbers, dots, - or _.",
      });
      return;
    }
    if (password !== confirmPassword) {
      res.status(400).json({ error: "Passwords do not match." });
      return;
    }
    if (!isPasswordStrongEnough(password)) {
      res.status(400).json({
        error: "Password must be at least 8 characters and include a letter and a number.",
      });
      return;
    }
    if (findByUsername(db, username)) {
      res.status(409).json({ error: "That username is already taken." });
      return;
    }

    const user = createUser(db, {
      role: "admin",
      username,
      passwordHash: hashPassword(password),
    });
    const publicUser = toPublicUser(user, db);
    const token = createSession(res, publicUser);
    setActiveSessionToken(db, user.id, token);
    res.status(201).json({ user: publicUser });
  });

  router.post("/login", (req, res) => {
    const { role, username, password } = req.body ?? {};
    if (role !== "admin" && role !== "player") {
      res.status(400).json({ error: "Invalid role." });
      return;
    }
    if (typeof username !== "string" || typeof password !== "string") {
      res.status(400).json({ error: "Username and password are required." });
      return;
    }

    const user = findByUsername(db, username);
    // Same generic message whether the username or the password was wrong,
    // and whether the account belongs to the other role — this avoids
    // revealing which usernames exist or letting a Player account be
    // fingerprinted through the Admin login form.
    const invalid = () => res.status(401).json({ error: "Incorrect username or password." });

    if (!user || user.role !== role) {
      invalid();
      return;
    }
    if (!verifyPassword(password, user.password_hash)) {
      invalid();
      return;
    }
    if (user.status === "disabled") {
      res.status(403).json({ error: "This account has been disabled." });
      return;
    }

    // Only one Admin session is allowed at a time. Logging in again — from
    // any device — immediately kicks out whatever Admin session existed
    // before, by removing it from the session store: the next request that
    // arrives on the old cookie will find no session and be rejected. This
    // does not apply to Players, who can stay logged in on several phones
    // at once as before.
    if (role === "admin") {
      revokeSessionsForUser(user.id);
    }

    const publicUser = toPublicUser(user, db);
    const token = createSession(res, publicUser);
    if (role === "admin") {
      setActiveSessionToken(db, user.id, token);
    }
    res.json({ user: publicUser });
  });

  router.post("/logout", (req, res) => {
    if (req.user?.role === "admin") {
      setActiveSessionToken(db, req.user.id, null);
    }
    destroySession(req, res);
    res.status(204).end();
  });

  router.get("/me", requireAuth, (req, res) => {
    // req.user is a snapshot taken when the session was created; re-read so
    // things that can change mid-session (balance, display name) are current.
    const fresh = findById(db, req.user!.id);
    if (!fresh) {
      res.status(401).json({ error: "Please log in to continue." });
      return;
    }
    res.json({ user: toPublicUser(fresh, db) });
  });

  return router;
}
