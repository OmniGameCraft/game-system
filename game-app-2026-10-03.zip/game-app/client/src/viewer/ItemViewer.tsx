import { useEffect, useRef, useState } from "react";
import { Icon } from "../components/Icon";
import { listenForShake, motionState } from "./motion";
import { ItemScene, UseEffect } from "./scene";
import { loadSound, playSound } from "./sound";
import { getAuthStatus } from "../services/api";

export interface ViewerItem {
  name: string;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
}

const VERB: Record<UseEffect, string> = { shot: "fire", swing: "swing", none: "spin" };
const TAP_COOLDOWN: Record<UseEffect, number> = { shot: 110, swing: 300, none: 700 };

// Full-screen view of one item. Tap anywhere (or shake the phone) to use it:
// guns fire (sound, recoil, muzzle flash, vibration), blades swing, anything
// else spins.
export default function ItemViewer({ item, onClose }: { item: ViewerItem; onClose: () => void }) {
  const stageRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<ItemScene | null>(null);
  const soundRef = useRef<AudioBuffer | null>(null);
  const lastUse = useRef(0);
  const [modelState, setModelState] = useState<"loading" | "ready" | "none" | "error">(
    item.modelUrl ? "loading" : "none"
  );
  const [count, setCount] = useState(0);
  const [pulse, setPulse] = useState(0); // re-triggers the 2D/overlay animations
  const [shakeOn, setShakeOn] = useState(false);
  const effect = item.useEffect;

  // 3D model
  useEffect(() => {
    if (!item.modelUrl || !stageRef.current) return;
    const scene = new ItemScene(stageRef.current);
    sceneRef.current = scene;
    scene
      .load({ modelUrl: item.modelUrl, flip: item.modelFlip, upsideDown: item.modelUpsideDown, effect })
      .then(() => setModelState("ready"))
      .catch(() => setModelState("error"));
    const onResize = () => scene.resize();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      scene.dispose();
      sceneRef.current = null;
    };
  }, [item.modelUrl, item.modelFlip, item.modelUpsideDown, effect]);

  // Sound
  useEffect(() => {
    soundRef.current = null;
    if (!item.soundUrl) return;
    loadSound(item.soundUrl)
      .then((b) => (soundRef.current = b))
      .catch(() => {});
  }, [item.soundUrl]);

  function use() {
    const now = performance.now();
    if (now - lastUse.current < TAP_COOLDOWN[effect]) return;
    lastUse.current = now;
    if (soundRef.current) playSound(soundRef.current);
    sceneRef.current?.trigger();
    setPulse((p) => p + 1);
    setCount((c) => c + 1);
    try {
      navigator.vibrate?.(effect === "shot" ? 45 : 15);
    } catch {
      // no vibration on this phone
    }
  }
  const useRef_ = useRef(use);
  useRef_.current = use;

  // Shake to use
  useEffect(() => {
    if (motionState() !== "granted") return;
    setShakeOn(true);
    return listenForShake(() => useRef_.current());
  }, []);

  // Keyboard (desktop testing): Space/Enter uses, Esc closes
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      else if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        useRef_.current();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  // The server says which port its secure (https) address uses; 0 = none.
  const [httpsPort, setHttpsPort] = useState(0);
  useEffect(() => {
    getAuthStatus()
      .then((s) => setHttpsPort(s.httpsPort ?? 0))
      .catch(() => {});
  }, []);
  const secureUrl = `https://${location.hostname}:${httpsPort}${location.pathname}`;
  const ms = motionState();
  const verb = VERB[effect];
  const show2D = modelState === "none" || modelState === "error";

  return (
    <div
      className="fixed inset-0 z-50 flex select-none flex-col text-white"
      style={{
        background: "radial-gradient(ellipse at 50% 45%, #2b4a3b 0%, #12211a 55%, #070d0a 100%)",
        touchAction: "none",
        WebkitUserSelect: "none",
        paddingTop: "env(safe-area-inset-top)",
        paddingBottom: "env(safe-area-inset-bottom)",
      }}
      onPointerDown={(e) => {
        if ((e.target as HTMLElement).closest("[data-no-use]")) return;
        use();
      }}
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Screen flash on each shot */}
      {effect === "shot" && pulse > 0 && (
        <div key={pulse} className="pointer-events-none absolute inset-0 animate-shotflash bg-amber-200" />
      )}

      <header data-no-use className="relative z-10 flex items-center justify-between gap-3 px-4 py-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wider text-white/60">
            {effect === "shot" ? "Weapon" : effect === "swing" ? "Melee" : "Item"}
          </p>
          <p className="truncate text-2xl font-display font-bold">{item.name}</p>
        </div>
        <button
          onClick={onClose}
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/15 active:bg-white/25"
          aria-label="Close"
        >
          <Icon name="close" className="h-7 w-7" />
        </button>
      </header>

      <div className="relative min-h-0 flex-1">
        <div ref={stageRef} className="absolute inset-0" />
        {modelState === "loading" && (
          <p className="absolute inset-0 flex items-center justify-center text-white/70">Loading 3D model…</p>
        )}
        {show2D && (
          <div className="absolute inset-0 flex items-center justify-center p-6">
            {item.imageUrl ? (
              <img
                key={pulse}
                src={item.imageUrl}
                alt=""
                draggable={false}
                className={`max-h-full max-w-full object-contain drop-shadow-2xl ${
                  pulse > 0 ? (effect === "shot" ? "animate-recoil" : effect === "swing" ? "animate-swing" : "animate-spin-once") : ""
                }`}
              />
            ) : (
              <p className="text-6xl font-display font-bold text-white/30">{item.name.charAt(0)}</p>
            )}
          </div>
        )}
      </div>

      <footer data-no-use className="relative z-10 flex flex-col items-center gap-2 px-4 pb-5 pt-2 text-center">
        <p className="text-lg font-bold">
          Tap the screen{shakeOn ? " or shake the phone" : ""} to {verb}
        </p>
        {count > 0 && effect !== "none" && (
          <p className="text-sm tabular-nums text-white/60">
            {effect === "shot" ? "Shots" : "Swings"}: {count}
          </p>
        )}
        {!shakeOn && effect !== "none" && ms === "insecure" && httpsPort > 0 && (
          <a href={secureUrl} className="rounded-lg bg-white/10 px-3 py-2 text-sm font-semibold text-white/80 underline">
            Shake-to-{verb} needs the secure address. Open it
          </a>
        )}
        {!shakeOn && effect !== "none" && ms === "denied" && (
          <p className="text-sm text-white/60">Shake is off: motion access was not allowed.</p>
        )}
        {modelState === "error" && <p className="text-sm text-white/60">Couldn't load the 3D model.</p>}
      </footer>
    </div>
  );
}
