import { DatabaseSync } from "node:sqlite";
import { transaction } from "./db";

export type UseEffect = "none" | "shot" | "swing";
export type ItemKind = "gun" | "knife" | "ammo" | "healing" | "backpack" | "other";
export const ITEM_KINDS: ItemKind[] = ["gun", "knife", "ammo", "healing", "backpack", "other"];

// Herbs: G = green, R = red, Y = yellow, and the mixes they make. Every mix
// has a green herb in it (see inventory/herbs.ts for the mixing rules).
export type HerbCode = "G" | "R" | "Y" | "GG" | "GR" | "GY" | "GRY" | "GGY";
export const HERB_CODES: HerbCode[] = ["G", "R", "Y", "GG", "GR", "GY", "GRY", "GGY"];

// How many cells (columns × rows) a piece takes in the case when an item is
// made without a size: guns are wide, knives long and thin, the rest 1×1.
export const DEFAULT_GRID: Record<ItemKind, { w: number; h: number }> = {
  gun: { w: 3, h: 2 },
  knife: { w: 2, h: 1 },
  ammo: { w: 1, h: 1 },
  healing: { w: 1, h: 1 },
  backpack: { w: 1, h: 1 },
  other: { w: 1, h: 1 },
};
export const GRID_MAX = 10; // a piece is at most 10 cells wide or tall

// Kinds a player may sell back by default (the Admin can switch any item).
export const SELLABLE_BY_DEFAULT: ItemKind[] = ["gun", "knife", "ammo", "healing"];

export interface Item {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  max_stack: number | null;
  enabled: number; // SQLite has no boolean: 1 = enabled, 0 = disabled
  image_file: string | null;
  model_file: string | null;
  sound_file: string | null;
  use_effect: UseEffect;
  model_flip: number;
  model_upside_down: number;
  kind: ItemKind;
  ammo_for_item_id: number | null;
  ammo_per_pack: number | null;
  sellable: number;
  sell_percent: number;
  base_magazine: number | null;
  base_sharpness: number | null;
  base_length: number | null;
  up_price_magazine: number | null;
  up_price_damage: number | null;
  up_price_sharpness: number | null;
  up_price_length: number | null;
  // 2.0 Inventory Update
  grid_w: number; // cells wide in the case (1–10)
  grid_h: number; // cells tall in the case (1–10)
  stack_size: number | null; // units per piece; NULL = default (ammo: its rounds per pack, else 1)
  heal_amount: number | null; // HP a "Use" heals
  max_hp_bonus: number | null; // max HP a "Use" adds (and fills)
  full_heal: number; // 1 = a "Use" restores all HP
  herb_code: HerbCode | null;
  base_reload_ms: number | null; // guns: reload time at level 1 (NULL = 2 s)
  shake_force: number | null; // guns: 1 (light shake fires) – 10 (needs a hard shake)
  up_price_reload: number | null;
  up_price_firerate: number | null;
  hre: number | null; // calculator: 1 round of this = hre handgun rounds
  expand_rows: number | null; // backpacks: rows added to the case (NULL = 1)
  created_at: string;
}

// The Admin's full view of an item. Never sent to players: it contains the
// sell percentage, which players only learn when they choose to sell.
export interface PublicItem {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  maxStack: number | null;
  enabled: boolean;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  kind: ItemKind;
  ammoForItemId: number | null;
  ammoPerPack: number | null;
  sellable: boolean;
  sellPercent: number;
  baseMagazine: number | null;
  baseSharpness: number | null;
  baseLength: number | null;
  upgradePrices: {
    magazine: number | null;
    damage: number | null;
    reload: number | null;
    firerate: number | null;
    sharpness: number | null;
    length: number | null;
  };
  gridW: number;
  gridH: number;
  stackSize: number | null;
  healAmount: number | null;
  maxHpBonus: number | null;
  fullHeal: boolean;
  herbCode: HerbCode | null;
  baseReloadMs: number | null;
  shakeForce: number | null;
  hre: number | null;
  expandRows: number | null;
  createdAt: string;
}

export function imageUrlFor(file: string | null): string | null {
  return file ? `/media/items/${file}` : null;
}

export function toPublicItem(i: Item): PublicItem {
  return {
    id: i.id,
    name: i.name,
    description: i.description,
    category: i.category,
    maxStack: i.max_stack,
    enabled: i.enabled === 1,
    imageUrl: imageUrlFor(i.image_file),
    modelUrl: imageUrlFor(i.model_file),
    soundUrl: imageUrlFor(i.sound_file),
    useEffect: i.use_effect,
    modelFlip: i.model_flip === 1,
    modelUpsideDown: i.model_upside_down === 1,
    kind: i.kind,
    ammoForItemId: i.ammo_for_item_id,
    ammoPerPack: i.ammo_per_pack,
    sellable: i.sellable === 1,
    sellPercent: i.sell_percent,
    baseMagazine: i.base_magazine,
    baseSharpness: i.base_sharpness,
    baseLength: i.base_length,
    upgradePrices: {
      magazine: i.up_price_magazine,
      damage: i.up_price_damage,
      reload: i.up_price_reload,
      firerate: i.up_price_firerate,
      sharpness: i.up_price_sharpness,
      length: i.up_price_length,
    },
    gridW: i.grid_w,
    gridH: i.grid_h,
    stackSize: i.stack_size,
    healAmount: i.heal_amount,
    maxHpBonus: i.max_hp_bonus,
    fullHeal: i.full_heal === 1,
    herbCode: i.herb_code,
    baseReloadMs: i.base_reload_ms,
    shakeForce: i.shake_force,
    hre: i.hre,
    expandRows: i.expand_rows,
    createdAt: i.created_at,
  };
}

export function listItems(db: DatabaseSync): Item[] {
  return db.prepare("SELECT * FROM items ORDER BY name COLLATE NOCASE").all() as unknown as Item[];
}

export function findItemById(db: DatabaseSync, id: number): Item | undefined {
  return db.prepare("SELECT * FROM items WHERE id = ?").get(id) as Item | undefined;
}

// The name column is COLLATE NOCASE, so "Rifle" and "rifle" count as the same.
export function findItemByName(db: DatabaseSync, name: string): Item | undefined {
  return db.prepare("SELECT * FROM items WHERE name = ?").get(name) as Item | undefined;
}

export interface ItemFields {
  name?: string;
  description?: string | null;
  category?: string | null;
  maxStack?: number | null;
  enabled?: boolean;
  useEffect?: UseEffect;
  modelFlip?: boolean;
  modelUpsideDown?: boolean;
  kind?: ItemKind;
  ammoForItemId?: number | null;
  ammoPerPack?: number | null;
  sellable?: boolean;
  sellPercent?: number;
  baseMagazine?: number | null;
  baseSharpness?: number | null;
  baseLength?: number | null;
  upPriceMagazine?: number | null;
  upPriceDamage?: number | null;
  upPriceSharpness?: number | null;
  upPriceLength?: number | null;
  gridW?: number;
  gridH?: number;
  stackSize?: number | null;
  healAmount?: number | null;
  maxHpBonus?: number | null;
  fullHeal?: boolean;
  herbCode?: HerbCode | null;
  baseReloadMs?: number | null;
  shakeForce?: number | null;
  upPriceReload?: number | null;
  upPriceFirerate?: number | null;
  hre?: number | null;
  expandRows?: number | null;
}

// Field name -> column. Fixed list (never user input), so building the
// UPDATE statement from it is safe.
const COLUMNS: Record<keyof ItemFields, string> = {
  name: "name",
  description: "description",
  category: "category",
  maxStack: "max_stack",
  enabled: "enabled",
  useEffect: "use_effect",
  modelFlip: "model_flip",
  modelUpsideDown: "model_upside_down",
  kind: "kind",
  ammoForItemId: "ammo_for_item_id",
  ammoPerPack: "ammo_per_pack",
  sellable: "sellable",
  sellPercent: "sell_percent",
  baseMagazine: "base_magazine",
  baseSharpness: "base_sharpness",
  baseLength: "base_length",
  upPriceMagazine: "up_price_magazine",
  upPriceDamage: "up_price_damage",
  upPriceSharpness: "up_price_sharpness",
  upPriceLength: "up_price_length",
  gridW: "grid_w",
  gridH: "grid_h",
  stackSize: "stack_size",
  healAmount: "heal_amount",
  maxHpBonus: "max_hp_bonus",
  fullHeal: "full_heal",
  herbCode: "herb_code",
  baseReloadMs: "base_reload_ms",
  shakeForce: "shake_force",
  upPriceReload: "up_price_reload",
  upPriceFirerate: "up_price_firerate",
  hre: "hre",
  expandRows: "expand_rows",
};

function toDb(v: unknown): string | number | null {
  if (typeof v === "boolean") return v ? 1 : 0;
  return v as string | number | null;
}

// When an item's kind changes, settings that only made sense for the old
// kind follow along, unless the Admin set them in the same change:
// - a piece still at the old kind's default size gets the new kind's size
//   (a "Knife" turned into a gun becomes 3×2, not a 2×1 gun);
// - an item that stops being ammo stops counting as ammo for its gun.
export function withKindDefaults(current: Item | null, f: ItemFields): ItemFields {
  const out: ItemFields = { ...f };
  const kind = f.kind ?? current?.kind;
  if (!kind || (current && f.kind === undefined) || (current && f.kind === current.kind)) return out;
  const atOldDefault =
    !current || (current.grid_w === DEFAULT_GRID[current.kind].w && current.grid_h === DEFAULT_GRID[current.kind].h);
  if (out.gridW === undefined && out.gridH === undefined && atOldDefault) {
    out.gridW = DEFAULT_GRID[kind].w;
    out.gridH = DEFAULT_GRID[kind].h;
  }
  if (current && kind !== "ammo" && out.ammoForItemId === undefined && current.ammo_for_item_id !== null) {
    out.ammoForItemId = null;
  }
  return out;
}

export function createItem(db: DatabaseSync, f: ItemFields & { name: string }): Item {
  return transaction(db, () => {
    const result = db.prepare("INSERT INTO items (name) VALUES (?)").run(f.name);
    const id = Number(result.lastInsertRowid);
    const rest: ItemFields = withKindDefaults(null, f);
    delete rest.name;
    // New items follow their kind's selling default unless told otherwise.
    if (rest.sellable === undefined && rest.kind) rest.sellable = SELLABLE_BY_DEFAULT.includes(rest.kind);
    return updateItem(db, id, rest);
  });
}

// Other parts of the game that must react when an item's settings change
// register here — e.g. the case re-checks pieces when an item's size or
// stack size changes. Hooks run INSIDE the same database transaction as the
// change (if one fails, the change is undone). `previous` is the item as it
// was before this change.
export type ItemChangedHook = (db: DatabaseSync, item: Item, previous: Item) => void;
const itemHooks: ItemChangedHook[] = [];

export function onItemChanged(fn: ItemChangedHook): () => void {
  itemHooks.push(fn);
  return () => {
    const i = itemHooks.indexOf(fn);
    if (i >= 0) itemHooks.splice(i, 1);
  };
}

// Writes the given fields (already validated by the caller) in one step.
export function updateItem(db: DatabaseSync, id: number, f: ItemFields): Item {
  return transaction(db, () => {
    const previous = findItemById(db, id);
    if (!previous) throw new Error("Item not found.");
    for (const key of Object.keys(f) as (keyof ItemFields)[]) {
      const v = f[key];
      if (v === undefined) continue;
      db.prepare(`UPDATE items SET ${COLUMNS[key]} = ? WHERE id = ?`).run(toDb(v), id);
    }
    const item = findItemById(db, id)!;
    for (const hook of itemHooks) hook(db, item, previous);
    return item;
  });
}

export function setItemImage(db: DatabaseSync, id: number, file: string | null): void {
  db.prepare("UPDATE items SET image_file = ? WHERE id = ?").run(file, id);
}

export function setItemFile(
  db: DatabaseSync,
  id: number,
  column: "model_file" | "sound_file",
  file: string | null
): void {
  // column is one of two fixed names (never user input), so building the
  // statement with it is safe.
  db.prepare(`UPDATE items SET ${column} = ? WHERE id = ?`).run(file, id);
}
