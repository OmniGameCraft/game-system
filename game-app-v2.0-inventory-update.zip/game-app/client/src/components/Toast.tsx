import { useSyncExternalStore } from "react";

// Quick feedback that slides in at the top and goes away by itself:
// "Mixed: Mixed Herb (G+Y)", "Picked up Shotgun", "Not enough room".
// Call toast("…") from anywhere; <ToastHost /> (mounted once by the app)
// shows them. Toasts don't make a sound by themselves: the screen that calls
// toast() plays the sound that fits (purchase, pickup, error…).

export type ToastTone = "info" | "good" | "bad";

interface ToastItem {
  id: number;
  message: string;
  tone: ToastTone;
  leaving: boolean;
}

const MAX_VISIBLE = 3;
const LEAVE_MS = 180;

let items: ToastItem[] = [];
let nextId = 1;
const timers = new Map<number, ReturnType<typeof setTimeout>>();
const listeners = new Set<() => void>();

function setItems(next: ToastItem[]) {
  items = next;
  listeners.forEach((l) => l());
}

function lifetime(t: ToastItem): number {
  // Bad news and longer messages stay a little longer so they can be read.
  const base = t.tone === "bad" ? 4000 : 2600;
  return base + Math.min(2500, t.message.length * 25);
}

function arm(t: ToastItem) {
  const old = timers.get(t.id);
  if (old) clearTimeout(old);
  timers.set(
    t.id,
    setTimeout(() => dismissToast(t.id), lifetime(t))
  );
}

export function toast(message: string, tone: ToastTone = "info"): void {
  const text = String(message ?? "").trim();
  if (!text) return;
  // The same message again while it's still up: keep one, restart its timer.
  const same = items.find((t) => t.message === text && t.tone === tone && !t.leaving);
  if (same) {
    arm(same);
    return;
  }
  const t: ToastItem = { id: nextId++, message: text, tone, leaving: false };
  setItems([...items, t]);
  arm(t);
  const visible = items.filter((x) => !x.leaving);
  if (visible.length > MAX_VISIBLE) dismissToast(visible[0].id);
}

export function dismissToast(id: number): void {
  const t = items.find((x) => x.id === id);
  if (!t || t.leaving) return;
  const old = timers.get(id);
  if (old) clearTimeout(old);
  setItems(items.map((x) => (x.id === id ? { ...x, leaving: true } : x)));
  timers.set(
    id,
    setTimeout(() => {
      timers.delete(id);
      setItems(items.filter((x) => x.id !== id));
    }, LEAVE_MS)
  );
}

function subscribe(fn: () => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}
const snapshot = () => items;

const TONE: Record<ToastTone, { bar: string; icon: string; path: string }> = {
  info: { bar: "bg-steel-light", icon: "bg-ink/10 text-ink", path: "M12 11v6M12 7.5h.01" },
  good: { bar: "bg-olive", icon: "bg-olive-soft text-olive", path: "M6.5 12.5l3.5 3.5 7.5-8" },
  bad: { bar: "bg-alert", icon: "bg-alert/15 text-alert", path: "M12 7v6M12 16.5h.01" },
};

// Mount once near the top of the app.
export function ToastHost(): JSX.Element {
  const list = useSyncExternalStore(subscribe, snapshot, snapshot);
  return (
    <div
      className="pointer-events-none fixed inset-x-0 z-[90] flex flex-col items-center gap-2 px-3"
      style={{ top: "calc(env(safe-area-inset-top) + 0.5rem)" }}
      role="status"
      aria-live="polite"
    >
      {list.map((t) => {
        const look = TONE[t.tone];
        return (
          <button
            key={t.id}
            type="button"
            data-sound="none"
            onClick={() => dismissToast(t.id)}
            className={`pointer-events-auto relative flex w-full max-w-md items-center gap-3 overflow-hidden rounded-lg border border-panel-line bg-[#141619]/95 py-2.5 pl-4 pr-3 text-left shadow-lift backdrop-blur ${
              t.leaving ? "animate-toast-out" : "animate-toast-in"
            }`}
          >
            <span className={`absolute inset-y-0 left-0 w-1 ${look.bar}`} aria-hidden />
            <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${look.icon}`} aria-hidden>
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
                <path d={look.path} />
              </svg>
            </span>
            <span className="min-w-0 flex-1 text-base font-semibold leading-snug text-ink">{t.message}</span>
          </button>
        );
      })}
    </div>
  );
}
