import { useEffect, useState } from "react";
import { Button } from "../components/Button";
import { ErrorBanner } from "../components/ErrorBanner";
import { TransactionList } from "../components/TransactionList";
import { getMyTransactions, PublicUser, Transaction } from "../services/api";
import { PlayerInventory } from "./PlayerInventory";

type Tab = "home" | "bag";

export function PlayerHome({
  user,
  onLogout,
  onRefresh,
}: {
  user: PublicUser;
  onLogout: () => void;
  onRefresh: () => Promise<void>;
}) {
  const [transactions, setTransactions] = useState<Transaction[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<Tab>("home");

  function load() {
    setError(null);
    setLoading(true);
    Promise.all([getMyTransactions(), onRefresh()])
      .then(([tx]) => setTransactions(tx))
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load."))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  return (
    <div className="flex flex-col gap-6 pb-24">
      {tab === "home" && (
        <>
          <div>
            <p className="text-lg text-ink/60">Hello,</p>
            <h1 className="text-3xl font-bold text-pine">{user.displayName || user.username}</h1>
          </div>

          <div className="rounded-2xl border-2 border-pine bg-pine-soft px-6 py-6 text-center">
            <p className="text-lg text-ink/70">Money</p>
            <p className="text-4xl font-extrabold text-pine">${user.balance}</p>
          </div>

          <Button onClick={() => setTab("bag")}>Open Bag</Button>

          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-pine">Transaction History</h2>
              <button
                onClick={load}
                disabled={loading}
                className="text-sm font-semibold text-pine underline disabled:opacity-50"
              >
                {loading ? "Refreshing…" : "Refresh"}
              </button>
            </div>
            <ErrorBanner message={error} />
            {transactions && <TransactionList transactions={transactions} />}
          </div>

          <Button variant="ghost" onClick={onLogout}>
            Log out
          </Button>
        </>
      )}

      {tab === "bag" && <PlayerInventory />}

      <nav
        aria-label="Player"
        className="fixed inset-x-0 bottom-0 z-10 border-t-2 border-ink/10 bg-white"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="mx-auto grid max-w-md grid-cols-2">
          {(["home", "bag"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              aria-current={tab === t ? "page" : undefined}
              className={`py-4 text-lg font-bold ${tab === t ? "text-pine" : "text-ink/50"}`}
            >
              <span className={`mx-auto block w-fit rounded-full px-5 py-1 ${tab === t ? "bg-pine-soft" : ""}`}>
                {t === "home" ? "Home" : "Bag"}
              </span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
