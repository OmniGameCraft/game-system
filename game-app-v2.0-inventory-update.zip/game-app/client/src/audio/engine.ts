import { AppSettings, getSettings, subscribeSettings } from "./settings";

// The one sound engine for the whole app (Web Audio API). Every sound is made
// in code, so nothing is downloaded and it all works offline.
//
//   music  ─┐
//   sfx    ─┼─► master ─► limiter ─► speakers
//   clicks ─┘
//
// Each bus has its own volume from Settings. Volume changes glide over a few
// milliseconds instead of jumping, so there are never clicks or pops. The
// limiter keeps many sounds at once (shots + music + effects) from distorting.
//
// Phones only allow sound after the player taps something, so the engine
// listens for the first tap and "unlocks" itself then (also after a phone
// call or alarm interrupted the sound on iPhones).

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let music: GainNode | null = null;
let sfx: GainNode | null = null;
let clicks: GainNode | null = null;
let lastResumeAsk = -1e9;
let suspendedByUs = false;
let hideTimer: ReturnType<typeof setTimeout> | null = null;
const stateListeners = new Set<() => void>();

// Volume sliders are 0–100. Ears hear loudness roughly logarithmically, so a
// curved mapping makes the slider feel even from quiet to loud.
export function sliderToGain(v: number): number {
  if (!(v > 0)) return 0;
  const x = Math.min(100, v) / 100;
  return Math.pow(x, 1.5);
}

function targets(s: AppSettings) {
  return {
    master: s.masterMute ? 0 : 1,
    music: s.musicOn ? sliderToGain(s.musicVolume) : 0,
    sfx: s.sfxOn ? sliderToGain(s.sfxVolume) : 0,
    clicks: s.clickOn ? sliderToGain(s.clickVolume) : 0,
  };
}

function glide(node: GainNode | null, value: number, seconds = 0.06) {
  if (!node || !ctx) return;
  const p = node.gain;
  const t = ctx.currentTime;
  try {
    p.cancelScheduledValues(t);
    p.setValueAtTime(p.value, t);
    p.setTargetAtTime(value, t, seconds / 3);
  } catch {
    p.value = value;
  }
}

function applyVolumes(s: AppSettings) {
  const t = targets(s);
  glide(master, t.master);
  glide(music, t.music);
  glide(sfx, t.sfx);
  glide(clicks, t.clicks);
}

function build(): AudioContext {
  const C: typeof AudioContext = window.AudioContext || (window as any).webkitAudioContext;
  const c = new C({ latencyHint: "interactive" });
  ctx = c;

  const limiter = c.createDynamicsCompressor();
  limiter.threshold.value = -8;
  limiter.knee.value = 6;
  limiter.ratio.value = 6;
  limiter.attack.value = 0.003;
  limiter.release.value = 0.2;
  limiter.connect(c.destination);

  const t = targets(getSettings());
  master = c.createGain();
  master.gain.value = t.master;
  master.connect(limiter);

  music = c.createGain();
  music.gain.value = t.music;
  music.connect(master);

  sfx = c.createGain();
  sfx.gain.value = t.sfx;
  sfx.connect(master);

  clicks = c.createGain();
  clicks.gain.value = t.clicks;
  clicks.connect(master);

  subscribeSettings(applyVolumes);
  c.onstatechange = () => stateListeners.forEach((fn) => fn());
  installGestureUnlock();
  installVisibility();
  return c;
}

// The shared AudioContext (made on first use).
export function audioContext(): AudioContext {
  return ctx ?? build();
}

// Gun sounds and all sound effects go through this bus.
export function sfxBus(): GainNode {
  audioContext();
  return sfx!;
}

// Background music goes through this bus.
export function musicBus(): GainNode {
  audioContext();
  return music!;
}

// Button clicks, switches and tab sounds go through this bus, so the player
// can turn the little taps down without losing the game sounds.
export function clickBus(): GainNode {
  audioContext();
  return clicks!;
}

// Call inside a tap: phones only start sound from a tap.
export function unlockAudio(): void {
  try {
    const c = audioContext();
    if (c.state !== "running") {
      lastResumeAsk = performance.now();
      suspendedByUs = false;
      void c.resume().catch(() => {});
      // Older iPhones also need a (silent) sound started inside the tap.
      const b = c.createBuffer(1, 1, 22050);
      const src = c.createBufferSource();
      src.buffer = b;
      src.connect(c.destination);
      src.start(0);
    }
  } catch {
    // no sound support on this browser: the app just stays silent
  }
}

// True when a sound started now will be heard soon. A sound scheduled while
// the engine is asleep would otherwise all play at once when it wakes up.
export function audioReady(): boolean {
  if (!ctx) return false;
  if (ctx.state === "running") return true;
  // The tap that unlocks sound may itself make a sound (a button click), so
  // a sound asked for during that same tap is allowed. Outside a tap (e.g. a
  // live update before anyone touched the screen) it is skipped, otherwise
  // it would play late, out of the blue, on the first tap.
  const inTap = (navigator as any).userActivation?.isActive ?? true;
  return inTap && performance.now() - lastResumeAsk < 400 && ctx.state === "suspended";
}

export function audioRunning(): boolean {
  return !!ctx && ctx.state === "running";
}

// Called when the engine wakes up or goes to sleep.
export function onAudioStateChange(fn: () => void): () => void {
  stateListeners.add(fn);
  return () => {
    stateListeners.delete(fn);
  };
}

// Is anything on this bus going to be heard? Lets callers skip making sounds
// nobody can hear (saves battery).
export function busAudible(bus: "music" | "sfx" | "clicks"): boolean {
  const t = targets(getSettings());
  return t.master > 0 && t[bus] > 0;
}

let gestureInstalled = false;
function installGestureUnlock() {
  if (gestureInstalled) return;
  gestureInstalled = true;
  const wake = () => {
    if (!ctx || ctx.state !== "running") unlockAudio();
  };
  // touchend + click: iPhones only count those as "real" taps for sound.
  for (const ev of ["pointerdown", "touchend", "click", "keydown"]) {
    document.addEventListener(ev, wake, { capture: true, passive: true });
  }
}

// Make sure the first tap anywhere unlocks sound, even before anything has
// played. Safe to call many times.
export function prepareAudioUnlock(): void {
  installGestureUnlock();
}

// While the app is in the background, put the engine to sleep (saves
// battery and nobody is listening). Music fades itself out first.
let visibilityInstalled = false;
function installVisibility() {
  if (visibilityInstalled) return;
  visibilityInstalled = true;
  document.addEventListener("visibilitychange", () => {
    if (!ctx) return;
    if (document.visibilityState === "hidden") {
      if (hideTimer) clearTimeout(hideTimer);
      hideTimer = setTimeout(() => {
        hideTimer = null;
        if (ctx && document.visibilityState === "hidden" && ctx.state === "running") {
          suspendedByUs = true;
          void ctx.suspend().catch(() => {});
        }
      }, 1500);
    } else {
      if (hideTimer) {
        clearTimeout(hideTimer);
        hideTimer = null;
      }
      if (suspendedByUs && ctx.state !== "running") {
        suspendedByUs = false;
        // Usually allowed without a tap; if not, the next tap wakes it.
        void ctx.resume().catch(() => {});
      }
    }
  });
}

// One second of white noise, shared by every effect that needs a "shh" sound.
let noise: AudioBuffer | null = null;
export function noiseBuffer(): AudioBuffer {
  const c = audioContext();
  if (!noise || noise.sampleRate !== c.sampleRate) {
    const len = c.sampleRate;
    noise = c.createBuffer(1, len, c.sampleRate);
    const d = noise.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }
  return noise;
}
