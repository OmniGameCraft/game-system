import { ReactNode } from "react";

// A boxed section with its own title bar, so every part of a screen is
// clearly separated and labelled.
export function Section({
  title,
  action,
  children,
  tone = "pine",
  flush = false,
}: {
  title: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  tone?: "pine" | "alert" | "sun";
  flush?: boolean; // no padding around the body (for full-width lists)
}) {
  const bar =
    tone === "alert" ? "bg-alert text-white" : tone === "sun" ? "bg-sun text-ink" : "bg-pine text-white";
  const border = tone === "alert" ? "border-alert/30" : tone === "sun" ? "border-sun/60" : "border-pine/20";
  return (
    <section className={`overflow-hidden rounded-2xl border-2 ${border} bg-white shadow-sm`}>
      <header className={`flex min-h-[3.25rem] items-center justify-between gap-3 px-4 py-2 ${bar}`}>
        <h2 className="text-lg font-bold leading-tight">{title}</h2>
        {action}
      </header>
      <div className={flush ? "" : "flex flex-col gap-4 p-4"}>{children}</div>
    </section>
  );
}

// Small button that sits in a Section's title bar.
export function SectionAction({
  children,
  onClick,
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="flex min-h-[2.5rem] items-center gap-1 rounded-lg bg-white/15 px-3 text-sm font-bold active:bg-white/25 disabled:opacity-50"
    >
      {children}
    </button>
  );
}
