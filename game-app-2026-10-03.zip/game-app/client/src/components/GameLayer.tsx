import { useEffect, useRef, useState } from "react";
import { GameEvent, GameStatus, getGame, PlayerGame } from "../services/api";
import { useLive } from "../services/live";
import { Button } from "./Button";
import { Icon } from "./Icon";

// Remembering which messages a player has already seen is a convenience
// only: if the browser won't store it, they may just see a message twice.
function readSeen(key: string): number | null {
  try {
    const v = localStorage.getItem(key);
    return v === null ? null : Number(v);
  } catch {
    return null;
  }
}
function writeSeen(key: string, id: number) {
  try {
    localStorage.setItem(key, String(id));
  } catch {
    // ignore
  }
}
function buzz(pattern: number[]) {
  try {
    navigator.vibrate?.(pattern);
  } catch {
    // not supported
  }
}

// Loads the game's status and this player's messages, and keeps them fresh.
export function useGame(): PlayerGame | null {
  const [game, setGame] = useState<PlayerGame | null>(null);
  const load = () => {
    getGame().then(setGame).catch(() => {});
  };
  useEffect(load, []);
  useLive(["game:changed"], load, true);
  return game;
}

// Everything the game status puts on top of a player's screen:
//  - "Game on" flash when the Admin starts or resumes the game
//  - a pause screen that stays until the Admin resumes
//  - a game-over screen (can be closed)
//  - a pop-up for each new message from the Admin
export function GameLayer({ game, userId }: { game: PlayerGame | null; userId: number }) {
  const prevStatus = useRef<GameStatus | null>(null);
  const [flash, setFlash] = useState(false);
  const [closedEndAt, setClosedEndAt] = useState<string | null>(null);
  const [popup, setPopup] = useState<GameEvent | null>(null);
  const seenKey = `seen-announcement:${userId}`;

  // Status changes
  useEffect(() => {
    if (!game) return;
    const before = prevStatus.current;
    prevStatus.current = game.status;
    if (before !== null && before !== game.status) {
      if (game.status === "active") {
        setFlash(true);
        buzz([120, 60, 120]);
        const t = setTimeout(() => setFlash(false), 2200);
        return () => clearTimeout(t);
      }
      if (game.status === "paused" || game.status === "ended") buzz([400]);
    }
  }, [game?.status]);

  // New messages. On the first load on this phone, everything already sent
  // counts as seen (no flood of old pop-ups); after that, anything newer pops up.
  useEffect(() => {
    if (!game) return;
    const newestId = game.announcements[0]?.id ?? 0;
    const seen = readSeen(seenKey);
    if (seen === null) {
      writeSeen(seenKey, newestId);
      return;
    }
    if (newestId > seen) {
      setPopup(game.announcements[0]);
      buzz([200, 100, 200]);
    }
  }, [game, seenKey]);

  function closePopup() {
    if (popup) writeSeen(seenKey, popup.id);
    setPopup(null);
  }

  if (!game) return null;

  return (
    <>
      {flash && (
        <div
          className="pointer-events-none fixed inset-0 z-[60] flex items-center justify-center bg-paper/80"
          role="status"
        >
          <p className="chamfer animate-[gameon_2.2s_ease-out_forwards] bg-pine px-10 py-6 font-display text-6xl font-bold text-pine-ink">
            Game on
          </p>
        </div>
      )}

      {game.status === "paused" && (
        <FullScreen tone="sun" title="Game paused" icon="pause">
          <p className="text-lg text-ink/80">Hold your position. The Admin will resume the game.</p>
          {game.announcements[0] && <LatestMessage e={game.announcements[0]} />}
        </FullScreen>
      )}

      {game.status === "ended" && closedEndAt !== game.changedAt && (
        <FullScreen tone="alert" title="Game over" icon="flag">
          <p className="text-lg text-ink/80">Thanks for playing. Your money and bag are still here.</p>
          {game.announcements[0] && <LatestMessage e={game.announcements[0]} />}
          <Button variant="ghost" onClick={() => setClosedEndAt(game.changedAt)}>
            Close
          </Button>
        </FullScreen>
      )}

      {popup && game.status !== "paused" && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-paper/70 p-4 sm:items-center" role="alertdialog" aria-label="Message from the Admin">
          <div className="chamfer w-full max-w-md bg-panel">
            <div className="flex items-center gap-3 border-b border-panel-line bg-panel-raised px-4 py-3">
              <Icon name="megaphone" className="h-7 w-7 text-pine" />
              <p className="font-display text-xl font-bold">Message from the Admin</p>
            </div>
            <div className="flex flex-col gap-4 p-4">
              <p className="text-xl leading-snug">{popup.message}</p>
              <Button onClick={closePopup}>Got it</Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function LatestMessage({ e }: { e: GameEvent }) {
  return (
    <div className="w-full border-l-4 border-pine bg-panel-raised px-4 py-3 text-left">
      <p className="text-sm font-semibold text-pine">Latest message</p>
      <p className="text-lg">{e.message}</p>
    </div>
  );
}

function FullScreen({
  tone,
  title,
  icon,
  children,
}: {
  tone: "sun" | "alert";
  title: string;
  icon: "pause" | "flag";
  children: React.ReactNode;
}) {
  const color = tone === "sun" ? "text-sun" : "text-alert";
  const bar = tone === "sun" ? "bg-sun" : "bg-alert";
  return (
    <div className="fixed inset-0 z-[65] flex flex-col items-center justify-center gap-6 bg-paper/95 px-6 text-center" role="alertdialog" aria-label={title}>
      {/* hazard stripes top and bottom */}
      <div className={`absolute inset-x-0 top-0 h-3 ${bar} opacity-80 [background-image:repeating-linear-gradient(45deg,transparent_0_12px,rgba(0,0,0,.45)_12px_24px)]`} />
      <div className={`absolute inset-x-0 bottom-0 h-3 ${bar} opacity-80 [background-image:repeating-linear-gradient(45deg,transparent_0_12px,rgba(0,0,0,.45)_12px_24px)]`} />
      <Icon name={icon} className={`h-16 w-16 ${color}`} />
      <h1 className={`font-display text-5xl font-bold ${color}`}>{title}</h1>
      <div className="flex w-full max-w-sm flex-col gap-4">{children}</div>
    </div>
  );
}
