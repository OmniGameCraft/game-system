import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { randomBytes } from "crypto";
import fs from "fs";
import path from "path";
import { requireRole } from "../auth/middleware";
import { ITEM_IMAGE_DIR, PACKS_DIR } from "../config";
import { createItem, findItemByName, setItemFile, setItemImage, toPublicItem, UseEffect } from "../database/items";

// Item packs that ship with the app (e.g. the free weapon pack). Nothing is
// created automatically: the Admin chooses which items to add, and they
// arrive like any item the Admin made by hand — not in the shop, not given
// to anyone.

interface PackItem {
  key: string;
  name: string;
  category: string | null;
  description: string | null;
  useEffect: UseEffect;
  picture: string | null;
  model: string | null;
  sound: string | null;
}
interface Pack {
  id: string;
  title: string;
  credits: string;
  items: PackItem[];
}

const SAFE_ID = /^[a-z0-9-]{1,40}$/;

function readPacks(): Pack[] {
  let dirs: string[] = [];
  try {
    dirs = fs.readdirSync(PACKS_DIR).filter((d) => SAFE_ID.test(d));
  } catch {
    return [];
  }
  const packs: Pack[] = [];
  for (const d of dirs) {
    try {
      const m = JSON.parse(fs.readFileSync(path.join(PACKS_DIR, d, "manifest.json"), "utf8")) as Pack;
      packs.push({ ...m, id: d });
    } catch {
      // not a pack folder
    }
  }
  return packs;
}

// Only plain file names inside the pack folder (never ../ paths).
function packFile(packId: string, name: string | null): string | null {
  if (!name || path.basename(name) !== name) return null;
  const p = path.join(PACKS_DIR, packId, name);
  return fs.existsSync(p) ? p : null;
}

function copyIn(src: string | null, itemId: number, kind: string): string | null {
  if (!src) return null;
  const file = `item-${itemId}-${kind}-${randomBytes(6).toString("hex")}${path.extname(src).toLowerCase()}`;
  fs.mkdirSync(ITEM_IMAGE_DIR, { recursive: true });
  fs.copyFileSync(src, path.join(ITEM_IMAGE_DIR, file));
  return file;
}

export function createPacksRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  router.get("/", (_req, res) => {
    const packs = readPacks().map((p) => ({
      id: p.id,
      title: p.title,
      credits: p.credits,
      items: p.items.map((i) => ({
        key: i.key,
        name: i.name,
        category: i.category,
        useEffect: i.useEffect,
        pictureUrl: i.picture && packFile(p.id, i.picture) ? `/packs/${p.id}/${i.picture}` : null,
        hasModel: Boolean(packFile(p.id, i.model)),
        hasSound: Boolean(packFile(p.id, i.sound)),
        alreadyAdded: Boolean(findItemByName(db, i.name)),
      })),
    }));
    res.json({ packs });
  });

  // Body: { keys: ["pistol", "knife", ...] }
  router.post("/:id/import", (req, res) => {
    const pack = readPacks().find((p) => p.id === req.params.id);
    if (!pack) {
      res.status(404).json({ error: "Pack not found." });
      return;
    }
    const keys = req.body?.keys;
    if (!Array.isArray(keys) || keys.length === 0 || keys.some((k) => typeof k !== "string")) {
      res.status(400).json({ error: "Choose at least one item." });
      return;
    }
    const created = [];
    const skipped: string[] = [];
    for (const key of new Set(keys as string[])) {
      const pi = pack.items.find((i) => i.key === key);
      if (!pi) continue;
      if (findItemByName(db, pi.name)) {
        skipped.push(pi.name);
        continue;
      }
      const effect: UseEffect = pi.useEffect === "shot" || pi.useEffect === "swing" ? pi.useEffect : "none";
      db.exec("BEGIN");
      try {
        const item = createItem(db, {
          name: pi.name,
          description: pi.description ?? null,
          category: pi.category ?? null,
          maxStack: null,
          useEffect: effect,
        });
        const pic = copyIn(packFile(pack.id, pi.picture), item.id, "pic");
        const model = copyIn(packFile(pack.id, pi.model), item.id, "model");
        const sound = copyIn(packFile(pack.id, pi.sound), item.id, "sound");
        if (pic) setItemImage(db, item.id, pic);
        if (model) setItemFile(db, item.id, "model_file", model);
        if (sound) setItemFile(db, item.id, "sound_file", sound);
        db.exec("COMMIT");
        created.push(pi.name);
      } catch {
        db.exec("ROLLBACK");
        res.status(500).json({ error: `Could not add ${pi.name}. Please try again.`, created, skipped });
        return;
      }
    }
    res.json({ created, skipped });
  });

  return router;
}
