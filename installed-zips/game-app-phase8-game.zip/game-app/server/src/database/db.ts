import { DatabaseSync } from "node:sqlite"; // built into Node 22.13+, nothing to compile
import fs from "fs";
import path from "path";
import { DB_PATH } from "../config";

// Each entry is one schema step, applied once (SQLite's user_version tracks
// how many have run). Never insert seed data here.
const migrations: string[] = [
  // v1 — auth: admins and players in one table, one row per account.
  `CREATE TABLE users (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     role TEXT NOT NULL CHECK (role IN ('admin', 'player')),
     username TEXT NOT NULL UNIQUE,
     display_name TEXT,
     password_hash TEXT NOT NULL,
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );`,
  // v2 — player management: an account can be disabled so it can no longer log in.
  `ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'active'
     CHECK (status IN ('active', 'disabled'));`,
  // v3 — single-active-session enforcement for Admin accounts. Only ever
  // read/written for role='admin'; players never use this column.
  `ALTER TABLE users ADD COLUMN active_session_token TEXT;`,
  // v4 — money. balance lives on the account (meaningful for players only;
  // admin accounts stay at 0). transactions is the audit trail: every add
  // or remove records the balance before and after, and who performed it.
  `ALTER TABLE users ADD COLUMN balance INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0);
   CREATE TABLE transactions (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     type TEXT NOT NULL CHECK (type IN ('ADD', 'REMOVE')),
     amount INTEGER NOT NULL CHECK (amount > 0),
     balance_before INTEGER NOT NULL,
     balance_after INTEGER NOT NULL,
     performed_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE INDEX idx_transactions_player_id ON transactions(player_id);`,
  // v5 — items & inventory. items is the Admin's catalogue (starts empty).
  // inventory holds one row per (player, item) the player actually owns;
  // a row is deleted when its quantity reaches 0, so quantity is always > 0.
  // inventory_log is the audit trail for every Admin give/remove/set,
  // written in the same database transaction as the inventory change.
  `CREATE TABLE items (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     name TEXT NOT NULL UNIQUE COLLATE NOCASE,
     description TEXT,
     category TEXT,
     max_stack INTEGER CHECK (max_stack IS NULL OR max_stack > 0),
     enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
     image_file TEXT,
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE TABLE inventory (
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     quantity INTEGER NOT NULL CHECK (quantity > 0),
     PRIMARY KEY (player_id, item_id)
   );
   CREATE INDEX idx_inventory_item_id ON inventory(item_id);
   CREATE TABLE inventory_log (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     action TEXT NOT NULL CHECK (action IN ('GIVE', 'REMOVE', 'SET')),
     quantity_before INTEGER NOT NULL CHECK (quantity_before >= 0),
     quantity_after INTEGER NOT NULL CHECK (quantity_after >= 0),
     performed_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE INDEX idx_inventory_log_player_id ON inventory_log(player_id);`,
  // v6 — shop.
  // game_state: simple key/value settings the Admin controls. No rows are
  // inserted here: a missing 'shop_open' row simply means the shop is closed.
  // shop_items: one listing per item (price, stock, limits). stock NULL means
  // unlimited; max_per_purchase NULL means no per-purchase limit.
  // transactions and inventory_log are rebuilt (SQLite can't change a CHECK
  // constraint in place) so a purchase can be recorded as type/action
  // 'PURCHASE', with the item and quantity on the money record. Every
  // existing row is copied across unchanged, ids included.
  `CREATE TABLE game_state (
     key TEXT PRIMARY KEY,
     value TEXT NOT NULL
   );
   CREATE TABLE shop_items (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     item_id INTEGER NOT NULL UNIQUE REFERENCES items(id),
     price INTEGER NOT NULL CHECK (price >= 0),
     stock INTEGER CHECK (stock IS NULL OR stock >= 0),
     max_per_purchase INTEGER CHECK (max_per_purchase IS NULL OR max_per_purchase > 0),
     enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );

   CREATE TABLE transactions_v6 (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     type TEXT NOT NULL CHECK (type IN ('ADD', 'REMOVE', 'PURCHASE')),
     amount INTEGER NOT NULL CHECK (amount >= 0),
     balance_before INTEGER NOT NULL,
     balance_after INTEGER NOT NULL,
     performed_by INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER REFERENCES items(id),
     quantity INTEGER CHECK (quantity IS NULL OR quantity > 0),
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     CHECK (type = 'PURCHASE' OR amount > 0),
     CHECK ((type = 'PURCHASE') = (item_id IS NOT NULL AND quantity IS NOT NULL))
   );
   INSERT INTO transactions_v6
     (id, player_id, type, amount, balance_before, balance_after, performed_by, created_at)
     SELECT id, player_id, type, amount, balance_before, balance_after, performed_by, created_at
       FROM transactions;
   DROP TABLE transactions;
   ALTER TABLE transactions_v6 RENAME TO transactions;
   CREATE INDEX idx_transactions_player_id ON transactions(player_id);
   CREATE INDEX idx_transactions_type ON transactions(type);

   CREATE TABLE inventory_log_v6 (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     action TEXT NOT NULL CHECK (action IN ('GIVE', 'REMOVE', 'SET', 'PURCHASE')),
     quantity_before INTEGER NOT NULL CHECK (quantity_before >= 0),
     quantity_after INTEGER NOT NULL CHECK (quantity_after >= 0),
     performed_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   INSERT INTO inventory_log_v6
     SELECT id, player_id, item_id, action, quantity_before, quantity_after, performed_by, created_at
       FROM inventory_log;
   DROP TABLE inventory_log;
   ALTER TABLE inventory_log_v6 RENAME TO inventory_log;
   CREATE INDEX idx_inventory_log_player_id ON inventory_log(player_id);`,
  // v7 — 3D model + sound per item (for the full-screen "use" view in a
  // player's Bag). use_effect says what a tap/shake does there:
  //   none = just show it, shot = fire (recoil + flash), swing = melee swing.
  // model_flip / model_upside_down let the Admin fix a model that faces the
  // wrong way, since every downloaded model is oriented differently.
  `ALTER TABLE items ADD COLUMN model_file TEXT;
   ALTER TABLE items ADD COLUMN sound_file TEXT;
   ALTER TABLE items ADD COLUMN use_effect TEXT NOT NULL DEFAULT 'none'
     CHECK (use_effect IN ('none', 'shot', 'swing'));
   ALTER TABLE items ADD COLUMN model_flip INTEGER NOT NULL DEFAULT 0 CHECK (model_flip IN (0, 1));
   ALTER TABLE items ADD COLUMN model_upside_down INTEGER NOT NULL DEFAULT 0
     CHECK (model_upside_down IN (0, 1));`,
  // v8 — game controls. The game's status lives in game_state (key
  // 'game_status'; no row = not started). game_events keeps a history of
  // status changes and announcements. Starts empty.
  `CREATE TABLE game_events (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     type TEXT NOT NULL CHECK (type IN ('STATUS', 'ANNOUNCEMENT')),
     status TEXT CHECK (status IS NULL OR status IN ('not_started', 'active', 'paused', 'ended')),
     message TEXT,
     player_id INTEGER REFERENCES users(id),
     created_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     CHECK ((type = 'STATUS') = (status IS NOT NULL)),
     CHECK ((type = 'ANNOUNCEMENT') = (message IS NOT NULL))
   );
   CREATE INDEX idx_game_events_player_id ON game_events(player_id);`,
];

export function openDatabase(): DatabaseSync {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec("PRAGMA journal_mode = WAL");
  db.exec("PRAGMA foreign_keys = ON");

  const row = db.prepare("PRAGMA user_version").get() as { user_version: number };
  for (let v = row.user_version; v < migrations.length; v++) {
    db.exec("BEGIN");
    try {
      db.exec(migrations[v]);
      db.exec(`PRAGMA user_version = ${v + 1}`);
      db.exec("COMMIT");
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  }
  return db;
}
