import type { DatabaseSync } from "node:sqlite";

// Voice hit calls: turns what a phone heard ("three forty", "340",
// "player 3, 40") into { target: 3, damage: 40 } — Player 3 loses 40 HP.
//
// The phones run the SAME algorithm: client/src/voice/parse.ts is an exact
// copy of this file without the import line and the "Server only" part at
// the end. So a call means the same thing on every phone and on the server.
// Change both together, then run: npx tsx scripts/test-voice-parse.ts
//
// How a call is read:
//  1. Lower-case it. Punctuation becomes a space, so "3-40", "3:40", "3.40"
//     and "player 3, 40" all work, and "player3" is split into two words.
//  2. Each word becomes digits:
//       zero / oh / o → 0, one … nine → 1–9, ten … nineteen, twenty … ninety
//       (a following one … nine joins it: "forty five" → 45), "hundred"
//       ("three hundred forty" → 340, "a hundred" / "one hundred" → 100),
//       and words speech recognition often writes instead of a number:
//       to / too → 2, for → 4, won → 1, ate → 8, tree → 3, fife → 5,
//       niner → 9. Digits stay digits ("340", "3 40").
//  3. "player", "hit", "damage", "number", "and", "hp" and "points" are
//     ignored. ANY other word means it wasn't a call and the answer is null:
//     people talk during a game, and "give me 25 seconds" must never cost
//     anyone HP. Missing a call is better than inventing one.
//  4. All the digits are joined. The first D are the player number, the rest
//     are the damage. D is 1 while every player number is 1–9, otherwise 2
//     (then Player 3 is called "zero three"). The player number must be 1 or
//     more; the damage 1–999 (at most three digits).
//  5. "for" / "to" / "too" right after the player number is first read as
//     the plain English word, because "player three for forty" means
//     Player 3, 40 HP (not 440). Only if that doesn't make a valid call is it
//     read as the digit: "three for zero" → 340 → Player 3, 40 HP.

export interface Callout {
  target: number; // the player number called
  damage: number; // HP to take away
}

export const DAMAGE_MIN = 1;
export const DAMAGE_MAX = 999;

// A real call is a few words. Anything much longer is someone talking.
const MAX_TEXT_LENGTH = 200;

const IGNORED = new Set(["player", "players", "hit", "hits", "damage", "number", "and", "hp", "points"]);

// Maps (not plain objects) so a word like "constructor" is never mistaken
// for a number.
const UNITS = new Map<string, number>([
  ["zero", 0], ["oh", 0], ["o", 0],
  ["one", 1], ["won", 1],
  ["two", 2], ["to", 2], ["too", 2],
  ["three", 3], ["tree", 3],
  ["four", 4], ["for", 4],
  ["five", 5], ["fife", 5],
  ["six", 6],
  ["seven", 7],
  ["eight", 8], ["ate", 8],
  ["nine", 9], ["niner", 9],
]);

const TEENS = new Map<string, number>([
  ["ten", 10], ["eleven", 11], ["twelve", 12], ["thirteen", 13], ["fourteen", 14],
  ["fifteen", 15], ["sixteen", 16], ["seventeen", 17], ["eighteen", 18], ["nineteen", 19],
]);

const TENS = new Map<string, number>([
  ["twenty", 20], ["thirty", 30], ["forty", 40], ["fourty", 40], ["fifty", 50],
  ["sixty", 60], ["seventy", 70], ["eighty", 80], ["ninety", 90],
]);

// Number words that are also everyday English joining words (step 5).
const LINK_WORDS = new Set(["for", "to", "too"]);

// One spoken number, as the digits it stands for. `link` marks a
// "for" / "to" / "too" that might be the English word instead.
interface Part {
  digits: string;
  link: boolean;
}

// The number of digits the player number takes in a call: 1 or 2.
function clampDigits(playerNumberDigits: number): number {
  return playerNumberDigits >= 2 ? 2 : 1;
}

// Text → words: lower case, no punctuation, letters and digits apart.
function words(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/['’]/g, "") // "player's" → "players"
    .replace(/[^a-z0-9]+/g, " ") // "3-40", "3:40", "3.40", "3, 40" → "3 40"
    .replace(/([0-9])([a-z])/g, "$1 $2") // "3rd" → "3 rd"
    .replace(/([a-z])([0-9])/g, "$1 $2") // "player3" → "player 3"
    .trim()
    .split(" ")
    .filter((w) => w !== "");
}

// A unit word 1–9 that can finish a tens word ("forty five"). Not a link
// word: "twenty to forty" is 20 then 40, not 22 then 40.
function joiningUnit(word: string | undefined): number | null {
  if (word === undefined || LINK_WORDS.has(word)) return null;
  const u = UNITS.get(word);
  return u !== undefined && u > 0 ? u : null;
}

// The part after "hundred": "(and) forty five", "(and) twelve", "five",
// "40". Returns the value and the index of the first word after it.
function afterHundred(list: string[], start: number): { value: number; next: number } | null {
  let i = start;
  while (list[i] === "and") i++;
  const w = list[i];
  if (w === undefined) return null;
  if (/^[0-9]{1,2}$/.test(w)) return { value: Number(w), next: i + 1 };
  const teen = TEENS.get(w);
  if (teen !== undefined) return { value: teen, next: i + 1 };
  const tens = TENS.get(w);
  if (tens !== undefined) {
    const u = joiningUnit(list[i + 1]);
    return u === null ? { value: tens, next: i + 1 } : { value: tens + u, next: i + 2 };
  }
  const unit = joiningUnit(w);
  return unit === null ? null : { value: unit, next: i + 1 };
}

// Words → spoken numbers, or null when a word isn't part of a call.
function toParts(list: string[]): Part[] | null {
  const parts: Part[] = [];
  for (let i = 0; i < list.length; i++) {
    const w = list[i];
    if (IGNORED.has(w)) continue;

    if (/^[0-9]+$/.test(w)) {
      parts.push({ digits: w, link: false });
      continue;
    }

    // "three hundred forty" = 340, "a hundred" = 100. The single digit just
    // before says how many hundreds; anything else before it stays as it is
    // ("fifteen hundred" = 15 then 100).
    if (w === "hundred" || (w === "a" && list[i + 1] === "hundred")) {
      let hundreds = 1;
      if (w === "a") {
        i++; // skip the word "hundred" too
      } else {
        const prev = parts[parts.length - 1];
        if (prev && !prev.link && /^[1-9]$/.test(prev.digits)) {
          hundreds = Number(prev.digits);
          parts.pop();
        }
      }
      const rest = afterHundred(list, i + 1);
      if (rest) i = rest.next - 1;
      parts.push({ digits: String(hundreds * 100 + (rest?.value ?? 0)), link: false });
      continue;
    }

    const unit = UNITS.get(w);
    if (unit !== undefined) {
      parts.push({ digits: String(unit), link: LINK_WORDS.has(w) });
      continue;
    }
    const teen = TEENS.get(w);
    if (teen !== undefined) {
      parts.push({ digits: String(teen), link: false });
      continue;
    }
    const tens = TENS.get(w);
    if (tens !== undefined) {
      const u = joiningUnit(list[i + 1]);
      if (u !== null) i++;
      parts.push({ digits: String(tens + (u ?? 0)), link: false });
      continue;
    }

    return null; // any other word: not a call
  }
  return parts;
}

// All digits → player number (first d digits) + damage (the rest).
function split(all: string, d: number): Callout | null {
  if (all.length <= d || all.length > d + 3) return null;
  const target = Number(all.slice(0, d));
  const damage = Number(all.slice(d));
  if (target < 1 || damage < DAMAGE_MIN || damage > DAMAGE_MAX) return null;
  return { target, damage };
}

// Where a "for" / "to" / "too" sits right after the player number (with
// something after it), or -1.
function linkAfterPlayer(parts: Part[], d: number): number {
  let count = 0;
  for (let i = 0; i < parts.length - 1; i++) {
    if (count === d && parts[i].link) return i;
    count += parts[i].digits.length;
    if (count > d) break;
  }
  return -1;
}

// Reads one heard sentence. playerNumberDigits = D (see step 4): 1 while
// every player number is 1–9, else 2. Returns null if it isn't a call.
export function parseCallout(text: string, playerNumberDigits: number): Callout | null {
  if (typeof text !== "string" || text.length > MAX_TEXT_LENGTH) return null;
  const d = clampDigits(playerNumberDigits);
  const parts = toParts(words(text));
  if (!parts || parts.length === 0) return null;

  const link = linkAfterPlayer(parts, d);
  if (link >= 0) {
    const asWord = split(
      parts
        .filter((_, i) => i !== link)
        .map((p) => p.digits)
        .join(""),
      d
    );
    if (asWord) return asWord;
  }
  return split(parts.map((p) => p.digits).join(""), d);
}

// ---- Server only (not copied to the phones) ---------------------------------
// Phones get D from GET /api/voice/info.

// D for a highest player number: 1 for 1–9 (or no players), else 2.
export function digitsForHighest(highest: number | null): number {
  return highest !== null && highest >= 10 ? 2 : 1;
}

// D right now: from the highest number among players who can play (a
// disabled account isn't in the game, so its number doesn't count).
export function playerNumberDigits(db: DatabaseSync): number {
  const row = db
    .prepare(
      `SELECT MAX(player_number) AS n FROM users
        WHERE role = 'player' AND status = 'active' AND player_number IS NOT NULL`
    )
    .get() as { n: number | null } | undefined;
  return digitsForHighest(row?.n ?? null);
}
