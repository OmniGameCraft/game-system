import { Icon } from "./Icon";

// [-] 3 [+] with big touch targets. The number bumps when it changes.
export function Stepper({
  value,
  onChange,
  min = 1,
  max,
  label,
}: {
  value: number;
  onChange: (n: number) => void;
  min?: number;
  max?: number;
  label: string;
}) {
  const atMin = value <= min;
  const atMax = max !== undefined && value >= max;
  const btn =
    "press flex h-12 w-12 shrink-0 items-center justify-center rounded-md border border-panel-line bg-gradient-to-b from-[#25282c] to-[#17191c] text-pine shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_2px_0_#08090a] active:bg-pine-soft disabled:opacity-30";
  return (
    <div className="flex items-center gap-2" role="group" aria-label={label}>
      <button type="button" className={btn} disabled={atMin} onClick={() => onChange(value - 1)} aria-label="Less">
        <Icon name="minus" />
      </button>
      <span className="min-w-[3rem] overflow-hidden text-center" aria-live="polite">
        <span key={value} className="inline-block animate-tick font-display text-3xl font-bold tabular-nums text-ink">
          {value}
        </span>
      </span>
      <button type="button" className={btn} disabled={atMax} onClick={() => onChange(value + 1)} aria-label="More">
        <Icon name="plus" />
      </button>
    </div>
  );
}
