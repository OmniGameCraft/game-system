import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "../components/Toast";
import { Callout, parseCallout } from "./parse";
import { sendVoiceHit, VoiceApiError } from "./voiceApi";

// The "listening system": while the game is on, this phone keeps the
// microphone open and listens for hit calls like "three, forty". Each call
// it understands is sent to the server, which takes the HP off once even if
// many phones heard the same shout.
//
// Uses the browser's speech recognition (Chrome on Android, Safari on
// iPhone). It needs a secure (https) page and the microphone permission.
// Where the phone can recognise speech on the device itself we ask for that,
// so it works without internet; otherwise the browser decides.

export type VoiceState = "off" | "starting" | "listening" | "denied" | "unsupported" | "insecure" | "error";

// The parts of the Web Speech API we use. TypeScript doesn't ship these
// types, and Chrome/Safari only have the "webkit" prefixed version on some
// phones, so they are described here.
interface RecAlternative {
  transcript: string;
}
interface RecResult {
  isFinal: boolean;
  length: number;
  [index: number]: RecAlternative;
}
interface RecEvent {
  resultIndex: number;
  results: { length: number; [index: number]: RecResult };
}
interface Recognition {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  processLocally?: boolean;
  onstart: (() => void) | null;
  onaudiostart: (() => void) | null;
  onresult: ((e: RecEvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}
interface RecognitionClass {
  new (): Recognition;
  // Newer Chrome: can this language be recognised on the device?
  available?: (o: { langs: string[]; processLocally: boolean }) => Promise<string>;
}

function recognitionClass(): RecognitionClass | null {
  const w = window as any;
  return (w.SpeechRecognition || w.webkitSpeechRecognition || null) as RecognitionClass | null;
}

export function speechSupported(): boolean {
  return recognitionClass() !== null;
}

const LANG = "en-US";
const SAME_CALL_MS = 1500; // the same call again from this phone within this time is an echo
const ERROR_TOAST_MS = 6000; // don't nag: at most one "couldn't send" message this often

// Runs the recognition loop outside React. The hook below owns one.
class VoiceEngine {
  private rec: Recognition | null = null;
  private enabled = false;
  private denied = false; // the mic was refused: wait for requestPermission()
  private unsupported = false;
  private restartTimer = 0;
  private failures = 0; // errors in a row, for the back-off
  private startedAt = 0;
  private local: boolean | null = null; // on-device recognition: null = not checked yet
  private checkingLocal = false;
  private lastCall = new Map<string, number>();
  private lastErrorToast = 0;
  private permissionStatus: PermissionStatus | null = null;
  private disposed = false;

  constructor(
    private setState: (s: VoiceState) => void,
    private onHeard: (text: string, call: Callout | null) => void,
    private digits: () => number
  ) {
    document.addEventListener("visibilitychange", this.onVisibility);
    this.watchPermission();
  }

  setEnabled(on: boolean): void {
    this.enabled = on;
    this.update();
  }

  dispose(): void {
    this.disposed = true;
    document.removeEventListener("visibilitychange", this.onVisibility);
    if (this.permissionStatus) this.permissionStatus.onchange = null;
    this.stop();
  }

  // Called from a tap ("Allow microphone"): phones only show the
  // microphone question, and some only start listening, from a tap.
  async requestPermission(): Promise<void> {
    if (!window.isSecureContext) {
      this.setState(this.enabled ? "insecure" : "off");
      return;
    }
    this.denied = false;
    this.failures = 0;
    if (this.enabled && recognitionClass() && !this.unsupported) {
      // Start straight away, still inside the tap.
      this.stop();
      this.start();
      return;
    }
    // Not listening right now: just ask for the microphone so it's ready.
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
    } catch (err) {
      const name = (err as { name?: string })?.name;
      if (name === "NotAllowedError" || name === "SecurityError") this.denied = true;
    }
    this.update();
  }

  // Decides what should be happening right now and makes it so.
  private update = (): void => {
    if (this.disposed) return;
    if (!this.enabled) {
      this.stop();
      this.setState("off");
      return;
    }
    if (!window.isSecureContext) {
      this.stop();
      this.setState("insecure");
      return;
    }
    if (!recognitionClass() || this.unsupported) {
      this.stop();
      this.setState("unsupported");
      return;
    }
    if (this.denied) {
      this.stop();
      this.setState("denied");
      return;
    }
    if (document.hidden) {
      // Background tab: let the microphone go; it comes back when visible.
      this.stop();
      this.setState("starting");
      return;
    }
    if (!this.rec && !this.restartTimer) this.start();
  };

  private onVisibility = () => this.update();

  // If the person already blocked the microphone for this site, show that
  // straight away, and notice when they allow it in the browser settings.
  private watchPermission(): void {
    try {
      navigator.permissions
        ?.query({ name: "microphone" as PermissionName })
        .then((status) => {
          if (this.disposed) return;
          this.permissionStatus = status;
          if (status.state === "denied") {
            this.denied = true;
            this.update();
          }
          status.onchange = () => {
            this.denied = status.state === "denied";
            this.failures = 0;
            this.update();
          };
        })
        .catch(() => {});
    } catch {
      // Permissions API not available (older Safari): errors tell us instead
    }
  }

  private start(): void {
    const Rec = recognitionClass();
    if (!Rec) return;

    // First time only: ask newer Chrome whether English can be recognised on
    // the phone itself (no internet needed). Older browsers just try.
    if (this.local === null) {
      if (typeof Rec.available === "function" && !this.checkingLocal) {
        this.checkingLocal = true;
        Rec.available({ langs: [LANG], processLocally: true })
          .then((a) => (this.local = a === "available"))
          .catch(() => (this.local = false))
          .finally(() => {
            this.checkingLocal = false;
            this.update();
          });
        this.setState("starting");
        return;
      }
      if (this.checkingLocal) return;
      this.local = true; // we'll find out from the first error if it can't
    }

    let rec: Recognition;
    try {
      rec = new Rec();
    } catch {
      this.failed("error");
      return;
    }
    rec.lang = LANG;
    rec.continuous = true;
    rec.interimResults = false;
    rec.maxAlternatives = 3;
    const triedLocal = Boolean(this.local && "processLocally" in rec);
    if (triedLocal) {
      try {
        rec.processLocally = true;
      } catch {
        // read-only on this browser: fine, use the default
      }
    }

    const markListening = () => {
      if (this.rec === rec) this.setState("listening");
    };
    rec.onstart = markListening;
    rec.onaudiostart = markListening;
    rec.onresult = (e) => this.handleResult(e);
    rec.onerror = (e) => this.handleError(e.error, triedLocal);
    rec.onend = () => {
      if (this.rec !== rec) return;
      this.rec = null;
      // A session that ran a while was healthy, whatever ended it.
      if (Date.now() - this.startedAt > 15_000) this.failures = 0;
      this.scheduleRestart();
    };

    this.rec = rec;
    this.startedAt = Date.now();
    this.setState("starting");
    try {
      rec.start();
    } catch {
      this.rec = null;
      this.failures++;
      this.scheduleRestart();
    }
  }

  private stop(): void {
    if (this.restartTimer) {
      window.clearTimeout(this.restartTimer);
      this.restartTimer = 0;
    }
    const rec = this.rec;
    this.rec = null;
    if (rec) {
      rec.onstart = rec.onaudiostart = rec.onresult = rec.onerror = rec.onend = null;
      try {
        rec.abort();
      } catch {
        // already stopped
      }
    }
  }

  private failed(state: VoiceState): void {
    this.failures++;
    this.setState(state);
    this.scheduleRestart();
  }

  // Chrome stops listening after a quiet spell, and errors happen; while
  // listening is wanted, start again — quickly at first, then backing off
  // (up to 30 s) if it keeps failing.
  private scheduleRestart(): void {
    if (this.disposed || !this.enabled || this.denied || this.unsupported || document.hidden) {
      this.update();
      return;
    }
    if (this.restartTimer) return;
    const delay = this.failures === 0 ? 250 : Math.min(30_000, 500 * 2 ** (this.failures - 1));
    this.restartTimer = window.setTimeout(() => {
      this.restartTimer = 0;
      this.update();
    }, delay);
  }

  private handleError(code: string, triedLocal: boolean): void {
    switch (code) {
      case "no-speech": // just quiet for a while
      case "aborted": // we (or the phone) stopped it; onend restarts if needed
        return;
      case "not-allowed":
        this.denied = true;
        this.setState("denied");
        return;
      case "service-not-allowed":
      case "language-not-supported":
        if (triedLocal) {
          // On-device recognition isn't possible here: use the normal one.
          this.local = false;
          return;
        }
        if (code === "language-not-supported") {
          this.unsupported = true;
          this.setState("unsupported");
        } else {
          this.denied = true;
          this.setState("denied");
        }
        return;
      default:
        // "network" (phone needs internet for speech), "audio-capture" (no
        // microphone / in use by another app), and anything else.
        this.failures++;
        this.setState("error");
    }
  }

  private handleResult(e: RecEvent): void {
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const result = e.results[i];
      if (!result?.isFinal) continue;
      this.failures = 0;
      // Try every guess the recogniser offers until one is a valid call.
      let heard = "";
      let call: Callout | null = null;
      for (let j = 0; j < result.length; j++) {
        const text = (result[j]?.transcript ?? "").trim();
        if (!text) continue;
        if (!heard) heard = text;
        const parsed = parseCallout(text, this.digits());
        if (parsed) {
          heard = text;
          call = parsed;
          break;
        }
      }
      if (!heard) continue;
      this.onHeard(heard, call);
      if (call) this.send(call, heard);
    }
  }

  private send(call: Callout, heard: string): void {
    const key = `${call.target}:${call.damage}`;
    const now = Date.now();
    // Recognisers sometimes report the same words twice; one shout = one call.
    if (now - (this.lastCall.get(key) ?? 0) < SAME_CALL_MS) return;
    this.lastCall.set(key, now);
    for (const [k, t] of this.lastCall) if (now - t > 60_000) this.lastCall.delete(k);

    sendVoiceHit({ target: call.target, damage: call.damage, heard })
      .then((r) => {
        if (r.applied || r.duplicate) toast(`Heard: Player ${r.playerNumber ?? call.target} −${r.damage ?? call.damage} HP`, "info");
      })
      .catch((err) => {
        // Too many calls (429) is the server's runaway guard: stay quiet.
        if (err instanceof VoiceApiError && err.status === 429) return;
        if (now - this.lastErrorToast < ERROR_TOAST_MS) return;
        this.lastErrorToast = now;
        toast(err instanceof Error ? err.message : "Couldn't send the hit call.", "bad");
      });
  }
}

// Listens for hit calls while `enabled` is true (game on + voice rule on +
// this phone's setting on). Mount it once per logged-in phone.
export function useVoiceListener(opts: { enabled: boolean; playerNumberDigits: number }): {
  state: VoiceState;
  lastHeard: string | null;
  requestPermission: () => Promise<void>;
} {
  const [state, setState] = useState<VoiceState>("off");
  const [lastHeard, setLastHeard] = useState<string | null>(null);
  const digitsRef = useRef(opts.playerNumberDigits);
  digitsRef.current = opts.playerNumberDigits;
  const engineRef = useRef<VoiceEngine | null>(null);

  useEffect(() => {
    const engine = new VoiceEngine(
      setState,
      (text, call) =>
        setLastHeard(call ? `“${text}” → Player ${call.target}, ${call.damage} HP` : `“${text}” (not a hit call)`),
      () => digitsRef.current
    );
    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    engineRef.current?.setEnabled(opts.enabled);
  }, [opts.enabled]);

  const requestPermission = useCallback(async () => {
    await engineRef.current?.requestPermission();
  }, []);

  return { state, lastHeard, requestPermission };
}
