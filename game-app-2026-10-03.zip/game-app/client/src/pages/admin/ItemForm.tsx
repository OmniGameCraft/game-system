import { ChangeEvent, FormEvent, useEffect, useRef, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls, TextField } from "../../components/Field";
import { BackButton } from "../../components/BackButton";
import { Badge } from "../../components/Badge";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import { ItemMediaSection } from "./ItemMediaSection";
import { ItemImage } from "../../components/ItemImage";
import {
  createItem,
  getItem,
  Item,
  ItemInput,
  ItemKind,
  KIND_LABEL,
  listItems,
  removeItemImage,
  updateItem,
  uploadItemImage,
} from "../../services/api";
import { resizeImageToDataUrl } from "../../utils/image";

// One form for both "create" (no id) and "edit" (id given).
export function ItemForm({
  id,
  onSaved,
  onBack,
}: {
  id?: number;
  onSaved: (item: Item) => void;
  onBack: () => void;
}) {
  const isEdit = id !== undefined;
  const [item, setItem] = useState<Item | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [maxStack, setMaxStack] = useState("");
  const [categories, setCategories] = useState<string[]>([]);
  const [guns, setGuns] = useState<Item[]>([]);

  // Type, selling and upgrade settings. Numbers are kept as text while typing.
  const [kind, setKind] = useState<ItemKind>("other");
  const [ammoFor, setAmmoFor] = useState("");
  const [perPack, setPerPack] = useState("");
  const [sellable, setSellable] = useState(false);
  const [sellPercent, setSellPercent] = useState("50");
  const [baseMagazine, setBaseMagazine] = useState("");
  const [baseSharpness, setBaseSharpness] = useState("");
  const [baseLength, setBaseLength] = useState("");
  const [upMagazine, setUpMagazine] = useState("");
  const [upDamage, setUpDamage] = useState("");
  const [upSharpness, setUpSharpness] = useState("");
  const [upLength, setUpLength] = useState("");

  // Picture picked on the create screen is uploaded right after the item exists.
  const [pendingImage, setPendingImage] = useState<string | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [imageBusy, setImageBusy] = useState(false);
  const [toggling, setToggling] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Suggest categories the Admin has already used, so "Weapon" and
    // "weapons" don't end up as two different groups by accident.
    listItems()
      .then((all) => {
        const seen = new Set<string>();
        for (const i of all) if (i.category) seen.add(i.category);
        setCategories([...seen].sort((a, b) => a.localeCompare(b)));
        setGuns(all.filter((i) => i.kind === "gun" && i.id !== id));
      })
      .catch(() => {});
    if (id === undefined) return;
    getItem(id)
      .then((i) => {
        setItem(i);
        setName(i.name);
        setCategory(i.category ?? "");
        setDescription(i.description ?? "");
        setMaxStack(i.maxStack === null ? "" : String(i.maxStack));
        const t = (n: number | null) => (n === null ? "" : String(n));
        setKind(i.kind);
        setAmmoFor(t(i.ammoForItemId));
        setPerPack(t(i.ammoPerPack));
        setSellable(i.sellable);
        setSellPercent(String(i.sellPercent));
        setBaseMagazine(t(i.baseMagazine));
        setBaseSharpness(t(i.baseSharpness));
        setBaseLength(t(i.baseLength));
        setUpMagazine(t(i.upgradePrices.magazine));
        setUpDamage(t(i.upgradePrices.damage));
        setUpSharpness(t(i.upgradePrices.sharpness));
        setUpLength(t(i.upgradePrices.length));
      })
      .catch((err) => setLoadError(err instanceof Error ? err.message : "Failed to load item."));
  }, [id]);

  function parseMaxStack(): number | null | Error {
    const t = maxStack.trim();
    if (t === "") return null;
    const n = Number(t);
    if (!Number.isInteger(n) || n < 1) return new Error("Max per player must be a whole number of 1 or more, or empty.");
    return n;
  }

  // Picking a type sets the usual sell-back choice for it (it can still be changed).
  function pickKind(k: ItemKind) {
    setKind(k);
    setSellable(SELLABLE_KINDS.includes(k));
  }

  // Turns the type section into fields for the server, or an error message.
  function ruleFields(): ItemInput | Error {
    const out: ItemInput = { kind, sellable };
    const whole = (text: string, label: string, min: number): number | null | Error => {
      const t = text.trim();
      if (t === "") return null;
      const n = Number(t);
      if (!Number.isInteger(n) || n < min) return new Error(`${label} must be a whole number of ${min} or more, or empty.`);
      return n;
    };
    const pct = Number(sellPercent.trim());
    if (sellPercent.trim() === "" || !Number.isInteger(pct) || pct < 0 || pct > 100)
      return new Error("Sell-back must be a whole percent from 0 to 100.");
    out.sellPercent = pct;
    const checks: Array<[keyof ItemInput, string, string, number]> = [];
    if (kind === "ammo") {
      if (!ammoFor) return new Error("Choose which gun this ammo is for.");
      out.ammoForItemId = Number(ammoFor);
      checks.push(["ammoPerPack", perPack, "Rounds per pack", 1]);
    }
    if (kind === "gun") {
      checks.push(["baseMagazine", baseMagazine, "Starting magazine", 1]);
      checks.push(["upPriceMagazine", upMagazine, "Magazine upgrade price", 0]);
      checks.push(["upPriceDamage", upDamage, "Damage upgrade price", 0]);
    }
    if (kind === "knife") {
      checks.push(["baseSharpness", baseSharpness, "Starting sharpness", 1]);
      checks.push(["baseLength", baseLength, "Starting length", 1]);
      checks.push(["upPriceSharpness", upSharpness, "Sharpness upgrade price", 0]);
      checks.push(["upPriceLength", upLength, "Length upgrade price", 0]);
    }
    for (const [key, text, label, min] of checks) {
      const v = whole(text, label, min);
      if (v instanceof Error) return v;
      (out as Record<string, unknown>)[key] = v;
    }
    if (kind === "ammo" && out.ammoPerPack == null) return new Error("Enter how many rounds come in one pack.");
    return out;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    setError(null);
    setNotice(null);
    const ms = parseMaxStack();
    if (ms instanceof Error) {
      setError(ms.message);
      return;
    }
    const rules = ruleFields();
    if (rules instanceof Error) {
      setError(rules.message);
      return;
    }
    const input = { name, category: category || null, description: description || null, maxStack: ms, ...rules };
    setSaving(true);
    try {
      if (isEdit) {
        const updated = await updateItem(id!, input);
        setItem(updated);
        setNotice("Saved.");
      } else {
        let created = await createItem(input);
        if (pendingImage) {
          try {
            created = await uploadItemImage(created.id, pendingImage);
          } catch {
            // The item exists; the picture can be added again from the edit screen.
          }
        }
        onSaved(created);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save the item.");
    } finally {
      setSaving(false);
    }
  }

  async function handlePickImage(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setError(null);
    setNotice(null);
    setImageBusy(true);
    try {
      const dataUrl = await resizeImageToDataUrl(file);
      if (isEdit) {
        setItem(await uploadItemImage(id!, dataUrl));
      } else {
        setPendingImage(dataUrl);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not use that picture.");
    } finally {
      setImageBusy(false);
    }
  }

  async function handleRemoveImage() {
    setError(null);
    if (!isEdit) {
      setPendingImage(null);
      return;
    }
    setImageBusy(true);
    try {
      setItem(await removeItemImage(id!));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not remove the picture.");
    } finally {
      setImageBusy(false);
    }
  }

  async function handleToggleEnabled() {
    if (!item) return;
    setError(null);
    setNotice(null);
    setToggling(true);
    try {
      setItem(await updateItem(item.id, { enabled: !item.enabled }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not change the item.");
    } finally {
      setToggling(false);
    }
  }

  if (loadError) {
    return (
      <>
        <BackButton label="Items" onClick={onBack} />
        <ErrorBanner message={loadError} />
      </>
    );
  }
  if (isEdit && !item) return <p className="text-ink/60">Loading…</p>;

  const previewUrl = isEdit ? item!.imageUrl : pendingImage;

  return (
    <>
      <BackButton label="Items" onClick={onBack} />
      <ErrorBanner message={error} />
      <Notice message={notice} />

      <Section title="Picture">
        <div className="flex items-center gap-4">
          <ItemImage url={previewUrl} name={name || "?"} size="lg" />
          <div className="flex flex-1 flex-col gap-2">
            <input
              ref={fileInput}
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              className="hidden"
              onChange={handlePickImage}
            />
            <Button type="button" variant="ghost" size="md" loading={imageBusy} onClick={() => fileInput.current?.click()}>
              {previewUrl ? "Change picture" : "Add picture"}
            </Button>
            {previewUrl && !imageBusy && (
              <button type="button" onClick={handleRemoveImage} className="min-h-[2.5rem] text-sm font-bold text-alert">
                Remove picture
              </button>
            )}
          </div>
        </div>
        <p className="text-sm text-ink/55">Optional. PNG, JPG, WEBP or GIF. Transparent backgrounds are kept.</p>
      </Section>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Section title={isEdit ? "Item details" : "New item"}>
          <TextField id="item-name" label="Name" maxLength={60} value={name} onChange={(e) => setName(e.target.value)} required />
          <TextField
            id="item-category"
            label="Category (optional)"
            hint="Groups items, e.g. Weapon, Ammo, Medical."
            list="item-categories"
            maxLength={40}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          />
          <datalist id="item-categories">
            {categories.map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
          <label htmlFor="item-description" className="block">
            <span className="mb-1 block text-base font-semibold text-ink/80">Description (optional)</span>
            <textarea
              id="item-description"
              rows={3}
              maxLength={500}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={inputCls}
            />
          </label>
          <TextField
            id="item-max-stack"
            label="Max per player (optional)"
            hint={
              kind === "ammo"
                ? "Counted in rounds, not packs. Leave empty for no limit."
                : "Leave empty for no limit. Set 1 for “one each”."
            }
            type="number"
            inputMode="numeric"
            min={1}
            step={1}
            value={maxStack}
            onChange={(e) => setMaxStack(e.target.value)}
          />
        </Section>

        <Section title="Type & shop rules">
          <label htmlFor="item-kind" className="block">
            <span className="mb-1 block text-base font-semibold text-ink/75">Type</span>
            <select id="item-kind" value={kind} onChange={(e) => pickKind(e.target.value as ItemKind)} className={inputCls}>
              {KINDS.map((k) => (
                <option key={k} value={k}>
                  {KIND_LABEL[k]}
                </option>
              ))}
            </select>
            <span className="mt-1 block text-sm text-ink/55">{KIND_HINT[kind]}</span>
          </label>

          {kind === "ammo" && (
            <>
              <label htmlFor="item-ammo-for" className="block">
                <span className="mb-1 block text-base font-semibold text-ink/75">Ammo for</span>
                <select id="item-ammo-for" value={ammoFor} onChange={(e) => setAmmoFor(e.target.value)} className={inputCls}>
                  <option value="">Choose a gun…</option>
                  {guns.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
                {guns.length === 0 && (
                  <span className="mt-1 block text-sm text-sun">Make the gun first (type “Gun”), then come back to this.</span>
                )}
              </label>
              <NumberField id="item-per-pack" label="Rounds per pack" value={perPack} onChange={setPerPack} placeholder="e.g. 30" />
              <p className="text-sm text-ink/55">The shop price you set is per pack. Players hold the rounds.</p>
            </>
          )}

          {kind === "gun" && (
            <>
              <NumberField
                id="item-base-mag"
                label="Starting magazine (rounds)"
                value={baseMagazine}
                onChange={setBaseMagazine}
                placeholder="12"
                hint="Size at level 1. Each magazine upgrade adds about 20%."
              />
              <UpgradePrice id="item-up-mag" label="Magazine upgrade" value={upMagazine} onChange={setUpMagazine} />
              <UpgradePrice id="item-up-dmg" label="Damage upgrade" value={upDamage} onChange={setUpDamage} />
              <p className="text-sm text-ink/55">Damage shows as a level only for now. What players spend on it still counts when they sell.</p>
            </>
          )}

          {kind === "knife" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <NumberField id="item-base-sharp" label="Starting sharpness" value={baseSharpness} onChange={setBaseSharpness} placeholder="10" />
                <NumberField id="item-base-len" label="Starting length (cm)" value={baseLength} onChange={setBaseLength} placeholder="20" />
              </div>
              <UpgradePrice id="item-up-sharp" label="Sharpness upgrade" value={upSharpness} onChange={setUpSharpness} />
              <UpgradePrice id="item-up-len" label="Length upgrade" value={upLength} onChange={setUpLength} />
            </>
          )}

          <div className="border-t border-panel-line pt-4">
            <label className="flex min-h-[2.75rem] items-center gap-3">
              <input
                type="checkbox"
                checked={sellable}
                onChange={(e) => setSellable(e.target.checked)}
                className="h-6 w-6 accent-[#F5A524]"
              />
              <span className="text-base font-semibold">Players can sell this back</span>
            </label>
            {sellable && (
              <div className="mt-3">
                <NumberField
                  id="item-sell-pct"
                  label="Sell-back (% of what they paid)"
                  value={sellPercent}
                  onChange={setSellPercent}
                  placeholder="50"
                  hint="Includes upgrades they bought. 50 = half back. Players only see the amount when they choose to sell."
                />
              </div>
            )}
          </div>
        </Section>

        <Button type="submit" loading={saving}>
          {isEdit ? "Save changes" : "Create Item"}
        </Button>
      </form>

      {isEdit && item && <ItemMediaSection item={item} onChange={setItem} />}
      {!isEdit && (
        <p className="rounded-md bg-pine-soft px-4 py-3 text-ink/80">
          After you create the item you can add a 3D model and a sound for it.
        </p>
      )}

      {isEdit && item && (
        <Section title="Availability" tone={item.enabled ? "pine" : "alert"}>
          <div className="flex items-center gap-2">
            <Badge tone={item.enabled ? "good" : "bad"}>{item.enabled ? "Enabled" : "Disabled"}</Badge>
          </div>
          <p className="text-ink/70">
            {item.enabled
              ? "Disabling stops anyone giving or selling this item. Players keep what they already have."
              : "This item can't be given out or bought until you enable it again."}
          </p>
          <Button variant={item.enabled ? "dangerGhost" : "primary"} loading={toggling} onClick={handleToggleEnabled}>
            {item.enabled ? "Disable item" : "Enable item"}
          </Button>
        </Section>
      )}
    </>
  );
}

const KINDS: ItemKind[] = ["gun", "knife", "ammo", "healing", "backpack", "other"];
const SELLABLE_KINDS: ItemKind[] = ["gun", "knife", "ammo", "healing"];
const KIND_HINT: Record<ItemKind, string> = {
  gun: "Can get magazine and damage upgrades in the shop.",
  knife: "Can get sharpness and length upgrades in the shop.",
  ammo: "Sold in packs, held as rounds.",
  healing: "Med kits and herbs. Using them comes in a later update.",
  backpack: "Just an item for now. Extra bag space comes with the inventory update.",
  other: "Anything else.",
};

function NumberField({
  id,
  label,
  value,
  onChange,
  placeholder,
  hint,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  hint?: string;
}) {
  return (
    <TextField
      id={id}
      label={label}
      hint={hint}
      type="number"
      inputMode="numeric"
      min={0}
      step={1}
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

// Base price for level 2; each level after costs double.
function UpgradePrice({ id, label, value, onChange }: { id: string; label: string; value: string; onChange: (v: string) => void }) {
  const base = Number(value);
  const ok = value.trim() !== "" && Number.isInteger(base) && base >= 0;
  return (
    <div>
      <NumberField id={id} label={`${label} price ($)`} value={value} onChange={onChange} placeholder="Not for sale" />
      <span className="mt-1 block text-sm text-ink/55">
        {ok
          ? `Level 2 $${base} · 3 $${base * 2} · 4 $${base * 4} · 5 $${base * 8}`
          : "Empty = players can't buy this upgrade yet. Each level costs double the one before."}
      </span>
    </div>
  );
}
