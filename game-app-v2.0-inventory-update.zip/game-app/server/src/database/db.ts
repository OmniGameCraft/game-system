import { DatabaseSync } from "node:sqlite"; // built into Node 22.13+, nothing to compile
import fs from "fs";
import path from "path";
import { DB_PATH } from "../config";

// Each entry is one schema step, applied once (SQLite's user_version tracks
// how many have run). Never insert seed data here.
const migrations: string[] = [
  // v1 — auth: admins and players in one table, one row per account.
  `CREATE TABLE users (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     role TEXT NOT NULL CHECK (role IN ('admin', 'player')),
     username TEXT NOT NULL UNIQUE,
     display_name TEXT,
     password_hash TEXT NOT NULL,
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );`,
  // v2 — player management: an account can be disabled so it can no longer log in.
  `ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'active'
     CHECK (status IN ('active', 'disabled'));`,
  // v3 — single-active-session enforcement for Admin accounts. Only ever
  // read/written for role='admin'; players never use this column.
  `ALTER TABLE users ADD COLUMN active_session_token TEXT;`,
  // v4 — money. balance lives on the account (meaningful for players only;
  // admin accounts stay at 0). transactions is the audit trail: every add
  // or remove records the balance before and after, and who performed it.
  `ALTER TABLE users ADD COLUMN balance INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0);
   CREATE TABLE transactions (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     type TEXT NOT NULL CHECK (type IN ('ADD', 'REMOVE')),
     amount INTEGER NOT NULL CHECK (amount > 0),
     balance_before INTEGER NOT NULL,
     balance_after INTEGER NOT NULL,
     performed_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE INDEX idx_transactions_player_id ON transactions(player_id);`,
  // v5 — items & inventory. items is the Admin's catalogue (starts empty).
  // inventory holds one row per (player, item) the player actually owns;
  // a row is deleted when its quantity reaches 0, so quantity is always > 0.
  // inventory_log is the audit trail for every Admin give/remove/set,
  // written in the same database transaction as the inventory change.
  `CREATE TABLE items (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     name TEXT NOT NULL UNIQUE COLLATE NOCASE,
     description TEXT,
     category TEXT,
     max_stack INTEGER CHECK (max_stack IS NULL OR max_stack > 0),
     enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
     image_file TEXT,
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE TABLE inventory (
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     quantity INTEGER NOT NULL CHECK (quantity > 0),
     PRIMARY KEY (player_id, item_id)
   );
   CREATE INDEX idx_inventory_item_id ON inventory(item_id);
   CREATE TABLE inventory_log (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     action TEXT NOT NULL CHECK (action IN ('GIVE', 'REMOVE', 'SET')),
     quantity_before INTEGER NOT NULL CHECK (quantity_before >= 0),
     quantity_after INTEGER NOT NULL CHECK (quantity_after >= 0),
     performed_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE INDEX idx_inventory_log_player_id ON inventory_log(player_id);`,
  // v6 — shop.
  // game_state: simple key/value settings the Admin controls. No rows are
  // inserted here: a missing 'shop_open' row simply means the shop is closed.
  // shop_items: one listing per item (price, stock, limits). stock NULL means
  // unlimited; max_per_purchase NULL means no per-purchase limit.
  // transactions and inventory_log are rebuilt (SQLite can't change a CHECK
  // constraint in place) so a purchase can be recorded as type/action
  // 'PURCHASE', with the item and quantity on the money record. Every
  // existing row is copied across unchanged, ids included.
  `CREATE TABLE game_state (
     key TEXT PRIMARY KEY,
     value TEXT NOT NULL
   );
   CREATE TABLE shop_items (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     item_id INTEGER NOT NULL UNIQUE REFERENCES items(id),
     price INTEGER NOT NULL CHECK (price >= 0),
     stock INTEGER CHECK (stock IS NULL OR stock >= 0),
     max_per_purchase INTEGER CHECK (max_per_purchase IS NULL OR max_per_purchase > 0),
     enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );

   CREATE TABLE transactions_v6 (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     type TEXT NOT NULL CHECK (type IN ('ADD', 'REMOVE', 'PURCHASE')),
     amount INTEGER NOT NULL CHECK (amount >= 0),
     balance_before INTEGER NOT NULL,
     balance_after INTEGER NOT NULL,
     performed_by INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER REFERENCES items(id),
     quantity INTEGER CHECK (quantity IS NULL OR quantity > 0),
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     CHECK (type = 'PURCHASE' OR amount > 0),
     CHECK ((type = 'PURCHASE') = (item_id IS NOT NULL AND quantity IS NOT NULL))
   );
   INSERT INTO transactions_v6
     (id, player_id, type, amount, balance_before, balance_after, performed_by, created_at)
     SELECT id, player_id, type, amount, balance_before, balance_after, performed_by, created_at
       FROM transactions;
   DROP TABLE transactions;
   ALTER TABLE transactions_v6 RENAME TO transactions;
   CREATE INDEX idx_transactions_player_id ON transactions(player_id);
   CREATE INDEX idx_transactions_type ON transactions(type);

   CREATE TABLE inventory_log_v6 (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     action TEXT NOT NULL CHECK (action IN ('GIVE', 'REMOVE', 'SET', 'PURCHASE')),
     quantity_before INTEGER NOT NULL CHECK (quantity_before >= 0),
     quantity_after INTEGER NOT NULL CHECK (quantity_after >= 0),
     performed_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   INSERT INTO inventory_log_v6
     SELECT id, player_id, item_id, action, quantity_before, quantity_after, performed_by, created_at
       FROM inventory_log;
   DROP TABLE inventory_log;
   ALTER TABLE inventory_log_v6 RENAME TO inventory_log;
   CREATE INDEX idx_inventory_log_player_id ON inventory_log(player_id);`,
  // v7 — 3D model + sound per item (for the full-screen "use" view in a
  // player's Bag). use_effect says what a tap/shake does there:
  //   none = just show it, shot = fire (recoil + flash), swing = melee swing.
  // model_flip / model_upside_down let the Admin fix a model that faces the
  // wrong way, since every downloaded model is oriented differently.
  `ALTER TABLE items ADD COLUMN model_file TEXT;
   ALTER TABLE items ADD COLUMN sound_file TEXT;
   ALTER TABLE items ADD COLUMN use_effect TEXT NOT NULL DEFAULT 'none'
     CHECK (use_effect IN ('none', 'shot', 'swing'));
   ALTER TABLE items ADD COLUMN model_flip INTEGER NOT NULL DEFAULT 0 CHECK (model_flip IN (0, 1));
   ALTER TABLE items ADD COLUMN model_upside_down INTEGER NOT NULL DEFAULT 0
     CHECK (model_upside_down IN (0, 1));`,
  // v8 — game controls. The game's status lives in game_state (key
  // 'game_status'; no row = not started). game_events keeps a history of
  // status changes and announcements. Starts empty.
  `CREATE TABLE game_events (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     type TEXT NOT NULL CHECK (type IN ('STATUS', 'ANNOUNCEMENT')),
     status TEXT CHECK (status IS NULL OR status IN ('not_started', 'active', 'paused', 'ended')),
     message TEXT,
     player_id INTEGER REFERENCES users(id),
     created_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     CHECK ((type = 'STATUS') = (status IS NOT NULL)),
     CHECK ((type = 'ANNOUNCEMENT') = (message IS NOT NULL))
   );
   CREATE INDEX idx_game_events_player_id ON game_events(player_id);`,
  // v9 — shop update: item types, ammo packs, selling and weapon upgrades.
  // items.kind drives behaviour: gun / knife (upgradable), ammo (sold in
  // packs of ammo_per_pack rounds for one gun), healing, backpack, other.
  // sellable + sell_percent: players may sell it back for sell_percent % of
  // what they spent on it. base_* are level-1 weapon stats; up_price_* are
  // the Admin's base price for each upgrade (NULL = not on sale yet; each
  // further level costs double the one before).
  // inventory.spent: money this player has spent on the units they hold
  // (purchases + upgrades), the basis for the sell price.
  // weapon_upgrades: one row per player/weapon/upgrade once above level 1.
  // transactions + inventory_log are rebuilt to record SALE / UPGRADE / SELL.
  `ALTER TABLE items ADD COLUMN kind TEXT NOT NULL DEFAULT 'other'
     CHECK (kind IN ('gun', 'knife', 'ammo', 'healing', 'backpack', 'other'));
   ALTER TABLE items ADD COLUMN ammo_for_item_id INTEGER REFERENCES items(id);
   ALTER TABLE items ADD COLUMN ammo_per_pack INTEGER CHECK (ammo_per_pack IS NULL OR ammo_per_pack > 0);
   ALTER TABLE items ADD COLUMN sellable INTEGER NOT NULL DEFAULT 0 CHECK (sellable IN (0, 1));
   ALTER TABLE items ADD COLUMN sell_percent INTEGER NOT NULL DEFAULT 50 CHECK (sell_percent BETWEEN 0 AND 100);
   ALTER TABLE items ADD COLUMN base_magazine INTEGER CHECK (base_magazine IS NULL OR base_magazine > 0);
   ALTER TABLE items ADD COLUMN base_sharpness INTEGER CHECK (base_sharpness IS NULL OR base_sharpness > 0);
   ALTER TABLE items ADD COLUMN base_length INTEGER CHECK (base_length IS NULL OR base_length > 0);
   ALTER TABLE items ADD COLUMN up_price_magazine INTEGER CHECK (up_price_magazine IS NULL OR up_price_magazine >= 0);
   ALTER TABLE items ADD COLUMN up_price_damage INTEGER CHECK (up_price_damage IS NULL OR up_price_damage >= 0);
   ALTER TABLE items ADD COLUMN up_price_sharpness INTEGER CHECK (up_price_sharpness IS NULL OR up_price_sharpness >= 0);
   ALTER TABLE items ADD COLUMN up_price_length INTEGER CHECK (up_price_length IS NULL OR up_price_length >= 0);

   ALTER TABLE inventory ADD COLUMN spent INTEGER NOT NULL DEFAULT 0 CHECK (spent >= 0);

   CREATE TABLE weapon_upgrades (
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     track TEXT NOT NULL CHECK (track IN ('magazine', 'damage', 'sharpness', 'length')),
     level INTEGER NOT NULL CHECK (level BETWEEN 2 AND 5),
     PRIMARY KEY (player_id, item_id, track)
   );

   CREATE TABLE transactions_v9 (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     type TEXT NOT NULL CHECK (type IN ('ADD', 'REMOVE', 'PURCHASE', 'SALE', 'UPGRADE')),
     amount INTEGER NOT NULL CHECK (amount >= 0),
     balance_before INTEGER NOT NULL,
     balance_after INTEGER NOT NULL,
     performed_by INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER REFERENCES items(id),
     quantity INTEGER CHECK (quantity IS NULL OR quantity > 0),
     detail TEXT,
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     CHECK (type NOT IN ('ADD', 'REMOVE') OR amount > 0),
     CHECK ((type IN ('PURCHASE', 'SALE', 'UPGRADE')) = (item_id IS NOT NULL)),
     CHECK ((type IN ('PURCHASE', 'SALE')) = (quantity IS NOT NULL))
   );
   INSERT INTO transactions_v9
     (id, player_id, type, amount, balance_before, balance_after, performed_by, item_id, quantity, created_at)
   SELECT id, player_id, type, amount, balance_before, balance_after, performed_by, item_id, quantity, created_at
     FROM transactions;
   DROP TABLE transactions;
   ALTER TABLE transactions_v9 RENAME TO transactions;
   CREATE INDEX idx_transactions_player_id ON transactions(player_id);
   CREATE INDEX idx_transactions_type ON transactions(type);

   CREATE TABLE inventory_log_v9 (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     action TEXT NOT NULL CHECK (action IN ('GIVE', 'REMOVE', 'SET', 'PURCHASE', 'SELL')),
     quantity_before INTEGER NOT NULL CHECK (quantity_before >= 0),
     quantity_after INTEGER NOT NULL CHECK (quantity_after >= 0),
     performed_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   INSERT INTO inventory_log_v9
     SELECT id, player_id, item_id, action, quantity_before, quantity_after, performed_by, created_at
       FROM inventory_log;
   DROP TABLE inventory_log;
   ALTER TABLE inventory_log_v9 RENAME TO inventory_log;
   CREATE INDEX idx_inventory_log_player_id ON inventory_log(player_id);`,
  // v10 — 2.0 "Inventory Update": the attaché case (grid inventory), HP,
  // herb mixing, the drop box, voice hit calls and two new gun upgrades.
  //
  // items: grid_w × grid_h = cells a piece takes in the case; stack_size =
  // units per piece (NULL = default rule, see inventory/grid.ts); heal_amount,
  // max_hp_bonus, full_heal = what "Use" does; herb_code = which herb mix this
  // is (G, R, Y or a mix); base_reload_ms + shake_force = how a gun feels
  // (reload time, how hard to shake to fire); up_price_reload/firerate = the
  // two new upgrade prices; hre = "1 round is worth N handgun rounds" for the
  // Admin's calculator; expand_rows = rows a backpack adds to the case.
  //
  // users: player_number is what referees call out ("three forty" = Player 3
  // loses 40 HP), unique among players. hp NULL = full; max_hp NULL = the
  // game's base HP rule. Existing players are numbered 1, 2, 3… in the order
  // they were created (only the first 99 — numbers stop at 99).
  //
  // Existing guns and knives get their kind's case size (guns 3×2, knives
  // 2×1) so old saves look right straight away; the Admin can change it.
  //
  // inventory_pieces: where each unit sits in a player's case (x/y NULL =
  // the "doesn't fit" tray). dropped_items: the drop box. hp_log: every HP
  // change (hits, heals, deaths) for the Admin's hits feed.
  //
  // weapon_upgrades and inventory_log are rebuilt (SQLite can't change a
  // CHECK constraint in place) for the new upgrade tracks and actions. Every
  // existing row is copied across unchanged.
  `ALTER TABLE items ADD COLUMN grid_w INTEGER NOT NULL DEFAULT 1 CHECK (grid_w BETWEEN 1 AND 10);
   ALTER TABLE items ADD COLUMN grid_h INTEGER NOT NULL DEFAULT 1 CHECK (grid_h BETWEEN 1 AND 10);
   ALTER TABLE items ADD COLUMN stack_size INTEGER CHECK (stack_size IS NULL OR stack_size > 0);
   ALTER TABLE items ADD COLUMN heal_amount INTEGER CHECK (heal_amount IS NULL OR heal_amount >= 0);
   ALTER TABLE items ADD COLUMN max_hp_bonus INTEGER CHECK (max_hp_bonus IS NULL OR max_hp_bonus >= 0);
   ALTER TABLE items ADD COLUMN full_heal INTEGER NOT NULL DEFAULT 0 CHECK (full_heal IN (0, 1));
   ALTER TABLE items ADD COLUMN herb_code TEXT
     CHECK (herb_code IS NULL OR herb_code IN ('G', 'R', 'Y', 'GG', 'GR', 'GY', 'GRY', 'GGY'));
   ALTER TABLE items ADD COLUMN base_reload_ms INTEGER
     CHECK (base_reload_ms IS NULL OR base_reload_ms BETWEEN 200 AND 10000);
   ALTER TABLE items ADD COLUMN shake_force INTEGER CHECK (shake_force IS NULL OR shake_force BETWEEN 1 AND 10);
   ALTER TABLE items ADD COLUMN up_price_reload INTEGER CHECK (up_price_reload IS NULL OR up_price_reload >= 0);
   ALTER TABLE items ADD COLUMN up_price_firerate INTEGER CHECK (up_price_firerate IS NULL OR up_price_firerate >= 0);
   ALTER TABLE items ADD COLUMN hre REAL CHECK (hre IS NULL OR hre > 0);
   ALTER TABLE items ADD COLUMN expand_rows INTEGER CHECK (expand_rows IS NULL OR expand_rows BETWEEN 1 AND 5);
   UPDATE items SET grid_w = 3, grid_h = 2 WHERE kind = 'gun';
   UPDATE items SET grid_w = 2, grid_h = 1 WHERE kind = 'knife';

   ALTER TABLE users ADD COLUMN player_number INTEGER CHECK (player_number IS NULL OR player_number BETWEEN 1 AND 99);
   CREATE UNIQUE INDEX idx_users_player_number ON users(player_number) WHERE player_number IS NOT NULL;
   ALTER TABLE users ADD COLUMN hp INTEGER CHECK (hp IS NULL OR hp >= 0);
   ALTER TABLE users ADD COLUMN max_hp INTEGER CHECK (max_hp IS NULL OR max_hp > 0);
   ALTER TABLE users ADD COLUMN dead INTEGER NOT NULL DEFAULT 0 CHECK (dead IN (0, 1));
   UPDATE users
      SET player_number = (SELECT COUNT(*) FROM users p WHERE p.role = 'player' AND p.id <= users.id)
    WHERE role = 'player'
      AND (SELECT COUNT(*) FROM users p WHERE p.role = 'player' AND p.id <= users.id) <= 99;

   CREATE TABLE inventory_pieces (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     x INTEGER,
     y INTEGER,
     rotated INTEGER NOT NULL DEFAULT 0 CHECK (rotated IN (0, 1)),
     quantity INTEGER NOT NULL CHECK (quantity > 0),
     loaded INTEGER NOT NULL DEFAULT 0 CHECK (loaded >= 0),
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     CHECK ((x IS NULL) = (y IS NULL))
   );
   CREATE INDEX idx_pieces_player ON inventory_pieces(player_id);

   CREATE TABLE dropped_items (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     item_id INTEGER NOT NULL REFERENCES items(id),
     quantity INTEGER NOT NULL CHECK (quantity > 0),
     loaded INTEGER NOT NULL DEFAULT 0 CHECK (loaded >= 0),
     spent INTEGER NOT NULL DEFAULT 0 CHECK (spent >= 0),
     upgrades TEXT,
     owner_id INTEGER NOT NULL REFERENCES users(id),
     dropped_by INTEGER NOT NULL REFERENCES users(id),
     reason TEXT NOT NULL CHECK (reason IN ('DROP', 'DEATH')),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );

   CREATE TABLE hp_log (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     kind TEXT NOT NULL CHECK (kind IN ('HIT', 'HEAL', 'MAX_UP', 'FULL', 'SET', 'REVIVE', 'DEATH', 'RESET')),
     amount INTEGER NOT NULL DEFAULT 0,
     hp_before INTEGER NOT NULL,
     hp_after INTEGER NOT NULL,
     max_before INTEGER NOT NULL,
     max_after INTEGER NOT NULL,
     source TEXT,
     heard_by INTEGER,
     performed_by INTEGER REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE INDEX idx_hp_log_player ON hp_log(player_id);

   CREATE TABLE weapon_upgrades_v10 (
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     track TEXT NOT NULL
       CHECK (track IN ('magazine', 'damage', 'reload', 'firerate', 'sharpness', 'length')),
     level INTEGER NOT NULL CHECK (level BETWEEN 2 AND 5),
     PRIMARY KEY (player_id, item_id, track)
   );
   INSERT INTO weapon_upgrades_v10 (player_id, item_id, track, level)
     SELECT player_id, item_id, track, level FROM weapon_upgrades;
   DROP TABLE weapon_upgrades;
   ALTER TABLE weapon_upgrades_v10 RENAME TO weapon_upgrades;

   CREATE TABLE inventory_log_v10 (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     player_id INTEGER NOT NULL REFERENCES users(id),
     item_id INTEGER NOT NULL REFERENCES items(id),
     action TEXT NOT NULL CHECK (action IN ('GIVE', 'REMOVE', 'SET', 'PURCHASE', 'SELL',
       'MIX', 'USE', 'DROP', 'PICKUP', 'RETURN', 'FIRE', 'RELOAD', 'DEATH', 'EXPAND')),
     quantity_before INTEGER NOT NULL CHECK (quantity_before >= 0),
     quantity_after INTEGER NOT NULL CHECK (quantity_after >= 0),
     performed_by INTEGER NOT NULL REFERENCES users(id),
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   INSERT INTO inventory_log_v10
     (id, player_id, item_id, action, quantity_before, quantity_after, performed_by, created_at)
     SELECT id, player_id, item_id, action, quantity_before, quantity_after, performed_by, created_at
       FROM inventory_log;
   DROP TABLE inventory_log;
   ALTER TABLE inventory_log_v10 RENAME TO inventory_log;
   CREATE INDEX idx_inventory_log_player_id ON inventory_log(player_id);`,
];

// Runs `fn` as ONE all-or-nothing step: if it throws, every write it made is
// undone. Uses a SQLite savepoint, so it works both on its own (then it is
// a normal BEGIN…COMMIT) and inside a transaction someone else already
// opened (then it simply joins it, and only that outer COMMIT makes the
// changes permanent). That lets small building blocks — "take HP", "drop
// everything on death" — be safe to call from anywhere without a "cannot
// start a transaction within a transaction" error.
// Everything here is synchronous, so no other request can run in between.
let savepointCounter = 0;
export function transaction<T>(db: DatabaseSync, fn: () => T): T {
  const name = `sp_${++savepointCounter}`;
  db.exec(`SAVEPOINT ${name}`);
  try {
    const result = fn();
    db.exec(`RELEASE ${name}`);
    return result;
  } catch (err) {
    try {
      db.exec(`ROLLBACK TO ${name}`);
      db.exec(`RELEASE ${name}`);
    } catch {
      // SQLite already rolled the whole transaction back on its own (rare,
      // e.g. disk full) — nothing left to undo.
    }
    throw err;
  }
}

export function openDatabase(): DatabaseSync {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec("PRAGMA journal_mode = WAL");
  db.exec("PRAGMA foreign_keys = ON");

  const row = db.prepare("PRAGMA user_version").get() as { user_version: number };
  for (let v = row.user_version; v < migrations.length; v++) {
    db.exec("BEGIN");
    try {
      db.exec(migrations[v]);
      db.exec(`PRAGMA user_version = ${v + 1}`);
      db.exec("COMMIT");
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  }
  return db;
}
