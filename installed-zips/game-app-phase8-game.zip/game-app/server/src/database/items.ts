import { DatabaseSync } from "node:sqlite";

export interface Item {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  max_stack: number | null;
  enabled: number; // SQLite has no boolean: 1 = enabled, 0 = disabled
  image_file: string | null;
  model_file: string | null;
  sound_file: string | null;
  use_effect: UseEffect;
  model_flip: number;
  model_upside_down: number;
  created_at: string;
}

export type UseEffect = "none" | "shot" | "swing";

export interface PublicItem {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  maxStack: number | null;
  enabled: boolean;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  createdAt: string;
}

export function imageUrlFor(file: string | null): string | null {
  return file ? `/media/items/${file}` : null;
}

export function toPublicItem(i: Item): PublicItem {
  return {
    id: i.id,
    name: i.name,
    description: i.description,
    category: i.category,
    maxStack: i.max_stack,
    enabled: i.enabled === 1,
    imageUrl: imageUrlFor(i.image_file),
    modelUrl: imageUrlFor(i.model_file),
    soundUrl: imageUrlFor(i.sound_file),
    useEffect: i.use_effect,
    modelFlip: i.model_flip === 1,
    modelUpsideDown: i.model_upside_down === 1,
    createdAt: i.created_at,
  };
}

export function listItems(db: DatabaseSync): Item[] {
  return db.prepare("SELECT * FROM items ORDER BY name COLLATE NOCASE").all() as unknown as Item[];
}

export function findItemById(db: DatabaseSync, id: number): Item | undefined {
  return db.prepare("SELECT * FROM items WHERE id = ?").get(id) as Item | undefined;
}

// The name column is COLLATE NOCASE, so "Rifle" and "rifle" count as the same.
export function findItemByName(db: DatabaseSync, name: string): Item | undefined {
  return db.prepare("SELECT * FROM items WHERE name = ?").get(name) as Item | undefined;
}

export interface ItemFields {
  name?: string;
  description?: string | null;
  category?: string | null;
  maxStack?: number | null;
  enabled?: boolean;
  useEffect?: UseEffect;
  modelFlip?: boolean;
  modelUpsideDown?: boolean;
}

export function createItem(
  db: DatabaseSync,
  f: {
    name: string;
    description: string | null;
    category: string | null;
    maxStack: number | null;
    enabled?: boolean;
    useEffect?: UseEffect;
    modelFlip?: boolean;
    modelUpsideDown?: boolean;
  }
): Item {
  const result = db
    .prepare(
      "INSERT INTO items (name, description, category, max_stack, enabled, use_effect, model_flip, model_upside_down) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    )
    .run(
      f.name,
      f.description,
      f.category,
      f.maxStack,
      f.enabled === false ? 0 : 1,
      f.useEffect ?? "none",
      f.modelFlip ? 1 : 0,
      f.modelUpsideDown ? 1 : 0
    );
  return findItemById(db, Number(result.lastInsertRowid))!;
}

export function updateItem(db: DatabaseSync, id: number, f: ItemFields): Item {
  if (f.name !== undefined) db.prepare("UPDATE items SET name = ? WHERE id = ?").run(f.name, id);
  if (f.description !== undefined)
    db.prepare("UPDATE items SET description = ? WHERE id = ?").run(f.description, id);
  if (f.category !== undefined)
    db.prepare("UPDATE items SET category = ? WHERE id = ?").run(f.category, id);
  if (f.maxStack !== undefined)
    db.prepare("UPDATE items SET max_stack = ? WHERE id = ?").run(f.maxStack, id);
  if (f.enabled !== undefined)
    db.prepare("UPDATE items SET enabled = ? WHERE id = ?").run(f.enabled ? 1 : 0, id);
  if (f.useEffect !== undefined)
    db.prepare("UPDATE items SET use_effect = ? WHERE id = ?").run(f.useEffect, id);
  if (f.modelFlip !== undefined)
    db.prepare("UPDATE items SET model_flip = ? WHERE id = ?").run(f.modelFlip ? 1 : 0, id);
  if (f.modelUpsideDown !== undefined)
    db.prepare("UPDATE items SET model_upside_down = ? WHERE id = ?").run(f.modelUpsideDown ? 1 : 0, id);
  return findItemById(db, id)!;
}

export function setItemImage(db: DatabaseSync, id: number, file: string | null): void {
  db.prepare("UPDATE items SET image_file = ? WHERE id = ?").run(file, id);
}

export function setItemFile(
  db: DatabaseSync,
  id: number,
  column: "model_file" | "sound_file",
  file: string | null
): void {
  // column is one of two fixed names (never user input), so building the
  // statement with it is safe.
  db.prepare(`UPDATE items SET ${column} = ? WHERE id = ?`).run(file, id);
}
