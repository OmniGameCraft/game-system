import { DatabaseSync } from "node:sqlite";
import { transaction } from "./db";
import type { Item } from "./items";
import { GameRules, getRules } from "./settings";

// Player HP. Each player has hp and max_hp on their account row:
//   max_hp NULL = the game's base HP rule (100 unless the Admin changed it)
//   hp NULL     = full (equal to max HP) — so a full player stays full if
//                 the Admin later changes the base HP
//   dead = 1    = at 0 HP; can't fire, heal, mix, pick up or buy until the
//                 Admin revives them. Their money stays.
// Max HP can never go above the maxHpCap rule.
//
// Every change writes an hp_log row (the Admin's hits feed / history) and
// happens inside ONE database transaction together with whatever caused it.
// The apply* functions assume the caller already opened one; the short
// wrappers (damage, heal, …) open their own — and because they use a
// savepoint (see transaction() in db.ts) they also work inside one.
//
// These functions don't send live notices: the route that called them does,
// after the change is saved, with live.hpChanged(playerId, change).

export interface HpState {
  hp: number;
  maxHp: number;
  dead: boolean;
}

export type HpLogKind = "HIT" | "HEAL" | "MAX_UP" | "FULL" | "SET" | "REVIVE" | "DEATH" | "RESET";

// What one HP change did. Send { hp, maxHp, dead, delta, source } to the
// phone with live.hpChanged.
export interface HpChange extends HpState {
  playerId: number;
  delta: number; // HP gained (+) or lost (−)
  maxDelta: number; // max HP gained (+) or lost (−)
  source: string | null; // 'voice', 'admin', 'Green Herb', …
  died: boolean; // this change took them to 0 HP
  dropped: boolean; // …and their items went to the drop box (send live.dropsChanged)
  logId: number; // the hp_log row written for this change
}

// A rule the request broke. The message is written for whoever asked (the
// player or the Admin) and is safe to show as-is.
export class HpError extends Error {
  constructor(message: string, public code: "NOT_FOUND" | "RULE" = "RULE") {
    super(message);
  }
}

type HpRules = Pick<GameRules, "baseHp" | "maxHpCap">;

interface HpRow {
  id: number;
  role: string;
  hp: number | null;
  max_hp: number | null;
  dead: number;
}

// Turns the stored columns into the numbers everyone sees.
export function resolveHp(row: { hp: number | null; max_hp: number | null; dead: number }, rules: HpRules): HpState {
  const maxHp = Math.max(1, Math.min(rules.maxHpCap, row.max_hp ?? rules.baseHp));
  const dead = row.dead === 1;
  const hp = dead ? 0 : Math.max(0, Math.min(maxHp, row.hp ?? maxHp));
  return { hp, maxHp, dead };
}

function readRow(db: DatabaseSync, playerId: number): HpRow {
  const row = db.prepare("SELECT id, role, hp, max_hp, dead FROM users WHERE id = ?").get(playerId) as
    | HpRow
    | undefined;
  if (!row || row.role !== "player") throw new HpError("Player not found.", "NOT_FOUND");
  return row;
}

export function getHp(db: DatabaseSync, playerId: number): HpState {
  return resolveHp(readRow(db, playerId), getRules(db));
}

export interface PlayerHp extends HpState {
  playerId: number;
  playerNumber: number | null;
  name: string;
  active: boolean; // account not disabled
}

// Every player's HP (Admin screens, voice calls).
export function listHp(db: DatabaseSync): PlayerHp[] {
  const rules = getRules(db);
  const rows = db
    .prepare(
      `SELECT id, role, hp, max_hp, dead, player_number, status, COALESCE(display_name, username) AS name
         FROM users WHERE role = 'player' ORDER BY player_number IS NULL, player_number, id`
    )
    .all() as unknown as Array<HpRow & { player_number: number | null; status: string; name: string }>;
  return rows.map((r) => ({
    playerId: r.id,
    playerNumber: r.player_number,
    name: r.name,
    active: r.status === "active",
    ...resolveHp(r, rules),
  }));
}

// Saves a new state. Full + alive is stored as NULL ("full") and a max equal
// to the base HP as NULL ("base"), so both keep following the rules.
function write(db: DatabaseSync, playerId: number, next: HpState, rules: HpRules): void {
  const hp = next.dead ? 0 : next.hp >= next.maxHp ? null : next.hp;
  const maxHp = next.maxHp === rules.baseHp ? null : next.maxHp;
  db.prepare("UPDATE users SET hp = ?, max_hp = ?, dead = ? WHERE id = ?").run(hp, maxHp, next.dead ? 1 : 0, playerId);
}

interface LogOpts {
  source?: string | null;
  heardBy?: number | null;
  performedBy?: number | null;
}

function log(
  db: DatabaseSync,
  playerId: number,
  kind: HpLogKind,
  amount: number,
  before: HpState,
  after: HpState,
  opts: LogOpts
): number {
  const r = db
    .prepare(
      `INSERT INTO hp_log
         (player_id, kind, amount, hp_before, hp_after, max_before, max_after, source, heard_by, performed_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      playerId,
      kind,
      amount,
      before.hp,
      after.hp,
      before.maxHp,
      after.maxHp,
      opts.source ?? null,
      opts.heardBy ?? null,
      opts.performedBy ?? null
    );
  return Number(r.lastInsertRowid);
}

function change(
  playerId: number,
  before: HpState,
  after: HpState,
  source: string | null | undefined,
  logId: number,
  died = false,
  dropped = false
): HpChange {
  return {
    playerId,
    ...after,
    delta: after.hp - before.hp,
    maxDelta: after.maxHp - before.maxHp,
    source: source ?? null,
    died,
    dropped,
    logId,
  };
}

// ---- Death -----------------------------------------------------------------

// What happens to a player's things when they die. The case code registers
// drops.dropAllOnDeath here (this file can't import it: the case code
// imports this file). It runs inside the same transaction as the hit, and
// only while the deathDrops rule is on.
export type DeathHandler = (db: DatabaseSync, playerId: number) => void;
let deathHandler: DeathHandler | null = null;

export function setDeathHandler(fn: DeathHandler | null): void {
  deathHandler = fn;
}

// Marks the death in the log and empties their case into the drop box.
// Returns whether things were dropped.
function onDeath(db: DatabaseSync, playerId: number, state: HpState, opts: LogOpts): boolean {
  log(db, playerId, "DEATH", 0, state, state, opts);
  if (getRules(db).deathDrops && deathHandler) {
    deathHandler(db, playerId);
    return true;
  }
  return false;
}

// ---- Damage ------------------------------------------------------------------

export interface DamageOpts extends LogOpts {
  admin?: boolean; // word errors for the Admin instead of a player
}

// Takes `amount` HP. Reaching 0 = dead (+ drop box, see onDeath).
export function applyDamage(db: DatabaseSync, playerId: number, amount: number, opts: DamageOpts = {}): HpChange {
  if (!Number.isInteger(amount) || amount < 1) throw new HpError("Damage must be a whole number of 1 or more.");
  const rules = getRules(db);
  const before = resolveHp(readRow(db, playerId), rules);
  if (before.dead) throw new HpError(opts.admin ? "This player is already down." : "That player is already down.");
  const hp = Math.max(0, before.hp - amount);
  const after: HpState = { hp, maxHp: before.maxHp, dead: hp === 0 };
  write(db, playerId, after, rules);
  const logId = log(db, playerId, "HIT", amount, before, after, opts);
  const dropped = after.dead ? onDeath(db, playerId, after, opts) : false;
  return change(playerId, before, after, opts.source, logId, after.dead, dropped);
}

export function damage(db: DatabaseSync, playerId: number, amount: number, opts: DamageOpts = {}): HpChange {
  return transaction(db, () => applyDamage(db, playerId, amount, opts));
}

// After the voice de-dup hears the same call on more phones.
export function setHeardBy(db: DatabaseSync, logId: number, heardBy: number): void {
  db.prepare("UPDATE hp_log SET heard_by = ? WHERE id = ?").run(heardBy, logId);
}

// ---- Healing -----------------------------------------------------------------

export interface HealOpts extends LogOpts {
  heal?: number; // HP to add
  maxBonus?: number; // max HP to add (the new capacity is filled too)
  full?: boolean; // restore all HP
  admin?: boolean;
}

// What "Use" on an item does, or null if it does nothing on its own (e.g. a
// Red or Yellow Herb, which must be mixed with a Green Herb first).
export function healEffectOf(item: Pick<Item, "heal_amount" | "max_hp_bonus" | "full_heal">): {
  heal: number;
  maxBonus: number;
  full: boolean;
} | null {
  const heal = Math.max(0, item.heal_amount ?? 0);
  const maxBonus = Math.max(0, item.max_hp_bonus ?? 0);
  const full = item.full_heal === 1;
  return heal > 0 || maxBonus > 0 || full ? { heal, maxBonus, full } : null;
}

// Effects in order: max HP grows by maxBonus (never above the cap); then HP
// becomes full (full heal) or grows by heal + maxBonus (so the new capacity
// is filled), never above max HP.
export function applyHealing(db: DatabaseSync, playerId: number, opts: HealOpts): HpChange {
  const heal = Math.max(0, Math.floor(opts.heal ?? 0));
  const bonus = Math.max(0, Math.floor(opts.maxBonus ?? 0));
  const full = opts.full === true;
  const rules = getRules(db);
  const before = resolveHp(readRow(db, playerId), rules);
  if (before.dead) {
    throw new HpError(opts.admin ? "This player is down. Revive them first." : "You're down. Ask the Admin to revive you.");
  }
  const maxHp = Math.min(rules.maxHpCap, before.maxHp + bonus);
  const hp = full ? maxHp : Math.min(maxHp, before.hp + heal + bonus);
  if (hp === before.hp && maxHp === before.maxHp) {
    const who = opts.admin ? "This player is" : "You're";
    throw new HpError(
      bonus > 0 && before.maxHp >= rules.maxHpCap
        ? `${who} already at full health, and max HP is at the limit (${rules.maxHpCap}).`
        : `${who} already at full health.`
    );
  }
  const after: HpState = { hp, maxHp, dead: false };
  const kind: HpLogKind = full ? "FULL" : maxHp > before.maxHp ? "MAX_UP" : "HEAL";
  write(db, playerId, after, rules);
  const logId = log(db, playerId, kind, kind === "MAX_UP" ? maxHp - before.maxHp : hp - before.hp, before, after, opts);
  return change(playerId, before, after, opts.source, logId);
}

export function heal(db: DatabaseSync, playerId: number, opts: HealOpts): HpChange {
  return transaction(db, () => applyHealing(db, playerId, opts));
}

// ---- Admin controls (player page › HP) ------------------------------------------

// Sets HP to an exact number. 0 = the player dies (drops included); more
// than 0 on a player who is down brings them back with that HP.
export function adminSetHp(db: DatabaseSync, playerId: number, hp: number, adminId: number): HpChange {
  return transaction(db, () => {
    const rules = getRules(db);
    const before = resolveHp(readRow(db, playerId), rules);
    if (!Number.isInteger(hp) || hp < 0 || hp > before.maxHp) {
      throw new HpError(`HP must be a whole number from 0 to ${before.maxHp} (this player's max HP).`);
    }
    if (hp === 0 && before.dead) throw new HpError("This player is already down.");
    if (hp === before.hp && !before.dead) throw new HpError(`This player already has ${hp} HP.`);
    const after: HpState = { hp, maxHp: before.maxHp, dead: hp === 0 };
    const opts: LogOpts = { source: "admin", performedBy: adminId };
    write(db, playerId, after, rules);
    const logId = log(db, playerId, "SET", hp, before, after, opts);
    const dropped = after.dead ? onDeath(db, playerId, after, opts) : false;
    return change(playerId, before, after, opts.source, logId, after.dead, dropped);
  });
}

// Sets max HP (1 up to the cap). HP stays as it is, or drops to the new max.
export function adminSetMax(db: DatabaseSync, playerId: number, maxHp: number, adminId: number): HpChange {
  return transaction(db, () => {
    const rules = getRules(db);
    const before = resolveHp(readRow(db, playerId), rules);
    if (!Number.isInteger(maxHp) || maxHp < 1 || maxHp > rules.maxHpCap) {
      throw new HpError(`Max HP must be a whole number from 1 to ${rules.maxHpCap} (the max HP cap rule).`);
    }
    if (maxHp === before.maxHp) throw new HpError(`Max HP is already ${maxHp}.`);
    const after: HpState = { hp: before.dead ? 0 : Math.min(before.hp, maxHp), maxHp, dead: before.dead };
    const opts: LogOpts = { source: "admin", performedBy: adminId };
    write(db, playerId, after, rules);
    const logId = log(db, playerId, "SET", maxHp, before, after, opts);
    return change(playerId, before, after, opts.source, logId);
  });
}

// Back in the game at full HP. (Their dropped things stay in the drop box.)
export function revive(db: DatabaseSync, playerId: number, adminId: number): HpChange {
  return transaction(db, () => {
    const rules = getRules(db);
    const before = resolveHp(readRow(db, playerId), rules);
    if (!before.dead && before.hp === before.maxHp) throw new HpError("This player is already up and at full health.");
    const after: HpState = { hp: before.maxHp, maxHp: before.maxHp, dead: false };
    const opts: LogOpts = { source: "admin", performedBy: adminId };
    write(db, playerId, after, rules);
    const logId = log(db, playerId, "REVIVE", after.hp - before.hp, before, after, opts);
    return change(playerId, before, after, opts.source, logId);
  });
}

// ---- Everyone at once ---------------------------------------------------------------

// New round: everyone back to the base HP and alive. (resetRound also
// empties hp_log, so nothing is logged here.) Caller's transaction.
export function resetAllHp(db: DatabaseSync): void {
  db.prepare("UPDATE users SET hp = NULL, max_hp = NULL, dead = 0 WHERE role = 'player'").run();
}

// Game starting: everyone alive at full HP (a max HP the Admin set by hand
// is kept). Logs a RESET row for each player that actually changed and
// returns how many that was. Caller's transaction (or its own).
export function fullHealAll(db: DatabaseSync, opts: LogOpts = {}): number {
  return transaction(db, () => {
    const rules = getRules(db);
    const rows = db
      .prepare("SELECT id, role, hp, max_hp, dead FROM users WHERE role = 'player'")
      .all() as unknown as HpRow[];
    let changed = 0;
    for (const row of rows) {
      const before = resolveHp(row, rules);
      if (!before.dead && before.hp === before.maxHp) continue;
      const after: HpState = { hp: before.maxHp, maxHp: before.maxHp, dead: false };
      write(db, row.id, after, rules);
      log(db, row.id, "RESET", after.hp - before.hp, before, after, opts);
      changed++;
    }
    return changed;
  });
}

// ---- History ---------------------------------------------------------------------

export interface HpLogEntry {
  id: number;
  playerId: number;
  playerNumber: number | null;
  playerName: string;
  kind: HpLogKind;
  amount: number;
  hpBefore: number;
  hpAfter: number;
  maxBefore: number;
  maxAfter: number;
  source: string | null;
  heardBy: number | null;
  performedBy: number | null;
  performedByName: string | null;
  createdAt: string;
}

// Newest first. Pass playerId for one player's history, kinds to filter
// (e.g. ['HIT', 'DEATH'] for the hits feed).
export function listHpLog(
  db: DatabaseSync,
  opts: { limit?: number; playerId?: number; kinds?: HpLogKind[] } = {}
): HpLogEntry[] {
  const where: string[] = [];
  const args: Array<number | string> = [];
  if (opts.playerId !== undefined) {
    where.push("l.player_id = ?");
    args.push(opts.playerId);
  }
  if (opts.kinds && opts.kinds.length > 0) {
    where.push(`l.kind IN (${opts.kinds.map(() => "?").join(", ")})`);
    args.push(...opts.kinds);
  }
  const limit = Math.max(1, Math.min(500, Math.floor(opts.limit ?? 50)));
  const rows = db
    .prepare(
      `SELECT l.*, u.player_number, COALESCE(u.display_name, u.username) AS player_name,
              COALESCE(p.display_name, p.username) AS performer_name
         FROM hp_log l
         JOIN users u ON u.id = l.player_id
         LEFT JOIN users p ON p.id = l.performed_by
        ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
        ORDER BY l.id DESC LIMIT ?`
    )
    .all(...args, limit) as unknown as Array<{
    id: number;
    player_id: number;
    player_number: number | null;
    player_name: string;
    kind: HpLogKind;
    amount: number;
    hp_before: number;
    hp_after: number;
    max_before: number;
    max_after: number;
    source: string | null;
    heard_by: number | null;
    performed_by: number | null;
    performer_name: string | null;
    created_at: string;
  }>;
  return rows.map((r) => ({
    id: r.id,
    playerId: r.player_id,
    playerNumber: r.player_number,
    playerName: r.player_name,
    kind: r.kind,
    amount: r.amount,
    hpBefore: r.hp_before,
    hpAfter: r.hp_after,
    maxBefore: r.max_before,
    maxAfter: r.max_after,
    source: r.source,
    heardBy: r.heard_by,
    performedBy: r.performed_by,
    performedByName: r.performer_name,
    createdAt: r.created_at,
  }));
}
