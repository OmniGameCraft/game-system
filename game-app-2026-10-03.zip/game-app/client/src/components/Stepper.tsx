import { Icon } from "./Icon";

// [-] 3 [+] with big touch targets.
export function Stepper({
  value,
  onChange,
  min = 1,
  max,
  label,
}: {
  value: number;
  onChange: (n: number) => void;
  min?: number;
  max?: number;
  label: string;
}) {
  const atMin = value <= min;
  const atMax = max !== undefined && value >= max;
  const btn =
    "flex h-12 w-12 shrink-0 items-center justify-center rounded-sm border-2 border-panel-line bg-panel-raised text-pine active:bg-pine-soft disabled:opacity-30";
  return (
    <div className="flex items-center gap-2" role="group" aria-label={label}>
      <button type="button" className={btn} disabled={atMin} onClick={() => onChange(value - 1)} aria-label="Less">
        <Icon name="minus" />
      </button>
      <span className="min-w-[3rem] text-center font-display text-3xl font-bold tabular-nums" aria-live="polite">
        {value}
      </span>
      <button type="button" className={btn} disabled={atMax} onClick={() => onChange(value + 1)} aria-label="More">
        <Icon name="plus" />
      </button>
    </div>
  );
}
