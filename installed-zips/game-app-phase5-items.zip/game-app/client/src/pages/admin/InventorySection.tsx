import { useEffect, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { ItemImage } from "../../components/ItemImage";
import {
  AdminInventory,
  changePlayerInventory,
  getPlayerInventory,
  InventoryAction,
  InventoryLogEntry,
  Item,
  listItems,
} from "../../services/api";
import { formatDateTime } from "../../utils/format";

function describeLog(l: InventoryLogEntry): { text: string; up: boolean } {
  const diff = l.quantityAfter - l.quantityBefore;
  const up = diff > 0;
  if (l.action === "SET") return { text: `${l.itemName} set to ${l.quantityAfter}`, up };
  return { text: `${up ? "+" : "−"}${Math.abs(diff)} ${l.itemName}`, up };
}

export function InventorySection({ playerId }: { playerId: number }) {
  const [data, setData] = useState<AdminInventory | null>(null);
  const [items, setItems] = useState<Item[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [itemId, setItemId] = useState<string>("");
  const [quantity, setQuantity] = useState("1");
  const [pending, setPending] = useState<InventoryAction | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showLog, setShowLog] = useState(false);

  useEffect(() => {
    Promise.all([getPlayerInventory(playerId), listItems()])
      .then(([inv, all]) => {
        setData(inv);
        setItems(all);
      })
      .catch((err) => setLoadError(err instanceof Error ? err.message : "Failed to load inventory."));
  }, [playerId]);

  async function handleChange(action: InventoryAction) {
    setError(null);
    const id = Number(itemId);
    if (!id) {
      setError("Choose an item first.");
      return;
    }
    const q = Number(quantity);
    const min = action === "SET" ? 0 : 1;
    if (!Number.isInteger(q) || q < min) {
      setError(action === "SET" ? "Enter a whole number, 0 or more." : "Enter a whole number greater than 0.");
      return;
    }
    setPending(action);
    try {
      setData(await changePlayerInventory(playerId, { itemId: id, action, quantity: q }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update the inventory.");
    } finally {
      setPending(null);
    }
  }

  const selected = items?.find((i) => i.id === Number(itemId));
  const owned = data?.inventory.find((e) => e.itemId === Number(itemId));

  return (
    <div className="flex flex-col gap-4 rounded-2xl border-2 border-ink/15 bg-white p-4">
      <h3 className="text-xl font-bold text-pine">Inventory</h3>
      <ErrorBanner message={loadError} />
      {!data && !loadError && <p className="text-ink/60">Loading…</p>}

      {data && data.inventory.length === 0 && <p className="text-ink/60">This player has no items.</p>}
      {data && data.inventory.length > 0 && (
        <ul className="flex flex-col gap-2">
          {data.inventory.map((e) => (
            <li key={e.itemId}>
              <button
                type="button"
                onClick={() => setItemId(String(e.itemId))}
                className={`flex w-full items-center gap-3 rounded-xl border-2 p-2 text-left ${
                  String(e.itemId) === itemId ? "border-pine" : "border-ink/10"
                }`}
              >
                <ItemImage url={e.imageUrl} name={e.name} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{e.name}</p>
                  {e.enabled === false && <p className="text-xs font-medium text-alert">Item disabled</p>}
                </div>
                <span className="text-xl font-extrabold text-pine">×{e.quantity}</span>
              </button>
            </li>
          ))}
        </ul>
      )}

      {items && items.length === 0 && (
        <p className="rounded-xl bg-pine-soft px-4 py-3 text-ink/80">
          Create items in the Items tab first, then you can give them to players.
        </p>
      )}

      {items && items.length > 0 && (
        <div className="flex flex-col gap-3 border-t-2 border-ink/10 pt-4">
          <ErrorBanner message={error} />
          <label htmlFor="inv-item" className="block">
            <span className="mb-1 block text-base font-medium text-ink/80">Item</span>
            <select
              id="inv-item"
              value={itemId}
              onChange={(e) => setItemId(e.target.value)}
              className="w-full rounded-xl border-2 border-ink/15 bg-white px-4 py-3 text-lg outline-none focus:border-pine"
            >
              <option value="">Choose an item…</option>
              {items.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name}
                  {!i.enabled ? " (disabled)" : ""}
                </option>
              ))}
            </select>
          </label>
          {selected && (
            <p className="text-sm text-ink/60">
              Has {owned?.quantity ?? 0}
              {selected.maxStack !== null && ` · max ${selected.maxStack} per player`}
              {!selected.enabled && " · disabled, can only be removed"}
            </p>
          )}
          <label htmlFor="inv-qty" className="block">
            <span className="mb-1 block text-base font-medium text-ink/80">Quantity</span>
            <input
              id="inv-qty"
              type="number"
              inputMode="numeric"
              min={0}
              step={1}
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              className="w-full rounded-xl border-2 border-ink/15 bg-white px-4 py-3 text-lg outline-none focus:border-pine"
            />
          </label>
          <div className="flex gap-3">
            <Button onClick={() => handleChange("GIVE")} loading={pending === "GIVE"} disabled={pending !== null}>
              Give
            </Button>
            <Button
              onClick={() => handleChange("REMOVE")}
              loading={pending === "REMOVE"}
              disabled={pending !== null}
              className="!bg-alert"
            >
              Remove
            </Button>
          </div>
          <Button
            variant="ghost"
            onClick={() => handleChange("SET")}
            loading={pending === "SET"}
            disabled={pending !== null}
            className="!py-3 !text-base"
          >
            Set to exactly {quantity || "…"}
          </Button>
        </div>
      )}

      {data && (
        <div className="flex flex-col gap-2 border-t-2 border-ink/10 pt-4">
          <button type="button" onClick={() => setShowLog((v) => !v)} className="text-left text-lg font-semibold text-pine">
            Item history {showLog ? "▲" : "▼"}
          </button>
          {showLog &&
            (data.log.length === 0 ? (
              <p className="text-ink/60">No item changes yet.</p>
            ) : (
              <ul className="flex flex-col gap-2">
                {data.log.map((l) => {
                  const d = describeLog(l);
                  return (
                    <li key={l.id} className="flex items-center justify-between gap-3 rounded-xl border-2 border-ink/10 px-3 py-2">
                      <span className="text-sm text-ink/60">{formatDateTime(l.createdAt)}</span>
                      <span className={`text-right font-bold ${d.up ? "text-pine" : "text-alert"}`}>{d.text}</span>
                    </li>
                  );
                })}
              </ul>
            ))}
        </div>
      )}
    </div>
  );
}
