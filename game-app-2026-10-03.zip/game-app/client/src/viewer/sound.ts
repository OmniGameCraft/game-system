// Gun sounds through the Web Audio API: decoded once, then each shot starts
// instantly and shots can overlap (an <audio> tag can't do either well).
// Phones only allow sound after a tap, so unlockAudio() is called from the
// tap that opens the viewer.

let ctx: AudioContext | null = null;
const cache = new Map<string, Promise<AudioBuffer>>();

function context(): AudioContext {
  if (!ctx) {
    const C = window.AudioContext || (window as any).webkitAudioContext;
    ctx = new C();
  }
  return ctx;
}

export function unlockAudio(): void {
  try {
    const c = context();
    if (c.state === "suspended") void c.resume();
    // Play one silent sample: older iPhones need this inside the tap.
    const b = c.createBuffer(1, 1, 22050);
    const src = c.createBufferSource();
    src.buffer = b;
    src.connect(c.destination);
    src.start(0);
  } catch {
    // no audio support: the viewer just stays silent
  }
}

export function loadSound(url: string): Promise<AudioBuffer> {
  let p = cache.get(url);
  if (!p) {
    p = fetch(url)
      .then((r) => {
        if (!r.ok) throw new Error("sound not found");
        return r.arrayBuffer();
      })
      .then(
        (data) =>
          new Promise<AudioBuffer>((resolve, reject) =>
            // callback form: older Safari doesn't return a promise
            context().decodeAudioData(data, resolve, reject)
          )
      );
    p.catch(() => cache.delete(url));
    cache.set(url, p);
  }
  return p;
}

export function playSound(buffer: AudioBuffer, volume = 1): void {
  const c = context();
  if (c.state === "suspended") void c.resume();
  const src = c.createBufferSource();
  src.buffer = buffer;
  const gain = c.createGain();
  gain.gain.value = volume;
  // slight random pitch so rapid shots don't sound copy-pasted
  src.playbackRate.value = 0.96 + Math.random() * 0.08;
  src.connect(gain).connect(c.destination);
  src.start();
}
