import path from "path";

// Change these with environment variables, e.g.  PORT=4000 npm start
export const HOST = process.env.HOST ?? "0.0.0.0"; // 0.0.0.0 = reachable from the LAN
export const PORT = Number(process.env.PORT ?? 3000);
export const DB_PATH =
  process.env.DB_PATH ?? path.resolve(__dirname, "../data/game.db");
// Pictures the Admin uploads for items live next to the database file, so
// backing up the data folder backs up everything.
export const ITEM_IMAGE_DIR = path.join(path.dirname(DB_PATH), "uploads", "items");
export const CLIENT_DIST = path.resolve(__dirname, "../../client/dist");
// Second, secure address (https) for features phones only allow on secure
// pages, such as shake detection. Set HTTPS_PORT=0 to turn it off.
export const HTTPS_PORT = Number(process.env.HTTPS_PORT ?? 3443);
export const CERT_DIR = path.join(path.dirname(DB_PATH), "https");
// Ready-made item packs shipped with the app (pictures, 3D models, sounds).
export const PACKS_DIR = path.resolve(__dirname, "../asset-packs");
