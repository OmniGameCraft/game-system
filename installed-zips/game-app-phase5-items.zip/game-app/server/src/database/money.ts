import { DatabaseSync } from "node:sqlite";

export type TransactionType = "ADD" | "REMOVE";

export interface Transaction {
  id: number;
  player_id: number;
  type: TransactionType;
  amount: number;
  balance_before: number;
  balance_after: number;
  performed_by: number;
  created_at: string;
}

export interface PublicTransaction {
  id: number;
  type: TransactionType;
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  performedBy: number;
  createdAt: string;
}

export function toPublicTransaction(t: Transaction): PublicTransaction {
  return {
    id: t.id,
    type: t.type,
    amount: t.amount,
    balanceBefore: t.balance_before,
    balanceAfter: t.balance_after,
    performedBy: t.performed_by,
    createdAt: t.created_at,
  };
}

export class InsufficientFundsError extends Error {}

// A cap on any single transaction, not a cap on total balance — just a
// sanity limit against typos, well inside what a 64-bit SQLite INTEGER and
// a JS safe integer can both hold without any precision loss.
export const MAX_TRANSACTION_AMOUNT = 1_000_000_000;

export function listTransactionsForPlayer(db: DatabaseSync, playerId: number): Transaction[] {
  return db
    .prepare(
      "SELECT * FROM transactions WHERE player_id = ? ORDER BY id DESC"
    )
    .all(playerId) as unknown as Transaction[];
}

// Adjusts a player's balance and writes the audit row in one atomic step.
// Like the admin-setup and player-edit handlers elsewhere in this app, every
// call here is synchronous (node:sqlite and this function have no awaits),
// so Node's single JS thread can never interleave a second request between
// the balance check and the write below — that's what keeps two
// simultaneous requests for the same player from double-spending or
// producing a balance that doesn't match the transaction log.
export function adjustBalance(
  db: DatabaseSync,
  input: { playerId: number; type: TransactionType; amount: number; performedBy: number }
): { balance: number; transaction: Transaction } {
  const { playerId, type, amount, performedBy } = input;

  db.exec("BEGIN");
  try {
    const row = db.prepare("SELECT balance FROM users WHERE id = ?").get(playerId) as
      | { balance: number }
      | undefined;
    if (!row) {
      throw new Error("Player not found.");
    }
    const before = row.balance;
    const after = type === "ADD" ? before + amount : before - amount;

    if (after < 0) {
      throw new InsufficientFundsError("This player doesn't have enough money.");
    }

    db.prepare("UPDATE users SET balance = ? WHERE id = ?").run(after, playerId);
    const result = db
      .prepare(
        `INSERT INTO transactions
           (player_id, type, amount, balance_before, balance_after, performed_by)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(playerId, type, amount, before, after, performedBy);

    db.exec("COMMIT");

    const transaction = db
      .prepare("SELECT * FROM transactions WHERE id = ?")
      .get(Number(result.lastInsertRowid)) as unknown as Transaction;
    return { balance: after, transaction };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
