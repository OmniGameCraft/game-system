import { useEffect, useRef, useState } from "react";
import { GameEvent, GameStatus, getGame, PlayerGame } from "../services/api";
import { useLive } from "../services/live";
import { playSfx } from "../audio/sfx";
import { HAPTIC, vibrate } from "../audio/haptics";
import { useSettings } from "../audio/settings";
import { Button } from "./Button";
import { Icon } from "./Icon";

// Remembering which messages a player has already seen is a convenience
// only: if the browser won't store it, they may just see a message twice.
function readSeen(key: string): number | null {
  try {
    const v = localStorage.getItem(key);
    return v === null ? null : Number(v);
  } catch {
    return null;
  }
}
function writeSeen(key: string, id: number) {
  try {
    localStorage.setItem(key, String(id));
  } catch {
    // ignore
  }
}

// Loads the game's status and this player's messages, and keeps them fresh.
export function useGame(): PlayerGame | null {
  const [game, setGame] = useState<PlayerGame | null>(null);
  const load = () => {
    getGame().then(setGame).catch(() => {});
  };
  useEffect(load, []);
  useLive(["game:changed"], load, true);
  return game;
}

// Everything the game status puts on top of a player's screen:
//  - "Game on" flash + horn when the Admin starts or resumes the game
//  - a pause screen that stays until the Admin resumes
//  - a game-over screen (can be closed)
//  - a pop-up (with a chime) for each new message from the Admin
export function GameLayer({ game, userId }: { game: PlayerGame | null; userId: number }) {
  const prevStatus = useRef<GameStatus | null>(null);
  const [flash, setFlash] = useState(false);
  const [closedEndAt, setClosedEndAt] = useState<string | null>(null);
  const [popup, setPopup] = useState<GameEvent | null>(null);
  const [settings] = useSettings();
  const seenKey = `seen-announcement:${userId}`;

  // Status changes (not on the first load: opening the app mid-game is quiet).
  useEffect(() => {
    if (!game) return;
    const before = prevStatus.current;
    prevStatus.current = game.status;
    if (before === null || before === game.status) return;
    if (game.status === "active") {
      playSfx("gamestart");
      vibrate(HAPTIC.gameStart);
      setFlash(true);
      const t = setTimeout(() => setFlash(false), 2200);
      return () => clearTimeout(t);
    }
    if (game.status === "paused") {
      playSfx("pause");
      vibrate(HAPTIC.gameStop);
    }
    if (game.status === "ended") {
      playSfx("gameover");
      vibrate(HAPTIC.gameStop);
    }
  }, [game?.status]);

  // New messages. On the first load on this phone, everything already sent
  // counts as seen (no flood of old pop-ups); after that, anything newer pops up.
  useEffect(() => {
    if (!game) return;
    const newestId = game.announcements[0]?.id ?? 0;
    const seen = readSeen(seenKey);
    if (seen === null) {
      writeSeen(seenKey, newestId);
      return;
    }
    if (newestId > seen && popup?.id !== newestId) {
      setPopup(game.announcements[0]);
      playSfx("message");
      vibrate(HAPTIC.message);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game, seenKey]);

  function closePopup() {
    if (popup) writeSeen(seenKey, popup.id);
    setPopup(null);
  }

  if (!game) return null;

  return (
    <>
      {flash && (
        <div
          className="pointer-events-none fixed inset-0 z-[60] flex items-center justify-center bg-[radial-gradient(ellipse_at_center,rgba(11,12,14,0.55),rgba(11,12,14,0.92))] animate-fade-in"
          role="status"
        >
          <div className={settings.reduceMotion ? "" : "animate-gameon"}>
            <p className="flex items-center gap-4 rounded-lg border border-pine-light/60 bg-gradient-to-b from-pine-light to-pine px-10 py-6 font-display text-6xl font-bold text-pine-ink shadow-[0_0_60px_rgba(245,165,36,0.55),inset_0_1px_0_rgba(255,255,255,0.5)]">
              Game on
            </p>
          </div>
        </div>
      )}

      {game.status === "paused" && (
        <FullScreen tone="sun" title="Game paused" icon="pause">
          <p className="text-lg text-ink/80">Hold your position. The Admin will resume the game.</p>
          {game.announcements[0] && <LatestMessage e={game.announcements[0]} />}
        </FullScreen>
      )}

      {game.status === "ended" && closedEndAt !== game.changedAt && (
        <FullScreen tone="alert" title="Game over" icon="flag">
          <p className="text-lg text-ink/80">Thanks for playing. Your money and your case are still here.</p>
          {game.announcements[0] && <LatestMessage e={game.announcements[0]} />}
          <Button variant="ghost" onClick={() => setClosedEndAt(game.changedAt)}>
            Close
          </Button>
        </FullScreen>
      )}

      {popup && game.status !== "paused" && (
        <div
          className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-4 backdrop-blur-[2px] animate-fade-in sm:items-center"
          role="alertdialog"
          aria-label="Message from the Admin"
        >
          <div className="w-full max-w-md overflow-hidden rounded-xl border border-panel-line bg-panel shadow-lift animate-slide-up sm:animate-pop">
            <div className="case-strip !justify-start gap-3 !text-[0.85rem]">
              <Icon name="megaphone" className="h-5 w-5 text-pine" />
              Message from the Admin
            </div>
            <div className="flex flex-col gap-4 p-5">
              <p className="text-xl leading-snug text-ink">{popup.message}</p>
              <Button onClick={closePopup}>Got it</Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function LatestMessage({ e }: { e: GameEvent }) {
  return (
    <div className="w-full rounded-md border border-panel-line border-l-4 border-l-pine bg-panel-raised/80 px-4 py-3 text-left">
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-pine">Latest message</p>
      <p className="mt-0.5 text-lg">{e.message}</p>
    </div>
  );
}

function FullScreen({
  tone,
  title,
  icon,
  children,
}: {
  tone: "sun" | "alert";
  title: string;
  icon: "pause" | "flag";
  children: React.ReactNode;
}) {
  const color = tone === "sun" ? "text-sun" : "text-alert";
  const bar = tone === "sun" ? "bg-sun" : "bg-alert";
  const ring = tone === "sun" ? "border-sun/40 bg-sun/10" : "border-alert/40 bg-alert/10";
  const stripes =
    "opacity-80 [background-image:repeating-linear-gradient(45deg,transparent_0_12px,rgba(0,0,0,.45)_12px_24px)]";
  return (
    <div
      className="fixed inset-0 z-[65] flex flex-col items-center justify-center gap-6 bg-[radial-gradient(ellipse_at_50%_35%,rgba(30,33,37,0.97),rgba(8,9,10,0.99))] px-6 text-center animate-fade-in"
      role="alertdialog"
      aria-label={title}
    >
      {/* hazard stripes top and bottom */}
      <div className={`absolute inset-x-0 top-0 h-3 ${bar} ${stripes}`} />
      <div className={`absolute inset-x-0 bottom-0 h-3 ${bar} ${stripes}`} />
      <div className={`flex h-24 w-24 items-center justify-center rounded-full border-2 ${ring} animate-pop`}>
        <Icon name={icon} className={`h-12 w-12 ${color}`} />
      </div>
      <h1 className={`font-display text-5xl font-bold ${color} animate-enter`}>{title}</h1>
      <div className="flex w-full max-w-sm flex-col gap-4 animate-enter [animation-delay:80ms]">{children}</div>
    </div>
  );
}
