// Square picture for an item, shown in a little case cell, or the item's
// first letter when there's no picture yet.
export function ItemImage({
  url,
  name,
  size = "md",
}: {
  url: string | null;
  name: string;
  size?: "sm" | "md" | "lg";
}) {
  const box = size === "lg" ? "h-28 w-28 text-4xl" : size === "sm" ? "h-12 w-12 text-lg" : "h-16 w-16 text-2xl";
  if (url) {
    return (
      <span className={`${box} cell flex shrink-0 items-center justify-center overflow-hidden rounded-md`}>
        <img
          src={url}
          alt=""
          draggable={false}
          loading="lazy"
          className="h-full w-full object-contain p-1 drop-shadow-[0_3px_4px_rgba(0,0,0,0.7)]"
        />
      </span>
    );
  }
  return (
    <span
      aria-hidden
      className={`${box} cell flex shrink-0 items-center justify-center rounded-md font-display font-bold text-pine/80`}
    >
      {name.trim().charAt(0).toUpperCase() || "?"}
    </span>
  );
}
