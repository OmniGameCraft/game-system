import { useEffect, useState } from "react";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { ItemImage } from "../../components/ItemImage";
import { Section } from "../../components/Section";
import { Item, listItems } from "../../services/api";

export function ItemsList({ onCreate, onOpen }: { onCreate: () => void; onOpen: (id: number) => void }) {
  const [items, setItems] = useState<Item[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listItems()
      .then(setItems)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load items."));
  }, []);

  // Group by category so weapons, ammo etc. each get their own box.
  const groups = new Map<string, Item[]>();
  for (const i of items ?? []) {
    const k = i.category || "No category";
    groups.set(k, [...(groups.get(k) ?? []), i]);
  }
  const groupNames = [...groups.keys()].sort((a, b) =>
    a === "No category" ? 1 : b === "No category" ? -1 : a.localeCompare(b)
  );

  return (
    <>
      <Button onClick={onCreate}>+ Create Item</Button>
      <ErrorBanner message={error} />
      {items === null && !error && <p className="text-ink/60">Loading…</p>}
      {items?.length === 0 && (
        <Section title="All items (0)">
          <p className="text-ink/70">No items yet. Create weapons, ammo, gear or anything else your game uses.</p>
        </Section>
      )}
      {groupNames.map((g) => (
        <Section key={g} title={`${g} (${groups.get(g)!.length})`} flush>
          <ul className="divide-y-2 divide-ink/5">
            {groups.get(g)!.map((item) => (
              <li key={item.id}>
                <button onClick={() => onOpen(item.id)} className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-pine-soft">
                  <ItemImage url={item.imageUrl} name={item.name} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-lg font-bold text-ink">{item.name}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-2">
                      <Badge tone={item.enabled ? "good" : "bad"}>{item.enabled ? "Enabled" : "Disabled"}</Badge>
                      {item.maxStack !== null && <Badge tone="neutral">Max {item.maxStack} each</Badge>}
                    </div>
                  </div>
                  <Icon name="chevron" className="h-5 w-5 shrink-0 text-ink/30" />
                </button>
              </li>
            ))}
          </ul>
        </Section>
      ))}
    </>
  );
}
