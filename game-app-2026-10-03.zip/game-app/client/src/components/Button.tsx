import { ButtonHTMLAttributes } from "react";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  variant?: "primary" | "ghost" | "danger" | "dangerGhost";
  size?: "lg" | "md";
}

// Main actions are solid amber with a cut corner; secondary ones are
// outlined steel. Same height everywhere so thumbs always find them.
export function Button({
  loading,
  variant = "primary",
  size = "lg",
  disabled,
  children,
  className = "",
  ...rest
}: Props) {
  const look = {
    primary: "chamfer bg-pine text-pine-ink disabled:bg-pine/35 disabled:text-pine-ink/60",
    ghost: "border-2 border-panel-line bg-panel-raised text-ink disabled:opacity-50",
    danger: "chamfer bg-alert text-[#2A0707] disabled:bg-alert/40",
    dangerGhost: "border-2 border-alert/50 bg-transparent text-alert disabled:opacity-50",
  }[variant];
  const sz = size === "lg" ? "min-h-[3.5rem] px-4 py-3 text-xl" : "min-h-[3rem] px-3 py-2 text-lg";
  return (
    <button
      disabled={disabled || loading}
      className={`w-full rounded-sm font-display font-semibold tracking-wide transition-transform active:scale-[0.98] ${sz} ${look} ${className}`}
      {...rest}
    >
      {loading ? "Please wait…" : children}
    </button>
  );
}
