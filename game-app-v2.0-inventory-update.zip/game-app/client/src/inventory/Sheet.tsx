import { ReactNode, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { playSfx } from "../audio/sfx";
import { useSettings } from "../audio/settings";
import "./case.css";

// A panel that slides up from the bottom over a dimmed screen (the case's
// item menu, mixing, the drop box). Closes with the backdrop, Esc, the
// Close button, or by swiping the top handle down.

let locks = 0;
function lockScroll(on: boolean) {
  locks += on ? 1 : -1;
  document.body.style.overflow = locks > 0 ? "hidden" : "";
}

export function Sheet({
  open,
  onClose,
  label,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  label: string;
  children: ReactNode;
  footer?: ReactNode; // stays visible at the bottom while the body scrolls
}) {
  const [mounted, setMounted] = useState(open);
  const [shown, setShown] = useState(false);
  const [drag, setDrag] = useState(0);
  const openedAt = useRef(0);
  const panelRef = useRef<HTMLDivElement>(null);
  const backTo = useRef<HTMLElement | null>(null);
  const swipe = useRef<{ id: number; y: number } | null>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const [{ reduceMotion }] = useSettings();

  useEffect(() => {
    if (open) {
      setMounted(true);
      playSfx("open");
      openedAt.current = performance.now();
      backTo.current = document.activeElement as HTMLElement | null;
      // Two frames so the browser paints the closed position first and the
      // slide-up actually animates.
      let r2 = 0;
      const r1 = requestAnimationFrame(() => {
        r2 = requestAnimationFrame(() => setShown(true));
      });
      return () => {
        cancelAnimationFrame(r1);
        cancelAnimationFrame(r2);
      };
    }
    setShown(false);
    setDrag(0);
    const t = setTimeout(() => setMounted(false), 230);
    return () => clearTimeout(t);
  }, [open]);

  useEffect(() => {
    if (!mounted) return;
    lockScroll(true);
    return () => {
      lockScroll(false);
      // Put keyboard focus back where it was (the piece that opened this).
      const el = backTo.current;
      if (el && document.contains(el)) el.focus({ preventScroll: true });
    };
  }, [mounted]);

  useEffect(() => {
    if (shown) panelRef.current?.focus({ preventScroll: true });
  }, [shown]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        // Capture phase + stop: Esc closes only this menu, not the screen
        // underneath (e.g. the weapon screen when the case is open over it).
        e.stopPropagation();
        userClose();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  function userClose() {
    playSfx("close");
    closeRef.current();
  }

  if (!mounted) return null;

  return createPortal(
    // data-no-use: taps in here must never count as "use" on a screen below
    // (the weapon screen fires on any tap outside [data-no-use]).
    <div className={`cs-sheet-root ${reduceMotion ? "cs-reduce" : ""}`} role="presentation" data-no-use>
      <div
        className={`cs-sheet-backdrop ${shown ? "is-shown" : ""}`}
        onClick={() => {
          // The finger that long-pressed to open this may lift over the
          // backdrop; don't let that close it straight away.
          if (performance.now() - openedAt.current > 350) userClose();
        }}
        aria-hidden
      />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={label}
        tabIndex={-1}
        className={`cs-sheet ${shown ? "is-shown" : ""}`}
        style={drag > 0 ? { transform: `translateY(${drag}px)`, transition: "none" } : undefined}
      >
        <div
          className="cs-sheet-grip"
          onPointerDown={(e) => {
            swipe.current = { id: e.pointerId, y: e.clientY };
            (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (swipe.current?.id === e.pointerId) setDrag(Math.max(0, e.clientY - swipe.current.y));
          }}
          onPointerUp={(e) => {
            if (swipe.current?.id !== e.pointerId) return;
            swipe.current = null;
            if (drag > 80) userClose();
            else setDrag(0);
          }}
          onPointerCancel={() => {
            swipe.current = null;
            setDrag(0);
          }}
          aria-hidden
        >
          <span />
        </div>
        <div className="cs-sheet-body">{children}</div>
        {footer && <div className="cs-sheet-foot">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}

// Shared look for the buttons inside sheets.
export function SheetButton({
  icon,
  children,
  onClick,
  disabled,
  tone = "plain",
  busy,
  big,
  sound = false,
}: {
  icon?: ReactNode;
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
  tone?: "primary" | "plain" | "danger" | "good";
  busy?: boolean;
  big?: boolean;
  sound?: boolean; // true = let the global button click play (no own sound)
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled || busy}
      data-sound={sound ? undefined : "none"}
      className={`cs-btn cs-btn-${tone} ${big ? "cs-btn-big" : ""}`}
    >
      {icon}
      <span className="min-w-0 truncate">{busy ? "Please wait…" : children}</span>
    </button>
  );
}
