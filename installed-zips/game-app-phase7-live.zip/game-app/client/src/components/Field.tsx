import { InputHTMLAttributes, useState } from "react";

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: string;
}

const inputCls =
  "w-full rounded-xl border-2 border-ink/15 bg-white px-4 py-3 text-lg outline-none focus:border-pine";

export function TextField({ label, hint, id, ...rest }: FieldProps) {
  return (
    <label htmlFor={id} className="block">
      <span className="mb-1 block text-base font-semibold text-ink/80">{label}</span>
      <input id={id} className={inputCls} {...rest} />
      {hint && <span className="mt-1 block text-sm text-ink/55">{hint}</span>}
    </label>
  );
}

export function PasswordField({ label, hint, id, ...rest }: FieldProps) {
  const [visible, setVisible] = useState(false);
  return (
    <label htmlFor={id} className="block">
      <span className="mb-1 block text-base font-semibold text-ink/80">{label}</span>
      <div className="relative">
        <input id={id} type={visible ? "text" : "password"} className={`${inputCls} pr-20`} {...rest} />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          className="absolute inset-y-0 right-2 my-1 rounded-lg px-3 text-sm font-semibold text-pine"
          aria-label={visible ? "Hide password" : "Show password"}
        >
          {visible ? "Hide" : "Show"}
        </button>
      </div>
      {hint && <span className="mt-1 block text-sm text-ink/55">{hint}</span>}
    </label>
  );
}

export { inputCls };
