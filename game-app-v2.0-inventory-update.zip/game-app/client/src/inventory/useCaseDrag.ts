import { CSSProperties, PointerEvent as ReactPointerEvent, RefObject, useEffect, useRef, useState } from "react";
import { playSfx } from "../audio/sfx";
import { vibrate } from "../audio/haptics";
import type { Piece } from "./caseApi";
import { Box, boxOf, canStack, fits, footprint, pieceAt } from "./layout";
import { mixOf } from "./herbs";

// Moving pieces with a finger or a mouse (pointer events cover both).
//
//  - press and move a little → the piece lifts and follows the finger; a
//    ghost snaps to the cells underneath: green = fits, red = blocked,
//    amber = joins a stack / mixes herbs
//  - while dragging: a second finger tap (e.g. on the floating Rotate
//    button), the R key or the right mouse button turn the piece
//  - press and hold still (450 ms) → the item's menu opens
//  - a quick tap is a normal click (handled by the screen: select + menu)
//
// The finger position is applied straight to the floating piece's style
// (no React render per move), so dragging stays smooth on cheap phones.

export type Over = "grid" | "drop" | "tray" | null;

export interface Ghost {
  box: Box;
  state: "ok" | "blocked" | "merge" | "mix";
  label?: string;
  targetId?: number;
}

export interface DragView {
  piece: Piece;
  rotated: boolean;
  ghost: Ghost | null;
  over: Over;
}

const LONG_PRESS_MS = 450;

interface Live {
  pointerId: number;
  pointerType: string;
  piece: Piece;
  startX: number;
  startY: number;
  x: number;
  y: number;
  offX: number; // where the finger holds the piece, in grid pixels
  offY: number;
  rotated: boolean;
  active: boolean;
  timer: number;
  buttons: number;
  scroller: HTMLElement | null; // null = the page itself
  raf: number;
}

export function useCaseDrag(opts: {
  enabled: boolean;
  cell: number;
  cols: number;
  rows: number;
  pieces: Piece[];
  gridRef: RefObject<HTMLElement>;
  dropRefs: RefObject<HTMLElement>[];
  trayRef: RefObject<HTMLElement>;
  barRef: RefObject<HTMLElement>; // the floating Drop/Rotate bar: never auto-scroll under it
  floatRef: RefObject<HTMLDivElement>;
  onLongPress: (p: Piece) => void;
  onCommit: (d: DragView) => void;
}) {
  const [view, setView] = useState<DragView | null>(null);
  const live = useRef<Live | null>(null);
  const o = useRef(opts);
  o.current = opts;
  const swallowClick = useRef(false);
  const viewKey = useRef("");
  // The latest decision, kept in a ref so letting go can act on it at once
  // (React state may not have caught up yet).
  const current = useRef<DragView | null>(null);

  // Always tidy up if the screen goes away mid-drag.
  useEffect(() => () => stop(), []); // eslint-disable-line react-hooks/exhaustive-deps

  function place() {
    const l = live.current;
    const el = o.current.floatRef.current;
    if (!l || !el) return;
    el.style.transform = `translate3d(${l.x - l.offX}px, ${l.y - l.offY}px, 0)`;
  }

  function hit(ref: RefObject<HTMLElement>, x: number, y: number): boolean {
    const r = ref.current?.getBoundingClientRect();
    return !!r && r.width > 0 && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
  }

  // Work out what the piece is over and what would happen if let go here.
  function evaluate() {
    const l = live.current;
    if (!l || !l.active) return;
    const { cell, cols, rows, pieces, gridRef, dropRefs, trayRef } = o.current;
    let next: DragView;
    if (dropRefs.some((r) => hit(r, l.x, l.y))) {
      next = { piece: l.piece, rotated: l.rotated, ghost: null, over: "drop" };
    } else if (hit(trayRef, l.x, l.y)) {
      next = { piece: l.piece, rotated: l.rotated, ghost: null, over: "tray" };
    } else {
      const g = gridRef.current?.getBoundingClientRect();
      const margin = cell * 0.6;
      const fp = footprint(l.piece, l.rotated);
      // Judge by the middle of the piece as drawn (on touch it rides a bit
      // above the finger), so what you see is what you get.
      const px = l.x - l.offX + (fp.w * cell) / 2;
      const py = l.y - l.offY + (fp.h * cell) / 2;
      if (g && px >= g.left - margin && px <= g.right + margin && py >= g.top - margin && py <= g.bottom + margin) {
        // Snap the piece's top-left corner to the nearest cell, kept inside the case.
        let gx = Math.round((l.x - l.offX - g.left) / cell);
        let gy = Math.round((l.y - l.offY - g.top) / cell);
        if (fp.w <= cols) gx = Math.max(0, Math.min(cols - fp.w, gx));
        if (fp.h <= rows) gy = Math.max(0, Math.min(rows - fp.h, gy));
        const under = pieceAt(pieces, Math.floor((px - g.left) / cell), Math.floor((py - g.top) / cell), l.piece.id);
        let ghost: Ghost;
        const ub = under ? boxOf(under) : null;
        if (under && ub && canStack(under, l.piece)) {
          const n = Math.min(l.piece.quantity, under.stackSize - under.quantity);
          ghost = { box: ub, state: "merge", label: `+${n}`, targetId: under.id };
        } else if (under && ub && under.herbCode && l.piece.herbCode) {
          const m = mixOf(l.piece.herbCode, under.herbCode);
          ghost = m.ok
            ? { box: ub, state: "mix", label: `Mix → ${m.name}`, targetId: under.id }
            : { box: ub, state: "blocked", label: m.reason };
        } else {
          const box = { x: gx, y: gy, w: fp.w, h: fp.h };
          ghost = { box, state: fits(box, cols, rows, pieces, l.piece.id) ? "ok" : "blocked" };
        }
        next = { piece: l.piece, rotated: l.rotated, ghost, over: "grid" };
      } else {
        next = { piece: l.piece, rotated: l.rotated, ghost: null, over: null };
      }
    }
    current.current = next;
    const g = next.ghost;
    const key = `${next.over}|${next.rotated}|${g ? `${g.box.x},${g.box.y},${g.box.w},${g.box.h},${g.state},${g.targetId}` : ""}`;
    if (key !== viewKey.current) {
      // A soft tick each time the ghost snaps to a new cell.
      if (g && viewKey.current && g.state !== "blocked") vibrate(4);
      viewKey.current = key;
      setView(next);
    }
  }

  // Turn the piece around the finger, so the same part of it stays held.
  function rotate() {
    const l = live.current;
    if (!l || !l.active) return;
    const { cell } = o.current;
    const fp = footprint(l.piece, l.rotated);
    const oldH = fp.h * cell;
    const nx = oldH - l.offY;
    const ny = l.offX;
    l.offX = nx;
    l.offY = ny;
    l.rotated = !l.rotated;
    playSfx("rotate");
    vibrate(10);
    place();
    evaluate();
  }

  // Keep scrolling while the finger rests near the top/bottom edge, so a
  // long case can be rearranged on a small phone.
  function autoScroll() {
    const l = live.current;
    if (!l || !l.active) return;
    const overTarget =
      o.current.dropRefs.some((r) => hit(r, l.x, l.y)) || hit(o.current.trayRef, l.x, l.y) || hit(o.current.barRef, l.x, l.y);
    const top = l.scroller ? l.scroller.getBoundingClientRect().top : 0;
    const bottom = l.scroller ? l.scroller.getBoundingClientRect().bottom : window.innerHeight;
    const zone = 64;
    let dy = 0;
    if (!overTarget) {
      if (l.y < top + zone + (l.scroller ? 0 : 56)) dy = -Math.ceil(((top + zone + (l.scroller ? 0 : 56) - l.y) / zone) * 10);
      else if (l.y > bottom - zone) dy = Math.ceil(((l.y - (bottom - zone)) / zone) * 10);
    }
    if (dy !== 0) {
      dy = Math.max(-16, Math.min(16, dy));
      if (l.scroller) l.scroller.scrollTop += dy;
      else window.scrollBy(0, dy);
      evaluate();
    }
    l.raf = requestAnimationFrame(autoScroll);
  }

  function findScroller(el: HTMLElement | null): HTMLElement | null {
    let n = el?.parentElement ?? null;
    while (n && n !== document.body && n !== document.documentElement) {
      const s = getComputedStyle(n);
      if (/(auto|scroll)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 1) return n;
      n = n.parentElement;
    }
    return null;
  }

  function begin() {
    const l = live.current;
    if (!l) return;
    l.active = true;
    // On a touch screen the finger would hide a small piece and the green /
    // red preview under it, so the piece rides a little above the finger.
    if (l.pointerType !== "mouse") l.offY += Math.round(Math.max(18, Math.min(32, o.current.cell * 0.6)));
    clearTimeout(l.timer);
    swallowClick.current = true;
    document.documentElement.classList.add("cs-dragging");
    vibrate(8);
    viewKey.current = "";
    l.scroller = findScroller(o.current.gridRef.current);
    l.raf = requestAnimationFrame(autoScroll);
    evaluate();
    // Position the floating piece as soon as React has drawn it.
    requestAnimationFrame(place);
  }

  function stop() {
    const l = live.current;
    if (l) {
      clearTimeout(l.timer);
      cancelAnimationFrame(l.raf);
    }
    live.current = null;
    current.current = null;
    viewKey.current = "";
    document.documentElement.classList.remove("cs-dragging");
    listen(false);
    setView(null);
  }

  function onMove(e: PointerEvent) {
    const l = live.current;
    if (!l || e.pointerId !== l.pointerId) return;
    l.x = e.clientX;
    l.y = e.clientY;
    if (!l.active) {
      const limit = l.pointerType === "mouse" ? 5 : 9;
      if (Math.hypot(l.x - l.startX, l.y - l.startY) < limit) return;
      begin();
      return;
    }
    // Mouse: pressing the right button while dragging turns the piece.
    if (l.pointerType === "mouse" && e.buttons & 2 && !(l.buttons & 2)) rotate();
    l.buttons = e.buttons;
    place();
    evaluate();
  }

  function onUp(e: PointerEvent) {
    const l = live.current;
    if (!l || e.pointerId !== l.pointerId) return;
    if (l.active) {
      evaluate();
      const decided = current.current;
      stop();
      if (decided) o.current.onCommit(decided);
    } else {
      stop();
    }
  }

  function onCancel(e: PointerEvent) {
    if (live.current && e.pointerId === live.current.pointerId) stop();
  }

  // A second finger anywhere turns the dragged piece.
  function onOtherDown(e: PointerEvent) {
    const l = live.current;
    if (!l || !l.active || e.pointerId === l.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    rotate();
  }

  function onKey(e: KeyboardEvent) {
    if (!live.current?.active) return;
    if (e.key === "r" || e.key === "R") {
      e.preventDefault();
      rotate();
    } else if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      stop();
    }
  }

  function onContext(e: Event) {
    if (live.current) e.preventDefault();
  }

  function onPieceDown(p: Piece, e: ReactPointerEvent<HTMLElement>, sourceCell: number) {
    swallowClick.current = false;
    if (!o.current.enabled) return;
    if (e.pointerType === "mouse" && e.button !== 0) return;
    if (live.current) return; // already holding one
    const r = e.currentTarget.getBoundingClientRect();
    const scale = sourceCell > 0 ? o.current.cell / sourceCell : 1;
    const l: Live = {
      pointerId: e.pointerId,
      pointerType: e.pointerType,
      piece: p,
      startX: e.clientX,
      startY: e.clientY,
      x: e.clientX,
      y: e.clientY,
      offX: (e.clientX - r.left) * scale,
      offY: (e.clientY - r.top) * scale,
      rotated: p.rotated,
      active: false,
      timer: 0,
      buttons: e.buttons,
      scroller: null,
      raf: 0,
    };
    // Hold still → open the item's menu instead of dragging.
    l.timer = window.setTimeout(() => {
      if (live.current !== l || l.active) return;
      swallowClick.current = true;
      vibrate(15);
      stop();
      o.current.onLongPress(p);
    }, LONG_PRESS_MS);
    live.current = l;
    listen(true);
  }

  // Window listeners go through these fixed wrappers, which call the newest
  // handlers. Adding and removing the very same functions means nothing is
  // left behind, whichever screen update stops the drag.
  const fns = useRef({ onMove, onUp, onCancel, onOtherDown, onKey, onContext });
  fns.current = { onMove, onUp, onCancel, onOtherDown, onKey, onContext };
  const wrappers = useRef<{
    move: (e: PointerEvent) => void;
    up: (e: PointerEvent) => void;
    cancel: (e: PointerEvent) => void;
    other: (e: PointerEvent) => void;
    key: (e: KeyboardEvent) => void;
    context: (e: Event) => void;
  } | null>(null);
  if (!wrappers.current) {
    wrappers.current = {
      move: (e) => fns.current.onMove(e),
      up: (e) => fns.current.onUp(e),
      cancel: (e) => fns.current.onCancel(e),
      other: (e) => fns.current.onOtherDown(e),
      key: (e) => fns.current.onKey(e),
      context: (e) => fns.current.onContext(e),
    };
  }
  function listen(on: boolean) {
    const w = wrappers.current!;
    const f = on ? window.addEventListener.bind(window) : window.removeEventListener.bind(window);
    f("pointermove", w.move as EventListener);
    f("pointerup", w.up as EventListener);
    f("pointercancel", w.cancel as EventListener);
    f("pointerdown", w.other as EventListener, true);
    f("keydown", w.key as EventListener, true);
    f("contextmenu", w.context, true);
  }

  // Where the floating piece is drawn (also used when React re-renders it).
  function floatStyle(): CSSProperties {
    const l = live.current;
    return l ? { transform: `translate3d(${l.x - l.offX}px, ${l.y - l.offY}px, 0)` } : { display: "none" };
  }

  return {
    drag: view,
    onPieceDown,
    rotate,
    cancel: stop,
    floatStyle,
    // True once after a drag or long-press, so the click that follows the
    // finger lifting doesn't also open the menu. Keyboard clicks (detail 0)
    // are never swallowed.
    consumeClick(detail: number): boolean {
      const v = swallowClick.current && detail !== 0;
      swallowClick.current = false;
      return v;
    },
  };
}
