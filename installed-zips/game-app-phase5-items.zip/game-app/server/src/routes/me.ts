import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { requireAuth, requireRole } from "../auth/middleware";
import { listInventoryForPlayer } from "../database/inventory";
import { listTransactionsForPlayer, toPublicTransaction } from "../database/money";

// A player's own transaction history. Deliberately reads req.user.id from
// the authenticated session only — never from a URL param or the request
// body — so there is no field a player could edit to view someone else's
// history. (Their balance itself already comes back from GET /api/auth/me.)
export function createMeRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireAuth);

  router.get("/transactions", (req, res) => {
    const transactions = listTransactionsForPlayer(db, req.user!.id).map(toPublicTransaction);
    res.json({ transactions });
  });

  // The logged-in player's own items. Same rule as above: whose inventory
  // comes only from the session. Admin accounts don't carry items.
  router.get("/inventory", requireRole("player"), (req, res) => {
    const inventory = listInventoryForPlayer(db, req.user!.id).map((e) => ({
      itemId: e.itemId,
      name: e.name,
      description: e.description,
      category: e.category,
      imageUrl: e.imageUrl,
      quantity: e.quantity,
    }));
    res.json({ inventory });
  });

  return router;
}
