import { ReactNode } from "react";

// A steel panel with its own title strip, so every part of a screen is
// clearly separated and labelled. The amber notch on the strip marks it as
// a heading at a glance; tone changes the notch for warnings and danger.
export function Section({
  title,
  action,
  children,
  tone = "pine",
  flush = false,
}: {
  title: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  tone?: "pine" | "alert" | "sun";
  flush?: boolean; // no padding around the body (for full-width lists)
}) {
  const notch = tone === "alert" ? "bg-alert" : tone === "sun" ? "bg-sun" : "bg-pine";
  const titleColor = tone === "alert" ? "text-alert" : "text-ink";
  return (
    <section className="chamfer bg-panel">
      <header className="flex min-h-[3.25rem] items-center justify-between gap-3 border-b border-panel-line bg-panel-raised py-2 pl-4 pr-3">
        <h2 className={`flex items-center gap-2.5 text-lg font-semibold leading-tight ${titleColor}`}>
          <span className={`h-5 w-1.5 shrink-0 ${notch}`} aria-hidden />
          {title}
        </h2>
        {action}
      </header>
      <div className={flush ? "" : "flex flex-col gap-4 p-4"}>{children}</div>
    </section>
  );
}

// Small button that sits in a Section's title strip.
export function SectionAction({
  children,
  onClick,
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="flex min-h-[2.5rem] items-center gap-1 rounded-sm border border-panel-line px-3 text-sm font-semibold text-pine active:bg-pine-soft disabled:opacity-50"
    >
      {children}
    </button>
  );
}
