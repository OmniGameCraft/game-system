import { useEffect, useState } from "react";
import { useLive } from "../../services/live";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { ItemImage } from "../../components/ItemImage";
import { Section } from "../../components/Section";
import { AssetPack, importFromPack, Item, KIND_LABEL, listAssetPacks, listItems } from "../../services/api";
import { Notice } from "../../components/Notice";

// Ready-made items that ship with the app (free CC0 weapons, knife, medkit
// with pictures, 3D models and sounds). The Admin picks which to add.
function PackImport({ onDone }: { onDone: () => void }) {
  const [packs, setPacks] = useState<AssetPack[] | null>(null);
  const [open, setOpen] = useState(false);
  const [chosen, setChosen] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  function load() {
    listAssetPacks()
      .then((p) => {
        setPacks(p);
        const pack = p[0];
        if (pack) setChosen(new Set(pack.items.filter((i) => !i.alreadyAdded).map((i) => i.key)));
      })
      .catch(() => setPacks([]));
  }
  useEffect(load, []);
  useLive(["items:changed"], load);

  const pack = packs?.[0];
  if (!pack) return null;
  const remaining = pack.items.filter((i) => !i.alreadyAdded);

  async function add() {
    setError(null);
    setNotice(null);
    setBusy(true);
    try {
      const r = await importFromPack(pack!.id, [...chosen]);
      setNotice(
        r.created.length
          ? `Added: ${r.created.join(", ")}. Put them in the shop or give them to players whenever you like.`
          : "Nothing new to add."
      );
      setOpen(false);
      onDone();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not add the items.");
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <>
        <Notice message={notice} />
        {remaining.length > 0 && (
          <Button variant="ghost" onClick={() => setOpen(true)}>
            <span className="flex items-center justify-center gap-2">
              <Icon name="cube" className="h-5 w-5" /> Add from {pack.title.toLowerCase()} ({remaining.length})
            </span>
          </Button>
        )}
      </>
    );
  }

  return (
    <Section title={pack.title} tone="sun">
      <p className="text-ink/70">
        Free items with a picture, 3D model and sound. Pick the ones you want. They won't be put in the shop or
        given to anyone.
      </p>
      <ErrorBanner message={error} />
      <ul className="flex flex-col gap-2">
        {pack.items.map((i) => (
          <li key={i.key}>
            <label
              className={`flex min-h-[3.5rem] items-center gap-3 rounded-md border-2 px-3 py-2 ${
                i.alreadyAdded ? "border-ink/10 opacity-60" : chosen.has(i.key) ? "border-pine" : "border-ink/15"
              }`}
            >
              <input
                type="checkbox"
                className="h-6 w-6 accent-pine"
                disabled={i.alreadyAdded}
                checked={!i.alreadyAdded && chosen.has(i.key)}
                onChange={(e) =>
                  setChosen((s) => {
                    const n = new Set(s);
                    if (e.target.checked) n.add(i.key);
                    else n.delete(i.key);
                    return n;
                  })
                }
              />
              <ItemImage url={i.pictureUrl} name={i.name} size="sm" />
              <span className="min-w-0 flex-1">
                <span className="block font-bold">{i.name}</span>
                <span className="block text-sm text-ink/55">
                  {i.alreadyAdded
                    ? "Already added"
                    : [i.category, i.hasModel && "3D", i.hasSound && "sound"].filter(Boolean).join(" · ")}
                </span>
              </span>
            </label>
          </li>
        ))}
      </ul>
      <p className="text-xs text-ink/55">{pack.credits}</p>
      <div className="grid grid-cols-2 gap-3">
        <Button variant="ghost" size="md" onClick={() => setOpen(false)}>
          Cancel
        </Button>
        <Button size="md" loading={busy} disabled={chosen.size === 0} onClick={add}>
          Add {chosen.size} item{chosen.size === 1 ? "" : "s"}
        </Button>
      </div>
    </Section>
  );
}

export function ItemsList({ onCreate, onOpen }: { onCreate: () => void; onOpen: (id: number) => void }) {
  const [items, setItems] = useState<Item[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [tick, setTick] = useState(0);
  useLive(["items:changed"], () => setTick((t) => t + 1));

  useEffect(() => {
    listItems()
      .then(setItems)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load items."));
  }, [tick]);

  // Group by category so weapons, ammo etc. each get their own box.
  const groups = new Map<string, Item[]>();
  for (const i of items ?? []) {
    const k = i.category || "No category";
    groups.set(k, [...(groups.get(k) ?? []), i]);
  }
  const groupNames = [...groups.keys()].sort((a, b) =>
    a === "No category" ? 1 : b === "No category" ? -1 : a.localeCompare(b)
  );

  return (
    <>
      <Button onClick={onCreate}>+ Create Item</Button>
      <PackImport onDone={() => setTick((t) => t + 1)} />
      <ErrorBanner message={error} />
      {items === null && !error && <p className="text-ink/60">Loading…</p>}
      {items?.length === 0 && (
        <Section title="All items (0)">
          <p className="text-ink/70">No items yet. Create weapons, ammo, gear or anything else your game uses.</p>
        </Section>
      )}
      {groupNames.map((g) => (
        <Section key={g} title={`${g} (${groups.get(g)!.length})`} flush>
          <ul className="divide-y-2 divide-ink/5">
            {groups.get(g)!.map((item) => (
              <li key={item.id}>
                <button onClick={() => onOpen(item.id)} className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-pine-soft">
                  <ItemImage url={item.imageUrl} name={item.name} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-lg font-bold text-ink">{item.name}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-2">
                      <Badge tone={item.enabled ? "good" : "bad"}>{item.enabled ? "Enabled" : "Disabled"}</Badge>
                      {item.kind !== "other" && <Badge tone="neutral">{KIND_LABEL[item.kind]}</Badge>}
                      {item.kind === "ammo" && item.ammoPerPack && <Badge tone="neutral">{item.ammoPerPack}/pack</Badge>}
                      {item.sellable && <Badge tone="warn">Sell {item.sellPercent}%</Badge>}
                      {item.maxStack !== null && <Badge tone="neutral">Max {item.maxStack} each</Badge>}
                      {item.modelUrl && <Badge tone="neutral">3D</Badge>}
                      {item.soundUrl && <Badge tone="neutral">Sound</Badge>}
                    </div>
                  </div>
                  <Icon name="chevron" className="h-5 w-5 shrink-0 text-ink/30" />
                </button>
              </li>
            ))}
          </ul>
        </Section>
      ))}
    </>
  );
}
