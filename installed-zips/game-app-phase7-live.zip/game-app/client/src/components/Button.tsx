import { ButtonHTMLAttributes } from "react";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  variant?: "primary" | "ghost" | "danger" | "dangerGhost";
  size?: "lg" | "md";
}

export function Button({
  loading,
  variant = "primary",
  size = "lg",
  disabled,
  children,
  className = "",
  ...rest
}: Props) {
  const look = {
    primary: "bg-pine text-white disabled:bg-pine/40",
    ghost: "border-2 border-pine/30 bg-white text-pine disabled:opacity-50",
    danger: "bg-alert text-white disabled:bg-alert/40",
    dangerGhost: "border-2 border-alert/40 bg-white text-alert disabled:opacity-50",
  }[variant];
  const sz = size === "lg" ? "min-h-[3.5rem] px-4 py-3 text-lg" : "min-h-[3rem] px-3 py-2 text-base";
  return (
    <button
      disabled={disabled || loading}
      className={`w-full rounded-xl font-bold active:scale-[0.99] ${sz} ${look} ${className}`}
      {...rest}
    >
      {loading ? "Please wait…" : children}
    </button>
  );
}
