import { FormEvent, useEffect, useState } from "react";
import { BackButton } from "../../components/BackButton";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { PasswordField, TextField } from "../../components/Field";
import { Section } from "../../components/Section";
import { createPlayer, listPlayers, Player, setPlayerNumber } from "../../services/api";

// The lowest number from 1 to 99 nobody has yet (null if all are taken).
function lowestFree(taken: Set<number>): number | null {
  for (let n = 1; n <= 99; n++) if (!taken.has(n)) return n;
  return null;
}

export function CreatePlayerForm({ onCreated, onBack }: { onCreated: (player: Player) => void; onBack: () => void }) {
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [number, setNumber] = useState("");
  const [taken, setTaken] = useState<Map<number, string>>(new Map());
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Suggest the next free player number (the server would pick it anyway).
  useEffect(() => {
    listPlayers()
      .then((ps) => {
        const m = new Map<number, string>();
        for (const p of ps) if (p.playerNumber) m.set(p.playerNumber, p.displayName || p.username);
        setTaken(m);
        const free = lowestFree(new Set(m.keys()));
        setNumber((n) => (n === "" && free !== null ? String(free) : n));
      })
      .catch(() => {});
  }, []);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError(null);
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    let wanted: number | undefined;
    if (number.trim() !== "") {
      const n = Number(number);
      if (!Number.isInteger(n) || n < 1 || n > 99) {
        setError("Player number must be a whole number from 1 to 99, or empty to pick the next free one.");
        return;
      }
      if (taken.has(n)) {
        setError(`Number ${n} already belongs to ${taken.get(n)}. Pick another one.`);
        return;
      }
      wanted = n;
    }
    setLoading(true);
    try {
      let player = await createPlayer({ username, password, confirmPassword, displayName: displayName || undefined, playerNumber: wanted });
      // If the server gave a different number, ask for the chosen one. The
      // player exists either way; the number can be changed on their page.
      if (wanted !== undefined && player.playerNumber !== wanted) {
        try {
          player = await setPlayerNumber(player.id, wanted);
        } catch {
          // keep the number the server picked
        }
      }
      onCreated(player);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create player.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <BackButton label="Players" onClick={onBack} />
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Section title="New player">
          <ErrorBanner message={error} />
          <TextField
            id="player-username"
            label="Username"
            hint="What the player types to log in. Letters, numbers, dots, - or _."
            autoCapitalize="none"
            autoCorrect="off"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <TextField
            id="player-display-name"
            label="Display name (optional)"
            hint="The name shown in the app."
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
          />
          <TextField
            id="player-number"
            label="Player number"
            hint="Say this number first to call a hit: “three, forty” = Player 3 loses 40 HP. 1 to 99, each player has their own. Empty = next free number."
            type="number"
            inputMode="numeric"
            min={1}
            max={99}
            step={1}
            value={number}
            onChange={(e) => setNumber(e.target.value)}
          />
        </Section>
        <Section title="Password">
          <PasswordField
            id="player-password"
            label="Password"
            hint="At least 8 characters, with a letter and a number."
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <PasswordField
            id="player-confirm-password"
            label="Confirm password"
            autoComplete="new-password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </Section>
        <Button type="submit" loading={loading}>
          Create Player
        </Button>
      </form>
    </>
  );
}
