import { DatabaseSync } from "node:sqlite";
import { transaction } from "./db";

// Game rules the Admin can change (Game tab › "Game rules"). Each one lives
// in game_state as its own 'rule:<name>' row holding a JSON value. No row
// means "use the default", so a fresh or upgraded database needs no setup.

export interface GameRules {
  baseHp: number; // starting / base max HP of every player
  maxHpCap: number; // max HP can never go above this (herbs, Admin)
  caseCols: number; // columns in a player's case
  caseRows: number; // rows a case starts with
  caseMaxRows: number; // rows cap after backpack expansions
  voiceEnabled: boolean; // voice hit calls on/off
  voiceWindowMs: number; // the same call heard within this time counts once
  practiceFire: boolean; // before the game starts, guns test-fire without using ammo
  deathDrops: boolean; // a player who dies drops everything into the drop box
  returnDropsOnEnd: boolean; // when the game ends, unclaimed drops go back to their owner
}

export type RuleName = keyof GameRules;

export const DEFAULT_RULES: Readonly<GameRules> = Object.freeze({
  baseHp: 100,
  maxHpCap: 300,
  caseCols: 8,
  caseRows: 4,
  caseMaxRows: 9,
  voiceEnabled: true,
  voiceWindowMs: 4000,
  practiceFire: true,
  deathDrops: true,
  returnDropsOnEnd: true,
});

// The allowed range of each number rule. Two rules also depend on another
// one (the cap can't be below the base HP, the most rows can't be below the
// starting rows) — checked after the change is merged, see checkTogether.
export const RULE_LIMITS: Readonly<Record<string, { min: number; max: number }>> = Object.freeze({
  baseHp: { min: 10, max: 1000 },
  maxHpCap: { min: 10, max: 2000 },
  caseCols: { min: 4, max: 10 },
  caseRows: { min: 2, max: 10 },
  caseMaxRows: { min: 2, max: 12 },
  voiceWindowMs: { min: 1000, max: 15000 },
});

// Names used in error messages, written for the Admin.
const LABEL: Record<RuleName, string> = {
  baseHp: "Base HP",
  maxHpCap: "Max HP cap",
  caseCols: "Case columns",
  caseRows: "Starting case rows",
  caseMaxRows: "Most case rows",
  voiceEnabled: "Voice hit calls",
  voiceWindowMs: "Same-call window",
  practiceFire: "Practice firing",
  deathDrops: "Drop items on death",
  returnDropsOnEnd: "Return drops when the game ends",
};

const RULE_NAMES = Object.keys(DEFAULT_RULES) as RuleName[];
const KEY_PREFIX = "rule:";

// A rule change the Admin asked for that isn't allowed. The message is safe
// to show as-is.
export class RuleError extends Error {}

function isRuleName(name: string): name is RuleName {
  return (RULE_NAMES as string[]).includes(name);
}

// Reads every rule, falling back to the default for anything missing or
// unreadable, so a bad row can never stop the game from loading.
export function getRules(db: DatabaseSync): GameRules {
  const rules: GameRules = { ...DEFAULT_RULES };
  const rows = db
    .prepare("SELECT key, value FROM game_state WHERE key LIKE 'rule:%'")
    .all() as unknown as Array<{ key: string; value: string }>;
  for (const row of rows) {
    const name = row.key.slice(KEY_PREFIX.length);
    if (!isRuleName(name)) continue;
    let value: unknown;
    try {
      value = JSON.parse(row.value);
    } catch {
      continue;
    }
    const def = DEFAULT_RULES[name];
    if (typeof def === "boolean") {
      if (typeof value === "boolean") (rules as unknown as Record<string, unknown>)[name] = value;
    } else if (typeof value === "number" && Number.isInteger(value)) {
      const { min, max } = RULE_LIMITS[name];
      (rules as unknown as Record<string, unknown>)[name] = Math.min(max, Math.max(min, value));
    }
  }
  // Keep the pairs consistent even if rows were edited by hand.
  rules.maxHpCap = Math.max(rules.maxHpCap, rules.baseHp);
  rules.caseMaxRows = Math.max(rules.caseMaxRows, rules.caseRows);
  return rules;
}

export function getRule<K extends RuleName>(db: DatabaseSync, name: K): GameRules[K] {
  return getRules(db)[name];
}

// Checks one value on its own. Returns the clean value or throws RuleError.
function checkValue(name: RuleName, value: unknown): number | boolean {
  if (typeof DEFAULT_RULES[name] === "boolean") {
    if (typeof value !== "boolean") throw new RuleError(`${LABEL[name]} must be on or off.`);
    return value;
  }
  const { min, max } = RULE_LIMITS[name];
  if (typeof value !== "number" || !Number.isInteger(value) || value < min || value > max) {
    const unit = name === "voiceWindowMs" ? " milliseconds" : "";
    throw new RuleError(`${LABEL[name]} must be a whole number${unit} from ${min} to ${max}.`);
  }
  return value;
}

// Rules that depend on each other. The message says which one to change,
// based on what the Admin was editing.
function checkTogether(next: GameRules, changed: Set<RuleName>): void {
  if (next.maxHpCap < next.baseHp) {
    throw new RuleError(
      changed.has("maxHpCap")
        ? `The max HP cap can't be lower than the base HP (${next.baseHp}).`
        : `Base HP can't be more than the max HP cap (${next.maxHpCap}). Raise the cap first.`
    );
  }
  if (next.caseMaxRows < next.caseRows) {
    throw new RuleError(
      changed.has("caseMaxRows")
        ? `Most case rows can't be fewer than the starting rows (${next.caseRows}).`
        : `Starting case rows can't be more than the most case rows (${next.caseMaxRows}). Raise that first.`
    );
  }
}

// ---- Change hooks -----------------------------------------------------------

// Other parts of the game that must react when rules change register here,
// e.g. the case layout re-checks every player's case when its size changes
// (pieces that no longer fit go to the tray). Hooks run INSIDE the same
// database transaction as the change: if one fails, the change is undone.
export type RulesChangedHook = (db: DatabaseSync, rules: GameRules, previous: GameRules) => void;
const rulesHooks: RulesChangedHook[] = [];

export function onRulesChanged(fn: RulesChangedHook): () => void {
  rulesHooks.push(fn);
  return () => {
    const i = rulesHooks.indexOf(fn);
    if (i >= 0) rulesHooks.splice(i, 1);
  };
}

// Validates a partial change (straight from the Admin's request body — never
// trusted) and saves it in one step. Throws RuleError with a friendly message
// when anything is wrong; then nothing is saved.
export function updateRules(db: DatabaseSync, patch: unknown): GameRules {
  if (patch === null || typeof patch !== "object" || Array.isArray(patch)) {
    throw new RuleError("Send the rules to change.");
  }
  const entries = Object.entries(patch as Record<string, unknown>);
  const changed = new Set<RuleName>();
  const clean: Partial<Record<RuleName, number | boolean>> = {};
  for (const [name, value] of entries) {
    if (!isRuleName(name)) throw new RuleError(`"${name}" isn't a game rule.`);
    clean[name] = checkValue(name, value);
    changed.add(name);
  }

  return transaction(db, () => {
    const previous = getRules(db);
    const next = { ...previous, ...clean } as GameRules;
    checkTogether(next, changed);
    const differs = RULE_NAMES.some((n) => next[n] !== previous[n]);
    if (!differs) return previous;

    const save = db.prepare(
      `INSERT INTO game_state (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`
    );
    for (const name of changed) save.run(KEY_PREFIX + name, JSON.stringify(next[name]));
    for (const hook of rulesHooks) hook(db, next, previous);
    return next;
  });
}
