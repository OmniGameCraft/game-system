export function ErrorBanner({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="alert" className="rounded-sm border-l-4 border-alert bg-alert/10 px-4 py-3 font-medium text-ink">
      {message}
    </p>
  );
}
