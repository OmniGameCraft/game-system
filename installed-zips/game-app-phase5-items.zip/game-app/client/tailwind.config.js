/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#F3F4EE",
        ink: "#15211C",
        pine: { DEFAULT: "#1B4332", soft: "#DCE8E0" },
        sun: "#F2C230",
        alert: "#B3261E",
      },
      // System fonts only: nothing is fetched from the internet.
      fontFamily: {
        sans: ["system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"],
      },
    },
  },
  plugins: [],
};
