import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { requireRole } from "../auth/middleware";
import { InventoryRuleError, MAX_ITEM_QUANTITY } from "../database/inventory";
import { findItemById } from "../database/items";
import { InsufficientFundsError, toPublicTransaction } from "../database/money";
import { Track, TRACKS } from "../database/weapons";
import {
  createShopItem,
  deleteShopItem,
  findShopItem,
  findShopItemByItemId,
  isShopOpen,
  listRecentSales,
  listShopForAdmin,
  listShopForPlayer,
  MAX_PRICE,
  purchase,
  PurchaseError,
  sell,
  sellQuote,
  upgradeWeapon,
  setShopOpen,
  ShopItemFields,
  updateShopItem,
} from "../database/shop";

function isWhole(n: unknown, min: number, max: number): n is number {
  return typeof n === "number" && Number.isInteger(n) && n >= min && n <= max;
}

// Validates whichever shop fields are present. Nothing from the client is
// stored without passing through here.
function parseShopFields(b: any): { ok: true; fields: ShopItemFields } | { ok: false; error: string } {
  const fields: ShopItemFields = {};
  b = b ?? {};
  if (b.price !== undefined) {
    if (!isWhole(b.price, 0, MAX_PRICE)) {
      return { ok: false, error: `Price must be a whole number from 0 to ${MAX_PRICE}.` };
    }
    fields.price = b.price;
  }
  if (b.stock !== undefined) {
    if (b.stock !== null && !isWhole(b.stock, 0, MAX_ITEM_QUANTITY)) {
      return { ok: false, error: `Stock must be a whole number from 0 to ${MAX_ITEM_QUANTITY}, or empty for unlimited.` };
    }
    fields.stock = b.stock;
  }
  if (b.maxPerPurchase !== undefined) {
    if (b.maxPerPurchase !== null && !isWhole(b.maxPerPurchase, 1, MAX_ITEM_QUANTITY)) {
      return { ok: false, error: "Max per purchase must be a whole number of 1 or more, or empty for no limit." };
    }
    fields.maxPerPurchase = b.maxPerPurchase;
  }
  if (b.enabled !== undefined) {
    if (typeof b.enabled !== "boolean") return { ok: false, error: "Invalid enabled value." };
    fields.enabled = b.enabled;
  }
  return { ok: true, fields };
}

// ---- Admin: /api/admin/shop -------------------------------------------

export function createAdminShopRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  const snapshot = () => ({
    open: isShopOpen(db),
    listings: listShopForAdmin(db),
    sales: listRecentSales(db),
  });
  const listingById = (id: number) => listShopForAdmin(db).find((l) => l.id === id)!;

  router.get("/", (_req, res) => {
    res.json(snapshot());
  });

  router.post("/status", (req, res) => {
    const open = req.body?.open;
    if (typeof open !== "boolean") {
      res.status(400).json({ error: "Invalid shop status." });
      return;
    }
    setShopOpen(db, open);
    res.json({ open: isShopOpen(db) });
  });

  router.post("/items", (req, res) => {
    const itemId = req.body?.itemId;
    if (!isWhole(itemId, 1, Number.MAX_SAFE_INTEGER) || !findItemById(db, itemId)) {
      res.status(400).json({ error: "Choose an item." });
      return;
    }
    if (findShopItemByItemId(db, itemId)) {
      res.status(409).json({ error: "That item is already in the shop." });
      return;
    }
    if (req.body?.price === undefined) {
      res.status(400).json({ error: "Enter a price." });
      return;
    }
    const parsed = parseShopFields(req.body);
    if (!parsed.ok) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    const f = parsed.fields;
    const id = createShopItem(db, itemId, {
      price: f.price!,
      stock: f.stock ?? null,
      maxPerPurchase: f.maxPerPurchase ?? null,
      enabled: f.enabled ?? true,
    });
    res.status(201).json({ listing: listingById(id) });
  });

  router.patch("/items/:id", (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || !findShopItem(db, id)) {
      res.status(404).json({ error: "That item isn't in the shop." });
      return;
    }
    const parsed = parseShopFields(req.body);
    if (!parsed.ok) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    updateShopItem(db, id, parsed.fields);
    res.json({ listing: listingById(id) });
  });

  router.delete("/items/:id", (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || !findShopItem(db, id)) {
      res.status(404).json({ error: "That item isn't in the shop." });
      return;
    }
    deleteShopItem(db, id);
    res.status(204).end();
  });

  router.get("/sales", (_req, res) => {
    res.json({ sales: listRecentSales(db) });
  });

  return router;
}

// ---- Player: /api/shop ------------------------------------------------

export function createPlayerShopRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("player"));

  // Closed shop = no item list at all, not just a flag the client could ignore.
  router.get("/", (req, res) => {
    const open = isShopOpen(db);
    res.json({ open, listings: open ? listShopForPlayer(db, req.user!.id) : [] });
  });

  // POST /api/shop/purchase  Body: { shopItemId, quantity, expectedPrice? }. Who is buying comes
  // only from the session; the price charged only from the database.
  router.post("/purchase", (req, res) => {
    const { shopItemId, quantity, expectedPrice } = req.body ?? {};
    if (!isWhole(shopItemId, 1, Number.MAX_SAFE_INTEGER)) {
      res.status(400).json({ error: "Choose an item." });
      return;
    }
    if (!isWhole(quantity, 1, MAX_ITEM_QUANTITY)) {
      res.status(400).json({ error: "Choose a valid quantity." });
      return;
    }
    if (expectedPrice !== undefined && !isWhole(expectedPrice, 0, MAX_PRICE)) {
      res.status(400).json({ error: "Invalid request." });
      return;
    }
    try {
      const result = purchase(db, {
        playerId: req.user!.id,
        shopItemId,
        quantity,
        expectedPrice,
      });
      const tx = toPublicTransaction(result.transaction);
      res.json({
        balance: result.balance,
        quantity: tx.quantity,
        total: tx.amount,
        itemName: tx.itemName,
        owned: result.owned,
        stock: result.stock,
        transaction: tx,
      });
    } catch (err) {
      if (err instanceof PurchaseError) {
        res.status(err.code === "GONE" ? 404 : err.code === "PRICE_CHANGED" ? 409 : 400).json({
          error: err.message,
          code: err.code,
        });
        return;
      }
      if (err instanceof InsufficientFundsError || err instanceof InventoryRuleError) {
        res.status(400).json({ error: err.message });
        return;
      }
      res.status(500).json({ error: "Unable to complete purchase. Please try again." });
    }
  });

  // Turns a failed shop action into the right status + a message the
  // player can act on.
  function sendShopError(res: import("express").Response, err: unknown, fallback: string) {
    if (err instanceof PurchaseError) {
      res.status(err.code === "GONE" ? 404 : err.code === "PRICE_CHANGED" ? 409 : 400).json({
        error: err.message,
        code: err.code,
      });
      return;
    }
    if (err instanceof InsufficientFundsError || err instanceof InventoryRuleError) {
      res.status(400).json({ error: err.message });
      return;
    }
    res.status(500).json({ error: fallback });
  }

  // POST /api/shop/sell-quote  { itemId, quantity }  (quantity = packs for ammo)
  // The only place a player learns what the shop will pay. It changes nothing.
  router.post("/sell-quote", (req, res) => {
    const { itemId, quantity } = req.body ?? {};
    if (!isWhole(itemId, 1, Number.MAX_SAFE_INTEGER) || !isWhole(quantity, 1, MAX_ITEM_QUANTITY)) {
      res.status(400).json({ error: "Choose what to sell and how many." });
      return;
    }
    try {
      res.json(sellQuote(db, { playerId: req.user!.id, itemId, quantity }));
    } catch (err) {
      sendShopError(res, err, "Couldn't get an offer. Please try again.");
    }
  });

  // POST /api/shop/sell  { itemId, quantity, expectedAmount? }
  router.post("/sell", (req, res) => {
    const { itemId, quantity, expectedAmount } = req.body ?? {};
    if (!isWhole(itemId, 1, Number.MAX_SAFE_INTEGER) || !isWhole(quantity, 1, MAX_ITEM_QUANTITY)) {
      res.status(400).json({ error: "Choose what to sell and how many." });
      return;
    }
    if (expectedAmount !== undefined && !isWhole(expectedAmount, 0, Number.MAX_SAFE_INTEGER)) {
      res.status(400).json({ error: "Invalid request." });
      return;
    }
    try {
      const r = sell(db, { playerId: req.user!.id, itemId, quantity, expectedAmount });
      res.json({ balance: r.balance, amount: r.amount, itemName: r.itemName, owned: r.owned, transaction: toPublicTransaction(r.transaction) });
    } catch (err) {
      sendShopError(res, err, "Unable to sell right now. Please try again.");
    }
  });

  // POST /api/shop/upgrade  { itemId, track, expectedCost? }
  router.post("/upgrade", (req, res) => {
    const { itemId, track, expectedCost } = req.body ?? {};
    if (!isWhole(itemId, 1, Number.MAX_SAFE_INTEGER) || !TRACKS.includes(track)) {
      res.status(400).json({ error: "Choose a weapon and an upgrade." });
      return;
    }
    if (expectedCost !== undefined && !isWhole(expectedCost, 0, Number.MAX_SAFE_INTEGER)) {
      res.status(400).json({ error: "Invalid request." });
      return;
    }
    try {
      res.json(upgradeWeapon(db, { playerId: req.user!.id, itemId, track: track as Track, expectedCost }));
    } catch (err) {
      sendShopError(res, err, "Unable to upgrade right now. Please try again.");
    }
  });

  return router;
}
