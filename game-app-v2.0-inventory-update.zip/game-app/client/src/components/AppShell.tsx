import { ReactNode } from "react";
import { Icon, IconName } from "./Icon";
import { CrosshairLogo } from "./Brand";
import { useLiveStatus } from "../services/live";
import { playSfx } from "../audio/sfx";
import { APP_NAME, COMPANY } from "../version";

export interface Tab<K extends string> {
  key: K;
  label: string;
  icon: IconName;
}

// The frame around every logged-in screen:
//  - a slim top bar like a game HUD: logo + live signal on the left; status
//    pills (HP, microphone), money and the Settings gear on the right
//  - the screen's title at the top of the page
//  - the main tabs: a bottom bar on phones (easy to reach with a thumb) and a
//    sidebar on bigger screens
// Switching tabs plays a soft tab sound and the new screen fades in.
export function AppShell<K extends string>({
  title,
  subtitle,
  right,
  status,
  tabs,
  active,
  onTab,
  onLogout,
  onSettings,
  children,
}: {
  title: string;
  subtitle: string;
  right?: ReactNode;
  status?: ReactNode; // extra pills in the top bar (HP, mic indicator)
  tabs: Tab<K>[];
  active: K;
  onTab: (k: K) => void;
  onLogout: () => void;
  onSettings?: () => void; // shows a gear button that opens Settings
  children: ReactNode;
}) {
  function pick(k: K) {
    if (k !== active) playSfx("tab");
    onTab(k);
  }

  return (
    <div className="min-h-screen md:flex">
      {/* ---- sidebar (tablets / computers) ---- */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col gap-1.5 border-r border-panel-line bg-gradient-to-b from-[#16181b] to-[#0d0e10] p-4 shadow-[inset_-1px_0_0_rgba(255,255,255,0.04)] md:flex">
        <div className="flex items-center gap-2.5 px-2 pb-5 pt-1">
          <CrosshairLogo className="h-9 w-9" />
          <div className="min-w-0">
            <p className="font-display text-xl font-bold leading-none text-ink">{APP_NAME}</p>
            <p className="mt-1 text-[0.625rem] font-semibold uppercase tracking-[0.22em] text-steel">{COMPANY}</p>
          </div>
        </div>
        {tabs.map((t) => {
          const on = active === t.key;
          return (
            <button
              key={t.key}
              data-sound="none"
              onClick={() => pick(t.key)}
              aria-current={on ? "page" : undefined}
              className={`press relative flex items-center gap-3 rounded-md px-3 py-3 text-left font-display text-lg font-semibold transition-colors ${
                on
                  ? "bg-gradient-to-r from-pine/20 to-transparent text-pine shadow-[inset_2px_0_0_#F5A524]"
                  : "text-ink/70 hover:bg-ink/5"
              }`}
            >
              <Icon name={t.icon} />
              {t.label}
            </button>
          );
        })}
        <div className="mt-auto flex flex-col gap-1.5 border-t border-panel-line pt-3">
          {onSettings && (
            <button
              onClick={onSettings}
              data-sound="none"
              className="press flex items-center gap-3 rounded-md px-3 py-3 text-left font-semibold text-ink/70 hover:bg-ink/5"
            >
              <Icon name="gear" />
              Settings
            </button>
          )}
          <button
            onClick={onLogout}
            className="press flex items-center gap-3 rounded-md px-3 py-3 text-left font-semibold text-ink/60 hover:bg-ink/5"
          >
            <Icon name="logout" />
            Log out
          </button>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        {/* ---- top bar ---- */}
        {/* The bar reaches up under the phone's status bar / notch, so page
            content never shows through above it while scrolling. */}
        <header
          className="sticky top-0 z-20 border-b border-black/80 bg-gradient-to-b from-[#1b1d21]/95 to-[#121316]/95 shadow-[inset_0_-1px_0_rgba(255,255,255,0.05),0_6px_16px_-10px_rgba(0,0,0,0.9)] backdrop-blur"
          style={{ marginTop: "calc(-1 * env(safe-area-inset-top))", paddingTop: "env(safe-area-inset-top)" }}
        >
          <div className="mx-auto flex h-14 max-w-2xl items-center gap-2 px-3">
            <div className="flex min-w-0 flex-1 items-center">
              <LiveLogo />
            </div>
            {status && <div className="flex shrink-0 items-center gap-1.5">{status}</div>}
            {right}
            {onSettings && (
              <button
                onClick={onSettings}
                data-sound="none" /* Settings plays its own "open" sound */
                aria-label="Settings"
                className="icon-btn h-10 w-10 shrink-0 text-ink/80 active:text-pine"
              >
                <Icon name="gear" className="h-[22px] w-[22px]" />
              </button>
            )}
          </div>
        </header>

        {/* ---- page ---- (keyed on the tab so each new tab animates in) */}
        <main key={active} className="relative mx-auto flex max-w-2xl animate-page-in flex-col gap-4 px-4 pb-32 pt-4 md:pb-10">
          <div className="flex flex-col gap-0.5 px-0.5">
            <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-steel">
              <span className="truncate">{subtitle}</span>
              <LiveDot />
            </p>
            <h1 className="truncate font-display text-[1.75rem] font-bold leading-tight text-ink">{title}</h1>
          </div>
          {children}
        </main>
      </div>

      {/* ---- bottom tabs (phones) ---- */}
      <nav
        aria-label="Main"
        className="fixed inset-x-0 bottom-0 z-20 border-t border-black bg-gradient-to-b from-[#1a1c20] to-[#0c0d0f] shadow-[inset_0_1px_0_rgba(255,255,255,0.07),0_-8px_20px_-12px_rgba(0,0,0,0.9)] md:hidden"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="mx-auto grid max-w-2xl" style={{ gridTemplateColumns: `repeat(${tabs.length}, 1fr)` }}>
          {tabs.map((t) => {
            const on = active === t.key;
            return (
              <button
                key={t.key}
                data-sound="none"
                onClick={() => pick(t.key)}
                aria-current={on ? "page" : undefined}
                className={`relative flex min-h-[4rem] flex-col items-center justify-center gap-1 pb-2 pt-2 font-display text-[0.8125rem] font-semibold transition-colors duration-150 ${
                  on ? "text-ink" : "text-ink/45 active:text-ink/70"
                }`}
              >
                {/* active tab: amber bar along the top edge, like a HUD selector */}
                <span
                  className={`absolute inset-x-5 top-0 h-[3px] rounded-b-full transition-all duration-200 ${
                    on ? "bg-pine opacity-100 shadow-[0_0_10px_rgba(245,165,36,0.8)]" : "scale-x-50 bg-pine opacity-0"
                  }`}
                  aria-hidden
                />
                <span
                  className={`flex h-8 w-11 items-center justify-center rounded-md transition-all duration-200 ${
                    on
                      ? "bg-pine/[0.14] text-pine shadow-[inset_0_0_0_1px_rgba(245,165,36,0.35)]"
                      : "text-current"
                  }`}
                >
                  <Icon name={t.icon} className={`h-6 w-6 transition-transform duration-200 ${on ? "scale-110" : ""}`} />
                </span>
                {t.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

// The logo in the top bar, with a small status light: green = live updates
// flowing, amber blinking = reconnecting.
function LiveLogo() {
  const live = useLiveStatus();
  return (
    <span className="relative inline-flex shrink-0" title={live ? "Live" : "Reconnecting…"}>
      <CrosshairLogo className="h-8 w-8" />
      <span
        className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-[#15171a] ${
          live ? "bg-olive" : "animate-pulse bg-sun"
        }`}
        aria-hidden
      />
    </span>
  );
}

// Shows whether live updates are flowing. Green = connected; amber =
// trying to reconnect (the app still works, it just won't update by itself).
function LiveDot() {
  const live = useLiveStatus();
  return (
    <span
      className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2 py-0.5 text-[0.6875rem] font-bold normal-case tracking-normal ${
        live ? "border-olive/30 bg-olive-soft text-olive" : "border-sun/40 bg-sun/15 text-sun"
      }`}
      aria-live="polite"
    >
      <span className="relative flex h-1.5 w-1.5">
        {live && <span className="absolute inset-0 animate-ping-soft rounded-full bg-olive" aria-hidden />}
        <span className={`relative h-1.5 w-1.5 rounded-full ${live ? "bg-olive" : "bg-sun"}`} />
      </span>
      {live ? "Live" : "Reconnecting…"}
    </span>
  );
}
