import { useRef } from "react";
import { Icon } from "../components/Icon";
import type { HerbCode, Piece } from "./caseApi";
import { effectOfCode, HERB_COLOR, HERB_NAME, healText, mixOf } from "./herbs";
import { PieceArt } from "./PieceView";
import { Reason } from "./ItemActionSheet";
import { Sheet, SheetButton } from "./Sheet";

// "Combine" for herbs: lists the other herbs you carry with what each mix
// would make ("Mixed Herb (G+Y) — Heals 45 HP"). Mixes that don't work are
// shown greyed out with the reason, so players learn the rules by looking.

const GUIDE: Array<{ code: HerbCode; parts: string }> = [
  { code: "GG", parts: "G + G" },
  { code: "GY", parts: "G + Y" },
  { code: "GR", parts: "G + R" },
  { code: "GRY", parts: "G + R + Y" },
  { code: "GGY", parts: "G + G + Y" },
];

export function CombineSheet({
  open,
  piece: pieceNow,
  everything,
  busyWith,
  blockedReason,
  onPick,
  onBack,
  onClose,
}: {
  open: boolean;
  piece: Piece | null;
  everything: Piece[]; // case + tray
  busyWith: number | null; // piece id being mixed right now
  blockedReason: string | null; // dead / paused / ended
  onPick: (source: Piece, target: Piece) => void;
  onBack: () => void;
  onClose: () => void;
}) {
  const last = useRef<Piece | null>(pieceNow);
  if (pieceNow) last.current = pieceNow;
  const piece = pieceNow ?? last.current;
  if (!piece || !piece.herbCode) return null;
  const src = piece;
  const srcCode = piece.herbCode;

  // One row per kind of herb (three loose Green Herbs show as one "×3" row).
  const groups = new Map<number, Piece[]>();
  for (const p of everything) {
    if (p.id === src.id || !p.herbCode) continue;
    const g = groups.get(p.itemId) ?? [];
    g.push(p);
    groups.set(p.itemId, g);
  }
  const rows = [...groups.values()]
    .map((list) => {
      // Prefer a piece that's in the case over one set aside in the tray.
      const pick = list.find((p) => p.x !== null) ?? list[0];
      const mix = mixOf(srcCode, pick.herbCode!);
      return { pick, count: list.reduce((n, p) => n + p.quantity, 0), mix };
    })
    .sort((a, b) => Number(b.mix.ok) - Number(a.mix.ok));

  return (
    <Sheet
      open={open}
      onClose={onClose}
      label={`Combine ${src.name}`}
      footer={
        <div className="grid grid-cols-2 gap-2">
          <SheetButton onClick={onBack} icon={<Icon name="back" className="h-5 w-5" />} sound>
            Back
          </SheetButton>
          <SheetButton onClick={onClose} icon={<Icon name="close" className="h-5 w-5" />}>
            Close
          </SheetButton>
        </div>
      }
    >
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <div className="cs-sheet-pic h-16 w-16 shrink-0">
            <PieceArt piece={src} cell={64} rotated={false} numbers={false} />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-white/45">Combine</p>
            <h2 className="font-display text-2xl font-bold leading-tight">Mix {src.name} with…</h2>
          </div>
        </div>

        {blockedReason && <Reason text={blockedReason} />}

        {rows.length === 0 ? (
          <div className="flex flex-col items-center gap-2 rounded-sm border border-dashed border-white/15 px-4 py-6 text-center">
            <Icon name="combine" className="h-9 w-9 text-white/30" />
            <p className="font-display text-lg font-bold">No other herbs to mix with</p>
            <p className="text-sm text-ink/65">Every mix needs a Green Herb. Buy one in the Shop or check the Drop box.</p>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {rows.map(({ pick, count, mix }, i) => {
              const effect = mix.ok ? healText(effectOfCode(mix.code, everything)) : null;
              const disabled = !mix.ok || !!blockedReason || busyWith !== null;
              return (
                <li key={pick.itemId} className="cs-stagger" style={{ animationDelay: `${i * 40}ms` }}>
                  <button
                    type="button"
                    data-sound="none"
                    disabled={disabled}
                    onClick={() => onPick(src, pick)}
                    className={`cs-mix-row ${mix.ok ? "is-ok" : "is-no"}`}
                  >
                    <span className="cs-sheet-pic h-12 w-12 shrink-0">
                      <PieceArt piece={pick} cell={48} rotated={false} numbers={false} />
                    </span>
                    <span className="flex min-w-0 flex-1 flex-col text-left">
                      <span className="truncate font-semibold text-white">
                        {pick.name}
                        {count > 1 && <span className="text-white/50"> ×{count}</span>}
                      </span>
                      {mix.ok ? (
                        <span className="text-sm font-semibold text-[#8BE36B]">
                          → {mix.name}
                          <span className="block font-normal text-white/70">{effect}</span>
                        </span>
                      ) : (
                        <span className="text-sm text-alert">{mix.reason}</span>
                      )}
                    </span>
                    {mix.ok && (
                      <span className="flex shrink-0 items-center gap-1 rounded-sm bg-pine px-3 py-2 font-display font-bold text-pine-ink">
                        {busyWith === pick.id ? "…" : "Mix"}
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        )}

        <details className="cs-guide">
          <summary>Mixing guide</summary>
          <ul className="mt-2 flex flex-col gap-1.5">
            {GUIDE.map((g) => (
              <li key={g.code} className="flex items-center gap-2 text-sm">
                <span className="flex w-16 shrink-0 gap-0.5">
                  {g.code.split("").map((l, i) => (
                    <span key={i} className="h-3 w-3 rounded-full border border-black/40" style={{ background: HERB_COLOR[l] }} />
                  ))}
                </span>
                <span className="w-24 shrink-0 font-semibold text-white/80">{g.parts}</span>
                <span className="min-w-0 text-white/65">{healText(effectOfCode(g.code, everything))}</span>
              </li>
            ))}
            <li className="pt-1 text-xs text-white/50">
              A Green Herb is needed in every mix. Red or Yellow alone do nothing. {HERB_NAME.G} alone: {healText(effectOfCode("G", everything))}.
            </li>
          </ul>
        </details>
      </div>
    </Sheet>
  );
}
