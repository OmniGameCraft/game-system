import type { NextFunction, Request, Response } from "express";
import type { DatabaseSync } from "node:sqlite";
import { destroySession, getSessionUser, getToken } from "./sessions";
import { findById } from "../database/users";
import type { PublicUser, Role } from "../database/users";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: PublicUser;
    }
  }
}

// Runs on every request. For an Admin session, this also checks that the
// token in this request's cookie still matches the one and only session the
// account is currently allowed to use — set by /api/auth/login each time
// that account logs in anywhere. If another device has since logged in as
// the same Admin, this token no longer matches, the session is torn down
// right here, and req.user is left unset (so requireAuth/requireRole reject
// the request as if the visitor were never logged in).
export function attachUser(db: DatabaseSync) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = getSessionUser(req);
    if (!user) {
      next();
      return;
    }

    if (user.role === "admin") {
      const token = getToken(req);
      const current = findById(db, user.id);
      if (!current || current.active_session_token !== token) {
        destroySession(req, res);
        next();
        return;
      }
    }

    req.user = user;
    next();
  };
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({ error: "Please log in to continue." });
    return;
  }
  next();
}

export function requireRole(role: Role) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: "Please log in to continue." });
      return;
    }
    if (req.user.role !== role) {
      res.status(403).json({ error: "You don't have access to this." });
      return;
    }
    next();
  };
}
