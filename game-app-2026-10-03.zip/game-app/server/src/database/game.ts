import { DatabaseSync } from "node:sqlite";

export type GameStatus = "not_started" | "active" | "paused" | "ended";
export const GAME_STATUSES: GameStatus[] = ["not_started", "active", "paused", "ended"];
export const ANNOUNCEMENT_MAX = 300;

export function getGameStatus(db: DatabaseSync): { status: GameStatus; changedAt: string | null } {
  const row = db.prepare("SELECT value FROM game_state WHERE key = 'game_status'").get() as
    | { value: string }
    | undefined;
  const at = db.prepare("SELECT value FROM game_state WHERE key = 'game_status_at'").get() as
    | { value: string }
    | undefined;
  const status = GAME_STATUSES.includes(row?.value as GameStatus) ? (row!.value as GameStatus) : "not_started";
  return { status, changedAt: at?.value ?? null };
}

// Purchases are allowed before the game and while it runs, not while it is
// paused or after it has ended.
export function gameAllowsPlay(db: DatabaseSync): { ok: true } | { ok: false; reason: string } {
  const { status } = getGameStatus(db);
  if (status === "paused") return { ok: false, reason: "The game is paused." };
  if (status === "ended") return { ok: false, reason: "The game is over." };
  return { ok: true };
}

function setState(db: DatabaseSync, key: string, value: string) {
  db.prepare(
    `INSERT INTO game_state (key, value) VALUES (?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  ).run(key, value);
}

export function setGameStatus(db: DatabaseSync, status: GameStatus, adminId: number): void {
  db.exec("BEGIN");
  try {
    setState(db, "game_status", status);
    setState(db, "game_status_at", new Date().toISOString());
    db.prepare("INSERT INTO game_events (type, status, created_by) VALUES ('STATUS', ?, ?)").run(status, adminId);
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

export function addAnnouncement(db: DatabaseSync, message: string, playerId: number | null, adminId: number): void {
  db.prepare("INSERT INTO game_events (type, message, player_id, created_by) VALUES ('ANNOUNCEMENT', ?, ?, ?)").run(
    message,
    playerId,
    adminId
  );
}

export interface GameEvent {
  id: number;
  type: "STATUS" | "ANNOUNCEMENT";
  status: GameStatus | null;
  message: string | null;
  playerId: number | null;
  playerName: string | null;
  createdAt: string;
}

interface EventRow {
  id: number;
  type: "STATUS" | "ANNOUNCEMENT";
  status: GameStatus | null;
  message: string | null;
  player_id: number | null;
  player_name: string | null;
  created_at: string;
}

const toEvent = (r: EventRow): GameEvent => ({
  id: r.id,
  type: r.type,
  status: r.status,
  message: r.message,
  playerId: r.player_id,
  playerName: r.player_name,
  createdAt: r.created_at,
});

export function listEventsForAdmin(db: DatabaseSync, limit = 50): GameEvent[] {
  return (
    db
      .prepare(
        `SELECT e.*, COALESCE(u.display_name, u.username) AS player_name
           FROM game_events e LEFT JOIN users u ON u.id = e.player_id
          ORDER BY e.id DESC LIMIT ?`
      )
      .all(limit) as unknown as EventRow[]
  ).map(toEvent);
}

// A player sees announcements sent to everyone, plus ones sent to them.
// Never another player's private messages.
export function listAnnouncementsForPlayer(db: DatabaseSync, playerId: number, limit = 20): GameEvent[] {
  return (
    db
      .prepare(
        `SELECT e.*, NULL AS player_name FROM game_events e
          WHERE e.type = 'ANNOUNCEMENT' AND (e.player_id IS NULL OR e.player_id = ?)
          ORDER BY e.id DESC LIMIT ?`
      )
      .all(playerId, limit) as unknown as EventRow[]
  ).map(toEvent);
}

// "Start a new game": clear everything that happened in a round, keep the
// set-up. Player accounts, items (with pictures/models/sounds) and the
// shop's listings stay; money, bags, all histories, announcements and stock
// counts sold go back to the start. One transaction: all or nothing.
export function resetRound(db: DatabaseSync): void {
  db.exec("BEGIN");
  try {
    db.exec(`
      DELETE FROM inventory;
      DELETE FROM weapon_upgrades;
      DELETE FROM inventory_log;
      DELETE FROM transactions;
      DELETE FROM game_events;
      UPDATE users SET balance = 0 WHERE role = 'player';
      DELETE FROM game_state WHERE key IN ('game_status', 'game_status_at', 'shop_open');
    `);
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
