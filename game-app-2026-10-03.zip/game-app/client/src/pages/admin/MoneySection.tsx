import { useEffect, useState } from "react";
import { useLive } from "../../services/live";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls } from "../../components/Field";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import { TransactionList } from "../../components/TransactionList";
import { adjustPlayerMoney, getPlayerTransactions, Transaction } from "../../services/api";

export function MoneySection({
  playerId,
  balance,
  onBalanceChange,
}: {
  playerId: number;
  balance: number;
  onBalanceChange: (balance: number) => void;
}) {
  const [amount, setAmount] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [pending, setPending] = useState<"ADD" | "REMOVE" | null>(null);
  const [transactions, setTransactions] = useState<Transaction[] | null>(null);
  const [txError, setTxError] = useState<string | null>(null);

  const [tick, setTick] = useState(0);
  useLive(["player:changed"], (payload) => {
    if (!payload || payload.playerId === playerId) setTick((t) => t + 1);
  });

  useEffect(() => {
    getPlayerTransactions(playerId)
      .then(setTransactions)
      .catch((err) => setTxError(err instanceof Error ? err.message : "Failed to load."));
  }, [playerId, tick]);

  async function handleAdjust(type: "ADD" | "REMOVE") {
    setError(null);
    setNotice(null);
    const parsed = Number(amount);
    if (!Number.isInteger(parsed) || parsed <= 0) {
      setError("Enter a whole number greater than 0.");
      return;
    }
    setPending(type);
    try {
      const result = await adjustPlayerMoney(playerId, { type, amount: parsed });
      onBalanceChange(result.balance);
      setTransactions((prev) => [result.transaction, ...(prev ?? [])]);
      setAmount("");
      setNotice(type === "ADD" ? `Added $${parsed}.` : `Removed $${parsed}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not complete the transaction.");
    } finally {
      setPending(null);
    }
  }

  return (
    <>
      <Section title="Money">
        <div className="rounded-md bg-pine-soft px-4 py-3">
          <p className="text-sm font-semibold text-ink/60">Current balance</p>
          <p className="text-4xl font-display font-bold tabular-nums text-pine">${balance}</p>
        </div>
        <ErrorBanner message={error} />
        <Notice message={notice} />
        <label htmlFor="money-amount" className="block">
          <span className="mb-1 block text-base font-semibold text-ink/80">Amount</span>
          <input
            id="money-amount"
            type="number"
            inputMode="numeric"
            min={1}
            step={1}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className={inputCls}
            placeholder="e.g. 100"
          />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <Button onClick={() => handleAdjust("ADD")} loading={pending === "ADD"} disabled={pending !== null}>
            + Add
          </Button>
          <Button variant="danger" onClick={() => handleAdjust("REMOVE")} loading={pending === "REMOVE"} disabled={pending !== null}>
            − Remove
          </Button>
        </div>
      </Section>

      <Section title="Money history" flush>
        <ErrorBanner message={txError} />
        {transactions ? <TransactionList transactions={transactions} /> : !txError && <p className="p-4 text-ink/60">Loading…</p>}
      </Section>
    </>
  );
}
