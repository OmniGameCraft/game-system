// Which release of the app this is. Shown in Settings › About on the phones
// (the client has its own copy in client/src/version.ts — keep both the same)
// and reported by GET /api/health, so you can check what a server is running.
export const APP_NAME = "Game System";
export const APP_VERSION = "2.0.0";
export const APP_EDITION = "Inventory Update";
export const COMPANY = "OmniGameCraft";
export const CREATORS = ["Abdul Hadi", "Sheheryar Azam"];
