import type { Server as HttpServer } from "http";
import type { DatabaseSync } from "node:sqlite";
import { Server } from "socket.io";
import type { NextFunction, Request, Response } from "express";
import { sessionFromCookieHeader, setSessionHooks } from "./auth/sessions";
import { findById } from "./database/users";

// Live updates (Phase 7). The server only ever sends short "something
// changed" notices; each screen then re-loads its data through the normal,
// authorised HTTP API. So a notice never carries anyone's private data, and
// a missed notice is fixed by the next one or by the Refresh button.
//
// Rooms:
//   user:<id>     one account (all of its tabs/phones)
//   role:admin    the Admin
//   role:player   every player
//
// Events sent to clients:
//   me:changed        (to one player) their balance/inventory changed
//   player:changed    (to admin) {playerId} money/items/profile changed
//   players:changed   (to admin) the player list changed
//   items:changed     (to everyone) item names/pictures/models changed
//   shop:changed      (to everyone) open/closed, prices, stock, listings
//   game:changed      (to everyone, or one player + admin) status/announcements
//   session:ended     (to one account) you've been signed out
let io: Server | null = null;

export function attachRealtime(servers: HttpServer[], db: DatabaseSync): void {
  io = new Server({
    serveClient: false, // the client library is bundled into the app itself
    cors: { origin: false },
  });
  for (const s of servers) io.attach(s);

  io.use((socket, next) => {
    const session = sessionFromCookieHeader(socket.handshake.headers.cookie);
    if (!session) return next(new Error("unauthorized"));
    const current = findById(db, session.user.id);
    if (!current || current.status === "disabled") return next(new Error("unauthorized"));
    // Same single-Admin-session rule as the HTTP API.
    if (current.role === "admin" && current.active_session_token !== session.token) {
      return next(new Error("unauthorized"));
    }
    socket.data.userId = current.id;
    socket.data.role = current.role;
    socket.data.token = session.token;
    next();
  });

  setSessionHooks({
    revoked: (userId) => live.endSessionsForUser(userId, "signed-out"),
    destroyed: (token) => live.endToken(token),
  });

  io.on("connection", (socket) => {
    socket.join(`user:${socket.data.userId}`);
    socket.join(`role:${socket.data.role}`);
  });
}

export const live = {
  playerChanged(playerId: number) {
    io?.to(`user:${playerId}`).emit("me:changed");
    io?.to("role:admin").emit("player:changed", { playerId });
  },
  playersChanged() {
    io?.to("role:admin").emit("players:changed");
  },
  itemsChanged() {
    io?.emit("items:changed");
  },
  // Game status changed or an announcement went to everyone.
  gameChanged() {
    io?.emit("game:changed");
  },
  // An announcement for one player only.
  announcementTo(playerId: number) {
    io?.to(`user:${playerId}`).emit("game:changed");
    io?.to("role:admin").emit("game:changed");
  },
  // After "start a new game": every screen reloads everything.
  everythingChanged() {
    io?.emit("game:changed");
    io?.emit("shop:changed");
    io?.emit("items:changed");
    io?.to("role:player").emit("me:changed");
    io?.to("role:admin").emit("players:changed");
  },
  shopChanged() {
    io?.emit("shop:changed");
  },
  // Sign out every live connection of one account (player disabled,
  // password reset, or the Admin logged in somewhere else).
  endSessionsForUser(userId: number, reason: string, exceptToken?: string) {
    if (!io) return;
    for (const socket of io.of("/").sockets.values()) {
      if (socket.data.userId === userId && socket.data.token !== exceptToken) {
        socket.emit("session:ended", { reason });
        socket.disconnect(true);
      }
    }
  },
  // One device logging out: close only that device's connections.
  endToken(token: string) {
    if (!io) return;
    for (const socket of io.of("/").sockets.values()) {
      if (socket.data.token === token) socket.disconnect(true);
    }
  },
};

// Express middleware: run `fn` once a data-changing request (not GET) has
// finished successfully. Keeps the notices out of every individual handler.
// `path` is captured when the request arrives (relative to where the
// middleware is mounted, e.g. "/12/money"), because Express rewrites
// req.url while routing.
export function notifyAfter(fn: (req: Request, path: string) => void) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.method !== "GET") {
      const path = req.path;
      res.on("finish", () => {
        if (res.statusCode < 400) {
          try {
            fn(req, path);
          } catch {
            // a failed notice must never break the request
          }
        }
      });
    }
    next();
  };
}
