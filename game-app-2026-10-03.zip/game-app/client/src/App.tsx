import { useEffect, useState } from "react";
import { AdminSetupForm } from "./pages/AdminSetupForm";
import { LoginForm } from "./pages/LoginForm";
import { RoleSelect } from "./pages/RoleSelect";
import { AdminHome } from "./pages/AdminHome";
import { PlayerHome } from "./pages/PlayerHome";
import { setUnauthorizedHandler } from "./services/authEvents";
import { connectLive, disconnectLive, useLive } from "./services/live";
import {
  AuthStatus,
  getAuthStatus,
  getCurrentUser,
  logout as apiLogout,
  PublicUser,
  Role,
} from "./services/api";

type Screen = { name: "loading" } | { name: "role" } | { name: "login"; role: Role };

export default function App() {
  const [status, setStatus] = useState<AuthStatus | null>(null);
  const [user, setUser] = useState<PublicUser | null | undefined>(undefined); // undefined = not checked yet
  const [screen, setScreen] = useState<Screen>({ name: "loading" });
  const [loadError, setLoadError] = useState(false);
  const [signedOutNotice, setSignedOutNotice] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    Promise.all([getAuthStatus(), getCurrentUser()])
      .then(([s, u]) => {
        if (!alive) return;
        setStatus(s);
        setUser(u);
        setScreen({ name: "role" });
      })
      .catch(() => alive && setLoadError(true));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(() => {
      setUser(null);
      setScreen({ name: "role" });
    });
    return () => setUnauthorizedHandler(null);
  }, []);

  // Live updates run only while someone is logged in.
  const userId = user?.id;
  useEffect(() => {
    if (userId) connectLive();
    else disconnectLive();
  }, [userId]);

  // The server signed this device out (account disabled, password reset,
  // or the Admin logged in on another device).
  useLive(["session:ended"], () => {
    disconnectLive();
    setUser(null);
    setScreen({ name: "role" });
    setSignedOutNotice("You were signed out. Please log in again.");
  }, false);

  // A player's balance lives in `user` (shown in the top bar), so keep it fresh.
  useLive(["me:changed"], () => {
    if (user?.role === "player") refreshUser().catch(() => {});
  });

  async function handleLogout() {
    await apiLogout().catch(() => {});
    setUser(null);
    setScreen({ name: "role" });
  }

  function handleAuthed(u: PublicUser) {
    setSignedOutNotice(null);
    setUser(u);
    setStatus((s) => (s ? { ...s, hasAdmin: true } : s));
  }

  async function refreshUser() {
    const u = await getCurrentUser();
    if (u) setUser(u);
  }

  let body: React.ReactNode;

  if (loadError) {
    body = (
      <p className="rounded-sm border-l-4 border-alert bg-alert/10 px-4 py-4 text-ink">
        Can't reach the server. Check your Wi-Fi and try again.
      </p>
    );
  } else if (user === undefined || !status) {
    body = <p className="text-center text-lg text-ink/60">Loading…</p>;
  } else if (user) {
    // Logged-in screens bring their own top bar and navigation.
    return user.role === "admin" ? (
      <AdminHome user={user} onLogout={handleLogout} />
    ) : (
      <PlayerHome user={user} onLogout={handleLogout} onRefresh={refreshUser} />
    );
  } else if (screen.name === "role") {
    body = (
      <RoleSelect
        onSelect={(role) => setScreen({ name: "login", role })}
      />
    );
  } else if (screen.name === "login") {
    const { role } = screen;
    if (role === "admin" && !status.hasAdmin) {
      body = (
        <AdminSetupForm
          onSuccess={handleAuthed}
          onBack={() => setScreen({ name: "role" })}
        />
      );
    } else {
      body = (
        <LoginForm
          role={role}
          hint={
            role === "player" && !status.hasPlayers
              ? "No player accounts exist yet. Ask your Admin to create one."
              : undefined
          }
          onSuccess={handleAuthed}
          onBack={() => setScreen({ name: "role" })}
        />
      );
    }
  } else {
    // Not reachable in normal use (screen only ever holds "role" or "login"
    // once loading finishes), kept so `body` is always assigned.
    body = <p className="text-center text-lg text-ink/60">Loading…</p>;
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-8 px-6 py-10">
      <header className="flex flex-col items-center gap-3 text-center">
        {/* crosshair mark */}
        <svg viewBox="0 0 48 48" className="h-14 w-14 text-pine" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden>
          <circle cx="24" cy="24" r="14" />
          <path d="M24 4v10M24 34v10M4 24h10M34 24h10" />
          <circle cx="24" cy="24" r="2.5" fill="currentColor" />
        </svg>
        <h1 className="font-display text-5xl font-bold leading-none text-ink">Game System</h1>
        <p className="text-base text-ink/55">Connected over your local Wi-Fi</p>
      </header>
      {signedOutNotice && (
        <p role="status" className="rounded-sm border-l-4 border-sun bg-sun/10 px-4 py-3 text-center font-semibold text-ink">
          {signedOutNotice}
        </p>
      )}
      {body}
    </main>
  );
}
