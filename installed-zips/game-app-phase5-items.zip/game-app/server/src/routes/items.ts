import express, { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { randomBytes } from "crypto";
import fs from "fs";
import path from "path";
import { requireRole } from "../auth/middleware";
import { ITEM_IMAGE_DIR } from "../config";
import { MAX_ITEM_QUANTITY } from "../database/inventory";
import {
  createItem,
  findItemById,
  findItemByName,
  ItemFields,
  listItems,
  setItemImage,
  toPublicItem,
  updateItem,
} from "../database/items";

const NAME_MAX = 60;
const DESCRIPTION_MAX = 500;
const CATEGORY_MAX = 40;
const IMAGE_MAX_BYTES = 2 * 1024 * 1024;

// Only this route gets a larger JSON body limit (index.ts skips the default
// 100 KB parser for it). It runs after requireRole, so a non-Admin can't
// make the server parse a multi-megabyte body.
export const IMAGE_UPLOAD_PATH = /^\/api\/admin\/items\/\d+\/image$/;
const imageJson = express.json({ limit: "4mb" });

type FieldResult = { ok: true; fields: ItemFields } | { ok: false; error: string };

function optionalText(value: unknown, max: number, label: string): string | null | Error {
  if (value === null || value === undefined) return null;
  if (typeof value !== "string") return new Error(`Invalid ${label}.`);
  const trimmed = value.trim();
  if (trimmed.length > max) return new Error(`${label} can be at most ${max} characters.`);
  return trimmed === "" ? null : trimmed;
}

// Validates whichever item fields are present in the body. For create,
// `requireName` is true. Nothing from the client is written without passing
// through here.
function parseItemFields(body: any, requireName: boolean): FieldResult {
  const fields: ItemFields = {};
  const b = body ?? {};

  if (b.name !== undefined || requireName) {
    if (typeof b.name !== "string" || b.name.trim() === "") {
      return { ok: false, error: "Item name is required." };
    }
    const name = b.name.trim();
    if (name.length > NAME_MAX) {
      return { ok: false, error: `Item name can be at most ${NAME_MAX} characters.` };
    }
    fields.name = name;
  }

  if (b.description !== undefined) {
    const d = optionalText(b.description, DESCRIPTION_MAX, "Description");
    if (d instanceof Error) return { ok: false, error: d.message };
    fields.description = d;
  }

  if (b.category !== undefined) {
    const c = optionalText(b.category, CATEGORY_MAX, "Category");
    if (c instanceof Error) return { ok: false, error: c.message };
    fields.category = c;
  }

  if (b.maxStack !== undefined) {
    if (b.maxStack === null) {
      fields.maxStack = null;
    } else if (
      typeof b.maxStack !== "number" ||
      !Number.isInteger(b.maxStack) ||
      b.maxStack < 1 ||
      b.maxStack > MAX_ITEM_QUANTITY
    ) {
      return {
        ok: false,
        error: `Max per player must be a whole number between 1 and ${MAX_ITEM_QUANTITY}, or empty for no limit.`,
      };
    } else {
      fields.maxStack = b.maxStack;
    }
  }

  if (b.enabled !== undefined) {
    if (typeof b.enabled !== "boolean") return { ok: false, error: "Invalid enabled value." };
    fields.enabled = b.enabled;
  }

  return { ok: true, fields };
}

// Decides the file type from the file's own bytes, not from anything the
// client claims. SVG is deliberately not accepted (it can carry scripts).
function detectImageType(buf: Buffer): "png" | "jpg" | "webp" | "gif" | null {
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])))
    return "png";
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (buf.length >= 12 && buf.toString("ascii", 0, 4) === "RIFF" && buf.toString("ascii", 8, 12) === "WEBP")
    return "webp";
  if (buf.length >= 6 && (buf.toString("ascii", 0, 6) === "GIF87a" || buf.toString("ascii", 0, 6) === "GIF89a"))
    return "gif";
  return null;
}

function removeImageFile(file: string | null) {
  if (!file) return;
  fs.promises.unlink(path.join(ITEM_IMAGE_DIR, file)).catch(() => {});
}

export function createItemsRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  function getItemOr404(id: number) {
    return Number.isInteger(id) ? findItemById(db, id) ?? null : null;
  }

  router.get("/", (_req, res) => {
    res.json({ items: listItems(db).map(toPublicItem) });
  });

  router.post("/", (req, res) => {
    const parsed = parseItemFields(req.body, true);
    if (!parsed.ok) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    const f = parsed.fields;
    if (findItemByName(db, f.name!)) {
      res.status(409).json({ error: "An item with that name already exists." });
      return;
    }
    const item = createItem(db, {
      name: f.name!,
      description: f.description ?? null,
      category: f.category ?? null,
      maxStack: f.maxStack ?? null,
      enabled: f.enabled,
    });
    res.status(201).json({ item: toPublicItem(item) });
  });

  router.get("/:id", (req, res) => {
    const item = getItemOr404(Number(req.params.id));
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    res.json({ item: toPublicItem(item) });
  });

  router.patch("/:id", (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    const parsed = parseItemFields(req.body, false);
    if (!parsed.ok) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    if (parsed.fields.name !== undefined) {
      const existing = findItemByName(db, parsed.fields.name);
      if (existing && existing.id !== id) {
        res.status(409).json({ error: "An item with that name already exists." });
        return;
      }
    }
    res.json({ item: toPublicItem(updateItem(db, id, parsed.fields)) });
  });

  // Body: { image: "data:image/png;base64,..." } — the client shrinks the
  // picture first, so real uploads are small.
  router.post("/:id/image", imageJson, (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    const image = req.body?.image;
    const match = typeof image === "string" ? /^data:[\w/+.-]*;base64,([A-Za-z0-9+/=]+)$/.exec(image) : null;
    if (!match) {
      res.status(400).json({ error: "Please choose a PNG, JPG, WEBP or GIF picture." });
      return;
    }
    const buf = Buffer.from(match[1], "base64");
    if (buf.length === 0 || buf.length > IMAGE_MAX_BYTES) {
      res.status(400).json({ error: "Picture must be smaller than 2 MB." });
      return;
    }
    const ext = detectImageType(buf);
    if (!ext) {
      res.status(400).json({ error: "Please choose a PNG, JPG, WEBP or GIF picture." });
      return;
    }

    // New random file name each time, so phones never show a stale cached picture.
    const file = `item-${id}-${randomBytes(6).toString("hex")}.${ext}`;
    try {
      fs.mkdirSync(ITEM_IMAGE_DIR, { recursive: true });
      fs.writeFileSync(path.join(ITEM_IMAGE_DIR, file), buf);
    } catch {
      res.status(500).json({ error: "Could not save the picture. Please try again." });
      return;
    }
    setItemImage(db, id, file);
    removeImageFile(item.image_file);
    res.json({ item: toPublicItem(findItemById(db, id)!) });
  });

  router.delete("/:id/image", (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    setItemImage(db, id, null);
    removeImageFile(item.image_file);
    res.json({ item: toPublicItem(findItemById(db, id)!) });
  });

  return router;
}
