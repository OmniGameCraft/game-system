import { ReactNode } from "react";
import { playSfx } from "../audio/sfx";
import { HAPTIC, vibrate } from "../audio/haptics";

// An on/off switch. It plays its own little "toggle" sound, so the global
// click sound is turned off for it (data-sound="none").

function Switch({ checked, disabled }: { checked: boolean; disabled?: boolean }) {
  return (
    <span
      aria-hidden
      className={`relative inline-flex h-[30px] w-[52px] shrink-0 items-center rounded-full border transition-colors duration-200 ${
        checked
          ? "border-pine-deep bg-gradient-to-b from-pine-light to-pine shadow-[inset_0_1px_2px_rgba(0,0,0,0.25),0_0_12px_-2px_rgba(245,165,36,0.6)]"
          : "border-panel-line bg-panel-deep shadow-[inset_0_1px_3px_rgba(0,0,0,0.8)]"
      } ${disabled ? "opacity-40" : ""}`}
    >
      <span
        className={`absolute left-[3px] h-[22px] w-[22px] rounded-full bg-[radial-gradient(circle_at_35%_30%,#ffffff,#c8cdd3_45%,#7d848c_100%)] shadow-[0_2px_4px_rgba(0,0,0,0.6)] transition-transform duration-200 ease-[cubic-bezier(0.2,0.9,0.3,1.2)] ${
          checked ? "translate-x-[22px]" : "translate-x-0"
        }`}
      />
    </span>
  );
}

function flip(checked: boolean, onChange: (v: boolean) => void) {
  playSfx("toggle");
  vibrate(HAPTIC.tap);
  onChange(!checked);
}

// Just the switch (when the label is somewhere else).
export function Toggle({
  checked,
  onChange,
  label,
  disabled,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string; // read out by screen readers
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      data-sound="none"
      onClick={() => flip(checked, onChange)}
      className="inline-flex min-h-[2.75rem] items-center"
    >
      <Switch checked={checked} disabled={disabled} />
    </button>
  );
}

// A whole settings row: icon, label, a line of help, and the switch.
// The entire row is one big button, easy to hit with a thumb.
export function ToggleRow({
  label,
  description,
  checked,
  onChange,
  icon,
  disabled,
}: {
  label: string;
  description?: ReactNode;
  checked: boolean;
  onChange: (v: boolean) => void;
  icon?: ReactNode;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      data-sound="none"
      onClick={() => flip(checked, onChange)}
      className="flex min-h-[3.5rem] w-full items-center gap-3 rounded-md px-1 py-2 text-left transition-colors active:bg-ink/5 disabled:cursor-default"
    >
      {icon && (
        <span
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-md border border-panel-line bg-panel-deep shadow-bevel ${
            checked && !disabled ? "text-pine" : "text-ink/45"
          }`}
          aria-hidden
        >
          {icon}
        </span>
      )}
      <span className={`min-w-0 flex-1 ${disabled ? "opacity-50" : ""}`}>
        <span className="block text-lg font-semibold leading-tight text-ink">{label}</span>
        {description && <span className="mt-0.5 block text-sm leading-snug text-ink/55">{description}</span>}
      </span>
      <Switch checked={checked} disabled={disabled} />
    </button>
  );
}
