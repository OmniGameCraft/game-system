export function Avatar({ name, size = "md" }: { name: string; size?: "md" | "lg" }) {
  const box = size === "lg" ? "h-16 w-16 text-2xl" : "h-12 w-12 text-lg";
  return (
    <div className={`${box} flex shrink-0 items-center justify-center chamfer-sm bg-panel-raised font-display font-bold text-pine`} aria-hidden>
      {name.trim().charAt(0).toUpperCase() || "?"}
    </div>
  );
}
