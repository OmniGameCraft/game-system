import { useEffect, useState } from "react";
import { Button } from "../../components/Button";
import { ConfirmCard } from "../../components/ConfirmCard";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import {
  AdminGame as AdminGameData,
  GAME_STATUS_LABEL,
  GameStatus,
  getAdminGame,
  listPlayers,
  Player,
  resetRound,
  sendAnnouncement,
  setGameStatus,
} from "../../services/api";
import { useLive } from "../../services/live";
import { formatDateTime } from "../../utils/format";

const STATUS_COLOR: Record<GameStatus, string> = {
  not_started: "text-ink/70",
  active: "text-olive",
  paused: "text-sun",
  ended: "text-alert",
};

function sinceText(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return `since ${d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}`;
}

export function AdminGame() {
  const [data, setData] = useState<AdminGameData | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [confirmEnd, setConfirmEnd] = useState(false);

  const [message, setMessage] = useState("");
  const [to, setTo] = useState("all");

  const [resetText, setResetText] = useState("");

  function load() {
    Promise.all([getAdminGame(), listPlayers()])
      .then(([g, p]) => {
        setData(g);
        setPlayers(p.filter((x) => x.status === "active"));
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load."));
  }
  useEffect(load, []);
  useLive(["game:changed", "players:changed"], load);

  async function run(key: string, fn: () => Promise<AdminGameData>, done: string) {
    setError(null);
    setNotice(null);
    setBusy(key);
    try {
      setData(await fn());
      setNotice(done);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setBusy(null);
    }
  }

  if (!data) {
    return error ? <ErrorBanner message={error} /> : <p className="text-ink/60">Loading…</p>;
  }

  const s = data.status;
  const playerName = (id: number) => {
    const p = players.find((x) => x.id === id);
    return p ? p.displayName || p.username : "that player";
  };

  return (
    <>
      <ErrorBanner message={error} />
      <Notice message={notice} />

      <Section title="Game status">
        <div className="flex items-baseline justify-between gap-3">
          <p className={`font-display text-4xl font-bold ${STATUS_COLOR[s]}`}>{GAME_STATUS_LABEL[s]}</p>
          <p className="text-sm text-ink/55">{sinceText(data.changedAt)}</p>
        </div>
        <p className="text-ink/70">
          {s === "not_started" && "Players can log in and shop. Start the game when everyone is ready."}
          {s === "active" && "The game is running. Pausing puts a pause screen on every phone and stops buying."}
          {s === "paused" && "Every phone shows the pause screen and buying is off until you resume."}
          {s === "ended" && "Players see the game-over screen. Buying is off. Start again to play another round."}
        </p>

        {confirmEnd ? (
          <ConfirmCard
            title="End the game?"
            body="Every phone shows the game-over screen and buying stops. You can start again afterwards."
            confirmLabel="End game"
            loading={busy === "ended"}
            onCancel={() => setConfirmEnd(false)}
            onConfirm={() =>
              run("ended", () => setGameStatus("ended"), "Game ended.").then(() => setConfirmEnd(false))
            }
          />
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {(s === "not_started" || s === "ended") && (
              <Button
                className="col-span-2"
                loading={busy === "active"}
                onClick={() => run("active", () => setGameStatus("active"), "Game started. Every phone got the signal.")}
              >
                <span className="flex items-center justify-center gap-2 whitespace-nowrap">
                  <Icon name="flag" /> {s === "ended" ? "Start a new round" : "Start the game"}
                </span>
              </Button>
            )}
            {s === "active" && (
              <Button
                variant="ghost"
                size="md"
                loading={busy === "paused"}
                onClick={() => run("paused", () => setGameStatus("paused"), "Game paused.")}
              >
                <span className="flex items-center justify-center gap-2 whitespace-nowrap">
                  <Icon name="pause" /> Pause
                </span>
              </Button>
            )}
            {s === "paused" && (
              <Button
                size="md"
                loading={busy === "active"}
                onClick={() => run("active", () => setGameStatus("active"), "Game resumed.")}
              >
                <span className="flex items-center justify-center gap-2 whitespace-nowrap">
                  <Icon name="flag" /> Resume
                </span>
              </Button>
            )}
            {(s === "active" || s === "paused") && (
              <Button variant="dangerGhost" size="md" onClick={() => setConfirmEnd(true)}>
                <span className="flex items-center justify-center gap-2 whitespace-nowrap">
                  <Icon name="stop" /> End game
                </span>
              </Button>
            )}
          </div>
        )}
      </Section>

      <Section title="Send a message">
        <label htmlFor="ann-to" className="block">
          <span className="mb-1 block text-base font-semibold text-ink/75">To</span>
          <select
            id="ann-to"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            className="w-full rounded-sm border-2 border-panel-line px-4 py-3 text-lg outline-none focus:border-pine"
          >
            <option value="all">Every player</option>
            {players.map((p) => (
              <option key={p.id} value={p.id}>
                {p.displayName || p.username}
              </option>
            ))}
          </select>
        </label>
        <label htmlFor="ann-msg" className="block">
          <span className="mb-1 block text-base font-semibold text-ink/75">Message</span>
          <textarea
            id="ann-msg"
            rows={3}
            maxLength={300}
            value={message}
            placeholder="e.g. Shop closes in 5 minutes"
            onChange={(e) => setMessage(e.target.value)}
            className="w-full rounded-sm border-2 border-panel-line px-4 py-3 text-lg outline-none focus:border-pine"
          />
          <span className="mt-1 block text-right text-sm text-ink/45">{message.length}/300</span>
        </label>
        <Button
          disabled={!message.trim()}
          loading={busy === "msg"}
          onClick={() =>
            run(
              "msg",
              () => sendAnnouncement(message, to === "all" ? null : Number(to)),
              to === "all" ? "Sent to every player." : `Sent to ${playerName(Number(to))}.`
            ).then(() => setMessage(""))
          }
        >
          <span className="flex items-center justify-center gap-2 whitespace-nowrap">
            <Icon name="megaphone" /> Send
          </span>
        </Button>
      </Section>

      <Section title={`Game log (${data.events.length})`} flush>
        {data.events.length === 0 ? (
          <p className="p-4 text-ink/60">Nothing yet. Starting the game and messages show up here.</p>
        ) : (
          <ul className="divide-y divide-panel-line">
            {data.events.map((e) => (
              <li key={e.id} className="flex flex-col gap-0.5 px-4 py-3">
                {e.type === "STATUS" ? (
                  <p className={`font-display font-semibold ${STATUS_COLOR[e.status!]}`}>{GAME_STATUS_LABEL[e.status!]}</p>
                ) : (
                  <p>
                    <span className="font-semibold text-pine">{e.playerName ? `To ${e.playerName}: ` : "To everyone: "}</span>
                    {e.message}
                  </p>
                )}
                <p className="text-sm text-ink/50">{formatDateTime(e.createdAt)}</p>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="New round" tone="alert">
        <p className="text-ink/75">
          Clears money, bags, sales, histories and messages, and sets the game back to waiting. Players, items and
          the shop's price list stay. This can't be undone.
        </p>
        <label htmlFor="reset-confirm" className="block">
          <span className="mb-1 block text-base font-semibold text-ink/75">Type RESET to confirm</span>
          <input
            id="reset-confirm"
            value={resetText}
            autoCapitalize="characters"
            onChange={(e) => setResetText(e.target.value)}
            className="w-full rounded-sm border-2 border-panel-line px-4 py-3 text-lg outline-none focus:border-alert"
          />
        </label>
        <Button
          variant="danger"
          disabled={resetText.trim().toUpperCase() !== "RESET"}
          loading={busy === "reset"}
          onClick={() =>
            run("reset", resetRound, "New round ready: money, bags and histories are cleared.").then(() => setResetText(""))
          }
        >
          Clear for a new round
        </Button>
      </Section>
    </>
  );
}
