import { notifyUnauthorized } from "../services/authEvents";
import type { GameStatus } from "../services/api";

// Server calls made from the weapon screen: fire, reload, use a healing item,
// and a fresh look at the piece being held. Plus the ShotBatcher, which
// groups rapid shots into a few small requests.

export interface GunNumbers {
  reloadMs: number; // how long a reload takes (reload-speed upgrade lowers it)
  shakeThreshold: number; // m/s² of shake needed to fire (fire-rate upgrade lowers it)
  cooldownMs: number; // shortest time between shots (fire-rate upgrade lowers it)
  damagePct: number; // 100 = base damage
}

export interface HpNumbers {
  hp: number;
  maxHp: number;
  dead: boolean;
}

// An error with the server's friendly message and the HTTP status
// (0 = the server couldn't be reached).
export class PlayError extends Error {
  constructor(message: string, public status: number) {
    super(message);
  }
}

const OFFLINE = "Can't reach the game server. Check the Wi-Fi.";

async function call(url: string, init?: RequestInit): Promise<any> {
  let res: Response;
  try {
    res = await fetch(url, init);
  } catch {
    throw new PlayError(OFFLINE, 0);
  }
  let body: any = null;
  try {
    body = await res.json();
  } catch {
    // no JSON body
  }
  if (res.status === 401) notifyUnauthorized();
  if (!res.ok) throw new PlayError(body?.error || "Something went wrong. Please try again.", res.status);
  return body ?? {};
}

function post(url: string, data: unknown, keepalive = false): Promise<any> {
  return call(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
    keepalive,
  });
}

const num = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);

function readHp(v: any): HpNumbers | null {
  if (v && typeof v === "object" && num(v.hp) !== null && num(v.maxHp) !== null) {
    return { hp: v.hp, maxHp: v.maxHp, dead: Boolean(v.dead) };
  }
  return null;
}

// ---- Fire ----

export interface FireResult {
  loaded: number | null; // rounds left in the magazine (null = not reported)
  reserve: number | null; // spare rounds in the case
  practice: boolean; // game not started: nothing was used
  empty: boolean; // asked for more shots than were loaded
}

export async function fireShots(pieceId: number, shots: number, opts: { keepalive?: boolean } = {}): Promise<FireResult> {
  const b = await post("/api/play/fire", { pieceId, shots }, opts.keepalive);
  return { loaded: num(b.loaded), reserve: num(b.reserve), practice: b.practice === true, empty: b.empty === true };
}

// ---- Reload ----

export interface ReloadResult {
  loaded: number | null;
  reserve: number | null;
  reloadMs: number | null;
  practice: boolean;
}

export async function reloadGun(pieceId: number): Promise<ReloadResult> {
  const b = await post("/api/play/reload", { pieceId });
  return { loaded: num(b.loaded), reserve: num(b.reserve), reloadMs: num(b.reloadMs), practice: b.practice === true };
}

// ---- Use a healing item ----

export interface HealResult {
  hp: HpNumbers | null; // HP after using it, when the server says
  remaining: number | null; // units of this piece left (null = not reported)
}

export async function healWith(pieceId: number): Promise<HealResult> {
  const b = await post("/api/case/use", { pieceId });
  const hp = readHp(b.hp) ?? readHp(b);
  let remaining: number | null = null;
  if (num(b.remaining) !== null) remaining = b.remaining;
  else if (b.piece === null) remaining = 0;
  else if (b.piece && num(b.piece.quantity) !== null) remaining = b.piece.quantity;
  return { hp, remaining };
}

// ---- The piece, fresh from the server ----

export interface PieceNow {
  quantity: number;
  loaded: number;
  magazine: number | null;
  reserve: number;
  gun: GunNumbers | null;
  usable: boolean;
}

export interface CaseNow {
  piece: PieceNow | null; // null = it's not in the case any more
  status: GameStatus | null;
  practiceFire: boolean;
  hp: HpNumbers | null;
}

export async function fetchPieceNow(pieceId: number): Promise<CaseNow> {
  const b = await call("/api/case");
  const all: any[] = [...(Array.isArray(b.pieces) ? b.pieces : []), ...(Array.isArray(b.tray) ? b.tray : [])];
  const p = all.find((x) => x && x.id === pieceId);
  const gun = p?.gun;
  return {
    piece: p
      ? {
          quantity: num(p.quantity) ?? 1,
          loaded: num(p.loaded) ?? 0,
          magazine: num(p.magazine),
          reserve: num(p.reserve) ?? 0,
          gun:
            gun && num(gun.reloadMs) !== null
              ? {
                  reloadMs: gun.reloadMs,
                  shakeThreshold: num(gun.shakeThreshold) ?? 14,
                  cooldownMs: num(gun.cooldownMs) ?? 250,
                  damagePct: num(gun.damagePct) ?? 100,
                }
              : null,
          usable: Boolean(p.usable),
        }
      : null,
    status: (b.game?.status as GameStatus) ?? null,
    practiceFire: b.rules?.practiceFire !== false,
    hp: readHp(b.hp),
  };
}

// ---- Shot batching ----
//
// Every shot shows on the phone at once (sound, flash, counter); the server
// is told in small batches, at most every FLUSH_MS, with only one request
// on the way at a time. A shot fired by a finger that may turn into a
// "swipe down to reload" is held back briefly, so a swipe doesn't waste a
// round: if it becomes a swipe, the shot is taken back before it's sent.

const FLUSH_MS = 120;
const HOLD_MAX_MS = 700; // the swipe-to-reload window
const MAX_BATCH = 10; // the server takes 1–10 shots per request

export interface ShotToken {
  release(): void; // it was a real shot: send it
  cancel(): boolean; // take it back (true if it hadn't been sent yet)
}

interface Hold {
  done: boolean;
  timer: number;
}

export class ShotBatcher {
  pending = 0; // fired here, not sent yet (includes held shots)
  inflight = 0; // sent, waiting for the answer
  private held = new Set<Hold>();
  private timer = 0;
  private retryAt = 0;
  private failures = 0; // failed sends in a row
  private waiters: (() => void)[] = [];
  private disposed = false;

  constructor(
    private pieceId: number,
    private on: {
      result: (r: FireResult, sent: number) => void;
      error: (err: unknown, sent: number) => void;
      change: () => void;
    }
  ) {}

  get idle(): boolean {
    return this.pending === 0 && this.inflight === 0;
  }

  // Shots on the phone that the server hasn't confirmed yet.
  get unconfirmed(): number {
    return this.pending + this.inflight;
  }

  add(opts: { hold?: boolean } = {}): ShotToken | null {
    if (this.disposed) return null;
    this.pending++;
    let token: ShotToken | null = null;
    if (opts.hold) {
      const h: Hold = { done: false, timer: 0 };
      h.timer = window.setTimeout(() => token?.release(), HOLD_MAX_MS);
      this.held.add(h);
      token = {
        release: () => {
          if (h.done) return;
          this.endHold(h);
          this.schedule();
        },
        cancel: () => {
          if (h.done) return false;
          this.endHold(h);
          this.pending = Math.max(0, this.pending - 1);
          this.on.change();
          this.notify();
          return true;
        },
      };
    }
    this.schedule();
    return token;
  }

  // Treat every held shot as real (e.g. before an automatic reload).
  releaseAll(): void {
    for (const h of [...this.held]) this.endHold(h);
    this.schedule();
  }

  // Send everything and wait for the answers (before a reload, so the
  // server reloads from the right count). Gives up after a few failures.
  async drain(): Promise<void> {
    this.releaseAll();
    this.failures = 0;
    while (!this.disposed && !this.idle) {
      if (this.inflight === 0) {
        if (this.failures >= 3) throw new PlayError(OFFLINE, 0);
        if (this.timer) {
          window.clearTimeout(this.timer);
          this.timer = 0;
        }
        void this.flush(true);
      }
      await new Promise<void>((resolve) => this.waiters.push(resolve));
    }
  }

  flushNow(): void {
    if (this.timer) {
      window.clearTimeout(this.timer);
      this.timer = 0;
    }
    void this.flush(true);
  }

  // The screen closed: send what's left without waiting for an answer
  // (keepalive lets the request finish even as the page moves on).
  dispose(): void {
    if (this.disposed) return;
    for (const h of [...this.held]) this.endHold(h);
    this.disposed = true;
    if (this.timer) window.clearTimeout(this.timer);
    let left = this.pending;
    this.pending = 0;
    while (left > 0) {
      const n = Math.min(MAX_BATCH, left);
      left -= n;
      fireShots(this.pieceId, n, { keepalive: true }).catch(() => {});
    }
    this.notify();
  }

  private endHold(h: Hold): void {
    h.done = true;
    window.clearTimeout(h.timer);
    this.held.delete(h);
  }

  private schedule(delay = FLUSH_MS): void {
    if (this.disposed || this.timer) return;
    const wait = Math.max(delay, this.retryAt - Date.now(), 0);
    this.timer = window.setTimeout(() => {
      this.timer = 0;
      void this.flush(false);
    }, wait);
  }

  private async flush(force: boolean): Promise<void> {
    if (this.disposed || this.inflight > 0) return;
    if (!force && this.retryAt > Date.now()) {
      this.schedule();
      return;
    }
    const n = Math.min(MAX_BATCH, this.pending - this.held.size);
    if (n <= 0) {
      this.notify();
      return;
    }
    this.pending -= n;
    this.inflight = n;
    try {
      const r = await fireShots(this.pieceId, n);
      this.inflight = 0;
      this.retryAt = 0;
      this.failures = 0;
      if (!this.disposed) this.on.result(r, n);
    } catch (err) {
      this.inflight = 0;
      if (!this.disposed) {
        if (err instanceof PlayError && err.status >= 400 && err.status < 500) {
          // Refused (game paused, player down, gun gone…): the rest would be too.
          for (const h of [...this.held]) this.endHold(h);
          this.pending = 0;
        } else {
          this.failures++;
          this.retryAt = Date.now() + 1000; // Wi-Fi trouble: try again in a moment
        }
        this.on.error(err, n);
      }
    }
    if (this.disposed) return;
    this.on.change();
    if (this.pending - this.held.size > 0) this.schedule(0);
    this.notify();
  }

  private notify(): void {
    const w = this.waiters;
    this.waiters = [];
    w.forEach((f) => f());
  }
}
