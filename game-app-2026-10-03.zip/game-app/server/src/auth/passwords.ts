import { randomBytes, scryptSync, timingSafeEqual } from "crypto";

// scrypt is a well-established, memory-hard password hashing function built
// into Node — no native module to compile, which matters on phones/Termux.
const KEY_LENGTH = 64;

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const derived = scryptSync(password, salt, KEY_LENGTH);
  return `${salt.toString("hex")}:${derived.toString("hex")}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [saltHex, hashHex] = stored.split(":");
  if (!saltHex || !hashHex) return false;
  const salt = Buffer.from(saltHex, "hex");
  const expected = Buffer.from(hashHex, "hex");
  const actual = scryptSync(password, salt, expected.length);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

// Reasonable minimum, not maximum — never reject a passphrase for being long.
export function isPasswordStrongEnough(password: string): boolean {
  if (password.length < 8) return false;
  const hasLetter = /[a-zA-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  return hasLetter && hasNumber;
}

const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,32}$/;
export function isUsernameValid(username: string): boolean {
  return USERNAME_RE.test(username);
}
