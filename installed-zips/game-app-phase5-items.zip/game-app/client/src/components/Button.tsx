import { ButtonHTMLAttributes } from "react";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  variant?: "primary" | "ghost";
}

export function Button({ loading, variant = "primary", disabled, children, className = "", ...rest }: Props) {
  const base =
    variant === "primary"
      ? "bg-pine text-white disabled:bg-pine/50"
      : "border-2 border-pine/30 text-pine bg-transparent";
  return (
    <button
      disabled={disabled || loading}
      className={`w-full rounded-xl px-4 py-4 text-lg font-semibold active:scale-[0.99] ${base} ${className}`}
      {...rest}
    >
      {loading ? "Please wait…" : children}
    </button>
  );
}
