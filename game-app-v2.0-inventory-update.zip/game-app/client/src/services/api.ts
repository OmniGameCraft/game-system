import { notifyUnauthorized } from "./authEvents";

export interface Health {
  status: string;
  database: string;
  time: string;
  version?: string; // e.g. "2.0.0"
}

export async function getHealth(): Promise<Health> {
  const res = await fetch("/api/health");
  if (!res.ok) throw new Error("Server unavailable");
  return res.json();
}

export type Role = "admin" | "player";

export interface PublicUser {
  id: number;
  role: Role;
  username: string;
  displayName: string | null;
  status: "active" | "disabled";
  balance: number;
  createdAt: string;
  // The number others say first when they call a hit ("three, forty" =
  // Player 3 loses 40 HP). Players only; null for the Admin.
  playerNumber: number | null;
  // Health — only sent for players.
  hp?: number;
  maxHp?: number;
  dead?: boolean;
}

export type Player = PublicUser;

export interface AuthStatus {
  hasAdmin: boolean;
  hasPlayers: boolean;
  httpsPort?: number; // secure address port, 0 when not running
}

class ApiError extends Error {}

async function parseJsonOrThrow(res: Response): Promise<any> {
  let body: any = null;
  try {
    body = await res.json();
  } catch {
    // no JSON body
  }
  if (!res.ok) {
    throw new ApiError(body?.error || "Something went wrong. Please try again.");
  }
  return body;
}

// Same as parseJsonOrThrow, but for endpoints that require an active Admin
// session. A 401 here doesn't just mean "this one call failed" — it means
// the server no longer considers this device's session valid (most likely
// because the same Admin account logged in elsewhere), so the whole app
// needs to drop back to the login screen, not just show an inline error.
async function parseAdminJsonOrThrow(res: Response): Promise<any> {
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

export async function getAuthStatus(): Promise<AuthStatus> {
  const res = await fetch("/api/auth/status");
  return parseJsonOrThrow(res);
}

export async function getCurrentUser(): Promise<PublicUser | null> {
  const res = await fetch("/api/auth/me");
  if (res.status === 401) return null;
  const body = await parseJsonOrThrow(res);
  return body.user;
}

export async function setupAdmin(input: {
  username: string;
  password: string;
  confirmPassword: string;
}): Promise<PublicUser> {
  const res = await fetch("/api/auth/admin-setup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseJsonOrThrow(res);
  return body.user;
}

export async function login(input: {
  role: Role;
  username: string;
  password: string;
}): Promise<PublicUser> {
  const res = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseJsonOrThrow(res);
  return body.user;
}

export async function logout(): Promise<void> {
  await fetch("/api/auth/logout", { method: "POST" });
}

export async function listPlayers(): Promise<Player[]> {
  const res = await fetch("/api/admin/players");
  const body = await parseAdminJsonOrThrow(res);
  return body.players;
}

export async function createPlayer(input: {
  username: string;
  password: string;
  confirmPassword: string;
  displayName?: string;
  playerNumber?: number; // optional: the server picks the lowest free number when it's left out
}): Promise<Player> {
  const res = await fetch("/api/admin/players", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.player;
}

export async function getPlayer(id: number): Promise<Player> {
  const res = await fetch(`/api/admin/players/${id}`);
  const body = await parseAdminJsonOrThrow(res);
  return body.player;
}

export async function updatePlayer(
  id: number,
  fields: {
    username?: string;
    displayName?: string | null;
    status?: "active" | "disabled";
    playerNumber?: number; // 1–99, each player has their own
  }
): Promise<Player> {
  const res = await fetch(`/api/admin/players/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(fields),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.player;
}

// Shortcut for the player page: the server checks the number is 1–99 and
// not already someone else's, and answers with a friendly message if not.
export function setPlayerNumber(id: number, playerNumber: number): Promise<Player> {
  return updatePlayer(id, { playerNumber });
}

export async function resetPlayerPassword(
  id: number,
  input: { password: string; confirmPassword: string }
): Promise<void> {
  const res = await fetch(`/api/admin/players/${id}/reset-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  if (res.status !== 204) {
    await parseAdminJsonOrThrow(res);
  }
}

export type TransactionType = "ADD" | "REMOVE" | "PURCHASE" | "SALE" | "UPGRADE";

export interface Transaction {
  id: number;
  type: TransactionType;
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  performedBy: number;
  itemId: number | null;
  itemName: string | null;
  quantity: number | null;
  detail?: string | null;
  createdAt: string;
}

export async function adjustPlayerMoney(
  id: number,
  input: { type: "ADD" | "REMOVE"; amount: number }
): Promise<{ balance: number; transaction: Transaction }> {
  const res = await fetch(`/api/admin/players/${id}/money`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  return parseAdminJsonOrThrow(res);
}

export async function getPlayerTransactions(id: number): Promise<Transaction[]> {
  const res = await fetch(`/api/admin/players/${id}/transactions`);
  const body = await parseAdminJsonOrThrow(res);
  return body.transactions;
}

// A player's own transaction history — no id parameter, since the server
// derives whose history to return from the session, never from a request
// argument a player could tamper with.
export async function getMyTransactions(): Promise<Transaction[]> {
  const res = await fetch("/api/me/transactions");
  const body = await parseJsonOrThrow(res);
  return body.transactions;
}

// ---- Items & Inventory (Phase 5) ----

export type UseEffect = "none" | "shot" | "swing";

export interface Item {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  maxStack: number | null;
  enabled: boolean;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  kind: ItemKind;
  ammoForItemId: number | null;
  ammoPerPack: number | null;
  sellable: boolean;
  sellPercent: number;
  baseMagazine: number | null;
  baseSharpness: number | null;
  baseLength: number | null;
  upgradePrices: {
    magazine: number | null;
    damage: number | null;
    reload: number | null;
    firerate: number | null;
    sharpness: number | null;
    length: number | null;
  };
  // ---- 2.0 "Inventory Update" ----
  gridW: number; // cells wide in the case (1–10)
  gridH: number; // cells tall
  stackSize: number | null; // units that share one space; null = the usual rule
  healAmount: number | null; // HP it gives back when used
  maxHpBonus: number | null; // raises max HP (and fills the new room)
  fullHeal: boolean; // restores all HP
  herbCode: HerbCode | null; // G / R / Y or a mix, for combining herbs
  baseReloadMs: number | null; // guns: reload time at level 1; null = 2 s
  shakeForce: number | null; // guns: 1 = a light flick fires … 10 = a big shove
  hre: number | null; // calculator: 1 round = hre handgun rounds
  expandRows: number | null; // backpacks: rows added to the case
  createdAt: string;
}

// Herbs: G = green, R = red, Y = yellow; the others are mixes.
export type HerbCode = "G" | "R" | "Y" | "GG" | "GR" | "GY" | "GRY" | "GGY";
export const HERB_LABEL: Record<HerbCode, string> = {
  G: "Green Herb",
  R: "Red Herb",
  Y: "Yellow Herb",
  GG: "Mixed Herb (G+G)",
  GR: "Mixed Herb (G+R)",
  GY: "Mixed Herb (G+Y)",
  GRY: "Mixed Herb (G+R+Y)",
  GGY: "Mixed Herb (G+G+Y)",
};

export type ItemKind = "gun" | "knife" | "ammo" | "healing" | "backpack" | "other";
export const KIND_LABEL: Record<ItemKind, string> = {
  gun: "Gun",
  knife: "Knife / melee",
  ammo: "Ammo",
  healing: "Healing",
  backpack: "Backpack",
  other: "Other",
};

export interface ItemInput {
  name?: string;
  description?: string | null;
  category?: string | null;
  maxStack?: number | null;
  enabled?: boolean;
  useEffect?: UseEffect;
  modelFlip?: boolean;
  modelUpsideDown?: boolean;
  kind?: ItemKind;
  ammoForItemId?: number | null;
  ammoPerPack?: number | null;
  sellable?: boolean;
  sellPercent?: number;
  baseMagazine?: number | null;
  baseSharpness?: number | null;
  baseLength?: number | null;
  upPriceMagazine?: number | null;
  upPriceDamage?: number | null;
  upPriceSharpness?: number | null;
  upPriceLength?: number | null;
  upPriceReload?: number | null;
  upPriceFirerate?: number | null;
  gridW?: number;
  gridH?: number;
  stackSize?: number | null;
  healAmount?: number | null;
  maxHpBonus?: number | null;
  fullHeal?: boolean;
  herbCode?: HerbCode | null;
  baseReloadMs?: number | null;
  shakeForce?: number | null;
  hre?: number | null;
  expandRows?: number | null;
}

export type Track = "magazine" | "damage" | "reload" | "firerate" | "sharpness" | "length";
export const TRACK_LABEL: Record<Track, string> = {
  magazine: "Magazine",
  damage: "Damage",
  reload: "Reload speed",
  firerate: "Fire rate",
  sharpness: "Sharpness",
  length: "Length",
};
// One short line on what each upgrade does, in players' words.
export const TRACK_HINT: Record<Track, string> = {
  magazine: "More rounds before you reload",
  damage: "Every hit counts for more",
  reload: "Faster reloads",
  firerate: "A lighter shake fires",
  sharpness: "A sharper blade",
  length: "A longer reach",
};
export interface TrackView {
  track: Track;
  level: number;
  maxLevel: number;
  // Numbers come from the server (the formulas live there only):
  // magazine = rounds, damage = percent (100, 115…), reload = ms,
  // firerate = shake needed in m/s² (lower = lighter), sharpness, length = cm.
  value: number | null;
  nextValue: number | null;
  nextCost: number | null;
  available: boolean;
}

export async function listItems(): Promise<Item[]> {
  const res = await fetch("/api/admin/items");
  const body = await parseAdminJsonOrThrow(res);
  return body.items;
}

export async function getItem(id: number): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}`);
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function createItem(input: ItemInput): Promise<Item> {
  const res = await fetch("/api/admin/items", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function updateItem(id: number, input: ItemInput): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function uploadItemImage(id: number, dataUrl: string): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}/image`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ image: dataUrl }),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function removeItemImage(id: number): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}/image`, { method: "DELETE" });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

// 3D model (.glb) and sound are sent as the raw file.
export async function uploadItemFile(id: number, kind: "model" | "sound", file: File): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}/${kind}`, {
    method: "POST",
    headers: { "Content-Type": "application/octet-stream" },
    body: file,
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function removeItemFile(id: number, kind: "model" | "sound"): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}/${kind}`, { method: "DELETE" });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export type InventoryAction =
  | "GIVE"
  | "REMOVE"
  | "SET"
  | "PURCHASE"
  | "SELL"
  // 2.0: things that happen in the case
  | "MIX"
  | "USE"
  | "DROP"
  | "PICKUP"
  | "RETURN"
  | "FIRE"
  | "RELOAD"
  | "DEATH"
  | "EXPAND";
export type AdminInventoryAction = "GIVE" | "REMOVE" | "SET";

export interface InventoryEntry {
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  quantity: number; // rounds, for ammo
  kind: ItemKind;
  ammoPerPack: number | null;
  ammoForItemId: number | null;
  sellable: boolean;
  upgrades: TrackView[];
  // Only present in the Admin view:
  enabled?: boolean;
  maxStack?: number | null;
}

export interface InventoryLogEntry {
  id: number;
  itemId: number;
  itemName: string;
  action: InventoryAction;
  quantityBefore: number;
  quantityAfter: number;
  performedBy: number;
  createdAt: string;
}

export interface AdminInventory {
  inventory: InventoryEntry[];
  log: InventoryLogEntry[];
  note?: string; // e.g. "2 didn't fit in the case and wait in the tray."
}

export async function getPlayerInventory(id: number): Promise<AdminInventory> {
  const res = await fetch(`/api/admin/players/${id}/inventory`);
  return parseAdminJsonOrThrow(res);
}

export async function changePlayerInventory(
  id: number,
  input: { itemId: number; action: AdminInventoryAction; quantity: number }
): Promise<AdminInventory> {
  const res = await fetch(`/api/admin/players/${id}/inventory`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  return parseAdminJsonOrThrow(res);
}

// The logged-in player's own items; the server decides whose from the session.
export async function getMyInventory(): Promise<InventoryEntry[]> {
  const res = await fetch("/api/me/inventory");
  if (res.status === 401) notifyUnauthorized();
  const body = await parseJsonOrThrow(res);
  return body.inventory;
}

// ---- Shop (Phase 6) ----

export interface Listing {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  price: number;
  stock: number | null; // null = unlimited
  maxPerPurchase: number | null;
  enabled: boolean;
  itemEnabled: boolean;
  maxStack: number | null;
  kind: ItemKind;
  ammoPerPack: number | null;
  gridW?: number;
  gridH?: number;
  expandRows?: number | null;
}

export interface Sale {
  id: number;
  type: "PURCHASE" | "SALE" | "UPGRADE";
  playerId: number;
  playerName: string;
  itemName: string;
  quantity: number | null;
  total: number;
  detail: string | null;
  createdAt: string;
}

export interface AdminShop {
  open: boolean;
  listings: Listing[];
  sales: Sale[];
}

export interface ListingInput {
  price?: number;
  stock?: number | null;
  maxPerPurchase?: number | null;
  enabled?: boolean;
}

export async function getAdminShop(): Promise<AdminShop> {
  const res = await fetch("/api/admin/shop");
  return parseAdminJsonOrThrow(res);
}

export async function setShopOpen(open: boolean): Promise<boolean> {
  const res = await fetch("/api/admin/shop/status", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ open }),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.open;
}

export async function addListing(input: ListingInput & { itemId: number }): Promise<Listing> {
  const res = await fetch("/api/admin/shop/items", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.listing;
}

export async function updateListing(id: number, input: ListingInput): Promise<Listing> {
  const res = await fetch(`/api/admin/shop/items/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.listing;
}

export async function removeListing(id: number): Promise<void> {
  const res = await fetch(`/api/admin/shop/items/${id}`, { method: "DELETE" });
  if (res.status !== 204) await parseAdminJsonOrThrow(res);
}

export interface PlayerListing {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  price: number;
  stock: number | null;
  maxPerPurchase: number | null;
  maxStack: number | null;
  owned: number; // rounds, for ammo
  kind: ItemKind;
  ammoPerPack: number | null;
  // 2.0: how much room it takes in the case (backpacks add rows instead).
  gridW?: number;
  gridH?: number;
  stackSize?: number | null;
  expandRows?: number | null;
}

async function parsePlayerJsonOrThrow(res: Response): Promise<any> {
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

export async function getShop(): Promise<{ open: boolean; listings: PlayerListing[] }> {
  const res = await fetch("/api/shop");
  return parsePlayerJsonOrThrow(res);
}

export async function buy(input: {
  shopItemId: number;
  quantity: number;
  expectedPrice: number;
}): Promise<{ balance: number; quantity: number; total: number; itemName: string; owned: number }> {
  const res = await fetch("/api/shop/purchase", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  return parsePlayerJsonOrThrow(res);
}

// ---- Ready-made item packs (free CC0 weapons, medkit…) ----

export interface PackItem {
  key: string;
  name: string;
  category: string | null;
  useEffect: UseEffect;
  pictureUrl: string | null;
  hasModel: boolean;
  hasSound: boolean;
  alreadyAdded: boolean;
}

export interface AssetPack {
  id: string;
  title: string;
  credits: string;
  items: PackItem[];
}

export async function listAssetPacks(): Promise<AssetPack[]> {
  const res = await fetch("/api/admin/asset-packs");
  const body = await parseAdminJsonOrThrow(res);
  return body.packs;
}

export async function importFromPack(
  packId: string,
  keys: string[]
): Promise<{ created: string[]; skipped: string[] }> {
  const res = await fetch(`/api/admin/asset-packs/${packId}/import`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ keys }),
  });
  return parseAdminJsonOrThrow(res);
}

// ---- Game controls (Phase 8) ----

export type GameStatus = "not_started" | "active" | "paused" | "ended";

export interface GameEvent {
  id: number;
  type: "STATUS" | "ANNOUNCEMENT";
  status: GameStatus | null;
  message: string | null;
  playerId: number | null;
  playerName: string | null;
  createdAt: string;
}

export interface AdminGame {
  status: GameStatus;
  changedAt: string | null;
  events: GameEvent[];
}

export async function getAdminGame(): Promise<AdminGame> {
  return parseAdminJsonOrThrow(await fetch("/api/admin/game"));
}

export async function setGameStatus(status: GameStatus): Promise<AdminGame> {
  const res = await fetch("/api/admin/game/status", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status }),
  });
  return parseAdminJsonOrThrow(res);
}

export async function sendAnnouncement(message: string, playerId: number | null): Promise<AdminGame> {
  const res = await fetch("/api/admin/game/announcements", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, playerId }),
  });
  return parseAdminJsonOrThrow(res);
}

export async function resetRound(): Promise<AdminGame> {
  const res = await fetch("/api/admin/game/reset-round", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ confirm: "RESET" }),
  });
  return parseAdminJsonOrThrow(res);
}

export interface PlayerGame {
  status: GameStatus;
  changedAt: string | null;
  announcements: GameEvent[];
}

export async function getGame(): Promise<PlayerGame> {
  const res = await fetch("/api/game");
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

export const GAME_STATUS_LABEL: Record<GameStatus, string> = {
  not_started: "Waiting to start",
  active: "Game on",
  paused: "Paused",
  ended: "Game over",
};

// ---- Selling back + upgrades (shop update) ----

// Ask what the shop would pay. This is the only way a player sees a sell value.
export async function getSellQuote(itemId: number, quantity: number): Promise<{ amount: number; itemName: string; quantity: number }> {
  const res = await fetch("/api/shop/sell-quote", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ itemId, quantity }),
  });
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

export async function sellItem(input: {
  itemId: number;
  quantity: number;
  expectedAmount: number;
}): Promise<{ balance: number; amount: number; itemName: string; owned: number }> {
  const res = await fetch("/api/shop/sell", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

export async function upgradeWeapon(input: {
  itemId: number;
  track: Track;
  expectedCost: number;
}): Promise<{ balance: number; level: number; value: number | null; cost: number; itemName: string }> {
  const res = await fetch("/api/shop/upgrade", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

// One upgrade's number in plain words: "17 rounds", "+15%", "1.4 s",
// "Shake 12.6", "22 cm". Null when the server sent no number.
export function statText(t: TrackView, value: number | null = t.value): string | null {
  if (value === null || value === undefined || !Number.isFinite(value)) return null;
  switch (t.track) {
    case "magazine":
      return `${value} rounds`;
    case "damage":
      // The server sends a percent: 100 = normal, 115 = 15% stronger.
      return value <= 100 ? "Normal" : `+${Math.round((value - 100) * 10) / 10}%`;
    case "reload":
      return `${(value / 1000).toFixed(1)} s`;
    case "firerate":
      // How hard the phone has to be shaken to fire (lower = lighter).
      return `Shake ${value.toFixed(1)}`;
    case "length":
      return `${value} cm`;
    default:
      return String(value);
  }
}

// The number now and after the next level, ready to show as "now → next".
// next is null when maxed out; the "Shake" word isn't repeated for fire rate.
export function statParts(t: TrackView): { now: string | null; next: string | null } {
  const now = statText(t);
  if (now === null || t.nextValue === null || t.nextValue === undefined || t.level >= t.maxLevel) return { now, next: null };
  return { now, next: t.track === "firerate" ? t.nextValue.toFixed(1) : statText(t, t.nextValue) };
}

// "1.4 s → 1.2 s", "Shake 12.6 → 11.1", "Normal → +15%"; just the current
// number when maxed out; null when the server sent no number.
export function statChangeText(t: TrackView): string | null {
  const { now, next } = statParts(t);
  return now !== null && next !== null ? `${now} → ${next}` : now;
}

// Case/shop wording for how much of an item a player holds.
export function heldText(kind: ItemKind, quantity: number, perPack: number | null): string {
  if (kind === "ammo") {
    const per = perPack || 1;
    const packs = Math.floor(quantity / per);
    return per > 1 ? `${quantity} rounds (${packs} pack${packs === 1 ? "" : "s"})` : `${quantity} rounds`;
  }
  return `×${quantity}`;
}

// ============================================================================
// 2.0 "Inventory Update" — Admin calls for HP, game rules, the drop box, the
// hits feed, a player's case and the calculator.
// ============================================================================

// ---- HP ----

export interface HpView {
  hp: number;
  maxHp: number;
  dead: boolean;
}

export type AdminHpAction = "damage" | "heal" | "set" | "setMax" | "revive";

// Pulls { hp, maxHp, dead } out of whichever shape the server answered with
// ({ hp: {…} }, { player: {…} } or the numbers at the top level).
function toHpView(body: any): HpView | null {
  const src = body?.hp && typeof body.hp === "object" ? body.hp : body?.player ?? body;
  if (!src || typeof src.hp !== "number" || typeof src.maxHp !== "number") return null;
  return { hp: src.hp, maxHp: src.maxHp, dead: !!src.dead };
}

// damage / heal / set / setMax take an amount; revive = full HP and alive.
export async function adminHp(playerId: number, action: AdminHpAction, amount?: number): Promise<HpView | null> {
  const res = await fetch(`/api/admin/players/${playerId}/hp`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(amount === undefined ? { action } : { action, amount }),
  });
  return toHpView(await parseAdminJsonOrThrow(res));
}

// ---- Hits feed (HP history for everyone, newest first) ----

export type HpLogKind = "HIT" | "HEAL" | "MAX_UP" | "FULL" | "SET" | "REVIVE" | "DEATH" | "RESET";

export interface HitEntry {
  id: number;
  playerId: number;
  playerName: string;
  playerNumber: number | null;
  kind: HpLogKind;
  amount: number;
  hpBefore: number;
  hpAfter: number;
  maxBefore: number;
  maxAfter: number;
  source: string | null; // "voice", "admin", "Green Herb"…
  heardBy: number | null; // voice: how many phones heard the same call
  createdAt: string;
}

export async function getHits(): Promise<HitEntry[]> {
  const body = await parseAdminJsonOrThrow(await fetch("/api/admin/hits"));
  return body.hits ?? [];
}

// ---- Game rules ----

export interface GameRules {
  baseHp: number; // starting HP
  maxHpCap: number; // max HP can never go above this
  caseCols: number; // columns in every case
  caseRows: number; // starting rows
  caseMaxRows: number; // rows cap after backpack expansions
  voiceEnabled: boolean; // voice hit calls on/off
  voiceWindowMs: number; // the same call within this time counts once
  practiceFire: boolean; // test-fire before the game starts without using ammo
  deathDrops: boolean; // a player who goes down drops everything in the drop box
  returnDropsOnEnd: boolean; // at game end, drops nobody picked up go back to their owner
}

export const DEFAULT_RULES: GameRules = {
  baseHp: 100,
  maxHpCap: 300,
  caseCols: 8,
  caseRows: 4,
  caseMaxRows: 9,
  voiceEnabled: true,
  voiceWindowMs: 4000,
  practiceFire: true,
  deathDrops: true,
  returnDropsOnEnd: true,
};

export async function getRules(): Promise<GameRules> {
  const body = await parseAdminJsonOrThrow(await fetch("/api/admin/rules"));
  return { ...DEFAULT_RULES, ...(body.rules ?? {}) };
}

// Send only what changed; the server checks every value and answers with
// the full set.
export async function updateRules(patch: Partial<GameRules>): Promise<GameRules> {
  const res = await fetch("/api/admin/rules", {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch),
  });
  const body = await parseAdminJsonOrThrow(res);
  return { ...DEFAULT_RULES, ...(body.rules ?? {}) };
}

// ---- A player's case (read-only for the Admin) ----

export interface CasePieceView {
  id: number;
  itemId: number;
  name: string;
  kind: ItemKind;
  imageUrl: string | null;
  x: number | null; // null = in the "doesn't fit" tray
  y: number | null;
  w: number; // cells it covers on the grid, as placed
  h: number;
  rotated: boolean;
  quantity: number;
  stackSize?: number;
  loaded?: number; // guns: rounds in the magazine
  magazine?: number | null;
  herbCode?: HerbCode | null;
  upgrades?: TrackView[];
}

export interface CaseView {
  cols: number;
  rows: number;
  expansions: number;
  pieces: CasePieceView[];
  tray: CasePieceView[];
}

export async function getAdminPlayerCase(id: number): Promise<CaseView> {
  const body = await parseAdminJsonOrThrow(await fetch(`/api/admin/players/${id}/case`));
  const c = body.case ?? body;
  return {
    cols: c.cols ?? DEFAULT_RULES.caseCols,
    rows: c.rows ?? DEFAULT_RULES.caseRows,
    expansions: c.expansions ?? 0,
    pieces: c.pieces ?? [],
    tray: c.tray ?? [],
  };
}

// ---- Drop box ----

export interface DropEntry {
  id: number;
  itemId: number;
  name: string;
  kind: ItemKind;
  imageUrl: string | null;
  quantity: number;
  loaded: number;
  w: number;
  h: number;
  ownerName: string; // who gets it back when the game ends
  droppedByName?: string;
  reason: "DROP" | "DEATH"; // DEATH = fell when its owner went down
  createdAt: string;
}

export async function getAdminDrops(): Promise<DropEntry[]> {
  const body = await parseAdminJsonOrThrow(await fetch("/api/admin/drops"));
  return body.drops ?? [];
}

// Everything in the drop box goes back to whoever owned it (into their case,
// or their tray when there's no room).
export async function clearDrops(): Promise<{ returned: number | null }> {
  const res = await fetch("/api/admin/drops/clear", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: "{}",
  });
  const body = await parseAdminJsonOrThrow(res);
  return { returned: typeof body?.returned === "number" ? body.returned : null };
}

// ---- Calculator ----

export interface Boss {
  id: string;
  name: string;
  handgunRounds: number; // rounds he absorbs before he gets stronger
  phases: number; // 1–5
  scalePerPhase: number; // ×this stronger each phase
}

export interface CalculatorConfig {
  hpPerHandgunRound: number; // one handgun round hit = this much HP
  damagePerLevel: number; // percent each damage upgrade adds
  bosses: Boss[];
}

export const DEFAULT_CALCULATOR: CalculatorConfig = { hpPerHandgunRound: 10, damagePerLevel: 15, bosses: [] };

// Ammo the whole team holds right now (in cases and loaded in guns), per gun.
export interface FirepowerGun {
  itemId: number; // the gun
  name: string;
  rounds: number;
  handgunRounds: number;
}
export interface Firepower {
  guns: FirepowerGun[];
  totalHandgunRounds: number;
}

export interface CalculatorData {
  config: CalculatorConfig;
  firepower: Firepower | null; // null when the answer didn't include it (keep the last one)
}

const num = (v: unknown, fallback: number): number => (typeof v === "number" && Number.isFinite(v) ? v : fallback);

function toCalculatorData(body: any): CalculatorData {
  const raw = body?.calculator ?? body?.config ?? body ?? {};
  const config: CalculatorConfig = {
    hpPerHandgunRound: num(raw.hpPerHandgunRound, DEFAULT_CALCULATOR.hpPerHandgunRound),
    damagePerLevel: num(raw.damagePerLevel, DEFAULT_CALCULATOR.damagePerLevel),
    bosses: Array.isArray(raw.bosses)
      ? raw.bosses.map((b: any, i: number) => ({
          id: String(b?.id ?? `boss-${i + 1}`),
          name: typeof b?.name === "string" ? b.name : `Boss ${i + 1}`,
          handgunRounds: num(b?.handgunRounds, 100),
          phases: num(b?.phases, 3),
          scalePerPhase: num(b?.scalePerPhase, 1.5),
        }))
      : [],
  };
  // Firepower is worked out on the server from every player's case.
  if (!body?.firepower) return { config, firepower: null };
  const fp = body.firepower;
  const rows: any[] = Array.isArray(fp) ? fp : fp.guns ?? fp.perGun ?? fp.byGun ?? [];
  const guns: FirepowerGun[] = rows.map((r) => {
    const rounds = num(r?.rounds, num(r?.held, 0) + num(r?.loaded, 0));
    return {
      itemId: num(r?.itemId ?? r?.gunItemId ?? r?.gunId, 0),
      name: String(r?.name ?? r?.gunName ?? ""),
      rounds,
      handgunRounds: num(r?.handgunRounds, rounds * num(r?.hre, 1)),
    };
  });
  const total = num(
    fp.totalHandgunRounds ?? fp.total,
    guns.reduce((sum, g) => sum + g.handgunRounds, 0)
  );
  return { config, firepower: { guns, totalHandgunRounds: total } };
}

export async function getCalculator(): Promise<CalculatorData> {
  return toCalculatorData(await parseAdminJsonOrThrow(await fetch("/api/admin/calculator")));
}

export async function saveCalculator(config: CalculatorConfig): Promise<CalculatorData> {
  const res = await fetch("/api/admin/calculator", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(config),
  });
  return toCalculatorData(await parseAdminJsonOrThrow(res));
}
