import { CSSProperties, KeyboardEvent, MouseEvent, PointerEvent, ReactNode, RefObject } from "react";
import type { Piece } from "./caseApi";
import type { Ghost } from "./useCaseDrag";
import { PieceView } from "./PieceView";
import { Icon } from "../components/Icon";

// Frame thickness around the cells (outer body, bright metal rim, black
// well). The screen subtracts these from the width before sizing cells.
export interface Chrome {
  outer: number;
  rim: number;
  well: number;
}
export const chromeWidth = (c: Chrome) => 2 * (c.outer + c.rim + c.well);

// The open attaché case: a dark body with metal corners, an "ITEMS" plate,
// a bright rim, and the grid of dark square cells the pieces sit in.
export function CaseGrid({
  cols,
  rows,
  cell,
  chrome,
  compact,
  pieces,
  selectedId,
  liftedId,
  ghost,
  slots,
  freshIds,
  settleId,
  gridRef,
  overlay,
  onPieceDown,
  onPieceClick,
  onPieceKey,
  onBackground,
}: {
  cols: number;
  rows: number;
  cell: number;
  chrome: Chrome;
  compact?: boolean;
  pieces: Piece[];
  selectedId: number | null;
  liftedId: number | null;
  ghost: Ghost | null;
  slots: Map<number, number>;
  freshIds: Set<number>;
  settleId: number | null;
  gridRef: RefObject<HTMLDivElement>;
  overlay?: ReactNode; // e.g. the empty-case message
  onPieceDown: (p: Piece, e: PointerEvent<HTMLButtonElement>) => void;
  onPieceClick: (p: Piece, e: MouseEvent<HTMLButtonElement>) => void;
  onPieceKey: (p: Piece, e: KeyboardEvent<HTMLButtonElement>) => void;
  onBackground: () => void;
}) {
  // Roving focus: Tab lands on one piece; the arrow keys move between them.
  const focusId = selectedId !== null && pieces.some((p) => p.id === selectedId) ? selectedId : pieces[0]?.id ?? null;
  const gridStyle = {
    width: cols * cell,
    height: rows * cell,
    "--cell": `${cell}px`,
  } as CSSProperties;

  return (
    <div className={`cs-case ${compact ? "is-compact" : ""}`} style={{ padding: chrome.outer, paddingTop: chrome.outer + (compact ? 14 : 18) }}>
      <span className="cs-corner cs-corner-tl" aria-hidden />
      <span className="cs-corner cs-corner-tr" aria-hidden />
      <span className="cs-corner cs-corner-bl" aria-hidden />
      <span className="cs-corner cs-corner-br" aria-hidden />
      <div className="cs-plate" aria-hidden>
        <span>ITEMS</span>
      </div>
      <div className="cs-rim" style={{ padding: chrome.rim }}>
        <div className="cs-well" style={{ padding: chrome.well }}>
          <div
            ref={gridRef}
            className="cs-grid"
            style={gridStyle}
            role="group"
            aria-label={`Case, ${cols} by ${rows} cells. Drag to move, tap for options, arrow keys to choose, R to turn.`}
            onPointerDown={(e) => {
              if (e.target === e.currentTarget) onBackground();
            }}
          >
            {ghost && (
              <div
                className={`cs-ghost cs-ghost-${ghost.state}`}
                style={{
                  width: ghost.box.w * cell,
                  height: ghost.box.h * cell,
                  transform: `translate(${ghost.box.x * cell}px, ${ghost.box.y * cell}px)`,
                }}
                aria-hidden
              >
                {ghost.state === "merge" && ghost.label && <span className="cs-ghost-badge">{ghost.label}</span>}
                {ghost.state === "mix" && (
                  <span className="cs-ghost-badge" aria-hidden>
                    <Icon name="combine" className="h-4 w-4" />
                  </span>
                )}
              </div>
            )}
            {pieces.map((p) => (
              <PieceView
                key={p.id}
                piece={p}
                cell={cell}
                slot={slots.get(p.id)}
                selected={selectedId === p.id}
                lifted={liftedId === p.id}
                fresh={freshIds.has(p.id)}
                settle={settleId === p.id}
                tabIndex={focusId === p.id ? 0 : -1}
                onPointerDown={(e) => onPieceDown(p, e)}
                onClick={(e) => onPieceClick(p, e)}
                onKeyDown={(e) => onPieceKey(p, e)}
              />
            ))}
            {overlay}
          </div>
        </div>
      </div>
      {!compact && (
        <div className="cs-handle" aria-hidden>
          <span className="cs-latch" />
          <span className="cs-grip" />
          <span className="cs-latch" />
        </div>
      )}
    </div>
  );
}
