import { Icon, IconName } from "../../components/Icon";
import { HitEntry } from "../../services/api";
import { clockTime, NumberPlate } from "./ui";

// One line of HP history (voice hits, Admin changes, healing items), in words.
export function describeHit(h: HitEntry): { icon: IconName; tone: string; title: string } {
  const healed = h.hpAfter - h.hpBefore;
  switch (h.kind) {
    case "HIT":
      return { icon: "bolt", tone: "text-alert", title: `−${h.amount || h.hpBefore - h.hpAfter} HP` };
    case "HEAL":
      return { icon: "heart", tone: "text-olive", title: `+${healed > 0 ? healed : h.amount} HP` };
    case "MAX_UP":
      return { icon: "heart", tone: "text-olive", title: `Max HP ${h.maxBefore} → ${h.maxAfter}` };
    case "FULL":
      return { icon: "heart", tone: "text-olive", title: `All HP restored (+${Math.max(0, healed)})` };
    case "SET":
      return {
        icon: "gear",
        tone: "text-sun",
        title: h.maxAfter !== h.maxBefore ? `Max HP set to ${h.maxAfter}` : `HP set to ${h.hpAfter}`,
      };
    case "REVIVE":
      return { icon: "shield", tone: "text-olive", title: `Revived with ${h.hpAfter} HP` };
    case "DEATH":
      return { icon: "skull", tone: "text-alert", title: "Down!" };
    case "RESET":
      return { icon: "refresh", tone: "text-ink/60", title: "Back to full for a new round" };
    default:
      return { icon: "info", tone: "text-ink/70", title: String(h.kind) };
  }
}

function sourceText(h: HitEntry): string | null {
  if (!h.source) return null;
  if (h.source === "voice") return "Voice call";
  if (h.source === "admin") return "By the Admin";
  return h.source; // the item used, e.g. "Green Herb"
}

export function HitRow({ h, showPlayer = true, className = "" }: { h: HitEntry; showPlayer?: boolean; className?: string }) {
  const d = describeHit(h);
  const src = sourceText(h);
  const heard = h.source === "voice" && h.heardBy ? `heard by ${h.heardBy} phone${h.heardBy === 1 ? "" : "s"}` : null;
  const details = [src, heard, h.kind !== "DEATH" && h.kind !== "RESET" ? `now ${h.hpAfter}/${h.maxAfter}` : null].filter(
    Boolean
  );
  return (
    <li className={`flex items-center gap-3 px-4 py-3 ${className}`}>
      {showPlayer ? (
        <NumberPlate n={h.playerNumber} size="sm" />
      ) : (
        <Icon name={d.icon} className={`h-6 w-6 shrink-0 ${d.tone}`} />
      )}
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-2">
          <p className="flex min-w-0 flex-wrap items-baseline gap-x-2">
            {showPlayer && <span className="truncate font-bold text-ink">{h.playerName}</span>}
            <span className={`font-display text-lg font-bold tabular-nums ${d.tone}`}>{d.title}</span>
          </p>
          <span className="shrink-0 text-xs tabular-nums text-ink/45">{clockTime(h.createdAt)}</span>
        </div>
        {details.length > 0 && <p className="text-sm text-ink/55">{details.join(" · ")}</p>}
      </div>
      {showPlayer && <Icon name={d.icon} className={`h-5 w-5 shrink-0 ${d.tone}`} />}
    </li>
  );
}
