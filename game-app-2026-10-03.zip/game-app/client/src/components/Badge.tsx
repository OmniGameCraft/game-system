import { ReactNode } from "react";

export function Badge({ tone, children }: { tone: "good" | "bad" | "neutral" | "warn"; children: ReactNode }) {
  const cls =
    tone === "good"
      ? "bg-olive-soft text-olive"
      : tone === "bad"
      ? "bg-alert/15 text-alert"
      : tone === "warn"
      ? "bg-sun/20 text-sun"
      : "bg-ink/10 text-ink/75";
  return (
    <span className={`inline-flex items-center rounded-sm px-2 py-0.5 text-sm font-semibold ${cls}`}>{children}</span>
  );
}
