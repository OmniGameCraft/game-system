import { ReactNode, useEffect, useState } from "react";
import { playSfx } from "../../audio/sfx";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls } from "../../components/Field";
import { Icon, IconName } from "../../components/Icon";
import { Section, SectionAction } from "../../components/Section";
import { toast } from "../../components/Toast";
import { GameRules, updateRules } from "../../services/api";
import { Toggle } from "./ui";

type NumberKey = "baseHp" | "maxHpCap" | "caseCols" | "caseRows" | "caseMaxRows" | "voiceWindowMs";
type BoolKey = "voiceEnabled" | "practiceFire" | "deathDrops" | "returnDropsOnEnd";

// Number rules as text while typing. The voice window is shown in seconds.
type Draft = Record<NumberKey, string> & Record<BoolKey, boolean>;

function toDraft(r: GameRules): Draft {
  return {
    baseHp: String(r.baseHp),
    maxHpCap: String(r.maxHpCap),
    caseCols: String(r.caseCols),
    caseRows: String(r.caseRows),
    caseMaxRows: String(r.caseMaxRows),
    voiceWindowMs: String(Math.round(r.voiceWindowMs / 100) / 10),
    voiceEnabled: r.voiceEnabled,
    practiceFire: r.practiceFire,
    deathDrops: r.deathDrops,
    returnDropsOnEnd: r.returnDropsOnEnd,
  };
}

// Checks every number and returns the rules, or a friendly error.
function fromDraft(d: Draft): GameRules | Error {
  const whole = (text: string, label: string, min: number, max: number): number | Error => {
    const n = Number(text.trim());
    if (text.trim() === "" || !Number.isInteger(n) || n < min || n > max)
      return new Error(`${label} must be a whole number from ${min} to ${max}.`);
    return n;
  };
  const baseHp = whole(d.baseHp, "Starting HP", 10, 1000);
  if (baseHp instanceof Error) return baseHp;
  const maxHpCap = whole(d.maxHpCap, "Highest max HP", baseHp, 2000);
  if (maxHpCap instanceof Error) return maxHpCap;
  const caseCols = whole(d.caseCols, "Case width", 4, 10);
  if (caseCols instanceof Error) return caseCols;
  const caseRows = whole(d.caseRows, "Starting rows", 2, 10);
  if (caseRows instanceof Error) return caseRows;
  const caseMaxRows = whole(d.caseMaxRows, "Most rows", caseRows, 12);
  if (caseMaxRows instanceof Error) return caseMaxRows;
  const sec = Number(d.voiceWindowMs.trim());
  if (d.voiceWindowMs.trim() === "" || !Number.isFinite(sec) || sec < 1 || sec > 15)
    return new Error("“Same call counts once” must be between 1 and 15 seconds.");
  return {
    baseHp,
    maxHpCap,
    caseCols,
    caseRows,
    caseMaxRows,
    voiceWindowMs: Math.round(sec * 1000),
    voiceEnabled: d.voiceEnabled,
    practiceFire: d.practiceFire,
    deathDrops: d.deathDrops,
    returnDropsOnEnd: d.returnDropsOnEnd,
  };
}

// The game's rules: HP, case size, voice calls and drop box behaviour.
// Folded to a one-line summary until the Admin taps "Edit".
export function RulesSection({ rules, onSaved }: { rules: GameRules | null; onSaved: (r: GameRules) => void }) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Draft | null>(rules ? toDraft(rules) : null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // New rules from the server (or another Admin tab) replace the form only
  // while it isn't being edited.
  useEffect(() => {
    if (rules && !open) setDraft(toDraft(rules));
  }, [rules, open]);

  if (!rules || !draft) {
    return (
      <Section title="Game rules">
        <p className="text-ink/60">Loading…</p>
      </Section>
    );
  }

  const parsed = fromDraft(draft);
  const changes: Partial<GameRules> = {};
  if (!(parsed instanceof Error)) {
    for (const k of Object.keys(parsed) as (keyof GameRules)[]) {
      if (parsed[k] !== rules[k]) (changes as Record<string, unknown>)[k] = parsed[k];
    }
  }
  const dirty = parsed instanceof Error || Object.keys(changes).length > 0;
  const shrinking =
    !(parsed instanceof Error) &&
    (parsed.caseCols < rules.caseCols || parsed.caseRows < rules.caseRows || parsed.caseMaxRows < rules.caseMaxRows);

  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setDraft((d) => (d ? { ...d, [k]: v } : d));

  async function save() {
    setError(null);
    if (parsed instanceof Error) {
      setError(parsed.message);
      playSfx("error");
      return;
    }
    if (Object.keys(changes).length === 0) {
      setOpen(false);
      return;
    }
    setSaving(true);
    try {
      const saved = await updateRules(changes);
      onSaved(saved);
      setDraft(toDraft(saved));
      setOpen(false);
      playSfx("success");
      toast("Game rules saved. Every phone has them now.", "good");
    } catch (err) {
      playSfx("error");
      setError(err instanceof Error ? err.message : "Could not save the rules.");
    } finally {
      setSaving(false);
    }
  }

  function cancel() {
    setDraft(toDraft(rules!));
    setError(null);
    setOpen(false);
  }

  if (!open) {
    return (
      <Section
        title="Game rules"
        action={
          <SectionAction onClick={() => setOpen(true)}>
            <Icon name="gear" className="h-4 w-4" /> Edit
          </SectionAction>
        }
      >
        <ul className="grid grid-cols-1 gap-2 text-ink/80 sm:grid-cols-2">
          <RuleLine icon="heart" text={`Start with ${rules.baseHp} HP · max HP up to ${rules.maxHpCap}`} />
          <RuleLine icon="grid" text={`Case ${rules.caseCols} × ${rules.caseRows}, grows to ${rules.caseMaxRows} rows`} />
          <RuleLine
            icon={rules.voiceEnabled ? "mic" : "micOff"}
            text={rules.voiceEnabled ? `Voice hits on · same call once per ${rules.voiceWindowMs / 1000} s` : "Voice hits off"}
          />
          <RuleLine icon="target" text={rules.practiceFire ? "Practice shooting before the start" : "No practice shooting"} />
          <RuleLine icon="skull" text={rules.deathDrops ? "Down players drop everything" : "Down players keep their items"} />
          <RuleLine
            icon="drop"
            text={rules.returnDropsOnEnd ? "Unclaimed drops go home at the end" : "Unclaimed drops stay at the end"}
          />
        </ul>
      </Section>
    );
  }

  return (
    <Section title="Game rules" tone="sun">
      <RuleGroup title="Health">
        <RuleNumber
          id="rule-basehp"
          label="Starting HP"
          hint="Every player starts each round with this much. 10 to 1000."
          value={draft.baseHp}
          onChange={(v) => set("baseHp", v)}
        />
        <RuleNumber
          id="rule-maxcap"
          label="Highest max HP"
          hint="Red herb mixes raise a player's max HP, but never past this."
          value={draft.maxHpCap}
          onChange={(v) => set("maxHpCap", v)}
        />
      </RuleGroup>

      <RuleGroup title="Case size">
        <div className="grid grid-cols-2 gap-3">
          <RuleNumber id="rule-cols" label="Columns" hint="4 to 10" value={draft.caseCols} onChange={(v) => set("caseCols", v)} />
          <RuleNumber
            id="rule-rows"
            label="Starting rows"
            hint="2 to 10"
            value={draft.caseRows}
            onChange={(v) => set("caseRows", v)}
          />
        </div>
        <RuleNumber
          id="rule-maxrows"
          label="Most rows (with backpacks)"
          hint="Backpack expansions add rows up to this. Up to 12."
          value={draft.caseMaxRows}
          onChange={(v) => set("caseMaxRows", v)}
        />
        {shrinking && (
          <p className="border-l-4 border-sun bg-sun/10 px-3 py-2 text-sm font-semibold text-ink">
            Making the case smaller moves items that no longer fit into each player's tray. Nothing is lost.
          </p>
        )}
      </RuleGroup>

      <RuleGroup title="Voice hit calls">
        <Toggle
          checked={draft.voiceEnabled}
          onChange={(v) => set("voiceEnabled", v)}
          label="Listen for hit calls"
          hint="Phones hear calls like “three, forty” and take 40 HP from Player 3. Only while the game is running."
        />
        {draft.voiceEnabled && (
          <label htmlFor="rule-window" className="block">
            <span className="mb-1 block text-base font-semibold text-ink/75">Same call counts once within</span>
            <span className="flex items-center gap-3">
              <input
                id="rule-window"
                type="number"
                inputMode="decimal"
                min={1}
                max={15}
                step={0.5}
                value={draft.voiceWindowMs}
                onChange={(e) => set("voiceWindowMs", e.target.value)}
                className={`${inputCls} !w-28 text-center`}
              />
              <span className="font-semibold text-ink/70">seconds</span>
            </span>
            <span className="mt-1 block text-sm text-ink/55">
              When several phones hear the same call, it's applied once. Said again after this time, it counts as a new hit.
            </span>
          </label>
        )}
      </RuleGroup>

      <RuleGroup title="Play">
        <Toggle
          checked={draft.practiceFire}
          onChange={(v) => set("practiceFire", v)}
          label="Practice shooting before the start"
          hint="Before you start the game, players can test-fire their guns without using ammo."
        />
        <Toggle
          checked={draft.deathDrops}
          onChange={(v) => set("deathDrops", v)}
          label="Down players drop everything"
          hint="When a player hits 0 HP, their items fall into the drop box for others to pick up. Their money stays."
        />
        <Toggle
          checked={draft.returnDropsOnEnd}
          onChange={(v) => set("returnDropsOnEnd", v)}
          label="Give back unclaimed drops at the end"
          hint="When the game ends, anything still in the drop box goes back to whoever owned it."
        />
      </RuleGroup>

      <ErrorBanner message={error} />
      <div className="grid grid-cols-2 gap-3">
        <Button variant="ghost" size="md" onClick={cancel} disabled={saving}>
          Cancel
        </Button>
        <Button size="md" onClick={save} loading={saving} disabled={!dirty}>
          Save rules
        </Button>
      </div>
    </Section>
  );
}

function RuleLine({ icon, text }: { icon: IconName; text: string }) {
  return (
    <li className="flex items-center gap-2 text-sm">
      <Icon name={icon} className="h-4 w-4 shrink-0 text-pine" />
      {text}
    </li>
  );
}

function RuleGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <fieldset className="flex flex-col gap-3 border-t border-panel-line pt-3 first:border-t-0 first:pt-0">
      <legend className="float-left mb-1 w-full font-display text-sm font-bold uppercase tracking-wider text-ink/55">
        {title}
      </legend>
      {children}
    </fieldset>
  );
}

function RuleNumber({
  id,
  label,
  hint,
  value,
  onChange,
}: {
  id: string;
  label: string;
  hint?: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label htmlFor={id} className="block">
      <span className="mb-1 block text-base font-semibold text-ink/75">{label}</span>
      <input
        id={id}
        type="number"
        inputMode="numeric"
        step={1}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={inputCls}
      />
      {hint && <span className="mt-1 block text-sm text-ink/55">{hint}</span>}
    </label>
  );
}
