import { useEffect, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { TransactionList } from "../../components/TransactionList";
import {
  adjustPlayerMoney,
  getPlayerTransactions,
  Transaction,
  TransactionType,
} from "../../services/api";

export function MoneySection({
  playerId,
  balance,
  onBalanceChange,
}: {
  playerId: number;
  balance: number;
  onBalanceChange: (balance: number) => void;
}) {
  const [amount, setAmount] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<TransactionType | null>(null);
  const [transactions, setTransactions] = useState<Transaction[] | null>(null);
  const [txError, setTxError] = useState<string | null>(null);

  function loadTransactions() {
    setTxError(null);
    getPlayerTransactions(playerId)
      .then(setTransactions)
      .catch((err) => setTxError(err instanceof Error ? err.message : "Failed to load."));
  }

  useEffect(loadTransactions, [playerId]);

  async function handleAdjust(type: TransactionType) {
    setError(null);
    const parsed = Number(amount);
    if (!Number.isInteger(parsed) || parsed <= 0) {
      setError("Enter a whole number greater than 0.");
      return;
    }
    setPending(type);
    try {
      const result = await adjustPlayerMoney(playerId, { type, amount: parsed });
      onBalanceChange(result.balance);
      setTransactions((prev) => (prev ? [result.transaction, ...prev] : [result.transaction]));
      setAmount("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not complete the transaction.");
    } finally {
      setPending(null);
    }
  }

  return (
    <div className="flex flex-col gap-4 rounded-2xl border-2 border-ink/15 bg-white p-4">
      <div>
        <p className="text-lg text-ink/60">Current Balance</p>
        <p className="text-3xl font-extrabold text-pine">${balance}</p>
      </div>

      <ErrorBanner message={error} />

      <label htmlFor="money-amount" className="block">
        <span className="mb-1 block text-base font-medium text-ink/80">Amount</span>
        <input
          id="money-amount"
          type="number"
          inputMode="numeric"
          min={1}
          step={1}
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="w-full rounded-xl border-2 border-ink/15 bg-white px-4 py-3 text-lg outline-none focus:border-pine"
          placeholder="100"
        />
      </label>

      <div className="flex gap-3">
        <Button onClick={() => handleAdjust("ADD")} loading={pending === "ADD"} disabled={pending !== null}>
          Add Money
        </Button>
        <Button
          onClick={() => handleAdjust("REMOVE")}
          loading={pending === "REMOVE"}
          disabled={pending !== null}
          className="!bg-alert"
        >
          Remove Money
        </Button>
      </div>

      <div className="flex flex-col gap-3">
        <h3 className="text-lg font-bold text-pine">Transaction History</h3>
        <ErrorBanner message={txError} />
        {transactions && <TransactionList transactions={transactions} />}
      </div>
    </div>
  );
}
