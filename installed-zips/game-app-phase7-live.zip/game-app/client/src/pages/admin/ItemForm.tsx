import { ChangeEvent, FormEvent, useEffect, useRef, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls, TextField } from "../../components/Field";
import { BackButton } from "../../components/BackButton";
import { Badge } from "../../components/Badge";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import { ItemMediaSection } from "./ItemMediaSection";
import { ItemImage } from "../../components/ItemImage";
import {
  createItem,
  getItem,
  Item,
  listItems,
  removeItemImage,
  updateItem,
  uploadItemImage,
} from "../../services/api";
import { resizeImageToDataUrl } from "../../utils/image";

// One form for both "create" (no id) and "edit" (id given).
export function ItemForm({
  id,
  onSaved,
  onBack,
}: {
  id?: number;
  onSaved: (item: Item) => void;
  onBack: () => void;
}) {
  const isEdit = id !== undefined;
  const [item, setItem] = useState<Item | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [maxStack, setMaxStack] = useState("");
  const [categories, setCategories] = useState<string[]>([]);

  // Picture picked on the create screen is uploaded right after the item exists.
  const [pendingImage, setPendingImage] = useState<string | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [imageBusy, setImageBusy] = useState(false);
  const [toggling, setToggling] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Suggest categories the Admin has already used, so "Weapon" and
    // "weapons" don't end up as two different groups by accident.
    listItems()
      .then((all) => {
        const seen = new Set<string>();
        for (const i of all) if (i.category) seen.add(i.category);
        setCategories([...seen].sort((a, b) => a.localeCompare(b)));
      })
      .catch(() => {});
    if (id === undefined) return;
    getItem(id)
      .then((i) => {
        setItem(i);
        setName(i.name);
        setCategory(i.category ?? "");
        setDescription(i.description ?? "");
        setMaxStack(i.maxStack === null ? "" : String(i.maxStack));
      })
      .catch((err) => setLoadError(err instanceof Error ? err.message : "Failed to load item."));
  }, [id]);

  function parseMaxStack(): number | null | Error {
    const t = maxStack.trim();
    if (t === "") return null;
    const n = Number(t);
    if (!Number.isInteger(n) || n < 1) return new Error("Max per player must be a whole number of 1 or more, or empty.");
    return n;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    setError(null);
    setNotice(null);
    const ms = parseMaxStack();
    if (ms instanceof Error) {
      setError(ms.message);
      return;
    }
    const input = { name, category: category || null, description: description || null, maxStack: ms };
    setSaving(true);
    try {
      if (isEdit) {
        const updated = await updateItem(id!, input);
        setItem(updated);
        setNotice("Saved.");
      } else {
        let created = await createItem(input);
        if (pendingImage) {
          try {
            created = await uploadItemImage(created.id, pendingImage);
          } catch {
            // The item exists; the picture can be added again from the edit screen.
          }
        }
        onSaved(created);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save the item.");
    } finally {
      setSaving(false);
    }
  }

  async function handlePickImage(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setError(null);
    setNotice(null);
    setImageBusy(true);
    try {
      const dataUrl = await resizeImageToDataUrl(file);
      if (isEdit) {
        setItem(await uploadItemImage(id!, dataUrl));
      } else {
        setPendingImage(dataUrl);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not use that picture.");
    } finally {
      setImageBusy(false);
    }
  }

  async function handleRemoveImage() {
    setError(null);
    if (!isEdit) {
      setPendingImage(null);
      return;
    }
    setImageBusy(true);
    try {
      setItem(await removeItemImage(id!));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not remove the picture.");
    } finally {
      setImageBusy(false);
    }
  }

  async function handleToggleEnabled() {
    if (!item) return;
    setError(null);
    setNotice(null);
    setToggling(true);
    try {
      setItem(await updateItem(item.id, { enabled: !item.enabled }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not change the item.");
    } finally {
      setToggling(false);
    }
  }

  if (loadError) {
    return (
      <>
        <BackButton label="Items" onClick={onBack} />
        <ErrorBanner message={loadError} />
      </>
    );
  }
  if (isEdit && !item) return <p className="text-ink/60">Loading…</p>;

  const previewUrl = isEdit ? item!.imageUrl : pendingImage;

  return (
    <>
      <BackButton label="Items" onClick={onBack} />
      <ErrorBanner message={error} />
      <Notice message={notice} />

      <Section title="Picture">
        <div className="flex items-center gap-4">
          <ItemImage url={previewUrl} name={name || "?"} size="lg" />
          <div className="flex flex-1 flex-col gap-2">
            <input
              ref={fileInput}
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              className="hidden"
              onChange={handlePickImage}
            />
            <Button type="button" variant="ghost" size="md" loading={imageBusy} onClick={() => fileInput.current?.click()}>
              {previewUrl ? "Change picture" : "Add picture"}
            </Button>
            {previewUrl && !imageBusy && (
              <button type="button" onClick={handleRemoveImage} className="min-h-[2.5rem] text-sm font-bold text-alert">
                Remove picture
              </button>
            )}
          </div>
        </div>
        <p className="text-sm text-ink/55">Optional. PNG, JPG, WEBP or GIF. Transparent backgrounds are kept.</p>
      </Section>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Section title={isEdit ? "Item details" : "New item"}>
          <TextField id="item-name" label="Name" maxLength={60} value={name} onChange={(e) => setName(e.target.value)} required />
          <TextField
            id="item-category"
            label="Category (optional)"
            hint="Groups items, e.g. Weapon, Ammo, Medical."
            list="item-categories"
            maxLength={40}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          />
          <datalist id="item-categories">
            {categories.map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
          <label htmlFor="item-description" className="block">
            <span className="mb-1 block text-base font-semibold text-ink/80">Description (optional)</span>
            <textarea
              id="item-description"
              rows={3}
              maxLength={500}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={inputCls}
            />
          </label>
          <TextField
            id="item-max-stack"
            label="Max per player (optional)"
            hint="Leave empty for no limit. Set 1 for “one each”."
            type="number"
            inputMode="numeric"
            min={1}
            step={1}
            value={maxStack}
            onChange={(e) => setMaxStack(e.target.value)}
          />
        </Section>
        <Button type="submit" loading={saving}>
          {isEdit ? "Save changes" : "Create Item"}
        </Button>
      </form>

      {isEdit && item && <ItemMediaSection item={item} onChange={setItem} />}
      {!isEdit && (
        <p className="rounded-xl bg-pine-soft px-4 py-3 text-ink/80">
          After you create the item you can add a 3D model and a sound for it.
        </p>
      )}

      {isEdit && item && (
        <Section title="Availability" tone={item.enabled ? "pine" : "alert"}>
          <div className="flex items-center gap-2">
            <Badge tone={item.enabled ? "good" : "bad"}>{item.enabled ? "Enabled" : "Disabled"}</Badge>
          </div>
          <p className="text-ink/70">
            {item.enabled
              ? "Disabling stops anyone giving or selling this item. Players keep what they already have."
              : "This item can't be given out or bought until you enable it again."}
          </p>
          <Button variant={item.enabled ? "dangerGhost" : "primary"} loading={toggling} onClick={handleToggleEnabled}>
            {item.enabled ? "Disable item" : "Enable item"}
          </Button>
        </Section>
      )}
    </>
  );
}
