import { useId } from "react";
import { APP_NAME, APP_VERSION, COMPANY } from "../version";

// The crosshair mark: the app's logo everywhere (start screen, top bar, About).
export function CrosshairLogo({ className = "h-12 w-12" }: { className?: string }) {
  // Each logo gets its own gradient id: a shared id breaks when the first
  // logo on the page is hidden (e.g. the desktop sidebar on a phone).
  const id = "gs-logo-" + useId().replace(/[^a-zA-Z0-9_-]/g, "");
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" aria-hidden>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FFC861" />
          <stop offset="1" stopColor="#E0901A" />
        </linearGradient>
      </defs>
      <circle cx="24" cy="24" r="14.5" stroke={`url(#${id})`} strokeWidth="2.6" />
      <circle cx="24" cy="24" r="8" stroke="#F5A524" strokeOpacity="0.35" strokeWidth="1.4" />
      <path
        d="M24 3.5v10M24 34.5v10M3.5 24h10M34.5 24h10"
        stroke={`url(#${id})`}
        strokeWidth="2.6"
        strokeLinecap="round"
      />
      <circle cx="24" cy="24" r="2.6" fill="#F5A524" />
    </svg>
  );
}

// Big title block for the start screens: logo, name, maker.
export function BrandHeader({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <div className="flex items-center justify-center gap-2.5 animate-fade-in">
        <CrosshairLogo className="h-8 w-8" />
        <span className="font-display text-xl font-bold tracking-wide text-ink">{APP_NAME}</span>
      </div>
    );
  }
  return (
    <header className="flex flex-col items-center gap-3 text-center animate-enter">
      <div className="relative">
        {/* soft amber halo behind the mark */}
        <div className="absolute inset-[-30%] rounded-full bg-pine/15 blur-2xl" aria-hidden />
        <CrosshairLogo className="relative h-16 w-16" />
      </div>
      <h1 className="font-display text-5xl font-bold leading-none text-ink">{APP_NAME}</h1>
      <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.28em] text-steel">
        <span className="h-px w-6 bg-steel/40" aria-hidden />
        by {COMPANY}
        <span className="h-px w-6 bg-steel/40" aria-hidden />
      </p>
    </header>
  );
}

// Shown while the app starts up (or when the server can't be reached).
export function SplashScreen({ message, error = false }: { message?: string; error?: boolean }) {
  return (
    <div className="fixed inset-0 z-[80] flex flex-col items-center justify-center gap-8 bg-paper px-8 text-center">
      <BrandHeader />
      {error ? (
        <p role="alert" className="max-w-sm rounded-md border-l-4 border-alert bg-alert/10 px-4 py-3 text-ink animate-enter">
          {message ?? "Can't reach the server. Check your Wi-Fi and try again."}
        </p>
      ) : (
        <div className="flex flex-col items-center gap-3" role="status">
          <div className="h-1 w-40 overflow-hidden rounded-full bg-panel-raised">
            <div
              className="h-full w-full animate-shimmer"
              style={{
                backgroundImage: "linear-gradient(90deg, transparent 0%, #F5A524 50%, transparent 100%)",
                backgroundSize: "200% 100%",
              }}
            />
          </div>
          <p className="text-sm text-ink/50">{message ?? "Loading…"}</p>
        </div>
      )}
      <p className="absolute bottom-[calc(env(safe-area-inset-bottom)+1.25rem)] text-xs text-ink/35">
        Version {APP_VERSION} · Works offline on your local Wi-Fi
      </p>
    </div>
  );
}
