import { DatabaseSync } from "node:sqlite";
import { Item, ItemKind } from "./items";

// Weapon upgrades. Guns have four: magazine, damage, reload speed and fire
// rate; knives have two: sharpness and length. Each goes from level 1 (as
// bought) to level 5. The Admin sets a base price per upgrade; each next
// level costs double: level 2 = base, 3 = 2×base, 4 = 4×base, 5 = 8×base.
//
// Every number a level gives (magazine size, damage %, reload time, how hard
// to shake to fire) is worked out HERE and nowhere else: phones receive the
// finished numbers (see gunNumbers) and never re-implement the formulas.

export type Track = "magazine" | "damage" | "reload" | "firerate" | "sharpness" | "length";
export const TRACKS: Track[] = ["magazine", "damage", "reload", "firerate", "sharpness", "length"];
export const MAX_LEVEL = 5;

export const TRACKS_FOR: Partial<Record<ItemKind, Track[]>> = {
  gun: ["magazine", "damage", "reload", "firerate"],
  knife: ["sharpness", "length"],
};

export function tracksFor(kind: ItemKind): Track[] {
  return TRACKS_FOR[kind] ?? [];
}

export const TRACK_LABEL: Record<Track, string> = {
  magazine: "Magazine",
  damage: "Damage",
  reload: "Reload speed",
  firerate: "Fire rate",
  sharpness: "Sharpness",
  length: "Length",
};

export function basePriceFor(item: Item, track: Track): number | null {
  switch (track) {
    case "magazine":
      return item.up_price_magazine;
    case "damage":
      return item.up_price_damage;
    case "reload":
      return item.up_price_reload;
    case "firerate":
      return item.up_price_firerate;
    case "sharpness":
      return item.up_price_sharpness;
    case "length":
      return item.up_price_length;
  }
}

// Price to go from `currentLevel` to the next one.
export function upgradeCost(basePrice: number, currentLevel: number): number {
  return basePrice * 2 ** (currentLevel - 1);
}

// Sensible starting values when the Admin hasn't set them.
// A gun with no shake setting uses 4: about as hard to shake as before the
// fire-rate upgrade existed (14 m/s², ~0.3 s between shots).
export const DEFAULT_BASE = { magazine: 12, sharpness: 10, length: 20, reloadMs: 2000, shakeForce: 4 };
export const DEFAULT_DAMAGE_PER_LEVEL = 15; // % extra damage per level (calculator setting)

// ---- The shared formulas ---------------------------------------------------

// Reload time and the pause between shots both shrink 15% per level
// (level 5 ≈ 52% of level 1).
const SPEED_STEP = 0.85;

// How hard (m/s² of sudden movement) the phone must be shaken to fire.
// A light gun (force 3, pistol) fires at 12.6; a shotgun (force 9) needs
// 25.8. Each fire-rate level makes it 11% easier (level 5 = 56%).
export function shakeThreshold(force: number, level: number): number {
  return round1((6 + force * 2.2) * (1 - 0.11 * (level - 1)));
}

// Shortest time between two shots at level 1, in milliseconds.
export function cooldownBase(force: number): number {
  return 120 + force * 45;
}

export function cooldownMs(force: number, level: number): number {
  return Math.round(cooldownBase(force) * SPEED_STEP ** (level - 1));
}

export function reloadMs(baseReloadMs: number, level: number): number {
  return Math.round(baseReloadMs * SPEED_STEP ** (level - 1));
}

// Damage as a percent of level 1: 100, 115, 130… with the default 15%.
export function damagePct(damagePerLevel: number, level: number): number {
  return Math.round(100 + damagePerLevel * (level - 1));
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function forceOf(item: Item): number {
  return item.shake_force ?? DEFAULT_BASE.shakeForce;
}

// The "% extra damage per level" lives in the Admin's calculator settings
// (game_state 'calculator', JSON). Missing or unreadable = the default.
export function getDamagePerLevel(db: DatabaseSync): number {
  const row = db.prepare("SELECT value FROM game_state WHERE key = 'calculator'").get() as
    | { value: string }
    | undefined;
  if (!row) return DEFAULT_DAMAGE_PER_LEVEL;
  try {
    const v = (JSON.parse(row.value) as { damagePerLevel?: unknown })?.damagePerLevel;
    return typeof v === "number" && Number.isFinite(v) && v >= 0 && v <= 1000 ? v : DEFAULT_DAMAGE_PER_LEVEL;
  } catch {
    return DEFAULT_DAMAGE_PER_LEVEL;
  }
}

// The stat a track gives at a level:
//   magazine   rounds; grows ~20% per level (always at least +1)
//   damage     % of level 1 (100, 115, 130…)
//   reload     reload time in milliseconds (lower = faster)
//   firerate   shake needed to fire, m/s² (lower = fires with a lighter shake)
//   sharpness  grows ~15% per level (at least +1)
//   length     cm; +1 per level
// damagePerLevel only matters for "damage"; pass getDamagePerLevel(db).
export function statAt(
  item: Item,
  track: Track,
  level: number,
  damagePerLevel: number = DEFAULT_DAMAGE_PER_LEVEL
): number {
  switch (track) {
    case "damage":
      return damagePct(damagePerLevel, level);
    case "reload":
      return reloadMs(item.base_reload_ms ?? DEFAULT_BASE.reloadMs, level);
    case "firerate":
      return shakeThreshold(forceOf(item), level);
    case "length":
      return (item.base_length ?? DEFAULT_BASE.length) + (level - 1);
    case "magazine":
    case "sharpness": {
      const base =
        track === "magazine" ? item.base_magazine ?? DEFAULT_BASE.magazine : item.base_sharpness ?? DEFAULT_BASE.sharpness;
      const growth = track === "magazine" ? 0.2 : 0.15;
      let v = base;
      for (let l = 2; l <= level; l++) v = Math.max(v + 1, Math.round(base * (1 + growth * (l - 1))));
      return v;
    }
  }
}

export function levelsFor(db: DatabaseSync, playerId: number, itemId: number): Record<Track, number> {
  const out: Record<Track, number> = { magazine: 1, damage: 1, reload: 1, firerate: 1, sharpness: 1, length: 1 };
  for (const r of db
    .prepare("SELECT track, level FROM weapon_upgrades WHERE player_id = ? AND item_id = ?")
    .all(playerId, itemId) as unknown as Array<{ track: Track; level: number }>) {
    if (r.track in out) out[r.track] = r.level;
  }
  return out;
}

// Everything the weapon screen needs to know about one gun for one player,
// at that player's upgrade levels.
export interface GunNumbers {
  magazine: number; // rounds the magazine holds
  reloadMs: number; // how long a reload takes
  shakeThreshold: number; // m/s² of shake needed to fire
  cooldownMs: number; // shortest time between shots
  damagePct: number; // damage as % of level 1
}

export function gunNumbersAt(item: Item, levels: Record<Track, number>, damagePerLevel: number): GunNumbers {
  return {
    magazine: statAt(item, "magazine", levels.magazine),
    reloadMs: statAt(item, "reload", levels.reload),
    shakeThreshold: statAt(item, "firerate", levels.firerate),
    cooldownMs: cooldownMs(forceOf(item), levels.firerate),
    damagePct: statAt(item, "damage", levels.damage, damagePerLevel),
  };
}

export function gunNumbers(db: DatabaseSync, playerId: number, item: Item): GunNumbers {
  return gunNumbersAt(item, levelsFor(db, playerId, item.id), getDamagePerLevel(db));
}

export interface TrackView {
  track: Track;
  level: number;
  maxLevel: number;
  value: number | null; // stat now (see statAt for units)
  nextValue: number | null; // stat after the next upgrade
  nextCost: number | null; // null = maxed out, or the Admin hasn't priced it yet
  available: boolean;
}

// What a player sees for one weapon they own.
export function weaponView(db: DatabaseSync, playerId: number, item: Item): TrackView[] {
  const levels = levelsFor(db, playerId, item.id);
  const perLevel = getDamagePerLevel(db);
  return tracksFor(item.kind).map((track) => {
    const level = levels[track];
    const base = basePriceFor(item, track);
    const maxed = level >= MAX_LEVEL;
    return {
      track,
      level,
      maxLevel: MAX_LEVEL,
      value: statAt(item, track, level, perLevel),
      nextValue: maxed ? null : statAt(item, track, level + 1, perLevel),
      nextCost: maxed || base === null ? null : upgradeCost(base, level),
      available: !maxed && base !== null,
    };
  });
}

export function clearUpgrades(db: DatabaseSync, playerId: number, itemId: number): void {
  db.prepare("DELETE FROM weapon_upgrades WHERE player_id = ? AND item_id = ?").run(playerId, itemId);
}

export function setLevel(db: DatabaseSync, playerId: number, itemId: number, track: Track, level: number): void {
  db.prepare(
    `INSERT INTO weapon_upgrades (player_id, item_id, track, level) VALUES (?, ?, ?, ?)
     ON CONFLICT(player_id, item_id, track) DO UPDATE SET level = excluded.level`
  ).run(playerId, itemId, track, level);
}
