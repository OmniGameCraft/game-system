import { FormEvent, useState } from "react";
import { Button } from "../components/Button";
import { ErrorBanner } from "../components/ErrorBanner";
import { PasswordField, TextField } from "../components/Field";
import { BackButton } from "../components/BackButton";
import { Section } from "../components/Section";
import { PublicUser, setupAdmin } from "../services/api";

export function AdminSetupForm({
  onSuccess,
  onBack,
}: {
  onSuccess: (user: PublicUser) => void;
  onBack: () => void;
}) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError(null);
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    try {
      const user = await setupAdmin({ username, password, confirmPassword });
      onSuccess(user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Setup failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <BackButton label="Back" onClick={onBack} />
      <Section title="Create the first Admin account">
      <p className="rounded-md bg-pine-soft px-4 py-3 text-ink/80">
        No admin exists yet. Whoever sets this up runs the game.
      </p>
      <ErrorBanner message={error} />
      <TextField
        id="new-username"
        label="Username"
        autoComplete="username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
      />
      <PasswordField
        id="new-password"
        label="Password"
        autoComplete="new-password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <PasswordField
        id="confirm-password"
        label="Confirm password"
        autoComplete="new-password"
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
        required
      />
      <p className="text-sm text-ink/60">At least 8 characters, with a letter and a number.</p>
      <Button type="submit" loading={loading}>
        Create Admin account
      </Button>
      </Section>
    </form>
  );
}
