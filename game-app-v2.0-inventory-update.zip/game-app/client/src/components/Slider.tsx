import { CSSProperties, ReactNode, useEffect, useId, useRef } from "react";

// A big, thumb-friendly slider (volume, shake sensitivity…). It is a normal
// range input underneath, so it works with touch, mouse, keyboard and screen
// readers. The amber fill shows how far up it is.
export function Slider({
  label,
  value,
  onChange,
  onCommit,
  min = 0,
  max = 100,
  step = 1,
  format,
  leftLabel,
  rightLabel,
  disabled,
  icon,
  hideLabel,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  // Called once the finger lets go (e.g. play a sample at the new volume).
  onCommit?: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
  format?: (v: number) => string;
  leftLabel?: ReactNode;
  rightLabel?: ReactNode;
  disabled?: boolean;
  icon?: ReactNode;
  hideLabel?: boolean;
}) {
  const id = useId();
  const pct = max > min ? ((value - min) / (max - min)) * 100 : 0;
  const text = format ? format(value) : String(value);
  // The browser's own "change" event fires once, when the finger lets go
  // (React's onChange fires on every move, which is what onChange is for).
  const ref = useRef<HTMLInputElement>(null);
  const commitRef = useRef(onCommit);
  commitRef.current = onCommit;
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fn = () => commitRef.current?.(Number(el.value));
    el.addEventListener("change", fn);
    return () => el.removeEventListener("change", fn);
  }, []);
  return (
    <div className={`flex flex-col ${disabled ? "opacity-60" : ""}`}>
      <div className={`flex items-center gap-3 ${hideLabel ? "sr-only" : ""}`}>
        {icon && <span className="text-ink/50" aria-hidden>{icon}</span>}
        <label htmlFor={id} className="min-w-0 flex-1 text-base font-semibold text-ink/80">
          {label}
        </label>
        <span className="font-display text-lg font-bold tabular-nums text-pine" aria-hidden>
          {text}
        </span>
      </div>
      <input
        ref={ref}
        id={id}
        type="range"
        className="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        aria-valuetext={text}
        style={{ "--pct": `${pct}%` } as CSSProperties}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      {(leftLabel || rightLabel) && (
        <div className="-mt-1 flex justify-between gap-4 text-xs font-semibold text-ink/45" aria-hidden>
          <span>{leftLabel}</span>
          <span className="text-right">{rightLabel}</span>
        </div>
      )}
    </div>
  );
}
