export function Notice({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="status" className="rounded-sm border-l-4 border-olive bg-olive-soft px-4 py-3 font-medium text-ink">
      {message}
    </p>
  );
}
