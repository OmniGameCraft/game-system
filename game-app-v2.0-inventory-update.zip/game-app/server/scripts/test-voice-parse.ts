// Checks the voice hit-call reader (src/voiceParse.ts) against phrases a
// referee might say and things people say that must NOT count as a hit.
//
// Run it from the server folder:
//     npx tsx scripts/test-voice-parse.ts
// It prints PASS/FAIL for every phrase and exits with an error code if any
// failed. The phones use an exact copy of the same reader
// (client/src/voice/parse.ts), so this checks both.

import { digitsForHighest, parseCallout } from "../src/voiceParse";

type Expect = [target: number, damage: number] | null;
interface Case {
  text: string;
  digits: number; // D: 1 while all player numbers are 1–9, else 2
  expect: Expect;
  why?: string;
}

const cases: Case[] = [
  // ---- One-digit player numbers (D = 1) ----
  { text: "three four zero", digits: 1, expect: [3, 40] },
  { text: "three forty", digits: 1, expect: [3, 40] },
  { text: "340", digits: 1, expect: [3, 40] },
  { text: "3 40", digits: 1, expect: [3, 40] },
  { text: "3-40", digits: 1, expect: [3, 40] },
  { text: "3:40", digits: 1, expect: [3, 40], why: "speech recognition may write it as a time" },
  { text: "3.40", digits: 1, expect: [3, 40] },
  { text: "player 3, 40", digits: 1, expect: [3, 40] },
  { text: "Player three, forty.", digits: 1, expect: [3, 40] },
  { text: "  PLAYER   THREE   FORTY  ", digits: 1, expect: [3, 40] },
  { text: "hit three forty", digits: 1, expect: [3, 40] },
  { text: "player3 damage 40", digits: 1, expect: [3, 40] },
  { text: "player's three forty hp", digits: 1, expect: [3, 40] },
  { text: "player number three forty points", digits: 1, expect: [3, 40] },
  { text: "three hundred forty", digits: 1, expect: [3, 40] },
  { text: "three hundred and forty", digits: 1, expect: [3, 40] },
  { text: "tree forty", digits: 1, expect: [3, 40] },
  { text: "to fifty", digits: 1, expect: [2, 50] },
  { text: "too twenty five", digits: 1, expect: [2, 25] },
  { text: "two twenty-five", digits: 1, expect: [2, 25] },
  { text: "for forty", digits: 1, expect: [4, 40] },
  { text: "won ten", digits: 1, expect: [1, 10] },
  { text: "ate sixty", digits: 1, expect: [8, 60] },
  { text: "fife fifteen", digits: 1, expect: [5, 15] },
  { text: "niner ninety nine", digits: 1, expect: [9, 99] },
  { text: "player 3 for 40", digits: 1, expect: [3, 40], why: "'for' here is the word, not 4" },
  { text: "player three to fifty", digits: 1, expect: [3, 50], why: "'to' here is the word, not 2" },
  { text: "three for zero", digits: 1, expect: [3, 40], why: "'for' as the word gives 0 damage, so it is 4" },
  { text: "seven, one hundred", digits: 1, expect: [7, 100] },
  { text: "seven a hundred", digits: 1, expect: [7, 100] },
  { text: "seven won hundred", digits: 1, expect: [7, 100] },
  { text: "one hundred twenty", digits: 1, expect: [1, 20] },
  { text: "six oh five", digits: 1, expect: [6, 5] },
  { text: "5 999", digits: 1, expect: [5, 999] },
  { text: "five nine hundred ninety nine", digits: 1, expect: [5, 999] },
  { text: "forty-five", digits: 1, expect: [4, 5] },
  { text: "three four", digits: 1, expect: [3, 4] },
  { text: "nine one", digits: 1, expect: [9, 1] },

  // ---- Two-digit player numbers (D = 2): Player 3 is "zero three" ----
  { text: "zero three forty", digits: 2, expect: [3, 40] },
  { text: "oh three forty", digits: 2, expect: [3, 40] },
  { text: "o 3 40", digits: 2, expect: [3, 40] },
  { text: "0340", digits: 2, expect: [3, 40] },
  { text: "twelve fifty", digits: 2, expect: [12, 50] },
  { text: "12 50", digits: 2, expect: [12, 50] },
  { text: "1250", digits: 2, expect: [12, 50] },
  { text: "player twelve, one twenty", digits: 2, expect: [12, 120] },
  { text: "twenty to forty", digits: 2, expect: [20, 40], why: "'to' after the player number is the word" },
  { text: "zero three for forty", digits: 2, expect: [3, 40] },
  { text: "zero three one hundred", digits: 2, expect: [3, 100] },
  { text: "ninety nine nine hundred ninety nine", digits: 2, expect: [99, 999] },
  { text: "eleven five", digits: 2, expect: [11, 5] },
  { text: "fifteen hundred", digits: 2, expect: [15, 100] },
  { text: "three forty", digits: 2, expect: null, why: "with D = 2 this is player 34 with 0 damage" },
  { text: "1250", digits: 3, expect: [12, 50], why: "D can never be more than 2" },
  { text: "340", digits: 0, expect: [3, 40], why: "D can never be less than 1" },

  // ---- Not a call: nothing may happen ----
  { text: "", digits: 1, expect: null },
  { text: "player", digits: 1, expect: null },
  { text: "hit", digits: 1, expect: null },
  { text: "seven", digits: 1, expect: null, why: "no damage" },
  { text: "three zero", digits: 1, expect: null, why: "0 damage" },
  { text: "zero forty", digits: 1, expect: null, why: "there is no player 0" },
  { text: "three one thousand", digits: 1, expect: null },
  { text: "31000", digits: 1, expect: null, why: "damage above 999" },
  { text: "3 0040", digits: 1, expect: null, why: "damage longer than three digits" },
  { text: "give me 25 seconds", digits: 1, expect: null },
  { text: "I'm hit", digits: 1, expect: null },
  { text: "go for it", digits: 1, expect: null },
  { text: "free for all", digits: 1, expect: null },
  { text: "three forty three forty", digits: 1, expect: null, why: "two calls at once can't be split safely" },
  { text: "constructor 40", digits: 1, expect: null, why: "built-in names are not number words" },
  { text: "toString forty", digits: 1, expect: null },
  { text: "a forty", digits: 1, expect: null },
  { text: "three forty " + "x".repeat(300), digits: 1, expect: null, why: "far too long to be a call" },
];

// The digit rule itself.
const digitCases: Array<[highest: number | null, expect: number]> = [
  [null, 1],
  [1, 1],
  [9, 1],
  [10, 2],
  [99, 2],
];

let failed = 0;
const show = (e: Expect) => (e ? `player ${e[0]}, ${e[1]} HP` : "not a call");

for (const c of cases) {
  const got = parseCallout(c.text, c.digits);
  const gotExpect: Expect = got ? [got.target, got.damage] : null;
  const ok = JSON.stringify(gotExpect) === JSON.stringify(c.expect);
  if (!ok) failed++;
  const label = c.text.length > 50 ? c.text.slice(0, 47) + "..." : c.text;
  console.log(
    `${ok ? "PASS" : "FAIL"}  D=${c.digits}  "${label}" → ${show(gotExpect)}` +
      (ok ? "" : `   (expected ${show(c.expect)})`) +
      (c.why ? `   — ${c.why}` : "")
  );
}

for (const [highest, expect] of digitCases) {
  const got = digitsForHighest(highest);
  const ok = got === expect;
  if (!ok) failed++;
  console.log(`${ok ? "PASS" : "FAIL"}  highest player number ${highest ?? "none"} → D=${got}`);
}

const total = cases.length + digitCases.length;
console.log(`\n${total - failed} of ${total} passed.`);
if (failed > 0) {
  console.log(`${failed} FAILED.`);
  process.exit(1);
}
