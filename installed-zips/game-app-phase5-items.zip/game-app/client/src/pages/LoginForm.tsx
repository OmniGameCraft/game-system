import { FormEvent, useState } from "react";
import { Button } from "../components/Button";
import { ErrorBanner } from "../components/ErrorBanner";
import { PasswordField, TextField } from "../components/Field";
import { login, PublicUser, Role } from "../services/api";

interface Props {
  role: Role;
  hint?: string;
  onSuccess: (user: PublicUser) => void;
  onBack: () => void;
}

export function LoginForm({ role, hint, onSuccess, onBack }: Props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setLoading(true);
    try {
      const user = await login({ role, username, password });
      onSuccess(user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <h2 className="text-2xl font-bold capitalize text-pine">{role} login</h2>
      {hint && <p className="rounded-xl bg-pine-soft px-4 py-3 text-ink/80">{hint}</p>}
      <ErrorBanner message={error} />
      <TextField
        id="username"
        label="Username"
        autoComplete="username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
      />
      <PasswordField
        id="password"
        label="Password"
        autoComplete="current-password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <Button type="submit" loading={loading}>
        Log in
      </Button>
      <Button type="button" variant="ghost" onClick={onBack}>
        Back
      </Button>
    </form>
  );
}
