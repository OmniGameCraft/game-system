import { FormEvent, useState } from "react";
import { BackButton } from "../../components/BackButton";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { PasswordField, TextField } from "../../components/Field";
import { Section } from "../../components/Section";
import { createPlayer, Player } from "../../services/api";

export function CreatePlayerForm({ onCreated, onBack }: { onCreated: (player: Player) => void; onBack: () => void }) {
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError(null);
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    try {
      onCreated(await createPlayer({ username, password, confirmPassword, displayName: displayName || undefined }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create player.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <BackButton label="Players" onClick={onBack} />
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Section title="New player">
          <ErrorBanner message={error} />
          <TextField
            id="player-username"
            label="Username"
            hint="What the player types to log in. Letters, numbers, dots, - or _."
            autoCapitalize="none"
            autoCorrect="off"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <TextField
            id="player-display-name"
            label="Display name (optional)"
            hint="The name shown in the app."
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
          />
        </Section>
        <Section title="Password">
          <PasswordField
            id="player-password"
            label="Password"
            hint="At least 8 characters, with a letter and a number."
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <PasswordField
            id="player-confirm-password"
            label="Confirm password"
            autoComplete="new-password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </Section>
        <Button type="submit" loading={loading}>
          Create Player
        </Button>
      </form>
    </>
  );
}
