import { useState } from "react";
import { AppShell, Tab } from "../components/AppShell";
import { Icon } from "../components/Icon";
import { PublicUser } from "../services/api";
import { CreatePlayerForm } from "./admin/CreatePlayerForm";
import { ItemForm } from "./admin/ItemForm";
import { ItemsList } from "./admin/ItemsList";
import { PlayerDetails } from "./admin/PlayerDetails";
import { PlayersList } from "./admin/PlayersList";
import { AdminShop } from "./admin/AdminShop";

type Section = "players" | "items" | "shop";
type View = { name: "list" } | { name: "create" } | { name: "details"; id: number };

const TABS: Tab<Section>[] = [
  { key: "players", label: "Players", icon: "users" },
  { key: "items", label: "Items", icon: "box" },
  { key: "shop", label: "Shop", icon: "store" },
];

export function AdminHome({ user, onLogout }: { user: PublicUser; onLogout: () => void }) {
  const [section, setSection] = useState<Section>("players");
  const [view, setView] = useState<View>({ name: "list" });

  function switchSection(s: Section) {
    setSection(s);
    setView({ name: "list" });
    window.scrollTo(0, 0);
  }
  function go(v: View) {
    setView(v);
    window.scrollTo(0, 0);
  }

  const title = TABS.find((t) => t.key === section)!.label;

  return (
    <AppShell
      title={title}
      subtitle={`Admin · ${user.username}`}
      tabs={TABS}
      active={section}
      onTab={switchSection}
      onLogout={onLogout}
      right={
        <button
          onClick={onLogout}
          className="flex min-h-[2.75rem] items-center gap-1 rounded-lg border-2 border-white/30 px-3 text-sm font-bold md:hidden"
        >
          <Icon name="logout" className="h-5 w-5" />
          Log out
        </button>
      }
    >
      {section === "players" && (
        <>
          {view.name === "list" && (
            <PlayersList onCreate={() => go({ name: "create" })} onOpen={(id) => go({ name: "details", id })} />
          )}
          {view.name === "create" && (
            <CreatePlayerForm
              onCreated={(player) => go({ name: "details", id: player.id })}
              onBack={() => go({ name: "list" })}
            />
          )}
          {view.name === "details" && <PlayerDetails id={view.id} onBack={() => go({ name: "list" })} />}
        </>
      )}

      {section === "items" && (
        <>
          {view.name === "list" && (
            <ItemsList onCreate={() => go({ name: "create" })} onOpen={(id) => go({ name: "details", id })} />
          )}
          {view.name === "create" && (
            <ItemForm onSaved={(item) => go({ name: "details", id: item.id })} onBack={() => go({ name: "list" })} />
          )}
          {view.name === "details" && (
            <ItemForm key={view.id} id={view.id} onSaved={() => {}} onBack={() => go({ name: "list" })} />
          )}
        </>
      )}

      {section === "shop" && <AdminShop />}
    </AppShell>
  );
}
