// A player's initial on a small steel plate.
export function Avatar({ name, size = "md" }: { name: string; size?: "md" | "lg" }) {
  const box = size === "lg" ? "h-16 w-16 text-2xl" : "h-12 w-12 text-lg";
  return (
    <div
      className={`${box} flex shrink-0 items-center justify-center rounded-lg border border-panel-line bg-gradient-to-b from-[#2a2d32] to-[#16181b] font-display font-bold text-pine shadow-[inset_0_1px_0_rgba(255,255,255,0.12),0_2px_6px_-2px_rgba(0,0,0,0.8)]`}
      aria-hidden
    >
      {name.trim().charAt(0).toUpperCase() || "?"}
    </div>
  );
}
