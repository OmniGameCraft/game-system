import { InputHTMLAttributes, useState } from "react";

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
}

export function TextField({ label, id, ...rest }: FieldProps) {
  return (
    <label htmlFor={id} className="block">
      <span className="mb-1 block text-base font-medium text-ink/80">{label}</span>
      <input
        id={id}
        className="w-full rounded-xl border-2 border-ink/15 bg-white px-4 py-3 text-lg
                   outline-none focus:border-pine"
        {...rest}
      />
    </label>
  );
}

export function PasswordField({ label, id, ...rest }: FieldProps) {
  const [visible, setVisible] = useState(false);
  return (
    <label htmlFor={id} className="block">
      <span className="mb-1 block text-base font-medium text-ink/80">{label}</span>
      <div className="relative">
        <input
          id={id}
          type={visible ? "text" : "password"}
          className="w-full rounded-xl border-2 border-ink/15 bg-white px-4 py-3 pr-20 text-lg
                     outline-none focus:border-pine"
          {...rest}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          className="absolute inset-y-0 right-2 my-1 rounded-lg px-3 text-sm font-semibold text-pine"
          aria-label={visible ? "Hide password" : "Show password"}
        >
          {visible ? "Hide" : "Show"}
        </button>
      </div>
    </label>
  );
}
