/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#F3F4EE",
        ink: "#15211C",
        pine: { DEFAULT: "#1B4332", soft: "#DCE8E0" },
        sun: "#F2C230",
        alert: "#B3261E",
      },
      // System fonts only: nothing is fetched from the internet.
      // Short one-shot animations for the item viewer (2D fallback + flash).
      keyframes: {
        shotflash: { "0%": { opacity: "0.35" }, "100%": { opacity: "0" } },
        recoil: {
          "0%": { transform: "translateX(0) rotate(0)" },
          "20%": { transform: "translateX(-18px) rotate(-9deg)" },
          "100%": { transform: "translateX(0) rotate(0)" },
        },
        swing: {
          "0%": { transform: "rotate(0)" },
          "40%": { transform: "rotate(55deg) translateX(20px)" },
          "100%": { transform: "rotate(0)" },
        },
        spinonce: { "0%": { transform: "rotateY(0)" }, "100%": { transform: "rotateY(360deg)" } },
      },
      animation: {
        shotflash: "shotflash 110ms ease-out forwards",
        recoil: "recoil 220ms ease-out",
        swing: "swing 320ms ease-in-out",
        "spin-once": "spinonce 700ms ease-out",
      },
      fontFamily: {
        sans: ["system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"],
      },
    },
  },
  plugins: [],
};
