import { audioContext, audioReady, busAudible, clickBus, noiseBuffer, sfxBus, unlockAudio } from "./engine";

// Every sound effect in the app, each a tiny recipe of tones and noise made
// on the spot (no sound files). Short, soft-edged and quiet enough to hear
// over and over without getting annoying.

export type SfxName =
  | "click"
  | "toggle"
  | "tab"
  | "open"
  | "close"
  | "success"
  | "error"
  | "purchase"
  | "sell"
  | "upgrade"
  | "pickup"
  | "drop"
  | "mix"
  | "heal"
  | "hit"
  | "death"
  | "reload"
  | "dryfire"
  | "gamestart"
  | "pause"
  | "gameover"
  | "message"
  | "rotate"
  | "snap";

// Taps on buttons, switches and tabs follow the "Button clicks" volume;
// everything else follows "Sound effects".
const CLICK_SOUNDS: ReadonlySet<SfxName> = new Set<SfxName>(["click", "toggle", "tab"]);

type Ctx = BaseAudioContext;

interface ToneOpts {
  t: number; // start time
  f: number; // frequency (Hz)
  to?: number; // glide to this frequency…
  glide?: number; // …over this many seconds (default: the whole sound)
  type?: OscillatorType;
  a?: number; // attack seconds
  d: number; // decay seconds (to silence)
  g: number; // peak level
  lp?: number; // optional low-pass filter (Hz)
  detune?: number;
}

function tone(c: Ctx, out: AudioNode, o: ToneOpts) {
  const osc = c.createOscillator();
  osc.type = o.type ?? "sine";
  osc.frequency.setValueAtTime(o.f, o.t);
  if (o.detune) osc.detune.value = o.detune;
  const a = o.a ?? 0.003;
  if (o.to) osc.frequency.exponentialRampToValueAtTime(o.to, o.t + (o.glide ?? a + o.d));
  const amp = c.createGain();
  amp.gain.setValueAtTime(0.0001, o.t);
  amp.gain.linearRampToValueAtTime(o.g, o.t + a);
  amp.gain.exponentialRampToValueAtTime(0.0001, o.t + a + o.d);
  let head: AudioNode = osc;
  let filter: BiquadFilterNode | null = null;
  if (o.lp) {
    filter = c.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = o.lp;
    osc.connect(filter);
    head = filter;
  }
  head.connect(amp).connect(out);
  osc.start(o.t);
  osc.stop(o.t + a + o.d + 0.03);
  osc.onended = () => {
    amp.disconnect();
    filter?.disconnect();
  };
}

interface NoiseOpts {
  t: number;
  type: BiquadFilterType;
  f: number; // filter frequency
  to?: number; // sweep the filter to this frequency
  q?: number;
  a?: number;
  d: number;
  g: number;
}

function hiss(c: Ctx, out: AudioNode, noise: AudioBuffer, o: NoiseOpts) {
  const src = c.createBufferSource();
  src.buffer = noise;
  const a = o.a ?? 0.001;
  const f = c.createBiquadFilter();
  f.type = o.type;
  f.frequency.setValueAtTime(o.f, o.t);
  if (o.to) f.frequency.exponentialRampToValueAtTime(o.to, o.t + a + o.d);
  f.Q.value = o.q ?? 0.8;
  const amp = c.createGain();
  amp.gain.setValueAtTime(0.0001, o.t);
  amp.gain.linearRampToValueAtTime(o.g, o.t + a);
  amp.gain.exponentialRampToValueAtTime(0.0001, o.t + a + o.d);
  src.connect(f).connect(amp).connect(out);
  src.start(o.t, Math.random() * 0.5, a + o.d + 0.05);
  src.onended = () => {
    f.disconnect();
    amp.disconnect();
  };
}

// A struck-bell tone: a pure note plus the bell's slightly "off" overtones.
function bell(c: Ctx, out: AudioNode, t: number, f: number, g: number, d: number) {
  tone(c, out, { t, f, g, d, a: 0.004 });
  tone(c, out, { t, f: f * 2.01, g: g * 0.22, d: d * 0.55, a: 0.003 });
  tone(c, out, { t, f: f * 3.02, g: g * 0.07, d: d * 0.3, a: 0.002 });
}

// A short brass note (game start / game over horns): three slightly detuned
// buzzy tones through a filter that opens as the note starts, like a breath.
function brass(c: Ctx, out: AudioNode, t: number, f: number, len: number, g: number, bright = 2600) {
  const filter = c.createBiquadFilter();
  filter.type = "lowpass";
  filter.Q.value = 0.9;
  filter.frequency.setValueAtTime(350, t);
  filter.frequency.linearRampToValueAtTime(bright, t + 0.06);
  filter.frequency.setTargetAtTime(bright * 0.5, t + 0.08, 0.2);
  const amp = c.createGain();
  amp.gain.setValueAtTime(0.0001, t);
  amp.gain.linearRampToValueAtTime(g, t + 0.04);
  amp.gain.setTargetAtTime(g * 0.75, t + 0.05, 0.15);
  amp.gain.setTargetAtTime(0.0001, t + len, 0.09);
  filter.connect(amp).connect(out);
  const end = t + len + 0.6;
  [-9, 0, 8].forEach((cents, i) => {
    const o = c.createOscillator();
    o.type = "sawtooth";
    o.frequency.value = f;
    o.detune.value = cents;
    o.connect(filter);
    o.start(t);
    o.stop(end);
    if (i === 0)
      o.onended = () => {
        filter.disconnect();
        amp.disconnect();
      };
  });
  tone(c, out, { t, f: f / 2, g: g * 0.6, a: 0.04, d: len + 0.25 });
}

const NOTE = {
  B4: 493.88,
  C5: 523.25,
  E5: 659.25,
  G5: 783.99,
  B5: 987.77,
  C6: 1046.5,
  E6: 1318.51,
  G6: 1567.98,
  B6: 1975.53,
  C7: 2093.0,
};

type Recipe = (c: Ctx, out: AudioNode, t: number, n: AudioBuffer) => void;

const RECIPES: Record<SfxName, Recipe> = {
  // A tiny, soft tick: there is one on almost every tap, so it must be subtle.
  click: (c, out, t, n) => {
    const v = 0.96 + Math.random() * 0.08;
    hiss(c, out, n, { t, type: "bandpass", f: 4200 * v, q: 1.4, d: 0.012, g: 0.11 });
    tone(c, out, { t, f: 1850 * v, to: 1450 * v, a: 0.001, d: 0.02, g: 0.05 });
  },
  toggle: (c, out, t, n) => {
    hiss(c, out, n, { t, type: "bandpass", f: 3500, q: 1.5, d: 0.01, g: 0.07 });
    tone(c, out, { t, f: 660, type: "triangle", d: 0.045, g: 0.1 });
    tone(c, out, { t: t + 0.05, f: 990, type: "triangle", d: 0.07, g: 0.09 });
  },
  tab: (c, out, t, n) => {
    tone(c, out, { t, f: 620, to: 430, glide: 0.06, d: 0.09, g: 0.12 });
    hiss(c, out, n, { t, type: "lowpass", f: 2600, d: 0.015, g: 0.05 });
  },
  // Sheets sliding up / away: a soft "whoosh".
  open: (c, out, t, n) => {
    hiss(c, out, n, { t, type: "bandpass", f: 500, to: 2300, q: 0.9, a: 0.04, d: 0.16, g: 0.13 });
    tone(c, out, { t, f: 520, to: 780, a: 0.01, d: 0.12, g: 0.06 });
  },
  close: (c, out, t, n) => {
    hiss(c, out, n, { t, type: "bandpass", f: 1900, to: 450, q: 0.9, a: 0.02, d: 0.14, g: 0.1 });
    tone(c, out, { t, f: 700, to: 470, a: 0.005, d: 0.1, g: 0.05 });
  },
  success: (c, out, t) => {
    bell(c, out, t, NOTE.C6, 0.15, 0.5);
    bell(c, out, t + 0.09, NOTE.G6, 0.13, 0.7);
  },
  error: (c, out, t) => {
    for (const s of [0, 0.14]) {
      tone(c, out, { t: t + s, f: 150, type: "square", a: 0.005, d: 0.11, g: 0.07, lp: 1100 });
      tone(c, out, { t: t + s, f: 143, type: "sawtooth", a: 0.005, d: 0.11, g: 0.05, lp: 900 });
    }
  },
  // Coin: the classic two-note "ka-ching" of buying something.
  purchase: (c, out, t) => {
    tone(c, out, { t, f: NOTE.B5, type: "square", d: 0.08, g: 0.07, lp: 4200 });
    tone(c, out, { t: t + 0.075, f: NOTE.E6, type: "square", d: 0.42, g: 0.07, lp: 4200 });
    tone(c, out, { t: t + 0.075, f: NOTE.E6 * 2, d: 0.3, g: 0.03 });
  },
  sell: (c, out, t, n) => {
    hiss(c, out, n, { t, type: "highpass", f: 5000, d: 0.06, g: 0.05 });
    bell(c, out, t + 0.05, NOTE.G6, 0.09, 0.35);
    bell(c, out, t + 0.13, NOTE.C7, 0.09, 0.55);
    hiss(c, out, n, { t: t + 0.13, type: "highpass", f: 6500, a: 0.01, d: 0.2, g: 0.035 });
  },
  // Rising notes: things just got better.
  upgrade: (c, out, t) => {
    const notes = [NOTE.C5, NOTE.E5, NOTE.G5, NOTE.C6, NOTE.E6];
    notes.forEach((f, i) => {
      const last = i === notes.length - 1;
      tone(c, out, { t: t + i * 0.06, f, type: "triangle", d: last ? 0.6 : 0.16, g: last ? 0.11 : 0.09 });
    });
    tone(c, out, { t, f: 300, to: 1200, glide: 0.3, a: 0.05, d: 0.3, g: 0.035 });
    bell(c, out, t + 0.3, NOTE.E6 * 2, 0.03, 0.6);
  },
  pickup: (c, out, t, n) => {
    tone(c, out, { t, f: 420, to: 980, glide: 0.08, d: 0.12, g: 0.14 });
    tone(c, out, { t: t + 0.06, f: 1320, type: "triangle", d: 0.1, g: 0.05 });
    hiss(c, out, n, { t, type: "bandpass", f: 3000, d: 0.02, g: 0.04 });
  },
  drop: (c, out, t, n) => {
    tone(c, out, { t, f: 520, to: 170, glide: 0.14, d: 0.16, g: 0.12 });
    hiss(c, out, n, { t: t + 0.1, type: "lowpass", f: 700, d: 0.08, g: 0.12 });
    tone(c, out, { t: t + 0.1, f: 95, to: 60, d: 0.12, g: 0.16 });
  },
  // Bubbles in a pot, then a little chime: herbs mixed.
  mix: (c, out, t) => {
    let s = 0;
    for (let i = 0; i < 6; i++) {
      const f = 450 + Math.random() * 550;
      tone(c, out, { t: t + s, f, to: f * 1.9, glide: 0.05, a: 0.004, d: 0.06, g: 0.07 });
      s += 0.045 + Math.random() * 0.035;
    }
    bell(c, out, t + s + 0.04, NOTE.E6, 0.07, 0.5);
    bell(c, out, t + s + 0.1, NOTE.B6, 0.05, 0.6);
  },
  // Warm rising swell with a sparkle on top: health coming back.
  heal: (c, out, t, n) => {
    tone(c, out, { t, f: 480, to: 960, glide: 0.35, a: 0.08, d: 0.4, g: 0.05 });
    [NOTE.C6, NOTE.E6, NOTE.G6, NOTE.B6].forEach((f, i) => {
      tone(c, out, { t: t + 0.05 + i * 0.035, f, a: 0.02, d: 0.9, g: 0.05 });
      tone(c, out, { t: t + 0.23 + i * 0.035, f, a: 0.02, d: 0.7, g: 0.018 }); // soft echo
    });
    hiss(c, out, n, { t: t + 0.05, type: "highpass", f: 7000, a: 0.05, d: 0.5, g: 0.025 });
  },
  // A body blow: deep punch + impact.
  // (The deep part is for headphones; the mid "thwack" and the slap are what
  // a phone speaker can actually play.)
  hit: (c, out, t, n) => {
    tone(c, out, { t, f: 150, to: 45, glide: 0.18, a: 0.002, d: 0.26, g: 0.4 });
    tone(c, out, { t, f: 330, to: 110, glide: 0.12, type: "triangle", a: 0.002, d: 0.16, g: 0.22 });
    hiss(c, out, n, { t, type: "lowpass", f: 1400, to: 250, d: 0.13, g: 0.24 });
    hiss(c, out, n, { t, type: "bandpass", f: 2200, q: 1, d: 0.03, g: 0.12 });
  },
  // Long, low and falling.
  death: (c, out, t, n) => {
    tone(c, out, { t, f: 220, to: 55, glide: 1.3, type: "sawtooth", a: 0.03, d: 1.4, g: 0.09, lp: 900 });
    tone(c, out, { t, f: 222, to: 56, glide: 1.3, type: "sawtooth", a: 0.03, d: 1.4, g: 0.07, lp: 700, detune: 12 });
    tone(c, out, { t, f: 75, to: 34, glide: 1.2, a: 0.01, d: 1.3, g: 0.3 });
    hiss(c, out, n, { t, type: "lowpass", f: 500, to: 120, a: 0.05, d: 0.9, g: 0.08 });
  },
  // Magazine out (click + slide), magazine in (thunk), lock (click).
  reload: (c, out, t, n) => {
    hiss(c, out, n, { t, type: "bandpass", f: 1800, q: 3, d: 0.03, g: 0.2 });
    tone(c, out, { t, f: 900, to: 600, type: "triangle", d: 0.03, g: 0.05 });
    hiss(c, out, n, { t: t + 0.05, type: "bandpass", f: 2600, to: 1200, q: 1.5, a: 0.01, d: 0.09, g: 0.05 });
    hiss(c, out, n, { t: t + 0.28, type: "bandpass", f: 1200, q: 2, d: 0.045, g: 0.24 });
    tone(c, out, { t: t + 0.28, f: 190, to: 120, d: 0.07, g: 0.16 });
    tone(c, out, { t: t + 0.28, f: 2400, type: "triangle", d: 0.05, g: 0.035 });
    hiss(c, out, n, { t: t + 0.43, type: "bandpass", f: 3600, q: 4, d: 0.02, g: 0.16 });
    tone(c, out, { t: t + 0.43, f: 1500, type: "triangle", d: 0.03, g: 0.04 });
  },
  // Empty gun: one dry metal click.
  dryfire: (c, out, t, n) => {
    hiss(c, out, n, { t, type: "bandpass", f: 3200, q: 4, a: 0.0005, d: 0.02, g: 0.28 });
    tone(c, out, { t, f: 1700, to: 1300, type: "triangle", d: 0.025, g: 0.07 });
    tone(c, out, { t, f: 380, d: 0.025, g: 0.05 });
  },
  // "Ta-daa" horn: the game is on.
  gamestart: (c, out, t) => {
    brass(c, out, t, 220, 0.16, 0.055);
    brass(c, out, t + 0.2, 329.63, 0.75, 0.055, 3000);
    brass(c, out, t + 0.2, 493.88, 0.75, 0.035, 3000);
    bell(c, out, t + 0.2, NOTE.E6, 0.04, 0.9);
  },
  pause: (c, out, t) => {
    tone(c, out, { t, f: NOTE.E5, type: "triangle", a: 0.01, d: 0.25, g: 0.1 });
    tone(c, out, { t: t + 0.16, f: NOTE.B4, type: "triangle", a: 0.01, d: 0.45, g: 0.1 });
  },
  gameover: (c, out, t) => {
    brass(c, out, t, 392, 0.22, 0.045, 2000);
    brass(c, out, t + 0.28, 329.63, 0.22, 0.045, 1800);
    brass(c, out, t + 0.56, 261.63, 1.1, 0.05, 1500);
  },
  // Gentle "ding-dong": a message from the Admin.
  message: (c, out, t) => {
    bell(c, out, t, NOTE.E6, 0.12, 0.7);
    bell(c, out, t + 0.17, NOTE.B5, 0.12, 0.95);
  },
  rotate: (c, out, t, n) => {
    hiss(c, out, n, { t, type: "bandpass", f: 1800, to: 4200, q: 1.2, a: 0.005, d: 0.07, g: 0.085 });
    tone(c, out, { t, f: 800, to: 1100, d: 0.05, g: 0.06 });
  },
  // A piece clicking into its place in the case.
  snap: (c, out, t, n) => {
    tone(c, out, { t, f: 340, to: 190, glide: 0.04, d: 0.06, g: 0.2 });
    hiss(c, out, n, { t, type: "lowpass", f: 3000, d: 0.012, g: 0.08 });
  },
};

// Writes one sound into any audio context at time `t` (also used offline to
// check levels while building the app).
export function renderSfx(c: Ctx, out: AudioNode, name: SfxName, t: number, noise: AudioBuffer): void {
  RECIPES[name](c, out, t, noise);
}

// The same sound asked for twice in a split second (a double tap, two
// screens reacting to one event) plays once instead of twice as loud.
const lastPlayed = new Map<SfxName, number>();

export function playSfx(name: SfxName): void {
  try {
    const bus = CLICK_SOUNDS.has(name) ? "clicks" : "sfx";
    if (!busAudible(bus)) return;
    unlockAudio(); // harmless when already unlocked; helps when called from a tap
    if (!audioReady()) return;
    const now = performance.now();
    if (now - (lastPlayed.get(name) ?? -1e9) < 40) return;
    lastPlayed.set(name, now);
    const c = audioContext();
    RECIPES[name](c, bus === "clicks" ? clickBus() : sfxBus(), c.currentTime + 0.005, noiseBuffer());
  } catch {
    // sound is a nice extra: never let it break the app
  }
}
