import { DatabaseSync } from "node:sqlite";
import { getGameStatus } from "./game";
import { damage, HpChange, HpError, setHeardBy } from "./health";
import { getRules } from "./settings";
import { findByPlayerNumber } from "./users";
import { DAMAGE_MAX, DAMAGE_MIN } from "../voiceParse";

// Voice hit calls: every listening phone that hears "three forty" reports
// it. Several phones hear the same shout, so the server must count it ONCE.
//
// How: recent calls are kept in memory under the key "<player>:<damage>".
// The first report applies the damage; any report of the same call within
// the voiceWindowMs rule (4 s by default), measured from that FIRST report,
// only adds its phone to "heard by" (saved on the hit's hp_log row for the
// Admin's hits feed). Another player or another damage is another call.
// After the window, the same call again is a new, real hit.
//
// Memory is fine for this: calls only matter for a few seconds, and if the
// server restarts the worst case is that one call is counted twice.
// Everything here runs synchronously, so two phones reporting at the same
// moment are handled one after the other, never at the same time.

// Stops a phone stuck in a loop: at most 10 reports per phone every 5 s.
export const VOICE_RATE_LIMIT = { calls: 10, perMs: 5000 };

// Why a call wasn't applied (the phone can show `message`).
export type VoiceReason =
  | "duplicate" // another phone already reported this call; counted once
  | "game_not_active" // only while the game is running
  | "voice_off" // the Admin turned voice calls off
  | "no_player" // nobody plays with that number
  | "player_down" // that player is already at 0 HP
  | "rate_limited" // this phone sent too many reports
  | "not_a_call" // the words heard weren't a hit call
  | "digits_changed"; // player numbers changed since the phone last checked

export interface VoiceResult {
  applied: boolean; // HP was taken away by THIS report
  duplicate: boolean; // the same call was already counted
  playerNumber: number;
  damage: number;
  heardBy: number; // phones that have reported this call so far (0 when it wasn't counted)
  reason?: VoiceReason;
  message: string; // short, friendly, safe to show on the phone
}

interface RecentCall {
  firstAt: number; // when the first phone reported it (ms)
  heardBy: Set<number>; // user ids of the phones that heard it
  logId: number; // the hp_log row of the hit
}

const recentCalls = new Map<string, RecentCall>();
const reportTimes = new Map<number, number[]>(); // user id → recent report times

// Forget everything (a new round starts, or tests).
export function clearVoiceMemory(): void {
  recentCalls.clear();
  reportTimes.clear();
}

// Counts one report from a phone. Returns false if that phone has already
// sent the most allowed in the last few seconds (then nothing else happens).
// Every report counts, even ones that turn out not to be calls.
export function takeReportSlot(userId: number, now: number = Date.now()): boolean {
  const since = now - VOICE_RATE_LIMIT.perMs;
  for (const [id, times] of reportTimes) {
    const recent = times.filter((t) => t > since);
    if (recent.length === 0) reportTimes.delete(id);
    else reportTimes.set(id, recent);
  }
  const mine = reportTimes.get(userId) ?? [];
  if (mine.length >= VOICE_RATE_LIMIT.calls) return false;
  mine.push(now);
  reportTimes.set(userId, mine);
  return true;
}

// Friendly text for each outcome.
export function voiceMessage(reason: VoiceReason | "applied", target: number, amount: number): string {
  switch (reason) {
    case "applied":
      return `Hit! Player ${target} loses ${amount} HP.`;
    case "duplicate":
      return `Already counted: Player ${target}, ${amount} HP.`;
    case "game_not_active":
      return "Hit calls only count while the game is running.";
    case "voice_off":
      return "The Admin has turned voice hit calls off.";
    case "no_player":
      return `There's no Player ${target} in the game.`;
    case "player_down":
      return `Player ${target} is already down.`;
    case "rate_limited":
      return "Too many calls from this phone. Wait a few seconds.";
    case "not_a_call":
      return "That didn't sound like a hit call. Say the player number, then the damage: “three, forty”.";
    case "digits_changed":
      return "Player numbers just changed. Please say the call again.";
  }
}

// The answer for one report. heardBy only matters for applied/duplicate.
export function voiceResult(
  reason: VoiceReason | "applied",
  target: number,
  amount: number,
  heardBy = 0
): VoiceResult {
  return {
    applied: reason === "applied",
    duplicate: reason === "duplicate",
    playerNumber: target,
    damage: amount,
    heardBy,
    ...(reason === "applied" ? {} : { reason }),
    message: voiceMessage(reason, target, amount),
  };
}

// Drops calls whose window is over: they can't be duplicates any more.
function forgetOldCalls(now: number, windowMs: number): void {
  for (const [key, call] of recentCalls) {
    if (now - call.firstAt >= windowMs) recentCalls.delete(key);
  }
}

// One phone reports one call ("Player `target` loses `amount` HP"). The
// numbers were already checked by the caller (whole numbers, player 1–99,
// damage 1–999); they are checked again here as a last guard.
// Returns what happened and, when HP was taken, the HpChange — the route
// sends the live notices with it (live.hpChanged, live.dropsChanged).
export function reportHit(
  db: DatabaseSync,
  input: { reporterId: number; target: number; damage: number; now?: number }
): { result: VoiceResult; change: HpChange | null } {
  const { reporterId, target } = input;
  const amount = input.damage;
  const now = input.now ?? Date.now();
  const notApplied = (reason: VoiceReason, heardBy = 0) => ({
    result: voiceResult(reason, target, amount, heardBy),
    change: null,
  });

  const validNumbers =
    Number.isInteger(target) && target >= 1 && Number.isInteger(amount) && amount >= DAMAGE_MIN && amount <= DAMAGE_MAX;
  if (!validNumbers) return notApplied("not_a_call");

  const rules = getRules(db);
  if (getGameStatus(db).status !== "active") return notApplied("game_not_active");
  if (!rules.voiceEnabled) return notApplied("voice_off");

  forgetOldCalls(now, rules.voiceWindowMs);
  const key = `${target}:${amount}`;

  // Same call still inside its window: count this phone, don't hit again.
  // (Checked before the player's HP, so a call that just took the player to
  // 0 is still "heard by" every phone, not "already down".)
  const recent = recentCalls.get(key);
  if (recent) {
    if (!recent.heardBy.has(reporterId)) {
      recent.heardBy.add(reporterId);
      setHeardBy(db, recent.logId, recent.heardBy.size);
    }
    return notApplied("duplicate", recent.heardBy.size);
  }

  const player = findByPlayerNumber(db, target);
  if (!player || player.role !== "player" || player.status !== "active") return notApplied("no_player");
  if (player.dead === 1) return notApplied("player_down");

  let change: HpChange;
  try {
    // One transaction: the hit, its hp_log row and — if this takes the
    // player to 0 HP — the death and their case going to the drop box.
    change = damage(db, player.id, amount, { source: "voice", heardBy: 1, performedBy: reporterId });
  } catch (err) {
    // Only "already down" can happen here (checked just above); anything
    // else is a real failure for the route to report.
    if (err instanceof HpError && err.code === "RULE") return notApplied("player_down");
    throw err;
  }
  recentCalls.set(key, { firstAt: now, heardBy: new Set([reporterId]), logId: change.logId });
  return { result: voiceResult("applied", target, amount, 1), change };
}
