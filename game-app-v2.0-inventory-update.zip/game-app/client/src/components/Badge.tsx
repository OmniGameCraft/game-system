import { ReactNode } from "react";

export function Badge({ tone, children }: { tone: "good" | "bad" | "neutral" | "warn"; children: ReactNode }) {
  const cls =
    tone === "good"
      ? "bg-olive-soft text-olive ring-olive/30"
      : tone === "bad"
      ? "bg-alert/15 text-alert ring-alert/30"
      : tone === "warn"
      ? "bg-sun/15 text-sun ring-sun/30"
      : "bg-ink/[0.07] text-ink/75 ring-ink/15";
  return (
    <span
      className={`inline-flex items-center gap-1 whitespace-nowrap rounded px-2 py-0.5 text-sm font-semibold ring-1 ring-inset ${cls}`}
    >
      {children}
    </span>
  );
}
