import { DatabaseSync } from "node:sqlite";

export type Role = "admin" | "player";
export type Status = "active" | "disabled";

export interface User {
  id: number;
  role: Role;
  username: string;
  display_name: string | null;
  password_hash: string;
  status: Status;
  active_session_token: string | null;
  balance: number;
  created_at: string;
}

export interface PublicUser {
  id: number;
  role: Role;
  username: string;
  displayName: string | null;
  status: Status;
  balance: number;
  createdAt: string;
}

export function toPublicUser(u: User): PublicUser {
  return {
    id: u.id,
    role: u.role,
    username: u.username,
    displayName: u.display_name,
    status: u.status,
    balance: u.balance,
    createdAt: u.created_at,
  };
}

export function countByRole(db: DatabaseSync, role: Role): number {
  const row = db
    .prepare("SELECT COUNT(*) AS n FROM users WHERE role = ?")
    .get(role) as { n: number };
  return row.n;
}

export function findByUsername(db: DatabaseSync, username: string): User | undefined {
  return db.prepare("SELECT * FROM users WHERE username = ?").get(username) as
    | User
    | undefined;
}

export function findById(db: DatabaseSync, id: number): User | undefined {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(id) as User | undefined;
}

export function listByRole(db: DatabaseSync, role: Role): User[] {
  return db
    .prepare("SELECT * FROM users WHERE role = ? ORDER BY username COLLATE NOCASE")
    .all(role) as unknown as User[];
}

export function createUser(
  db: DatabaseSync,
  input: { role: Role; username: string; displayName?: string | null; passwordHash: string }
): User {
  const result = db
    .prepare(
      "INSERT INTO users (role, username, display_name, password_hash) VALUES (?, ?, ?, ?)"
    )
    .run(input.role, input.username, input.displayName ?? null, input.passwordHash);
  return findById(db, Number(result.lastInsertRowid))!;
}

// Only the fields Phase 3 actually lets an Admin change. Username is
// re-checked for uniqueness by the caller (excluding this row) before this
// runs, same pattern as createUser above.
export function updateUser(
  db: DatabaseSync,
  id: number,
  fields: { username?: string; displayName?: string | null; status?: Status }
): User {
  if (fields.username !== undefined) {
    db.prepare("UPDATE users SET username = ? WHERE id = ?").run(fields.username, id);
  }
  if (fields.displayName !== undefined) {
    db.prepare("UPDATE users SET display_name = ? WHERE id = ?").run(fields.displayName, id);
  }
  if (fields.status !== undefined) {
    db.prepare("UPDATE users SET status = ? WHERE id = ?").run(fields.status, id);
  }
  return findById(db, id)!;
}

export function setPasswordHash(db: DatabaseSync, id: number, passwordHash: string): void {
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(passwordHash, id);
}

// Records which single session token is currently allowed to act as this
// account. Only ever called for Admin accounts — see routes/auth.ts.
export function setActiveSessionToken(db: DatabaseSync, id: number, token: string | null): void {
  db.prepare("UPDATE users SET active_session_token = ? WHERE id = ?").run(token, id);
}
