import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { requireRole } from "../auth/middleware";
import {
  addAnnouncement,
  ANNOUNCEMENT_MAX,
  GAME_STATUSES,
  GameStatus,
  getGameStatus,
  listAnnouncementsForPlayer,
  listEventsForAdmin,
  resetRound,
  setGameStatus,
} from "../database/game";
import { findById } from "../database/users";
import { live } from "../realtime";

// Admin: /api/admin/game
export function createAdminGameRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  const snapshot = () => ({ ...getGameStatus(db), events: listEventsForAdmin(db) });

  router.get("/", (_req, res) => {
    res.json(snapshot());
  });

  router.post("/status", (req, res) => {
    const status = req.body?.status;
    if (!GAME_STATUSES.includes(status)) {
      res.status(400).json({ error: "Invalid game status." });
      return;
    }
    if (getGameStatus(db).status === status) {
      res.status(400).json({ error: "The game is already in that state." });
      return;
    }
    setGameStatus(db, status as GameStatus, req.user!.id);
    live.gameChanged();
    res.json(snapshot());
  });

  // Body: { message, playerId? }  playerId missing/null = every player.
  router.post("/announcements", (req, res) => {
    const raw = req.body?.message;
    const message = typeof raw === "string" ? raw.trim() : "";
    if (!message) {
      res.status(400).json({ error: "Write a message first." });
      return;
    }
    if (message.length > ANNOUNCEMENT_MAX) {
      res.status(400).json({ error: `Keep it under ${ANNOUNCEMENT_MAX} characters.` });
      return;
    }
    let playerId: number | null = null;
    const pid = req.body?.playerId;
    if (pid !== undefined && pid !== null) {
      const p = typeof pid === "number" && Number.isInteger(pid) ? findById(db, pid) : undefined;
      if (!p || p.role !== "player") {
        res.status(400).json({ error: "Choose a valid player." });
        return;
      }
      playerId = p.id;
    }
    addAnnouncement(db, message, playerId, req.user!.id);
    if (playerId === null) live.gameChanged();
    else live.announcementTo(playerId);
    res.status(201).json(snapshot());
  });

  // Body: { confirm: "RESET" }
  router.post("/reset-round", (req, res) => {
    if (req.body?.confirm !== "RESET") {
      res.status(400).json({ error: "Type RESET to confirm." });
      return;
    }
    try {
      resetRound(db);
    } catch {
      res.status(500).json({ error: "Could not reset. Nothing was changed." });
      return;
    }
    live.everythingChanged();
    res.json(snapshot());
  });

  return router;
}

// Player: /api/game — the game's status and the announcements meant for them.
export function createPlayerGameRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("player"));
  router.get("/", (req, res) => {
    res.json({ ...getGameStatus(db), announcements: listAnnouncementsForPlayer(db, req.user!.id) });
  });
  return router;
}
