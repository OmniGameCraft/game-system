// Shake detection. Phones only send motion data to secure (https) pages,
// and iPhones also ask the player's permission once, from a tap.

export type MotionState = "granted" | "denied" | "insecure" | "unsupported";

let state: MotionState | null = null;
let pending: Promise<MotionState> | null = null;

// Call from inside a tap handler (iPhone requirement).
export function requestMotionPermission(): Promise<MotionState> {
  if (!window.isSecureContext) return Promise.resolve((state = "insecure"));
  const DME = (window as any).DeviceMotionEvent;
  if (!DME) return Promise.resolve((state = "unsupported"));
  if (typeof DME.requestPermission === "function") {
    if (state === "granted") return Promise.resolve(state);
    pending = DME.requestPermission()
      .then((r: string) => (state = r === "granted" ? "granted" : "denied"))
      .catch(() => (state = "denied"));
    return pending!;
  }
  return Promise.resolve((state = "granted"));
}

export function motionState(): MotionState | null {
  return state;
}

// The iPhone question is answered a moment after the tap that asked it, so
// a screen that opens on that tap waits for the answer here. Resolves to
// null if nobody has asked yet.
export function whenMotionReady(): Promise<MotionState | null> {
  return pending ?? Promise.resolve(state);
}

// True when shaking could work but the phone still has to be asked from a
// tap (iPhones before the first "Allow").
export function motionNeedsTap(): boolean {
  if (state !== null || !window.isSecureContext) return false;
  const DME = (window as any).DeviceMotionEvent;
  return Boolean(DME && typeof DME.requestPermission === "function");
}

export interface ShakeOptions {
  threshold?: number; // m/s² of sudden movement needed (lower = a lighter flick fires)
  cooldownMs?: number; // shortest time between two shakes
}

// Calls onShake for each sharp movement (like jerking a gun up to fire).
// One movement counts once: after a shake the phone has to settle a little
// before the next one can count. Returns a function that stops listening.
export function listenForShake(onShake: () => void, opts: ShakeOptions = {}): () => void {
  const threshold = Math.max(2, opts.threshold ?? 14);
  const cooldown = Math.max(50, opts.cooldownMs ?? 280);
  const rearm = threshold * 0.55;
  let last = 0;
  let armed = true;
  let prev: { x: number; y: number; z: number } | null = null;

  const handler = (e: DeviceMotionEvent) => {
    const a = e.acceleration;
    let strength = 0;
    if (a && a.x !== null && a.y !== null && a.z !== null) {
      // gravity already removed
      strength = Math.hypot(a.x!, a.y!, a.z!);
    } else {
      // only "including gravity" available: use change between readings
      const g = e.accelerationIncludingGravity;
      if (!g || g.x === null || g.y === null || g.z === null) return;
      const cur = { x: g.x!, y: g.y!, z: g.z! };
      if (prev) strength = Math.hypot(cur.x - prev.x, cur.y - prev.y, cur.z - prev.z);
      prev = cur;
    }
    if (!armed) {
      if (strength < rearm) armed = true;
      else return;
    }
    const now = performance.now();
    if (strength > threshold && now - last > cooldown) {
      last = now;
      armed = false;
      onShake();
    }
  };
  window.addEventListener("devicemotion", handler);
  return () => window.removeEventListener("devicemotion", handler);
}
