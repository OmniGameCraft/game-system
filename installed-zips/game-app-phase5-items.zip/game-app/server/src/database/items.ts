import { DatabaseSync } from "node:sqlite";

export interface Item {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  max_stack: number | null;
  enabled: number; // SQLite has no boolean: 1 = enabled, 0 = disabled
  image_file: string | null;
  created_at: string;
}

export interface PublicItem {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  maxStack: number | null;
  enabled: boolean;
  imageUrl: string | null;
  createdAt: string;
}

export function imageUrlFor(file: string | null): string | null {
  return file ? `/media/items/${file}` : null;
}

export function toPublicItem(i: Item): PublicItem {
  return {
    id: i.id,
    name: i.name,
    description: i.description,
    category: i.category,
    maxStack: i.max_stack,
    enabled: i.enabled === 1,
    imageUrl: imageUrlFor(i.image_file),
    createdAt: i.created_at,
  };
}

export function listItems(db: DatabaseSync): Item[] {
  return db.prepare("SELECT * FROM items ORDER BY name COLLATE NOCASE").all() as unknown as Item[];
}

export function findItemById(db: DatabaseSync, id: number): Item | undefined {
  return db.prepare("SELECT * FROM items WHERE id = ?").get(id) as Item | undefined;
}

// The name column is COLLATE NOCASE, so "Rifle" and "rifle" count as the same.
export function findItemByName(db: DatabaseSync, name: string): Item | undefined {
  return db.prepare("SELECT * FROM items WHERE name = ?").get(name) as Item | undefined;
}

export interface ItemFields {
  name?: string;
  description?: string | null;
  category?: string | null;
  maxStack?: number | null;
  enabled?: boolean;
}

export function createItem(db: DatabaseSync, f: Required<Omit<ItemFields, "enabled">> & { enabled?: boolean }): Item {
  const result = db
    .prepare(
      "INSERT INTO items (name, description, category, max_stack, enabled) VALUES (?, ?, ?, ?, ?)"
    )
    .run(f.name, f.description, f.category, f.maxStack, f.enabled === false ? 0 : 1);
  return findItemById(db, Number(result.lastInsertRowid))!;
}

export function updateItem(db: DatabaseSync, id: number, f: ItemFields): Item {
  if (f.name !== undefined) db.prepare("UPDATE items SET name = ? WHERE id = ?").run(f.name, id);
  if (f.description !== undefined)
    db.prepare("UPDATE items SET description = ? WHERE id = ?").run(f.description, id);
  if (f.category !== undefined)
    db.prepare("UPDATE items SET category = ? WHERE id = ?").run(f.category, id);
  if (f.maxStack !== undefined)
    db.prepare("UPDATE items SET max_stack = ? WHERE id = ?").run(f.maxStack, id);
  if (f.enabled !== undefined)
    db.prepare("UPDATE items SET enabled = ? WHERE id = ?").run(f.enabled ? 1 : 0, id);
  return findItemById(db, id)!;
}

export function setItemImage(db: DatabaseSync, id: number, file: string | null): void {
  db.prepare("UPDATE items SET image_file = ? WHERE id = ?").run(file, id);
}
