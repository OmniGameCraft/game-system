import { useEffect, useRef, useState } from "react";
import { useLive } from "../../services/live";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { Section } from "../../components/Section";
import { listPlayers, Player } from "../../services/api";
import { HP_CHANGED } from "./liveEvents";
import { hpColor, HpMeter, hpOf, NumberPlate } from "./ui";

// Players in callout-number order, so "Player 3" is easy to find mid-game.
function byNumber(a: Player, b: Player): number {
  const an = a.playerNumber ?? Number.MAX_SAFE_INTEGER;
  const bn = b.playerNumber ?? Number.MAX_SAFE_INTEGER;
  return an - bn || a.id - b.id;
}

export function PlayersList({ onCreate, onOpen }: { onCreate: () => void; onOpen: (id: number) => void }) {
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  // HP changes many times in a game, so those notices refresh the list too.
  // One hit sends two notices; a short wait turns them into one reload.
  const [tick, setTick] = useState(0);
  const wait = useRef<number | undefined>(undefined);
  useLive(["players:changed", "player:changed", HP_CHANGED], () => {
    window.clearTimeout(wait.current);
    wait.current = window.setTimeout(() => setTick((t) => t + 1), 150);
  });
  useEffect(() => () => window.clearTimeout(wait.current), []);

  useEffect(() => {
    listPlayers()
      .then((p) => {
        setPlayers([...p].sort(byNumber));
        setError(null);
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load players."));
  }, [tick]);

  const down = players?.filter((p) => p.dead).length ?? 0;

  return (
    <>
      <Button onClick={onCreate}>+ Create Player</Button>
      <ErrorBanner message={error} />
      <Section
        title={`All players${players ? ` (${players.length})` : ""}`}
        action={down > 0 ? <Badge tone="bad">{down} down</Badge> : undefined}
        flush
      >
        {players === null && !error && <p className="p-4 text-ink/60">Loading…</p>}
        {players?.length === 0 && <p className="p-4 text-ink/70">No players yet. Tap “Create Player” to add the first one.</p>}
        <ul className="divide-y-2 divide-ink/5">
          {players?.map((p) => {
            const hp = hpOf(p);
            return (
              <li key={p.id}>
                <button
                  onClick={() => onOpen(p.id)}
                  className={`flex w-full items-center gap-3 px-4 py-3 text-left active:bg-pine-soft ${p.dead ? "bg-alert/[0.06]" : ""}`}
                >
                  <NumberPlate n={p.playerNumber} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline justify-between gap-2">
                      <p className={`truncate text-lg font-bold ${p.dead ? "text-ink/60" : "text-ink"}`}>{p.displayName || p.username}</p>
                      {hp && (
                        <span className={`shrink-0 font-display text-base font-bold tabular-nums ${hpColor(hp).text}`}>
                          {hp.hp}
                          <span className="text-sm text-ink/45">/{hp.maxHp}</span>
                        </span>
                      )}
                    </div>
                    {hp && (
                      <div className="mt-1">
                        <HpMeter hp={hp} size="sm" />
                      </div>
                    )}
                    <div className="mt-1.5 flex flex-wrap items-center gap-2">
                      {p.dead && (
                        <Badge tone="bad">
                          <Icon name="skull" className="mr-1 h-4 w-4" />
                          Down
                        </Badge>
                      )}
                      {p.status !== "active" && <Badge tone="bad">Disabled</Badge>}
                      <span className="truncate text-sm text-ink/55">@{p.username}</span>
                      <span className="text-sm font-bold text-ink/70">${p.balance}</span>
                    </div>
                  </div>
                  <Icon name="chevron" className="h-5 w-5 shrink-0 text-ink/30" />
                </button>
              </li>
            );
          })}
        </ul>
      </Section>
    </>
  );
}
