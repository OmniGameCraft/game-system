import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { requireAuth } from "../auth/middleware";
import { getGameStatus, onRoundReset } from "../database/game";
import { getRules } from "../database/settings";
import { findById, PLAYER_NUMBER_MAX } from "../database/users";
import { clearVoiceMemory, reportHit, takeReportSlot, VoiceResult, voiceResult } from "../database/voice";
import { live } from "../realtime";
import { Callout, DAMAGE_MAX, DAMAGE_MIN, parseCallout, playerNumberDigits } from "../voiceParse";

// The longest "heard" text accepted from a phone (a call is a few words).
const HEARD_MAX = 200;

function isWhole(n: unknown, min: number, max: number): n is number {
  return typeof n === "number" && Number.isInteger(n) && n >= min && n <= max;
}

// /api/voice — hit calls heard by phones ("three forty" = Player 3 loses
// 40 HP). Any logged-in phone may report what it heard: every player's
// phone listens, and the Admin's can too. The server decides what counts
// (game running, voice calls on, a real player, the same call only once),
// so a report can never do more than a referee's shout would.
export function createVoiceRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireAuth);

  // A new round forgets recent calls (their hp_log rows are gone too).
  onRoundReset(() => clearVoiceMemory());

  // What a phone needs to listen: D (how many digits the player number
  // takes in a call), whether calls count right now, and "You are Player 3".
  router.get("/info", (req, res) => {
    const rules = getRules(db);
    const status = getGameStatus(db).status;
    const me = findById(db, req.user!.id);
    res.json({
      digits: playerNumberDigits(db),
      enabled: rules.voiceEnabled,
      active: status === "active",
      gameStatus: status,
      windowMs: rules.voiceWindowMs,
      myNumber: me?.role === "player" ? me.player_number ?? null : null,
    });
  });

  // Body (normal): { target, damage, heard?, digits? } — the phone already
  //   read the call. `heard` is the raw text; `digits` is the D the phone
  //   used. If D has changed since (a player got number 10 or more, say),
  //   the server reads `heard` again with the right D.
  // Body (fallback): { text } — the server reads the call itself.
  // Answer: { applied, duplicate, playerNumber, damage, heardBy, reason?,
  //   message, digits }. 200 even when not applied (a normal outcome for a
  //   listening phone); 400 for a malformed request; 429 (same shape, plus
  //   error) when this phone sent too many reports.
  router.post("/hit", (req, res) => {
    const b = req.body ?? {};
    const userId = req.user!.id;
    const digits = playerNumberDigits(db);
    const heard = typeof b.heard === "string" && b.heard.length <= HEARD_MAX ? b.heard : null;
    const send = (status: number, r: VoiceResult) =>
      res.status(status).json({ ...r, digits, ...(status === 429 ? { error: r.message } : {}) });

    // 1. Work out which call this is.
    let call: Callout | null;
    let notCall: VoiceResult | null = null;
    if (b.target === undefined && b.damage === undefined) {
      const text = typeof b.text === "string" ? b.text : heard;
      if (text === null) {
        res.status(400).json({ error: "Send the call: the player number and the damage, or the words heard." });
        return;
      }
      call = parseCallout(text, digits);
      if (!call) notCall = voiceResult("not_a_call", 0, 0);
    } else {
      if (!isWhole(b.target, 1, PLAYER_NUMBER_MAX)) {
        res.status(400).json({ error: `The player number must be a whole number from 1 to ${PLAYER_NUMBER_MAX}.` });
        return;
      }
      if (!isWhole(b.damage, DAMAGE_MIN, DAMAGE_MAX)) {
        res.status(400).json({ error: `The damage must be a whole number from ${DAMAGE_MIN} to ${DAMAGE_MAX}.` });
        return;
      }
      if (b.digits !== undefined && !isWhole(b.digits, 1, 2)) {
        res.status(400).json({ error: "Invalid request." });
        return;
      }
      call = { target: b.target, damage: b.damage };
      // The phone split the digits with an old D: read its words again.
      if (b.digits !== undefined && b.digits !== digits) {
        call = heard !== null ? parseCallout(heard, digits) : null;
        if (!call) notCall = voiceResult("digits_changed", b.target, b.damage);
      }
    }

    // 2. Every report counts towards this phone's limit, calls or not.
    if (!takeReportSlot(userId)) {
      send(429, voiceResult("rate_limited", call?.target ?? 0, call?.damage ?? 0));
      return;
    }
    if (!call || notCall) {
      send(200, notCall ?? voiceResult("not_a_call", 0, 0));
      return;
    }

    // 3. Count it (once, however many phones heard it).
    let outcome: ReturnType<typeof reportHit>;
    try {
      outcome = reportHit(db, { reporterId: userId, target: call.target, damage: call.damage });
    } catch {
      res.status(500).json({ error: "Could not count that hit. Nothing was changed." });
      return;
    }
    const { result, change } = outcome;
    if (change) {
      // The hit player's phone flashes red at once; the Admin's hits feed
      // and player list update.
      live.hpChanged(change.playerId, change);
      if (change.dropped) live.dropsChanged();
    }
    send(200, result);
  });

  return router;
}
