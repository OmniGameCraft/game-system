/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      // "Field kit" palette: gunmetal and steel with a signal-amber accent.
      // The old names are kept so every screen picks the theme up:
      //   paper = page, panel = surfaces, ink = text, pine = amber accent,
      //   olive = good news, alert = flare red, sun = caution yellow.
      colors: {
        paper: "#151B21",
        panel: { DEFAULT: "#1F2730", raised: "#29333E", line: "#34404C" },
        ink: "#E6EAED",
        pine: { DEFAULT: "#F5A524", soft: "rgba(245, 165, 36, 0.14)", ink: "#1C1405" },
        olive: { DEFAULT: "#9DC35B", soft: "rgba(157, 195, 91, 0.15)" },
        sun: "#E9C84A",
        alert: "#FF5D5D",
      },
      // Bundled with the app (npm @fontsource), never fetched from the internet.
      // Short one-shot animations for the item viewer (2D fallback + flash).
      keyframes: {
        shotflash: { "0%": { opacity: "0.35" }, "100%": { opacity: "0" } },
        recoil: {
          "0%": { transform: "translateX(0) rotate(0)" },
          "20%": { transform: "translateX(-18px) rotate(-9deg)" },
          "100%": { transform: "translateX(0) rotate(0)" },
        },
        swing: {
          "0%": { transform: "rotate(0)" },
          "40%": { transform: "rotate(55deg) translateX(20px)" },
          "100%": { transform: "rotate(0)" },
        },
        gameon: {
          "0%": { transform: "scale(0.6)", opacity: "0" },
          "15%": { transform: "scale(1.08)", opacity: "1" },
          "25%": { transform: "scale(1)" },
          "80%": { opacity: "1" },
          "100%": { opacity: "0" },
        },
        spinonce: { "0%": { transform: "rotateY(0)" }, "100%": { transform: "rotateY(360deg)" } },
      },
      animation: {
        shotflash: "shotflash 110ms ease-out forwards",
        recoil: "recoil 220ms ease-out",
        swing: "swing 320ms ease-in-out",
        "spin-once": "spinonce 700ms ease-out",
      },
      fontFamily: {
        sans: ["Barlow", "system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"],
        display: ["Chakra Petch", "Barlow", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
