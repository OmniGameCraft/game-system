import { Transaction } from "../services/api";
import { formatDateTime } from "../utils/format";

function describe(t: Transaction): string {
  const item = t.itemName ?? "item";
  if (t.type === "PURCHASE") return `Bought ${t.quantity} × ${item}`;
  if (t.type === "SALE") return `Sold ${t.quantity} × ${item}`;
  if (t.type === "UPGRADE") return `Upgraded ${item}${t.detail ? ` · ${t.detail}` : ""}`;
  return t.type === "ADD" ? "Money added" : "Money removed";
}

export function TransactionList({ transactions }: { transactions: Transaction[] }) {
  if (transactions.length === 0) {
    return <p className="p-4 text-ink/60">No money changes yet.</p>;
  }
  return (
    <ul className="stagger divide-y divide-panel-line/70">
      {transactions.map((t) => {
        const up = t.type === "ADD" || t.type === "SALE";
        return (
          <li key={t.id} className="flex items-center justify-between gap-3 px-4 py-3">
            <span
              className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-md border font-display text-lg font-bold ${
                up ? "border-olive/30 bg-olive-soft text-olive" : "border-alert/25 bg-alert/10 text-alert"
              }`}
              aria-hidden
            >
              {up ? "+" : "−"}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate font-semibold text-ink">{describe(t)}</p>
              <p className="text-sm text-ink/50">
                {formatDateTime(t.createdAt)} · balance ${t.balanceAfter}
              </p>
            </div>
            <span className={`shrink-0 font-display text-lg font-bold tabular-nums ${up ? "text-olive" : "text-alert"}`}>
              {t.amount === 0 ? "Free" : `${up ? "+" : "−"}$${t.amount}`}
            </span>
          </li>
        );
      })}
    </ul>
  );
}
