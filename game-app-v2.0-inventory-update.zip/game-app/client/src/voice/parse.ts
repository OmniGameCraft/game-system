// Turns a spoken hit call into "which player" and "how much damage".
//
// A call is the player number followed by the damage, said as digits or
// words: "three four zero", "three forty", "340", "player 3, 40" all mean
// Player 3 loses 40 HP.
//
// The number of digits that belong to the player is fixed for the whole
// game (playerNumberDigits): 1 while every player number is 1–9, 2 as soon
// as any player is numbered 10 or more. The first digits are the player and
// everything after them is the damage, so a call is never ambiguous. With 2
// digits, Player 3 is called "zero three".
//
// The server has the same parser (server/src/voiceParse.ts). Keep the two in
// step: same words, same rules, same results.

export interface Callout {
  target: number; // player number, 1–99
  damage: number; // HP to take off, 1–999
}

const UNITS: Record<string, number> = {
  zero: 0, oh: 0, o: 0,
  one: 1, won: 1,
  two: 2, to: 2, too: 2,
  three: 3, tree: 3,
  four: 4, for: 4,
  five: 5, fife: 5,
  six: 6,
  seven: 7,
  eight: 8, ate: 8,
  nine: 9, niner: 9,
};

const TEENS: Record<string, number> = {
  ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14,
  fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19,
};

const TENS: Record<string, number> = {
  twenty: 20, thirty: 30, forty: 40, fourty: 40, fifty: 50,
  sixty: 60, seventy: 70, eighty: 80, ninety: 90,
};

// Words people put in front of (or between) the numbers. They carry no digits.
const FILLER = new Set(["player", "hit", "damage"]);

// Splits the heard text into lowercase words and digit runs.
// "Player 3, 40!" -> ["player", "3", "40"]; "3:40" -> ["340"];
// "forty-five" -> ["forty", "five"].
function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/(\d)[.,:](?=\d)/g, "$1") // "3:40", "3.40", "3,40" are one number said quickly
    .replace(/([a-z])(\d)/g, "$1 $2") // "o3" -> "o 3"
    .replace(/(\d)([a-z])/g, "$1 $2")
    .replace(/[-–—_/]/g, " ")
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
}

// A spoken number (or a whole call) becomes one string of digits.
// Returns null when any word isn't part of a number, so ordinary chatter
// ("I need to go") is never mistaken for a hit call.
function toDigits(tokens: string[]): string | null {
  let out = "";
  let i = 0;
  const words = tokens.filter((t) => !FILLER.has(t));
  while (i < words.length) {
    const w = words[i];

    // Digits as the recogniser wrote them ("340", "03", "3").
    if (/^\d+$/.test(w)) {
      // "3 hundred 40"
      if (words[i + 1] === "hundred" && w.length === 1) {
        if (w === "0") return null; // "0 hundred" isn't a number
        const rest = hundredRest(words, i + 2);
        if (!rest) return null;
        out += String(Number(w) * 100 + rest.value);
        i = rest.next;
        continue;
      }
      out += w;
      i++;
      continue;
    }

    if (w in UNITS) {
      const d = UNITS[w];
      if (words[i + 1] === "hundred") {
        if (d === 0) return null; // "zero hundred" isn't a number
        const rest = hundredRest(words, i + 2);
        if (!rest) return null;
        out += String(d * 100 + rest.value);
        i = rest.next;
        continue;
      }
      out += String(d);
      i++;
      continue;
    }

    // "a hundred" / "hundred" on its own = 100 (plus anything after it)
    if (w === "hundred" || (w === "a" && words[i + 1] === "hundred")) {
      const rest = hundredRest(words, i + (w === "a" ? 2 : 1));
      if (!rest) return null;
      out += String(100 + rest.value);
      i = rest.next;
      continue;
    }

    if (w in TEENS) {
      out += String(TEENS[w]);
      i++;
      continue;
    }

    if (w in TENS) {
      const t = TENS[w];
      const next = words[i + 1];
      // "forty five" -> 45 (a unit 1–9 straight after a tens word joins it)
      const unit = next !== undefined ? unitValue(next) : null;
      if (unit !== null && unit > 0) {
        out += String(t + unit);
        i += 2;
      } else {
        out += String(t);
        i++;
      }
      continue;
    }

    return null; // not a number word: this wasn't a hit call
  }
  return out;
}

// A single digit 1–9 said as a word or written as a digit; null otherwise.
function unitValue(w: string): number | null {
  if (w in UNITS) return UNITS[w];
  if (/^\d$/.test(w)) return Number(w);
  return null;
}

// What follows "hundred": nothing, "and", or a number up to 99
// ("three hundred forty five", "one hundred and five", "3 hundred 40").
function hundredRest(words: string[], start: number): { value: number; next: number } | null {
  let i = start;
  if (words[i] === "and") i++;
  const w = words[i];
  if (w === undefined) return { value: 0, next: i };
  if (w in TEENS) return { value: TEENS[w], next: i + 1 };
  if (w in TENS) {
    const unit = words[i + 1] !== undefined ? unitValue(words[i + 1]) : null;
    if (unit !== null && unit > 0) return { value: TENS[w] + unit, next: i + 2 };
    return { value: TENS[w], next: i + 1 };
  }
  if (/^\d{1,2}$/.test(w)) return { value: Number(w), next: i + 1 };
  if (w in UNITS && UNITS[w] > 0) return { value: UNITS[w], next: i + 1 };
  // Something else follows (e.g. another call): "hundred" stands alone.
  if (words[start] === "and") return null; // "hundred and" then nothing usable
  return { value: 0, next: start };
}

// The parser. Returns null for anything that isn't a valid call.
export function parseCallout(text: string, playerNumberDigits: number): Callout | null {
  if (typeof text !== "string" || text.length > 200) return null;
  const digitsForPlayer = playerNumberDigits >= 2 ? 2 : 1;
  const tokens = tokenize(text);
  if (tokens.length === 0) return null;
  const digits = toDigits(tokens);
  if (!digits) return null;

  const playerPart = digits.slice(0, digitsForPlayer);
  const damagePart = digits.slice(digitsForPlayer);
  // Damage is 1 to 3 digits (1–999).
  if (playerPart.length < digitsForPlayer || damagePart.length < 1 || damagePart.length > 3) return null;
  const target = Number(playerPart);
  const damage = Number(damagePart);
  if (!Number.isInteger(target) || target < 1 || target > 99) return null;
  if (!Number.isInteger(damage) || damage < 1 || damage > 999) return null;
  return { target, damage };
}

// ---- Self-test (development only) ----
// Run in the browser console of a dev build:
//   import("/src/voice/parse.ts").then((m) => console.table(m.selfTestParse()))
// or from the project folder: npx tsx -e "import('./client/src/voice/parse.ts').then(m => console.log(m.selfTestParse()))"
// An empty list means every example passed.
export const PARSE_EXAMPLES: [text: string, digits: number, expected: Callout | null][] = [
  ["three four zero", 1, { target: 3, damage: 40 }],
  ["three forty", 1, { target: 3, damage: 40 }],
  ["340", 1, { target: 3, damage: 40 }],
  ["player 3, 40", 1, { target: 3, damage: 40 }],
  ["Player three, forty.", 1, { target: 3, damage: 40 }],
  ["3:40", 1, { target: 3, damage: 40 }],
  ["three hundred forty", 1, { target: 3, damage: 40 }],
  ["hit five twenty five", 1, { target: 5, damage: 25 }],
  ["five twenty-five", 1, { target: 5, damage: 25 }],
  ["tree fife", 1, { target: 3, damage: 5 }],
  ["niner ten", 1, { target: 9, damage: 10 }],
  ["won ate", 1, { target: 1, damage: 8 }],
  ["two too", 1, { target: 2, damage: 2 }],
  ["for fifteen", 1, { target: 4, damage: 15 }],
  ["seven one hundred", 1, { target: 7, damage: 100 }],
  ["seven a hundred", 1, { target: 7, damage: 100 }],
  ["six two hundred and fifty", 1, { target: 6, damage: 250 }],
  ["damage 2 99", 1, { target: 2, damage: 99 }],
  ["zero three forty", 2, { target: 3, damage: 40 }],
  ["oh three four zero", 2, { target: 3, damage: 40 }],
  ["0340", 2, { target: 3, damage: 40 }],
  ["O3 40", 2, { target: 3, damage: 40 }],
  ["twelve fifteen", 2, { target: 12, damage: 15 }],
  ["one two fifteen", 2, { target: 12, damage: 15 }],
  ["player 12 damage 100", 2, { target: 12, damage: 100 }],
  ["twenty one thirty", 2, { target: 21, damage: 30 }],
  ["ninety nine nine hundred ninety nine", 2, { target: 99, damage: 999 }],
  // not valid calls
  ["three", 1, null], // no damage
  ["zero forty", 1, null], // there is no Player 0
  ["three zero", 1, null], // 0 damage
  ["three four zero zero zero", 1, null], // damage over 999
  ["I need to go", 1, null], // chatter
  ["hello", 1, null],
  ["", 1, null],
  ["three forty", 2, null], // with 2 digits: "34" + "0" = no damage
  ["forty", 2, null], // with 2 digits: Player 40 but no damage
];

export function selfTestParse(): string[] {
  const failures: string[] = [];
  for (const [text, digits, expected] of PARSE_EXAMPLES) {
    const got = parseCallout(text, digits);
    const same = got === null || expected === null ? got === expected : got.target === expected.target && got.damage === expected.damage;
    if (!same) failures.push(`"${text}" (${digits} digit) → ${JSON.stringify(got)}, expected ${JSON.stringify(expected)}`);
  }
  return failures;
}
