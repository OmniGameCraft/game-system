import { prepareAudioUnlock } from "./engine";
import { playSfx } from "./sfx";

// One listener for the whole app gives every button, link, tab, switch,
// checkbox and drop-down a soft click, so no screen has to remember to.
//
// It listens for "click" (not the moment the finger touches): a click only
// happens when the tap really presses something, so scrolling a list of
// buttons with your thumb doesn't tick, and keyboard presses click too.
//
// Opt out with data-sound="none" on an element (or any parent): use it for
// things that play their own sound (tabs, switches, the fire area, the case
// grid) so they don't play two sounds at once.

const CLICKABLE =
  'button, [role="button"], [role="tab"], [role="switch"], [role="menuitem"], [role="option"], a[href], select, summary, input[type="checkbox"], input[type="radio"], input[type="submit"], input[type="button"]';

function onClick(e: Event) {
  const target = e.target as Element | null;
  if (!target || typeof target.closest !== "function") return;
  const el = target.closest(CLICKABLE) as HTMLElement | null;
  if (!el) return;
  if (el.closest('[data-sound="none"]')) return;
  if ((el as HTMLButtonElement).disabled || el.getAttribute("aria-disabled") === "true") return;
  playSfx("click");
}

let installs = 0;

// Turn the click sounds on for the whole page. Returns a function that turns
// them off again. Safe to call more than once.
export function installClickSounds(): () => void {
  prepareAudioUnlock();
  if (installs++ === 0) document.addEventListener("click", onClick, { capture: true, passive: true });
  let done = false;
  return () => {
    if (done) return;
    done = true;
    if (--installs === 0) document.removeEventListener("click", onClick, { capture: true });
  };
}
