import { ChangeEvent, FormEvent, useEffect, useRef, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls, TextField } from "../../components/Field";
import { BackButton } from "../../components/BackButton";
import { Badge } from "../../components/Badge";
import { Icon } from "../../components/Icon";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import { Stepper } from "../../components/Stepper";
import { ItemMediaSection } from "./ItemMediaSection";
import { ItemImage } from "../../components/ItemImage";
import {
  createItem,
  DEFAULT_RULES,
  getItem,
  getRules,
  HERB_LABEL,
  HerbCode,
  Item,
  ItemInput,
  ItemKind,
  KIND_LABEL,
  listItems,
  removeItemImage,
  updateItem,
  uploadItemImage,
} from "../../services/api";
import { resizeImageToDataUrl } from "../../utils/image";

// One form for both "create" (no id) and "edit" (id given).
export function ItemForm({
  id,
  onSaved,
  onBack,
}: {
  id?: number;
  onSaved: (item: Item) => void;
  onBack: () => void;
}) {
  const isEdit = id !== undefined;
  const [item, setItem] = useState<Item | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [maxStack, setMaxStack] = useState("");
  const [categories, setCategories] = useState<string[]>([]);
  const [guns, setGuns] = useState<Item[]>([]);
  // The case size from Game rules, so the size preview is true to life.
  const [caseSize, setCaseSize] = useState({ cols: DEFAULT_RULES.caseCols, rows: DEFAULT_RULES.caseRows });

  // Type, selling and upgrade settings. Numbers are kept as text while typing.
  const [kind, setKind] = useState<ItemKind>("other");
  const [ammoFor, setAmmoFor] = useState("");
  const [perPack, setPerPack] = useState("");
  const [sellable, setSellable] = useState(false);
  const [sellPercent, setSellPercent] = useState("50");
  const [baseMagazine, setBaseMagazine] = useState("");
  const [baseSharpness, setBaseSharpness] = useState("");
  const [baseLength, setBaseLength] = useState("");
  const [upMagazine, setUpMagazine] = useState("");
  const [upDamage, setUpDamage] = useState("");
  const [upReload, setUpReload] = useState("");
  const [upFirerate, setUpFirerate] = useState("");
  const [upSharpness, setUpSharpness] = useState("");
  const [upLength, setUpLength] = useState("");

  // Size in the case (cells) and how many share one space.
  const [gridW, setGridW] = useState(1);
  const [gridH, setGridH] = useState(1);
  const [sizeTouched, setSizeTouched] = useState(false);
  const [stackSize, setStackSize] = useState("");
  // Backpacks: rows they add to the case.
  const [expandRows, setExpandRows] = useState(1);

  // Healing.
  const [healAmount, setHealAmount] = useState("");
  const [maxHpBonus, setMaxHpBonus] = useState("");
  const [fullHeal, setFullHeal] = useState(false);
  const [herbCode, setHerbCode] = useState<HerbCode | "">("");

  // Gun feel + calculator value.
  const [reloadSec, setReloadSec] = useState("");
  const [shakeForce, setShakeForce] = useState<number | null>(null); // null = not set, the normal feel
  const [hre, setHre] = useState("");

  // Picture picked on the create screen is uploaded right after the item exists.
  const [pendingImage, setPendingImage] = useState<string | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [imageBusy, setImageBusy] = useState(false);
  const [toggling, setToggling] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Suggest categories the Admin has already used, so "Weapon" and
    // "weapons" don't end up as two different groups by accident.
    listItems()
      .then((all) => {
        const seen = new Set<string>();
        for (const i of all) if (i.category) seen.add(i.category);
        setCategories([...seen].sort((a, b) => a.localeCompare(b)));
        setGuns(all.filter((i) => i.kind === "gun" && i.id !== id));
      })
      .catch(() => {});
    getRules()
      .then((r) => setCaseSize({ cols: r.caseCols, rows: r.caseRows }))
      .catch(() => {});
    if (id === undefined) return;
    getItem(id)
      .then((i) => {
        setItem(i);
        setName(i.name);
        setCategory(i.category ?? "");
        setDescription(i.description ?? "");
        setMaxStack(i.maxStack === null ? "" : String(i.maxStack));
        const t = (n: number | null | undefined) => (n === null || n === undefined ? "" : String(n));
        setKind(i.kind);
        setAmmoFor(t(i.ammoForItemId));
        setPerPack(t(i.ammoPerPack));
        setSellable(i.sellable);
        setSellPercent(String(i.sellPercent));
        setBaseMagazine(t(i.baseMagazine));
        setBaseSharpness(t(i.baseSharpness));
        setBaseLength(t(i.baseLength));
        setUpMagazine(t(i.upgradePrices.magazine));
        setUpDamage(t(i.upgradePrices.damage));
        setUpReload(t(i.upgradePrices.reload));
        setUpFirerate(t(i.upgradePrices.firerate));
        setUpSharpness(t(i.upgradePrices.sharpness));
        setUpLength(t(i.upgradePrices.length));
        const size = DEFAULT_SIZE[i.kind];
        setGridW(i.gridW ?? size[0]);
        setGridH(i.gridH ?? size[1]);
        setSizeTouched(true); // an existing item keeps its size even if the type changes
        setStackSize(t(i.stackSize));
        setExpandRows(i.expandRows ?? 1);
        setHealAmount(t(i.healAmount));
        setMaxHpBonus(t(i.maxHpBonus));
        setFullHeal(!!i.fullHeal);
        setHerbCode(i.herbCode ?? "");
        setReloadSec(i.baseReloadMs ? String(Math.round(i.baseReloadMs / 10) / 100) : "");
        setShakeForce(i.shakeForce ?? null);
        setHre(t(i.hre));
      })
      .catch((err) => setLoadError(err instanceof Error ? err.message : "Failed to load item."));
  }, [id]);

  function parseMaxStack(): number | null | Error {
    const t = maxStack.trim();
    if (t === "") return null;
    const n = Number(t);
    if (!Number.isInteger(n) || n < 1) return new Error("Max per player must be a whole number of 1 or more, or empty.");
    return n;
  }

  // Picking a type sets the usual sell-back choice and case size for it
  // (both can still be changed).
  function pickKind(k: ItemKind) {
    setKind(k);
    setSellable(SELLABLE_KINDS.includes(k));
    if (!sizeTouched) {
      setGridW(DEFAULT_SIZE[k][0]);
      setGridH(DEFAULT_SIZE[k][1]);
    }
  }

  // Picking a herb fills in the usual healing when nothing is set yet.
  function pickHerb(code: HerbCode | "") {
    setHerbCode(code);
    if (code && healAmount.trim() === "" && maxHpBonus.trim() === "" && !fullHeal) applyHerbDefaults(code);
  }
  function applyHerbDefaults(code: HerbCode) {
    const d = HERB_DEFAULTS[code];
    setHealAmount(String(d.heal));
    setMaxHpBonus(d.max ? String(d.max) : "");
    setFullHeal(!!d.full);
  }

  // Turns the type section into fields for the server, or an error message.
  function ruleFields(): ItemInput | Error {
    const out: ItemInput = { kind, sellable };
    const whole = (text: string, label: string, min: number, max = 1_000_000_000): number | null | Error => {
      const t = text.trim();
      if (t === "") return null;
      const n = Number(t);
      if (!Number.isInteger(n) || n < min || n > max)
        return new Error(`${label} must be a whole number from ${min} to ${max.toLocaleString()}, or empty.`);
      return n;
    };
    const pct = Number(sellPercent.trim());
    if (sellPercent.trim() === "" || !Number.isInteger(pct) || pct < 0 || pct > 100)
      return new Error("Sell-back must be a whole percent from 0 to 100.");
    out.sellPercent = pct;
    const checks: Array<[keyof ItemInput, string, string, number, number?]> = [];
    if (kind === "ammo") {
      if (!ammoFor) return new Error("Choose which gun this ammo is for.");
      out.ammoForItemId = Number(ammoFor);
      checks.push(["ammoPerPack", perPack, "Rounds per pack", 1]);
    }
    if (kind === "gun") {
      checks.push(["baseMagazine", baseMagazine, "Starting magazine", 1]);
      checks.push(["upPriceMagazine", upMagazine, "Magazine upgrade price", 0]);
      checks.push(["upPriceDamage", upDamage, "Damage upgrade price", 0]);
      checks.push(["upPriceReload", upReload, "Reload speed upgrade price", 0]);
      checks.push(["upPriceFirerate", upFirerate, "Fire rate upgrade price", 0]);
    }
    if (kind === "knife") {
      checks.push(["baseSharpness", baseSharpness, "Starting sharpness", 1]);
      checks.push(["baseLength", baseLength, "Starting length", 1]);
      checks.push(["upPriceSharpness", upSharpness, "Sharpness upgrade price", 0]);
      checks.push(["upPriceLength", upLength, "Length upgrade price", 0]);
    }
    if (STACKABLE_KINDS.includes(kind)) {
      checks.push(["stackSize", stackSize, kind === "ammo" ? "Rounds per space" : "How many share one space", 1, 100_000]);
    }
    if (kind === "healing") {
      checks.push(["healAmount", healAmount, "Heals (HP)", 0, 10_000]);
      checks.push(["maxHpBonus", maxHpBonus, "Max HP bonus", 0, 10_000]);
    }
    for (const [key, text, label, min, max] of checks) {
      const v = whole(text, label, min, max);
      if (v instanceof Error) return v;
      (out as Record<string, unknown>)[key] = v;
    }
    if (kind === "ammo" && out.ammoPerPack == null) return new Error("Enter how many rounds come in one pack.");

    // Size in the case. Backpacks never take space, so they keep theirs.
    if (kind !== "backpack") {
      out.gridW = gridW;
      out.gridH = gridH;
    } else {
      out.expandRows = expandRows;
    }

    // Healing only means something on healing items; other types are cleared
    // so a renamed or re-typed item can't secretly heal.
    if (kind === "healing") {
      out.fullHeal = fullHeal;
      out.herbCode = herbCode || null;
    } else {
      out.healAmount = null;
      out.maxHpBonus = null;
      out.fullHeal = false;
      out.herbCode = null;
    }

    if (kind === "gun") {
      const rs = reloadSec.trim();
      if (rs === "") out.baseReloadMs = null;
      else {
        const sec = Number(rs);
        if (!Number.isFinite(sec) || sec < 0.2 || sec > 10)
          return new Error("Reload time must be between 0.2 and 10 seconds, or empty for the normal 2 seconds.");
        out.baseReloadMs = Math.round(sec * 1000);
      }
      out.shakeForce = shakeForce;
      const h = hre.trim();
      if (h === "") out.hre = null;
      else {
        const n = Number(h);
        if (!Number.isFinite(n) || n <= 0 || n > 1000)
          return new Error("Handgun rounds must be a number above 0 (like 1, 1.5 or 5), or empty.");
        out.hre = Math.round(n * 100) / 100;
      }
    }
    return out;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    setError(null);
    setNotice(null);
    const ms = parseMaxStack();
    if (ms instanceof Error) {
      setError(ms.message);
      return;
    }
    const rules = ruleFields();
    if (rules instanceof Error) {
      setError(rules.message);
      return;
    }
    const input = { name, category: category || null, description: description || null, maxStack: ms, ...rules };
    setSaving(true);
    try {
      if (isEdit) {
        const updated = await updateItem(id!, input);
        setItem(updated);
        setNotice("Saved.");
      } else {
        let created = await createItem(input);
        if (pendingImage) {
          try {
            created = await uploadItemImage(created.id, pendingImage);
          } catch {
            // The item exists; the picture can be added again from the edit screen.
          }
        }
        onSaved(created);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save the item.");
    } finally {
      setSaving(false);
    }
  }

  async function handlePickImage(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setError(null);
    setNotice(null);
    setImageBusy(true);
    try {
      const dataUrl = await resizeImageToDataUrl(file);
      if (isEdit) {
        setItem(await uploadItemImage(id!, dataUrl));
      } else {
        setPendingImage(dataUrl);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not use that picture.");
    } finally {
      setImageBusy(false);
    }
  }

  async function handleRemoveImage() {
    setError(null);
    if (!isEdit) {
      setPendingImage(null);
      return;
    }
    setImageBusy(true);
    try {
      setItem(await removeItemImage(id!));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not remove the picture.");
    } finally {
      setImageBusy(false);
    }
  }

  async function handleToggleEnabled() {
    if (!item) return;
    setError(null);
    setNotice(null);
    setToggling(true);
    try {
      setItem(await updateItem(item.id, { enabled: !item.enabled }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not change the item.");
    } finally {
      setToggling(false);
    }
  }

  if (loadError) {
    return (
      <>
        <BackButton label="Items" onClick={onBack} />
        <ErrorBanner message={loadError} />
      </>
    );
  }
  if (isEdit && !item) return <p className="text-ink/60">Loading…</p>;

  const previewUrl = isEdit ? item!.imageUrl : pendingImage;

  return (
    <>
      <BackButton label="Items" onClick={onBack} />
      <ErrorBanner message={error} />
      <Notice message={notice} />

      <Section title="Picture">
        <div className="flex items-center gap-4">
          <ItemImage url={previewUrl} name={name || "?"} size="lg" />
          <div className="flex flex-1 flex-col gap-2">
            <input
              ref={fileInput}
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              className="hidden"
              onChange={handlePickImage}
            />
            <Button type="button" variant="ghost" size="md" loading={imageBusy} onClick={() => fileInput.current?.click()}>
              {previewUrl ? "Change picture" : "Add picture"}
            </Button>
            {previewUrl && !imageBusy && (
              <button type="button" onClick={handleRemoveImage} className="min-h-[2.5rem] text-sm font-bold text-alert">
                Remove picture
              </button>
            )}
          </div>
        </div>
        <p className="text-sm text-ink/55">Optional. PNG, JPG, WEBP or GIF. Transparent backgrounds are kept.</p>
      </Section>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Section title={isEdit ? "Item details" : "New item"}>
          <TextField id="item-name" label="Name" maxLength={60} value={name} onChange={(e) => setName(e.target.value)} required />
          <TextField
            id="item-category"
            label="Category (optional)"
            hint="Groups items, e.g. Weapon, Ammo, Medical."
            list="item-categories"
            maxLength={40}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          />
          <datalist id="item-categories">
            {categories.map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
          <label htmlFor="item-description" className="block">
            <span className="mb-1 block text-base font-semibold text-ink/80">Description (optional)</span>
            <textarea
              id="item-description"
              rows={3}
              maxLength={500}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={inputCls}
            />
          </label>
          <TextField
            id="item-max-stack"
            label="Max per player (optional)"
            hint={
              kind === "ammo"
                ? "Counted in rounds, not packs. Leave empty for no limit."
                : "Leave empty for no limit. Set 1 for “one each”."
            }
            type="number"
            inputMode="numeric"
            min={1}
            step={1}
            value={maxStack}
            onChange={(e) => setMaxStack(e.target.value)}
          />
        </Section>

        <Section title="Type & shop rules">
          <label htmlFor="item-kind" className="block">
            <span className="mb-1 block text-base font-semibold text-ink/75">Type</span>
            <select id="item-kind" value={kind} onChange={(e) => pickKind(e.target.value as ItemKind)} className={inputCls}>
              {KINDS.map((k) => (
                <option key={k} value={k}>
                  {KIND_LABEL[k]}
                </option>
              ))}
            </select>
            <span className="mt-1 block text-sm text-ink/55">{KIND_HINT[kind]}</span>
          </label>

          {kind === "ammo" && (
            <>
              <label htmlFor="item-ammo-for" className="block">
                <span className="mb-1 block text-base font-semibold text-ink/75">Ammo for</span>
                <select id="item-ammo-for" value={ammoFor} onChange={(e) => setAmmoFor(e.target.value)} className={inputCls}>
                  <option value="">Choose a gun…</option>
                  {guns.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </select>
                {guns.length === 0 && (
                  <span className="mt-1 block text-sm text-sun">Make the gun first (type “Gun”), then come back to this.</span>
                )}
              </label>
              <NumberField id="item-per-pack" label="Rounds per pack" value={perPack} onChange={setPerPack} placeholder="e.g. 30" />
              <p className="text-sm text-ink/55">The shop price you set is per pack. Players hold the rounds.</p>
            </>
          )}

          <div className="border-t border-panel-line pt-4">
            <label className="flex min-h-[2.75rem] items-center gap-3">
              <input
                type="checkbox"
                checked={sellable}
                onChange={(e) => setSellable(e.target.checked)}
                className="h-6 w-6 accent-[#F5A524]"
              />
              <span className="text-base font-semibold">Players can sell this back</span>
            </label>
            {sellable && (
              <div className="mt-3">
                <NumberField
                  id="item-sell-pct"
                  label="Sell-back (% of what they paid)"
                  value={sellPercent}
                  onChange={setSellPercent}
                  placeholder="50"
                  hint="Includes upgrades they bought. 50 = half back. Players only see the amount when they choose to sell."
                />
              </div>
            )}
          </div>
        </Section>

        {kind === "backpack" ? (
          <Section title="Bigger case">
            <p className="text-ink/70">
              A backpack doesn't sit in the case — it makes the case bigger the moment a player gets it.
            </p>
            <div className="flex items-center justify-between gap-3">
              <span className="text-base font-semibold text-ink/80">Rows it adds</span>
              <Stepper label="Rows it adds" value={expandRows} onChange={setExpandRows} min={1} max={5} />
            </div>
            <p className="text-sm text-ink/55">
              Players see “Adds {expandRows} row{expandRows === 1 ? "" : "s"} to your case”. The case never grows past the
              most rows set in Game rules.
            </p>
          </Section>
        ) : (
          <Section title="Size in the case">
            <div className="grid grid-cols-2 gap-3">
              <SizeStepper
                label="Wide"
                value={gridW}
                onChange={(v) => {
                  setGridW(v);
                  setSizeTouched(true);
                }}
              />
              <SizeStepper
                label="Tall"
                value={gridH}
                onChange={(v) => {
                  setGridH(v);
                  setSizeTouched(true);
                }}
              />
            </div>
            <SizePreview w={gridW} h={gridH} imageUrl={previewUrl} name={name} caseCols={caseSize.cols} caseRows={caseSize.rows} />
            <p className="text-sm text-ink/55">
              Counted in squares of the player's case. Players can turn items sideways to make them fit. Usual sizes: pistol
              3×2, rifle or shotgun 6×2, knife 2×1, ammo and herbs 1×1.
            </p>
            {STACKABLE_KINDS.includes(kind) && (
              <NumberField
                id="item-stack"
                label={kind === "ammo" ? "Rounds that fit in one space" : "How many share one space"}
                value={stackSize}
                onChange={setStackSize}
                placeholder={kind === "ammo" ? (perPack.trim() ? perPack.trim() : "30") : "1"}
                hint={
                  kind === "ammo"
                    ? "Empty = one pack per space. More rounds than this take another space."
                    : "Empty = 1. For example 3 lets three of these sit on top of each other."
                }
              />
            )}
          </Section>
        )}

        {kind === "healing" && (
          <Section title="Healing">
            <label htmlFor="item-herb" className="block">
              <span className="mb-1 block text-base font-semibold text-ink/75">Herb type</span>
              <select id="item-herb" value={herbCode} onChange={(e) => pickHerb(e.target.value as HerbCode | "")} className={inputCls}>
                <option value="">Not a herb (e.g. a med kit)</option>
                {HERB_CODES.map((c) => (
                  <option key={c} value={c}>
                    {HERB_LABEL[c]}
                  </option>
                ))}
              </select>
              <span className="mt-1 block text-sm text-ink/55">
                Herbs can be mixed in the case. Every mix needs a Green Herb: G+G, G+R, G+Y, G+R+Y and G+G+Y.
              </span>
            </label>
            {herbCode && !matchesHerbDefaults(herbCode, healAmount, maxHpBonus, fullHeal) && (
              <button
                type="button"
                onClick={() => applyHerbDefaults(herbCode)}
                className="flex min-h-[2.75rem] w-fit items-center gap-2 rounded-sm border border-panel-line px-3 text-sm font-semibold text-pine active:bg-pine-soft"
              >
                <Icon name="refresh" className="h-4 w-4" />
                Use the usual values for {HERB_LABEL[herbCode]}
              </button>
            )}
            <div className="grid grid-cols-2 gap-3">
              <NumberField id="item-heal" label="Heals (HP)" value={healAmount} onChange={setHealAmount} placeholder="0" />
              <NumberField id="item-maxhp" label="Max HP bonus" value={maxHpBonus} onChange={setMaxHpBonus} placeholder="0" />
            </div>
            <p className="-mt-2 text-sm text-ink/55">
              Max HP bonus raises the player's top HP for good (and fills the new room). It never goes past the cap in Game
              rules.
            </p>
            <label className="flex min-h-[2.75rem] items-center gap-3">
              <input
                type="checkbox"
                checked={fullHeal}
                onChange={(e) => setFullHeal(e.target.checked)}
                className="h-6 w-6 accent-[#F5A524]"
              />
              <span className="text-base font-semibold">Restores all HP</span>
            </label>
            <p className="flex items-start gap-2 border-l-4 border-olive bg-olive-soft px-3 py-2 font-semibold text-ink">
              <Icon name="heart" className="mt-0.5 h-5 w-5 shrink-0 text-olive" />
              {healSummary(healAmount, maxHpBonus, fullHeal, herbCode)}
            </p>
          </Section>
        )}

        {kind === "gun" && (
          <Section title="How the gun feels">
            <NumberField
              id="item-reload"
              label="Reload time (seconds)"
              value={reloadSec}
              onChange={setReloadSec}
              placeholder="2.0"
              decimal
              hint="How long a reload takes at level 1. Empty = 2 seconds. Each Reload speed upgrade makes it faster; level 5 takes about half as long."
            />
            <ShakeSlider value={shakeForce} onChange={setShakeForce} />
          </Section>
        )}

        {(kind === "gun" || kind === "knife") && (
          <Section title="Upgrades in the shop">
            {kind === "gun" && (
              <>
                <NumberField
                  id="item-base-mag"
                  label="Starting magazine (rounds)"
                  value={baseMagazine}
                  onChange={setBaseMagazine}
                  placeholder="12"
                  hint="Size at level 1. Each magazine upgrade adds about 20%."
                />
                <UpgradePrice id="item-up-mag" label="Magazine upgrade" what="More rounds before a reload." value={upMagazine} onChange={setUpMagazine} />
                <UpgradePrice
                  id="item-up-dmg"
                  label="Damage upgrade"
                  what="Each level makes every hit count for more (how much is set in the Calc tab)."
                  value={upDamage}
                  onChange={setUpDamage}
                />
                <UpgradePrice id="item-up-reload" label="Reload speed upgrade" what="Faster reloads." value={upReload} onChange={setUpReload} />
                <UpgradePrice
                  id="item-up-firerate"
                  label="Fire rate upgrade"
                  what="A lighter shake fires, and shots come quicker."
                  value={upFirerate}
                  onChange={setUpFirerate}
                />
              </>
            )}
            {kind === "knife" && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <NumberField id="item-base-sharp" label="Starting sharpness" value={baseSharpness} onChange={setBaseSharpness} placeholder="10" />
                  <NumberField id="item-base-len" label="Starting length (cm)" value={baseLength} onChange={setBaseLength} placeholder="20" />
                </div>
                <UpgradePrice id="item-up-sharp" label="Sharpness upgrade" value={upSharpness} onChange={setUpSharpness} />
                <UpgradePrice id="item-up-len" label="Length upgrade" value={upLength} onChange={setUpLength} />
              </>
            )}
          </Section>
        )}

        {kind === "gun" && (
          <Section title="Calculator">
            <label htmlFor="item-hre" className="block">
              <span className="mb-1 block text-base font-semibold text-ink/75">How strong is one round?</span>
              <span className="flex items-center gap-3">
                <span className="shrink-0 font-semibold text-ink/70">1 round =</span>
                <input
                  id="item-hre"
                  type="number"
                  inputMode="decimal"
                  min={0}
                  step="any"
                  placeholder="1"
                  value={hre}
                  onChange={(e) => setHre(e.target.value)}
                  className={`${inputCls} !w-28 text-center`}
                />
                <span className="font-semibold text-ink/70">handgun rounds</span>
              </span>
              <span className="mt-1 block text-sm text-ink/55">
                A pistol round is 1. A shotgun round is about 5. Used in the Calc tab for bosses and voice call damage.
              </span>
            </label>
          </Section>
        )}

        <Button type="submit" loading={saving}>
          {isEdit ? "Save changes" : "Create Item"}
        </Button>
      </form>

      {isEdit && item && <ItemMediaSection item={item} onChange={setItem} />}
      {!isEdit && (
        <p className="rounded-md bg-pine-soft px-4 py-3 text-ink/80">
          After you create the item you can add a 3D model and a sound for it.
        </p>
      )}

      {isEdit && item && (
        <Section title="Availability" tone={item.enabled ? "pine" : "alert"}>
          <div className="flex items-center gap-2">
            <Badge tone={item.enabled ? "good" : "bad"}>{item.enabled ? "Enabled" : "Disabled"}</Badge>
          </div>
          <p className="text-ink/70">
            {item.enabled
              ? "Disabling stops anyone giving or selling this item. Players keep what they already have."
              : "This item can't be given out or bought until you enable it again."}
          </p>
          <Button variant={item.enabled ? "dangerGhost" : "primary"} loading={toggling} onClick={handleToggleEnabled}>
            {item.enabled ? "Disable item" : "Enable item"}
          </Button>
        </Section>
      )}
    </>
  );
}

const KINDS: ItemKind[] = ["gun", "knife", "ammo", "healing", "backpack", "other"];
const SELLABLE_KINDS: ItemKind[] = ["gun", "knife", "ammo", "healing"];
// Kinds where several can share one space in the case.
const STACKABLE_KINDS: ItemKind[] = ["ammo", "healing", "other"];
const KIND_HINT: Record<ItemKind, string> = {
  gun: "Fires and reloads. Can get magazine, damage, reload speed and fire rate upgrades in the shop.",
  knife: "Can get sharpness and length upgrades in the shop.",
  ammo: "Sold in packs, held as rounds. Players load it into the gun it's for.",
  healing: "Med kits and herbs. Players use them from their case to get HP back.",
  backpack: "Makes the player's case bigger as soon as they get it.",
  other: "Anything else.",
};
// Usual case size per type: [wide, tall].
const DEFAULT_SIZE: Record<ItemKind, [number, number]> = {
  gun: [3, 2],
  knife: [2, 1],
  ammo: [1, 1],
  healing: [1, 1],
  backpack: [1, 1],
  other: [1, 1],
};

const HERB_CODES: HerbCode[] = ["G", "R", "Y", "GG", "GR", "GY", "GRY", "GGY"];
// The game's usual herb effects (the Admin can change them per item).
const HERB_DEFAULTS: Record<HerbCode, { heal: number; max?: number; full?: boolean }> = {
  G: { heal: 30 },
  R: { heal: 0 },
  Y: { heal: 0 },
  GG: { heal: 60 },
  GR: { heal: 20, max: 20 },
  GY: { heal: 45 },
  GRY: { heal: 50, max: 15 },
  GGY: { heal: 0, full: true },
};

function matchesHerbDefaults(code: HerbCode, heal: string, max: string, full: boolean): boolean {
  const d = HERB_DEFAULTS[code];
  return Number(heal || 0) === d.heal && Number(max || 0) === (d.max ?? 0) && full === !!d.full;
}

// What happens when a player uses it, in one sentence.
function healSummary(heal: string, max: string, full: boolean, herb: HerbCode | ""): string {
  const h = Number(heal) || 0;
  const m = Number(max) || 0;
  if (full && m > 0) return `When used: max HP +${m}, then all HP restored.`;
  if (full) return "When used: restores all HP.";
  if (h > 0 && m > 0) return `When used: max HP +${m} and heals ${h + m} HP (fills the new room too).`;
  if (m > 0) return `When used: max HP +${m} (and fills it).`;
  if (h > 0) return `When used: heals ${h} HP.`;
  if (herb === "R" || herb === "Y") return "Does nothing on its own. Players mix it with a Green Herb first.";
  return "Does nothing yet. Set how much it heals.";
}

function NumberField({
  id,
  label,
  value,
  onChange,
  placeholder,
  hint,
  decimal = false,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  hint?: string;
  decimal?: boolean;
}) {
  return (
    <TextField
      id={id}
      label={label}
      hint={hint}
      type="number"
      inputMode={decimal ? "decimal" : "numeric"}
      min={0}
      step={decimal ? "any" : 1}
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

// [-] 3 [+] for one side of the item, 1 to 10 squares. Smaller than the
// shared Stepper so "Wide" and "Tall" sit side by side on a phone.
function SizeStepper({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  const btn =
    "flex h-11 w-11 shrink-0 items-center justify-center rounded-sm border-2 border-panel-line bg-panel-raised text-pine active:bg-pine-soft disabled:opacity-30";
  return (
    <div className="flex flex-col gap-1" role="group" aria-label={`${label} (squares)`}>
      <span className="text-sm font-semibold text-ink/60">{label}</span>
      <div className="flex items-center gap-1.5">
        <button type="button" className={btn} disabled={value <= 1} onClick={() => onChange(value - 1)} aria-label={`Less ${label.toLowerCase()}`}>
          <Icon name="minus" className="h-5 w-5" />
        </button>
        <span className="min-w-[2rem] text-center font-display text-2xl font-bold tabular-nums" aria-live="polite">
          {value}
        </span>
        <button type="button" className={btn} disabled={value >= 10} onClick={() => onChange(value + 1)} aria-label={`More ${label.toLowerCase()}`}>
          <Icon name="plus" className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}

// A little piece of case with the item drawn at its size, so the Admin sees
// at once how much room it takes.
function SizePreview({
  w,
  h,
  imageUrl,
  name,
  caseCols,
  caseRows,
}: {
  w: number;
  h: number;
  imageUrl: string | null;
  name: string;
  caseCols: number;
  caseRows: number;
}) {
  const cols = Math.min(10, Math.max(caseCols, w));
  const rows = Math.min(10, Math.max(2, h + 1));
  const fits = w <= caseCols && h <= caseRows;
  const fitsTurned = h <= caseCols && w <= caseRows;
  const cells = [];
  for (let y = 0; y < rows; y++)
    for (let x = 0; x < cols; x++)
      cells.push(
        <div
          key={`${x}-${y}`}
          aria-hidden
          style={{ gridColumn: x + 1, gridRow: y + 1 }}
          className="aspect-square border border-white/[0.07] bg-black/45"
        />
      );
  return (
    <div className="flex flex-col gap-2">
      <div
        className="w-full rounded-[4px] border border-white/15 bg-gradient-to-b from-[#202428] to-[#0b0d0f] p-1.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.10)]"
        style={{ maxWidth: cols * 28 + 14 }}
      >
        <div className="grid" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
          {cells}
          <div
            style={{ gridColumn: `1 / span ${Math.min(w, cols)}`, gridRow: `1 / span ${Math.min(h, rows)}` }}
            className="relative z-10 m-[1px] min-h-0 min-w-0 overflow-hidden rounded-[2px] border border-pine bg-pine-soft transition-all duration-200"
          >
            {imageUrl ? (
              <img src={imageUrl} alt="" className="absolute inset-0 h-full w-full object-contain p-0.5" />
            ) : (
              <span className="absolute inset-0 flex items-center justify-center font-display font-bold text-pine">
                {name.trim().charAt(0).toUpperCase() || "?"}
              </span>
            )}
          </div>
        </div>
      </div>
      <p className="text-sm font-semibold text-ink/70">
        Takes {w}×{h} = {w * h} of the {caseCols * caseRows} squares in a starting case ({caseCols}×{caseRows}).
      </p>
      {!fits && (
        <p className="text-sm font-semibold text-sun">
          {fitsTurned
            ? "Bigger than the case this way round — players will have to turn it sideways."
            : "Too big for a starting case. It only fits once the case grows, or it waits in the tray."}
        </p>
      )}
    </div>
  );
}

// Shake needed to fire: 1 = a light flick (pistol) … 10 = a hard shove
// (shotgun). Fire rate upgrades make every gun lighter from here.
function ShakeSlider({ value, onChange }: { value: number | null; onChange: (v: number | null) => void }) {
  const shown = value ?? 5;
  const words =
    shown <= 2 ? "Very light — a flick fires" : shown <= 4 ? "Light, like a pistol" : shown <= 6 ? "Medium, like a rifle" : shown <= 8 ? "Strong, like a sniper" : "Heavy — a hard shove, like a shotgun";
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-baseline justify-between gap-3">
        <label htmlFor="item-shake" className="text-base font-semibold text-ink/75">
          Shake needed to fire
        </label>
        <span className="font-display text-2xl font-bold tabular-nums text-pine">
          {shown}
          <span className="text-base text-ink/45">/10</span>
        </span>
      </div>
      <input
        id="item-shake"
        type="range"
        min={1}
        max={10}
        step={1}
        value={shown}
        onChange={(e) => onChange(Number(e.target.value))}
        className={`h-10 w-full accent-[#F5A524] ${value === null ? "opacity-60" : ""}`}
        aria-valuetext={`${shown} of 10: ${words}`}
      />
      <div className="flex justify-between text-xs font-semibold text-ink/50">
        <span>1 · light (pistol)</span>
        <span>heavy (shotgun) · 10</span>
      </div>
      <p className="text-sm text-ink/70">
        {value === null ? (
          <>
            Not set — uses the normal feel.{" "}
            <span className="text-ink/50">Move the slider to choose.</span>
          </>
        ) : (
          <>
            {words}.{" "}
            <button type="button" onClick={() => onChange(null)} className="font-semibold text-pine underline-offset-2 active:underline">
              Back to normal
            </button>
          </>
        )}
      </p>
      <p className="text-sm text-ink/55">Players shake the phone to fire. Fire rate upgrades make the shake lighter, up to level 5.</p>
    </div>
  );
}

// Base price for level 2; each level after costs double.
function UpgradePrice({
  id,
  label,
  what,
  value,
  onChange,
}: {
  id: string;
  label: string;
  what?: string;
  value: string;
  onChange: (v: string) => void;
}) {
  const base = Number(value);
  const ok = value.trim() !== "" && Number.isInteger(base) && base >= 0;
  return (
    <div>
      <NumberField id={id} label={`${label} price ($)`} value={value} onChange={onChange} placeholder="Not for sale" />
      <span className="mt-1 block text-sm text-ink/55">
        {what && <span className="text-ink/70">{what} </span>}
        {ok
          ? `Level 2 $${base} · 3 $${base * 2} · 4 $${base * 4} · 5 $${base * 8}`
          : "Empty = players can't buy this upgrade yet. Each level costs double the one before."}
      </span>
    </div>
  );
}
