import { ChangeEvent, lazy, Suspense, useRef, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import { Item, removeItemFile, updateItem, uploadItemFile, UseEffect } from "../../services/api";
import { leaveViewer, prepareViewer } from "../../viewer/open";

const ItemViewer = lazy(() => import("../../viewer/ItemViewer"));

const EFFECTS: { key: UseEffect; label: string; hint: string }[] = [
  { key: "shot", label: "Fire", hint: "Guns: sound, recoil, muzzle flash" },
  { key: "swing", label: "Swing", hint: "Knives and melee weapons" },
  { key: "none", label: "Just show", hint: "Medkits, gear, anything else" },
];

// 3D model, sound and "what a tap does" for one item. Players see this when
// they open the item from their Bag: full screen, tap or shake to use.
export function ItemMediaSection({ item, onChange }: { item: Item; onChange: (item: Item) => void }) {
  const modelInput = useRef<HTMLInputElement>(null);
  const soundInput = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [previewing, setPreviewing] = useState(false);

  async function run(label: string, fn: () => Promise<Item>, done?: string) {
    setError(null);
    setNotice(null);
    setBusy(label);
    try {
      onChange(await fn());
      if (done) setNotice(done);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(null);
    }
  }

  function pick(kind: "model" | "sound") {
    return (e: ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = "";
      if (!file) return;
      const max = kind === "model" ? 15 : 3;
      if (file.size > max * 1024 * 1024) {
        setError(`That file is too big. The limit is ${max} MB.`);
        return;
      }
      void run(kind, () => uploadItemFile(item.id, kind, file), kind === "model" ? "3D model saved." : "Sound saved.");
    };
  }

  function testSound() {
    if (!item.soundUrl) return;
    const a = new Audio(item.soundUrl);
    void a.play().catch(() => setError("Couldn't play the sound on this device."));
  }

  return (
    <Section title="3D model & sound">
      <p className="text-ink/70">
        Players open this item from their Bag. It fills the screen, and tapping it (or shaking the phone) uses it.
      </p>
      <ErrorBanner message={error} />
      <Notice message={notice} />

      {/* What a tap does */}
      <div>
        <p className="mb-2 text-base font-bold text-ink/80">When the player taps or shakes</p>
        <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Tap action">
          {EFFECTS.map((ef) => (
            <button
              key={ef.key}
              type="button"
              role="radio"
              aria-checked={item.useEffect === ef.key}
              disabled={busy !== null}
              onClick={() => run("effect", () => updateItem(item.id, { useEffect: ef.key }))}
              className={`flex min-h-[4.5rem] flex-col items-center justify-center rounded-md border-2 px-1 py-2 text-center ${
                item.useEffect === ef.key ? "border-pine bg-pine text-pine-ink" : "border-ink/15 bg-panel text-ink"
              }`}
            >
              <span className="text-base font-display font-bold">{ef.label}</span>
              <span className={`text-[11px] leading-tight ${item.useEffect === ef.key ? "text-pine-ink/80" : "text-ink/55"}`}>
                {ef.hint}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* 3D model */}
      <div className="flex flex-col gap-2 rounded-md border-2 border-ink/10 p-3">
        <div className="flex items-center gap-2">
          <Icon name="cube" className="h-5 w-5 text-pine" />
          <p className="font-bold">3D model</p>
          <span className="ml-auto text-sm font-semibold text-ink/55">{item.modelUrl ? "Added" : "None"}</span>
        </div>
        <input
          ref={modelInput}
          type="file"
          accept=".glb,model/gltf-binary"
          className="hidden"
          onChange={pick("model")}
        />
        <div className="grid grid-cols-2 gap-2">
          <Button variant="ghost" size="md" loading={busy === "model"} onClick={() => modelInput.current?.click()}>
            {item.modelUrl ? "Replace .glb" : "Add .glb"}
          </Button>
          <Button
            variant="dangerGhost"
            size="md"
            disabled={!item.modelUrl || busy !== null}
            onClick={() => run("model", () => removeItemFile(item.id, "model"), "3D model removed.")}
          >
            Remove
          </Button>
        </div>
        {item.modelUrl && (
          <div className="flex flex-col gap-2 pt-1">
            <p className="text-sm text-ink/60">Facing the wrong way in the preview? Fix it here:</p>
            <label className="flex min-h-[2.75rem] items-center gap-3 font-semibold">
              <input
                type="checkbox"
                className="h-6 w-6 accent-pine"
                checked={item.modelFlip}
                disabled={busy !== null}
                onChange={(e) => run("flip", () => updateItem(item.id, { modelFlip: e.target.checked }))}
              />
              Turn around (point the other way)
            </label>
            <label className="flex min-h-[2.75rem] items-center gap-3 font-semibold">
              <input
                type="checkbox"
                className="h-6 w-6 accent-pine"
                checked={item.modelUpsideDown}
                disabled={busy !== null}
                onChange={(e) => run("upside", () => updateItem(item.id, { modelUpsideDown: e.target.checked }))}
              />
              Upside down
            </label>
          </div>
        )}
      </div>

      {/* Sound */}
      <div className="flex flex-col gap-2 rounded-md border-2 border-ink/10 p-3">
        <div className="flex items-center gap-2">
          <Icon name="sound" className="h-5 w-5 text-pine" />
          <p className="font-bold">Sound</p>
          <span className="ml-auto text-sm font-semibold text-ink/55">{item.soundUrl ? "Added" : "None"}</span>
        </div>
        <input
          ref={soundInput}
          type="file"
          accept="audio/*,.mp3,.ogg,.wav,.m4a"
          className="hidden"
          onChange={pick("sound")}
        />
        <div className="grid grid-cols-3 gap-2">
          <Button variant="ghost" size="md" loading={busy === "sound"} onClick={() => soundInput.current?.click()}>
            {item.soundUrl ? "Replace" : "Add"}
          </Button>
          <Button variant="ghost" size="md" disabled={!item.soundUrl} onClick={testSound}>
            <span className="flex items-center justify-center gap-1">
              <Icon name="play" className="h-4 w-4" /> Play
            </span>
          </Button>
          <Button
            variant="dangerGhost"
            size="md"
            disabled={!item.soundUrl || busy !== null}
            onClick={() => run("sound", () => removeItemFile(item.id, "sound"), "Sound removed.")}
          >
            Remove
          </Button>
        </div>
        <p className="text-sm text-ink/55">MP3, OGG, WAV or M4A, up to 3 MB. Short sounds work best.</p>
      </div>

      <Button
        onClick={() => {
          prepareViewer(item.useEffect);
          setPreviewing(true);
        }}
      >
        <span className="flex items-center justify-center gap-2">
          <Icon name="target" className="h-5 w-5" /> Preview what players see
        </span>
      </Button>

      {previewing && (
        <Suspense fallback={<div className="fixed inset-0 z-50 bg-[#0b140f]" />}>
          <ItemViewer
            item={item}
            onClose={() => {
              leaveViewer();
              setPreviewing(false);
            }}
          />
        </Suspense>
      )}
    </Section>
  );
}
