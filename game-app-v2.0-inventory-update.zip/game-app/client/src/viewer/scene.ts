import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

// The full-screen 3D view of one item (a gun, a knife, a medkit…).
// Everything is drawn with three.js, bundled into the app, so it works
// offline. Kept out of React: the component only calls load / trigger /
// reload / resize / dispose.

export type UseEffect = "none" | "shot" | "swing";

export interface SceneOptions {
  modelUrl: string;
  flip: boolean; // turn around (barrel faces the other way)
  upsideDown: boolean;
  effect: UseEffect;
}

const TARGET_SIZE = 3; // longest side of the model, in scene units

const easeIn = (t: number) => t * t * t;
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);

// Reload: the gun drops out of view, stays down a moment (new magazine),
// then comes back up. Fractions of the reload time:
const RELOAD_DOWN = 0.36;
const RELOAD_UP = 0.58;

// How far down the gun is (0 = resting, 1 = fully out of view) at a point
// of the reload (0..1).
function reloadDrop(p: number): number {
  if (p < RELOAD_DOWN) return easeIn(p / RELOAD_DOWN);
  if (p < RELOAD_UP) return 1;
  return 1 - easeOut((p - RELOAD_UP) / (1 - RELOAD_UP));
}

function makeFlashTexture(): THREE.Texture {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grd.addColorStop(0, "rgba(255,255,240,1)");
  grd.addColorStop(0.18, "rgba(255,236,150,0.95)");
  grd.addColorStop(0.45, "rgba(255,160,40,0.55)");
  grd.addColorStop(1, "rgba(255,90,0,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  // a few spikes so it reads as a muzzle flash, not a glow
  g.globalCompositeOperation = "lighter";
  g.fillStyle = "rgba(255,220,120,0.6)";
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * Math.PI * 2;
    g.beginPath();
    g.moveTo(64, 64);
    g.lineTo(64 + Math.cos(a - 0.09) * 60, 64 + Math.sin(a - 0.09) * 60);
    g.lineTo(64 + Math.cos(a + 0.09) * 60, 64 + Math.sin(a + 0.09) * 60);
    g.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class ItemScene {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(32, 1, 0.05, 200);
  private rig = new THREE.Group(); // animated (recoil / swing / spin)
  private rigBase = new THREE.Vector3(); // rig's resting position (the pivot)
  private tilt = 0; // long guns lean diagonally on an upright phone so they're bigger
  private holder = new THREE.Group(); // offsets the model so `rig` pivots in the right place
  private flash: THREE.Sprite;
  private flashLight = new THREE.PointLight(0xffb040, 0, 6, 2);
  private fitSize = new THREE.Vector3(3, 1, 1);
  private raf = 0;
  private clock = new THREE.Clock();
  private effect: UseEffect = "none";
  private disposed = false;

  // animation state
  private kick = 0;
  private flashTime = 0;
  private shake = 0;
  private swingT = -1;
  private spinT = -1;
  private idle = 0;
  private reloadT = -1; // seconds into the reload, -1 = not reloading
  private reloadDur = 1.5; // seconds
  private recoverT = -1; // quick way back up after a cancelled reload
  private recoverFrom = 0;
  private dropDist = 4; // how far down "out of view" is, in scene units
  private calm = false; // reduce motion: no camera shake

  constructor(private container: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.setClearColor(0x000000, 0);
    container.appendChild(this.renderer.domElement);
    Object.assign(this.renderer.domElement.style, { width: "100%", height: "100%", display: "block" });

    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x3a4a40, 2.2));
    const key = new THREE.DirectionalLight(0xffffff, 2.4);
    key.position.set(3, 5, 6);
    this.scene.add(key);
    const rim = new THREE.DirectionalLight(0x9fd7ff, 1.2);
    rim.position.set(-5, 2, -4);
    this.scene.add(rim);

    this.flash = new THREE.Sprite(
      // Normal (not additive) blending: the canvas is transparent, and
      // additive blending would add colour without making it visible.
      new THREE.SpriteMaterial({
        map: makeFlashTexture(),
        depthWrite: false,
        depthTest: false,
        transparent: true,
      })
    );
    this.flash.visible = false;

    this.rig.add(this.holder);
    this.scene.add(this.rig);
    this.resize();
    this.loop();
  }

  async load(opts: SceneOptions): Promise<void> {
    this.effect = opts.effect;
    const gltf = await new GLTFLoader().loadAsync(opts.modelUrl);
    if (this.disposed) return;
    const model = gltf.scene;

    // Every downloaded model is oriented differently. Lay it along X (side
    // view) if it points at the camera, then apply the Admin's fixes.
    const orient = new THREE.Group();
    orient.add(model);
    let box = new THREE.Box3().setFromObject(orient);
    let size = box.getSize(new THREE.Vector3());
    if (size.z > size.x && size.z > size.y) orient.rotation.y = Math.PI / 2;
    if (opts.flip) orient.rotation.y += Math.PI;
    if (opts.upsideDown) orient.rotation.x += Math.PI;
    orient.updateMatrixWorld(true);

    // Scale so the longest side is TARGET_SIZE, and centre it.
    box = new THREE.Box3().setFromObject(orient);
    size = box.getSize(new THREE.Vector3());
    const s = TARGET_SIZE / Math.max(size.x, size.y, size.z);
    orient.scale.setScalar(s);
    orient.updateMatrixWorld(true);
    box = new THREE.Box3().setFromObject(orient);
    const center = box.getCenter(new THREE.Vector3());
    orient.position.sub(center);
    orient.updateMatrixWorld(true);
    box = new THREE.Box3().setFromObject(orient);
    this.fitSize = box.getSize(new THREE.Vector3());

    // Pivot: a gun kicks back around its middle; a blade swings from its
    // handle end (the low end of its longest side).
    const pivot = new THREE.Vector3();
    if (opts.effect === "swing") {
      // a little above the handle end, like a wrist
      if (this.fitSize.y >= this.fitSize.x) pivot.set(0, box.min.y + this.fitSize.y * 0.25, 0);
      else pivot.set(box.min.x + this.fitSize.x * 0.25, 0, 0);
    }
    this.rigBase.copy(pivot);
    this.rig.position.copy(pivot);
    this.holder.position.copy(pivot).negate();
    this.holder.add(orient);

    // Muzzle: the average height of the model's right-most points.
    if (opts.effect === "shot") {
      const muzzle = this.findMuzzle(orient, box);
      this.flash.position.copy(muzzle).add(new THREE.Vector3(0.28, 0, 0));
      this.flashLight.position.copy(muzzle).add(new THREE.Vector3(0.3, 0, 0.3));
      this.holder.add(this.flash, this.flashLight);
    }
    this.resize();
  }

  private findMuzzle(root: THREE.Object3D, box: THREE.Box3): THREE.Vector3 {
    const edge = box.max.x - (box.max.x - box.min.x) * 0.05;
    const v = new THREE.Vector3();
    let n = 0;
    let y = 0;
    let z = 0;
    root.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (!mesh.isMesh) return;
      const pos = mesh.geometry.getAttribute("position");
      if (!pos) return;
      for (let i = 0; i < pos.count; i++) {
        v.fromBufferAttribute(pos, i).applyMatrix4(mesh.matrixWorld);
        if (v.x >= edge) {
          y += v.y;
          z += v.z;
          n++;
        }
      }
    });
    return new THREE.Vector3(box.max.x, n ? y / n : 0, n ? z / n : 0);
  }

  // Reload animation over durationMs. Calling it again while reloading
  // keeps the progress and changes the length (the server's time wins).
  reload(durationMs: number): void {
    const dur = Math.max(0.3, durationMs / 1000);
    if (this.reloadT >= 0) {
      this.reloadT = (this.reloadT / this.reloadDur) * dur;
      this.reloadDur = dur;
      return;
    }
    this.reloadDur = dur;
    this.reloadT = 0;
    this.recoverT = -1;
    this.kick = 0;
    this.flashTime = 0;
  }

  // The reload failed: bring the gun straight back up.
  cancelReload(): void {
    if (this.reloadT < 0) return;
    this.recoverFrom = reloadDrop(this.reloadT / this.reloadDur);
    this.reloadT = -1;
    this.recoverT = 0;
  }

  // How tall the stage should be for its width on an upright phone, so the
  // item fills it without big empty bands (the HP bar then sits right under
  // the gun). Long guns lean diagonally there, so they want a taller stage.
  portraitHeightRatio(): number {
    const long = this.fitSize.x > this.fitSize.y * 2;
    if (long && this.effect !== "swing") return 1.12;
    const ratio = (this.fitSize.y * 1.5) / (Math.max(this.fitSize.x, 0.01) * 1.35);
    return Math.min(1.12, Math.max(0.62, ratio));
  }

  get reloading(): boolean {
    return this.reloadT >= 0;
  }

  // Reduce motion: keep the gun's own movement, drop the camera shake.
  setCalm(on: boolean): void {
    this.calm = on;
  }

  // One tap / shake.
  trigger(): void {
    if (this.reloadT >= 0) return; // the gun is down, being reloaded
    if (this.effect === "shot") {
      this.kick = 1;
      this.flashTime = 0.07;
      this.shake = 1;
      this.flash.material.rotation = Math.random() * Math.PI;
    } else if (this.effect === "swing") {
      this.swingT = 0;
    } else {
      this.spinT = 0;
    }
  }

  resize(): void {
    const w = this.container.clientWidth || 1;
    const h = this.container.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    // A long rifle lying flat on a tall, narrow screen would be tiny, so on
    // an upright phone it leans diagonally (muzzle up-right) instead.
    const long = this.fitSize.x > this.fitSize.y * 2;
    this.tilt = this.camera.aspect < 0.9 && long && this.effect !== "swing" ? 0.62 : 0;
    const c = Math.cos(this.tilt);
    const sn = Math.sin(this.tilt);
    const extX = this.fitSize.x * c + this.fitSize.y * sn;
    const extY = this.fitSize.x * sn + this.fitSize.y * c;
    // Fit the model's width and height (plus room for recoil and swing).
    const tan = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    const needW = extX * (this.tilt ? 1.12 : 1.35);
    const needH = extY * (this.tilt ? 1.2 : 1.5);
    const d = Math.max(needW / (2 * tan * this.camera.aspect), needH / (2 * tan), 2);
    // Far enough down that the whole gun (even leaning) is below the frame.
    this.dropDist = d * tan + Math.max(extX, extY) * 0.6 + 0.4;
    this.camera.position.set(0, this.fitSize.y * 0.08, d + this.fitSize.z / 2);
    this.camera.lookAt(0, 0, 0);
    this.camera.updateProjectionMatrix();
  }

  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.idle += dt;

    // Gentle idle turn so it looks 3D, not a flat picture.
    let rotY = Math.sin(this.idle * 0.7) * 0.22;
    let rotZ = this.tilt;
    let posX = 0;
    let posY = 0;

    // Reload: down out of view (speeding up), wait, back up (slowing down).
    let drop = 0;
    if (this.reloadT >= 0) {
      this.reloadT += dt;
      const p = this.reloadT / this.reloadDur;
      if (p >= 1) this.reloadT = -1;
      else drop = reloadDrop(p);
    } else if (this.recoverT >= 0) {
      this.recoverT += dt / 0.25;
      if (this.recoverT >= 1) this.recoverT = -1;
      else drop = this.recoverFrom * (1 - easeOut(this.recoverT));
    }
    if (drop > 0) {
      posY -= this.dropDist * drop;
      rotZ -= 0.35 * drop; // muzzle dips as it goes down
    }

    if (this.kick > 0) {
      this.kick = Math.max(0, this.kick - dt * 5.5);
      const k = this.kick * this.kick;
      posX -= 0.35 * k;
      rotZ += 0.22 * k; // muzzle climbs
    }
    if (this.swingT >= 0) {
      this.swingT += dt / 0.32;
      if (this.swingT >= 1) this.swingT = -1;
      else {
        const p = this.swingT;
        rotZ += -Math.sin(p * Math.PI) * 0.95; // slash down and back up
        posX += Math.sin(p * Math.PI) * 0.25;
      }
    }
    if (this.spinT >= 0) {
      this.spinT += dt / 0.7;
      if (this.spinT >= 1) this.spinT = -1;
      else rotY += (1 - Math.pow(1 - this.spinT, 3)) * Math.PI * 2;
    }

    this.rig.rotation.set(0, rotY, rotZ);
    this.rig.position.set(this.rigBase.x + posX, this.rigBase.y + posY, this.rigBase.z);

    // Flash
    if (this.flashTime > 0) {
      this.flashTime -= dt;
      const s = 0.85 + Math.random() * 0.5;
      this.flash.scale.set(s, s, s);
      this.flash.visible = true;
      this.flashLight.intensity = 40;
    } else {
      this.flash.visible = false;
      this.flashLight.intensity = 0;
    }

    // Camera shake
    const base = this.camera.position.clone();
    if (this.shake > 0) {
      this.shake = Math.max(0, this.shake - dt * 7);
      const a = this.calm ? 0 : 0.05 * this.shake;
      this.camera.position.x += (Math.random() - 0.5) * a;
      this.camera.position.y += (Math.random() - 0.5) * a;
    }
    this.renderer.render(this.scene, this.camera);
    this.camera.position.copy(base);
  };

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.scene.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
      const free = (m: THREE.Material) => {
        // textures (model skins, the muzzle-flash picture) hold GPU memory too
        for (const v of Object.values(m)) if (v instanceof THREE.Texture) v.dispose();
        m.dispose();
      };
      if (Array.isArray(mat)) mat.forEach(free);
      else if (mat) free(mat);
    });
    this.flash.material.map?.dispose();
    this.flash.material.dispose();
    this.renderer.dispose();
    // Phones only allow a few 3D canvases at once: give this one back now,
    // so opening and closing the weapon screen many times keeps working.
    this.renderer.forceContextLoss();
    this.renderer.domElement.remove();
  }
}
