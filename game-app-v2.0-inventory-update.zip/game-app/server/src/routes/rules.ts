import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { requireRole } from "../auth/middleware";
import { getRules, RULE_LIMITS, RuleError, updateRules } from "../database/settings";
import { live } from "../realtime";

// Admin: /api/admin/rules — the game rules (HP, case size, voice calls,
// practice firing, drop box). Players never call this: each player screen
// gets the few rules it needs inside its own responses (/api/case,
// /api/play/state).
export function createRulesRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  // limits = the allowed range of each number rule, so the form can show it.
  router.get("/", (_req, res) => {
    res.json({ rules: getRules(db), limits: RULE_LIMITS });
  });

  // Body: any of the rules, e.g. { baseHp: 150, voiceEnabled: false }.
  router.patch("/", (req, res) => {
    try {
      const rules = updateRules(db, req.body);
      // Case size, HP or voice rules can change what every screen shows
      // (e.g. pieces that no longer fit a smaller case went to the tray).
      live.rulesChanged();
      live.allPlayersChanged();
      res.json({ rules, limits: RULE_LIMITS });
    } catch (err) {
      if (err instanceof RuleError) {
        res.status(400).json({ error: err.message });
        return;
      }
      res.status(500).json({ error: "Could not save the rules. Nothing was changed." });
    }
  });

  return router;
}
