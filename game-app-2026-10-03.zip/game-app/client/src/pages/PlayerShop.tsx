import { LevelPips } from "../components/WeaponLevels";
import { useEffect, useState } from "react";
import { useLive } from "../services/live";
import { Badge } from "../components/Badge";
import { Button } from "../components/Button";
import { ErrorBanner } from "../components/ErrorBanner";
import { Icon } from "../components/Icon";
import { ItemImage } from "../components/ItemImage";
import { Notice } from "../components/Notice";
import { Section, SectionAction } from "../components/Section";
import { Stepper } from "../components/Stepper";
import {
  buy,
  getMyInventory,
  getSellQuote,
  getShop,
  heldText,
  InventoryEntry,
  PlayerListing,
  sellItem,
  statText,
  TRACK_LABEL,
  TrackView,
  upgradeWeapon,
} from "../services/api";

type Mode = "buy" | "sell" | "upgrade";

export function PlayerShop({ balance, onBalanceChanged }: { balance: number; onBalanceChanged: () => Promise<void> }) {
  const [open, setOpen] = useState<boolean | null>(null);
  const [listings, setListings] = useState<PlayerListing[]>([]);
  const [bag, setBag] = useState<InventoryEntry[]>([]);
  const [mode, setMode] = useState<Mode>("buy");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function load() {
    setError(null);
    setLoading(true);
    return Promise.all([getShop(), getMyInventory()])
      .then(([s, inv]) => {
        setOpen(s.open);
        setListings(s.listings);
        setBag(inv);
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load the shop."))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, []);
  // Prices, stock, open/closed and what you own update by themselves.
  useLive(["shop:changed", "items:changed", "me:changed"], () => {
    load();
  });

  async function afterChange(message: string) {
    setNotice(message);
    window.scrollTo({ top: 0, behavior: "smooth" });
    await Promise.all([load(), onBalanceChanged()]);
  }

  const refresh = (
    <SectionAction onClick={() => void load()} disabled={loading}>
      <Icon name="refresh" className="h-4 w-4" />
      {loading ? "…" : "Refresh"}
    </SectionAction>
  );

  if (open === null) {
    return error ? <ErrorBanner message={error} /> : <p className="text-ink/60">Loading…</p>;
  }

  if (!open) {
    return (
      <Section title="Shop" tone="alert" action={refresh}>
        <ErrorBanner message={error} />
        <div className="flex flex-col items-center gap-2 py-8 text-center">
          <Icon name="store" className="h-14 w-14 text-alert" />
          <p className="font-display text-3xl font-bold text-alert">Shop closed</p>
          <p className="text-ink/70">The Admin will open the shop during the game. This page updates by itself when it opens.</p>
        </div>
      </Section>
    );
  }

  const sellable = bag.filter((e) => e.sellable && (e.kind !== "ammo" || e.quantity >= (e.ammoPerPack || 1)));
  const weapons = bag.filter((e) => e.kind === "gun" || e.kind === "knife");
  const clear = () => setNotice(null);

  return (
    <>
      <div className="flex items-center justify-between gap-3 border-l-4 border-pine bg-panel px-4 py-3">
        <span className="flex items-center gap-2 font-display text-lg font-bold text-pine">
          <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-pine" aria-hidden />
          Shop open
        </span>
        <button onClick={() => void load()} disabled={loading} className="flex min-h-[2.5rem] items-center gap-1 px-2 font-semibold text-pine">
          <Icon name="refresh" className="h-4 w-4" />
          {loading ? "…" : "Refresh"}
        </button>
      </div>

      <div className="grid grid-cols-3 gap-1 bg-panel p-1" role="tablist" aria-label="Shop">
        {(
          [
            ["buy", "Buy"],
            ["sell", "Sell"],
            ["upgrade", "Upgrade"],
          ] as [Mode, string][]
        ).map(([k, label]) => (
          <button
            key={k}
            role="tab"
            aria-selected={mode === k}
            onClick={() => {
              setMode(k);
              clear();
            }}
            className={`chamfer-sm min-h-[3rem] font-display text-lg font-semibold ${mode === k ? "bg-pine text-pine-ink" : "text-ink/70"}`}
          >
            {label}
          </button>
        ))}
      </div>

      <ErrorBanner message={error} />
      <Notice message={notice} />

      {mode === "buy" && <BuyList listings={listings} balance={balance} onDone={afterChange} onClear={clear} />}

      {mode === "sell" &&
        (sellable.length === 0 ? (
          <Section title="Sell">
            <p className="text-ink/70">You have nothing the shop buys right now. Guns, knives, full ammo packs, herbs and med kits can be sold.</p>
          </Section>
        ) : (
          <Section title="Sell to the shop" flush>
            <ul className="divide-y divide-panel-line">
              {sellable.map((e) => (
                <SellCard key={e.itemId} entry={e} onDone={afterChange} onClear={clear} />
              ))}
            </ul>
          </Section>
        ))}

      {mode === "upgrade" &&
        (weapons.length === 0 ? (
          <Section title="Upgrade">
            <p className="text-ink/70">Buy a gun or a knife first. Then you can upgrade it here, up to level 5.</p>
          </Section>
        ) : (
          weapons.map((w) => <UpgradeCard key={w.itemId} weapon={w} balance={balance} onDone={afterChange} onClear={clear} />)
        ))}
    </>
  );
}

// ---- Buy -------------------------------------------------------------------

function BuyList({
  listings,
  balance,
  onDone,
  onClear,
}: {
  listings: PlayerListing[];
  balance: number;
  onDone: (m: string) => Promise<void>;
  onClear: () => void;
}) {
  if (listings.length === 0) {
    return (
      <Section title="Nothing for sale">
        <p className="text-ink/70">The shop is open but empty right now.</p>
      </Section>
    );
  }
  const groups = new Map<string, PlayerListing[]>();
  for (const l of listings) {
    const k = l.category || "Other";
    groups.set(k, [...(groups.get(k) ?? []), l]);
  }
  return (
    <>
      {[...groups.entries()]
        .sort(([a], [b]) => (a === "Other" ? 1 : b === "Other" ? -1 : a.localeCompare(b)))
        .map(([g, ls]) => (
          <Section key={g} title={g} flush>
            <ul className="divide-y divide-panel-line">
              {ls.map((l) => (
                <ShopCard key={l.id} listing={l} balance={balance} onBought={onDone} onClearNotice={onClear} />
              ))}
            </ul>
          </Section>
        ))}
    </>
  );
}

function ShopCard({
  listing: l,
  balance,
  onBought,
  onClearNotice,
}: {
  listing: PlayerListing;
  balance: number;
  onBought: (message: string) => Promise<void>;
  onClearNotice: () => void;
}) {
  const [qty, setQty] = useState(1);
  const [confirming, setConfirming] = useState(false);
  const [buying, setBuying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Ammo is bought in packs; the carry limit counts rounds.
  const perPack = l.kind === "ammo" && l.ammoPerPack ? l.ammoPerPack : 1;
  const room = l.maxStack !== null ? Math.floor((l.maxStack - l.owned) / perPack) : null;
  const limits = [l.stock, l.maxPerPurchase, room].filter((n): n is number => n !== null);
  const max = limits.length ? Math.min(...limits) : 999;
  const outOfStock = l.stock === 0;
  const full = room !== null && room < 1;
  const total = l.price * qty;
  const tooExpensive = total > balance;
  const canBuy = !outOfStock && !full && max >= 1 && !tooExpensive;
  const unit = perPack > 1 ? (qty === 1 ? "pack" : "packs") : "";

  useEffect(() => {
    if (qty > Math.max(1, max)) setQty(Math.max(1, max));
  }, [max]);

  async function handleBuy() {
    setBuying(true);
    setError(null);
    try {
      const r = await buy({ shopItemId: l.id, quantity: qty, expectedPrice: l.price });
      setConfirming(false);
      setQty(1);
      await onBought(
        perPack > 1
          ? `Bought ${r.quantity} ${r.quantity === 1 ? "pack" : "packs"} of ${r.itemName} (${r.quantity * perPack} rounds) for $${r.total}.`
          : `Bought ${r.quantity} × ${r.itemName} for $${r.total}. It's in your bag.`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to complete purchase. Please try again.");
      setConfirming(false);
    } finally {
      setBuying(false);
    }
  }

  return (
    <li className="flex flex-col gap-3 p-4">
      <div className="flex gap-4">
        <ItemImage url={l.imageUrl} name={l.name} size="lg" />
        <div className="min-w-0 flex-1">
          <p className="font-display text-xl font-bold leading-tight text-ink">{l.name}</p>
          <p className="font-display text-2xl font-bold tabular-nums text-pine">
            {l.price === 0 ? "Free" : `$${l.price}`}
            {perPack > 1 && <span className="ml-1 text-base font-semibold text-ink/55">per pack</span>}
          </p>
          <div className="mt-1 flex flex-wrap gap-1.5">
            {perPack > 1 && <Badge tone="neutral">{perPack} rounds per pack</Badge>}
            {l.stock === null ? null : outOfStock ? (
              <Badge tone="bad">Out of stock</Badge>
            ) : (
              <Badge tone={l.stock <= 3 ? "warn" : "neutral"}>{l.stock} left</Badge>
            )}
            {l.owned > 0 && (
              <Badge tone="good">{perPack > 1 ? `You have ${l.owned} rounds` : `You have ${l.owned}`}</Badge>
            )}
          </div>
        </div>
      </div>
      {l.description && <p className="text-ink/75">{l.description}</p>}

      <ErrorBanner message={error} />

      {outOfStock ? (
        <p className="bg-ink/5 px-4 py-3 text-center font-semibold text-ink/60">Out of stock</p>
      ) : full ? (
        <p className="bg-ink/5 px-4 py-3 text-center font-semibold text-ink/60">
          You're carrying the most allowed ({l.maxStack}
          {perPack > 1 ? " rounds" : ""})
        </p>
      ) : confirming ? (
        <div className="flex flex-col gap-3 border-l-4 border-pine bg-pine-soft p-4">
          <p className="text-lg font-semibold">
            Buy {qty} {unit || "×"} {l.name} for ${total}?
          </p>
          <p className="text-ink/70">You'll have ${balance - total} left.</p>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="ghost" size="md" onClick={() => setConfirming(false)} disabled={buying}>
              Cancel
            </Button>
            <Button size="md" onClick={handleBuy} loading={buying}>
              Confirm
            </Button>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between gap-3">
            <Stepper label={`How many ${perPack > 1 ? "packs of " : ""}${l.name}`} value={qty} onChange={setQty} min={1} max={max} />
            <div className="text-right">
              <p className="text-sm font-semibold text-ink/55">Total</p>
              <p className={`font-display text-2xl font-bold tabular-nums ${tooExpensive ? "text-alert" : "text-ink"}`}>${total}</p>
            </div>
          </div>
          {tooExpensive && <p className="text-sm font-semibold text-alert">You don't have enough money for this.</p>}
          <Button
            disabled={!canBuy}
            onClick={() => {
              onClearNotice();
              setError(null);
              setConfirming(true);
            }}
          >
            Buy
          </Button>
        </>
      )}
    </li>
  );
}

// ---- Sell ------------------------------------------------------------------

// The sell price is never shown up front: the player picks how many, taps
// "Sell…", and only then the shop's offer appears for them to accept.
function SellCard({
  entry: e,
  onDone,
  onClear,
}: {
  entry: InventoryEntry;
  onDone: (m: string) => Promise<void>;
  onClear: () => void;
}) {
  const perPack = e.kind === "ammo" && e.ammoPerPack ? e.ammoPerPack : 1;
  const max = Math.floor(e.quantity / perPack);
  const [qty, setQty] = useState(1);
  const [offer, setOffer] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const unit = perPack > 1 ? (qty === 1 ? "pack of" : "packs of") : "×";

  useEffect(() => {
    if (qty > Math.max(1, max)) setQty(Math.max(1, max));
  }, [max]);

  async function ask() {
    onClear();
    setError(null);
    setBusy(true);
    try {
      setOffer((await getSellQuote(e.itemId, qty)).amount);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't get an offer.");
    } finally {
      setBusy(false);
    }
  }

  async function confirm() {
    if (offer === null) return;
    setBusy(true);
    setError(null);
    try {
      const r = await sellItem({ itemId: e.itemId, quantity: qty, expectedAmount: offer });
      setOffer(null);
      setQty(1);
      await onDone(`Sold ${qty} ${unit} ${r.itemName} for $${r.amount}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to sell right now.");
      setOffer(null);
    } finally {
      setBusy(false);
    }
  }

  const levels = e.upgrades.filter((u) => u.level > 1);

  return (
    <li className="flex flex-col gap-3 p-4">
      <div className="flex items-center gap-4">
        <ItemImage url={e.imageUrl} name={e.name} />
        <div className="min-w-0 flex-1">
          <p className="font-display text-lg font-bold leading-tight">{e.name}</p>
          <p className="text-sm font-semibold text-ink/60">You have {heldText(e.kind, e.quantity, e.ammoPerPack)}</p>
          {levels.length > 0 && (
            <p className="text-sm text-pine">Upgraded: {levels.map((u) => `${TRACK_LABEL[u.track]} Lv ${u.level}`).join(", ")}</p>
          )}
        </div>
      </div>
      <ErrorBanner message={error} />
      {offer !== null ? (
        <div className="flex flex-col gap-3 border-l-4 border-olive bg-olive-soft p-4">
          <p className="text-lg font-semibold">
            The shop offers <span className="font-display text-2xl font-bold text-olive">${offer}</span> for {qty} {unit} {e.name}.
          </p>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="ghost" size="md" onClick={() => setOffer(null)} disabled={busy}>
              No thanks
            </Button>
            <Button size="md" onClick={confirm} loading={busy}>
              Sell
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between gap-3">
          {max > 1 ? <Stepper label={`How many to sell`} value={qty} onChange={setQty} min={1} max={max} /> : <span />}
          <Button variant="ghost" size="md" className="!w-auto px-6" onClick={ask} loading={busy}>
            Sell…
          </Button>
        </div>
      )}
    </li>
  );
}

// ---- Upgrade ---------------------------------------------------------------

function UpgradeCard({
  weapon: w,
  balance,
  onDone,
  onClear,
}: {
  weapon: InventoryEntry;
  balance: number;
  onDone: (m: string) => Promise<void>;
  onClear: () => void;
}) {
  return (
    <Section title={w.name}>
      <div className="flex items-center gap-4">
        <ItemImage url={w.imageUrl} name={w.name} />
        <p className="text-ink/70">Each upgrade goes up to level 5. Every level costs double the one before.</p>
      </div>
      <ul className="flex flex-col gap-3">
        {w.upgrades.map((t) => (
          <TrackRow key={t.track} weapon={w} t={t} balance={balance} onDone={onDone} onClear={onClear} />
        ))}
      </ul>
    </Section>
  );
}

function TrackRow({
  weapon: w,
  t,
  balance,
  onDone,
  onClear,
}: {
  weapon: InventoryEntry;
  t: TrackView;
  balance: number;
  onDone: (m: string) => Promise<void>;
  onClear: () => void;
}) {
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const maxed = t.level >= t.maxLevel;
  const cost = t.nextCost;
  const short = cost !== null && cost > balance;

  async function go() {
    if (cost === null) return;
    setBusy(true);
    setError(null);
    try {
      const r = await upgradeWeapon({ itemId: w.itemId, track: t.track, expectedCost: cost });
      setConfirming(false);
      await onDone(`${r.itemName}: ${TRACK_LABEL[t.track]} is now level ${r.level}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to upgrade right now.");
      setConfirming(false);
    } finally {
      setBusy(false);
    }
  }

  const now = statText(t);
  const next = statText(t, t.nextValue);

  return (
    <li className="flex flex-col gap-2 border border-panel-line bg-panel-raised p-3">
      <div className="flex items-center justify-between gap-3">
        <p className="font-display text-lg font-semibold">{TRACK_LABEL[t.track]}</p>
        <LevelPips level={t.level} max={t.maxLevel} />
      </div>
      <p className="text-ink/70">
        Level {t.level} of {t.maxLevel}
        {now && <> · {now}</>}
        {!maxed && next && <span className="text-pine"> → {next}</span>}
      </p>
      <ErrorBanner message={error} />
      {maxed ? (
        <p className="font-semibold text-olive">Top level reached</p>
      ) : cost === null ? (
        <p className="text-ink/55">Not for sale yet. The Admin hasn't set a price.</p>
      ) : confirming ? (
        <div className="flex flex-col gap-2">
          <p className="font-semibold">
            Upgrade {TRACK_LABEL[t.track].toLowerCase()} to level {t.level + 1} for ${cost}?
          </p>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="ghost" size="md" onClick={() => setConfirming(false)} disabled={busy}>
              Cancel
            </Button>
            <Button size="md" onClick={go} loading={busy}>
              Upgrade
            </Button>
          </div>
        </div>
      ) : (
        <Button
          size="md"
          disabled={short}
          onClick={() => {
            onClear();
            setError(null);
            setConfirming(true);
          }}
        >
          {short ? `Need $${cost}` : `Upgrade · $${cost}`}
        </Button>
      )}
    </li>
  );
}
