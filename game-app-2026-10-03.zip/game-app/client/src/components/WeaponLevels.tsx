import { statText, TRACK_LABEL, TrackView } from "../services/api";

export function LevelPips({ level, max, small = false }: { level: number; max: number; small?: boolean }) {
  return (
    <span className="flex shrink-0 gap-1" aria-label={`Level ${level} of ${max}`}>
      {Array.from({ length: max }, (_, i) => (
        <span
          key={i}
          className={`${small ? "h-2.5 w-3.5" : "h-3 w-5"} ${i < level ? "bg-pine" : "bg-ink/15"}`}
          style={{ clipPath: "polygon(3px 0,100% 0,calc(100% - 3px) 100%,0 100%)" }}
        />
      ))}
    </span>
  );
}

// Compact upgrade summary for a gun or knife: one row per upgrade.
// Meant to sit full width under the item, not squeezed beside the picture.
export function WeaponLevels({ upgrades }: { upgrades: TrackView[] }) {
  if (upgrades.length === 0) return null;
  return (
    <ul className="grid grid-cols-2 gap-2">
      {upgrades.map((t) => {
        const stat = statText(t);
        return (
          <li key={t.track} className="flex flex-col gap-1 border border-panel-line bg-panel-raised px-2.5 py-2 text-sm">
            <span className="flex items-baseline justify-between gap-2">
              <span className="font-semibold text-ink/80">{TRACK_LABEL[t.track]}</span>
              <span className="whitespace-nowrap font-display font-bold text-pine">Lv {t.level}</span>
            </span>
            <LevelPips level={t.level} max={t.maxLevel} small />
            <span className="whitespace-nowrap text-ink/60">{stat ?? "Level only"}</span>
          </li>
        );
      })}
    </ul>
  );
}
