import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { randomBytes } from "crypto";
import fs from "fs";
import path from "path";
import { requireRole } from "../auth/middleware";
import { ITEM_IMAGE_DIR, PACKS_DIR } from "../config";
import { transaction } from "../database/db";
import { MAX_ITEM_QUANTITY } from "../database/inventory";
import {
  createItem,
  findItemById,
  findItemByName,
  GRID_MAX,
  HERB_CODES,
  HerbCode,
  Item,
  ItemKind,
  ITEM_KINDS,
  setItemFile,
  setItemImage,
  UseEffect,
} from "../database/items";

// Item packs that ship with the app (e.g. the free weapon pack). Nothing is
// created automatically: the Admin chooses which items to add, and they
// arrive like any item the Admin made by hand — not in the shop, not given
// to anyone. (One exception: mixing herbs creates the mixed herb from its
// pack entry if the Admin hasn't added it yet, so mixing always works —
// see createItemFromPack.)

export interface PackItem {
  key: string;
  name: string;
  category: string | null;
  description: string | null;
  useEffect: UseEffect;
  picture: string | null; // .png, .jpg, .webp, .gif or .svg in the pack folder
  model: string | null;
  sound: string | null;
  kind?: ItemKind;
  ammoFor?: string; // key of the gun this ammo is for
  ammoPerPack?: number;
  baseMagazine?: number;
  baseSharpness?: number;
  baseLength?: number;
  // 2.0 Inventory Update
  gridW?: number;
  gridH?: number;
  stackSize?: number;
  healAmount?: number;
  maxHpBonus?: number;
  fullHeal?: boolean;
  herbCode?: HerbCode;
  baseReloadMs?: number;
  shakeForce?: number;
  hre?: number;
  expandRows?: number;
}
export interface Pack {
  id: string;
  title: string;
  credits: string;
  items: PackItem[];
}

const SAFE_ID = /^[a-z0-9-]{1,40}$/;

export function readPacks(): Pack[] {
  let dirs: string[] = [];
  try {
    dirs = fs.readdirSync(PACKS_DIR).filter((d) => SAFE_ID.test(d));
  } catch {
    return [];
  }
  const packs: Pack[] = [];
  for (const d of dirs) {
    try {
      const m = JSON.parse(fs.readFileSync(path.join(PACKS_DIR, d, "manifest.json"), "utf8")) as Pack;
      packs.push({ ...m, id: d });
    } catch {
      // not a pack folder
    }
  }
  return packs;
}

// Only plain file names inside the pack folder (never ../ paths).
export function packFile(packId: string, name: string | null): string | null {
  if (!name || path.basename(name) !== name) return null;
  const p = path.join(PACKS_DIR, packId, name);
  return fs.existsSync(p) ? p : null;
}

function copyIn(src: string | null, itemId: number, kind: string): string | null {
  if (!src) return null;
  const file = `item-${itemId}-${kind}-${randomBytes(6).toString("hex")}${path.extname(src).toLowerCase()}`;
  fs.mkdirSync(ITEM_IMAGE_DIR, { recursive: true });
  fs.copyFileSync(src, path.join(ITEM_IMAGE_DIR, file));
  return file;
}

// The first pack entry that matches, e.g. the "Mixed Herb (G+Y)" entry.
export function findPackItem(match: (pi: PackItem) => boolean): { pack: Pack; item: PackItem } | null {
  for (const pack of readPacks()) {
    const item = pack.items.find(match);
    if (item) return { pack, item };
  }
  return null;
}

export function findPackItemByHerbCode(code: HerbCode): { pack: Pack; item: PackItem } | null {
  return findPackItem((pi) => pi.herbCode === code && (pi.kind ?? "other") === "healing");
}

// Creates one catalogue item from a pack entry, pictures/model/sound
// included — exactly what "Add from item pack" does for that item. Runs in
// the caller's transaction if one is open. The caller checks the name isn't
// taken yet. Prices are never pre-filled: the Admin sets every price.
export function createItemFromPack(db: DatabaseSync, pack: Pack, pi: PackItem): Item {
  return transaction(db, () => {
    const effect: UseEffect = pi.useEffect === "shot" || pi.useEffect === "swing" ? pi.useEffect : "none";
    const kind: ItemKind = pi.kind && ITEM_KINDS.includes(pi.kind) ? pi.kind : "other";
    const gunName = pi.ammoFor ? pack.items.find((i) => i.key === pi.ammoFor)?.name : undefined;
    const gun = gunName ? findItemByName(db, gunName) : undefined;
    // A pack file is ours, but a hand-edited manifest shouldn't be able to
    // put nonsense into the database: anything out of range is ignored and
    // the item gets the normal default instead.
    const whole = (v: unknown, min: number, max: number) =>
      typeof v === "number" && Number.isInteger(v) && v >= min && v <= max ? v : undefined;
    const num = (v: unknown) => whole(v, 1, 10_000) ?? null;
    const item = createItem(db, {
      name: pi.name,
      description: pi.description ?? null,
      category: pi.category ?? null,
      maxStack: null,
      useEffect: effect,
      kind,
      ammoForItemId: kind === "ammo" && gun && gun.kind === "gun" ? gun.id : null,
      ammoPerPack: kind === "ammo" ? num(pi.ammoPerPack) : null,
      baseMagazine: kind === "gun" ? num(pi.baseMagazine) : null,
      baseSharpness: kind === "knife" ? num(pi.baseSharpness) : null,
      baseLength: kind === "knife" ? num(pi.baseLength) : null,
      gridW: whole(pi.gridW, 1, GRID_MAX),
      gridH: whole(pi.gridH, 1, GRID_MAX),
      stackSize: whole(pi.stackSize, 1, MAX_ITEM_QUANTITY),
      healAmount: whole(pi.healAmount, 0, 2000),
      maxHpBonus: whole(pi.maxHpBonus, 0, 2000),
      fullHeal: pi.fullHeal === true ? true : undefined,
      herbCode: pi.herbCode && HERB_CODES.includes(pi.herbCode) ? pi.herbCode : undefined,
      baseReloadMs: kind === "gun" ? whole(pi.baseReloadMs, 200, 10_000) : undefined,
      shakeForce: kind === "gun" ? whole(pi.shakeForce, 1, 10) : undefined,
      hre: kind === "gun" && typeof pi.hre === "number" && pi.hre > 0 && pi.hre <= 1000 ? pi.hre : undefined,
      expandRows: kind === "backpack" ? whole(pi.expandRows, 1, 5) : undefined,
    });
    const pic = copyIn(packFile(pack.id, pi.picture), item.id, "pic");
    const model = copyIn(packFile(pack.id, pi.model), item.id, "model");
    const sound = copyIn(packFile(pack.id, pi.sound), item.id, "sound");
    if (pic) setItemImage(db, item.id, pic);
    if (model) setItemFile(db, item.id, "model_file", model);
    if (sound) setItemFile(db, item.id, "sound_file", sound);
    return findItemById(db, item.id)!;
  });
}

export function createPacksRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  router.get("/", (_req, res) => {
    const packs = readPacks().map((p) => ({
      id: p.id,
      title: p.title,
      credits: p.credits,
      items: p.items.map((i) => ({
        key: i.key,
        name: i.name,
        category: i.category,
        kind: i.kind ?? "other",
        useEffect: i.useEffect,
        pictureUrl: i.picture && packFile(p.id, i.picture) ? `/packs/${p.id}/${i.picture}` : null,
        hasModel: Boolean(packFile(p.id, i.model)),
        hasSound: Boolean(packFile(p.id, i.sound)),
        alreadyAdded: Boolean(findItemByName(db, i.name)),
      })),
    }));
    res.json({ packs });
  });

  // Body: { keys: ["pistol", "knife", ...] }
  router.post("/:id/import", (req, res) => {
    const pack = readPacks().find((p) => p.id === req.params.id);
    if (!pack) {
      res.status(404).json({ error: "Pack not found." });
      return;
    }
    const keys = req.body?.keys;
    if (!Array.isArray(keys) || keys.length === 0 || keys.some((k) => typeof k !== "string")) {
      res.status(400).json({ error: "Choose at least one item." });
      return;
    }
    const created = [];
    const skipped: string[] = [];
    // Guns first, ammo last, so ammo can be linked to its gun.
    const chosen = [...new Set(keys as string[])].sort((a, b) => {
      const ka = pack.items.find((i) => i.key === a)?.kind === "ammo" ? 1 : 0;
      const kb = pack.items.find((i) => i.key === b)?.kind === "ammo" ? 1 : 0;
      return ka - kb;
    });
    for (const key of chosen) {
      const pi = pack.items.find((i) => i.key === key);
      if (!pi) continue;
      if (findItemByName(db, pi.name)) {
        skipped.push(pi.name);
        continue;
      }
      try {
        createItemFromPack(db, pack, pi); // its own all-or-nothing step
        created.push(pi.name);
      } catch {
        res.status(500).json({ error: `Could not add ${pi.name}. Please try again.`, created, skipped });
        return;
      }
    }
    res.json({ created, skipped });
  });

  return router;
}
