import { useState } from "react";
import { AppShell, Tab } from "../components/AppShell";
import { PublicUser } from "../services/api";
import { CreatePlayerForm } from "./admin/CreatePlayerForm";
import { ItemForm } from "./admin/ItemForm";
import { ItemsList } from "./admin/ItemsList";
import { PlayerDetails } from "./admin/PlayerDetails";
import { PlayersList } from "./admin/PlayersList";
import { AdminShop } from "./admin/AdminShop";
import { AdminGame } from "./admin/AdminGame";
import { AdminCalculator } from "./admin/AdminCalculator";
import { SettingsPage } from "./Settings";
import { useSettings } from "../audio/settings";
import { useVoiceListener } from "../voice/listener";
import { useVoiceInfo } from "../voice/voiceApi";
import { VoiceIndicator } from "../voice/VoiceIndicator";
import { VoiceSettings } from "../voice/VoiceSettings";

type Section = "game" | "players" | "items" | "shop" | "calc";
type View =
  | { name: "list" }
  | { name: "create" }
  | { name: "details"; id: number };

const TABS: Tab<Section>[] = [
  { key: "game", label: "Game", icon: "flag" },
  { key: "players", label: "Players", icon: "users" },
  { key: "items", label: "Items", icon: "box" },
  { key: "shop", label: "Shop", icon: "store" },
  { key: "calc", label: "Calc", icon: "calculator" },
];

export function AdminHome({
  user,
  onLogout,
}: {
  user: PublicUser;
  onLogout: () => void;
}) {
  const [section, setSection] = useState<Section>("game");
  const [view, setView] = useState<View>({ name: "list" });
  const [settingsOpen, setSettingsOpen] = useState(false);

  // The Admin's phone only listens for hit calls when switched on in Settings.
  const [settings] = useSettings();
  const voiceInfo = useVoiceInfo();
  const voice = useVoiceListener({
    enabled: Boolean(
      voiceInfo?.active && voiceInfo?.enabled && settings.adminListens,
    ),
    playerNumberDigits: voiceInfo?.digits ?? 1,
  });

  function switchSection(s: Section) {
    setSection(s);
    setView({ name: "list" });
    window.scrollTo(0, 0);
  }
  function go(v: View) {
    setView(v);
    window.scrollTo(0, 0);
  }

  const title = TABS.find((t) => t.key === section)!.label;

  return (
    <>
      <AppShell
        title={title}
        subtitle={`Admin · ${user.username}`}
        tabs={TABS}
        active={section}
        onTab={switchSection}
        onLogout={onLogout}
        onSettings={() => setSettingsOpen(true)}
        status={
          <VoiceIndicator
            state={voice.state}
            hideWhenOff
            onClick={() => setSettingsOpen(true)}
          />
        }
      >
        {section === "players" && (
          <>
            {view.name === "list" && (
              <PlayersList
                onCreate={() => go({ name: "create" })}
                onOpen={(id) => go({ name: "details", id })}
              />
            )}
            {view.name === "create" && (
              <CreatePlayerForm
                onCreated={(player) => go({ name: "details", id: player.id })}
                onBack={() => go({ name: "list" })}
              />
            )}
            {view.name === "details" && (
              <PlayerDetails id={view.id} onBack={() => go({ name: "list" })} />
            )}
          </>
        )}

        {section === "items" && (
          <>
            {view.name === "list" && (
              <ItemsList
                onCreate={() => go({ name: "create" })}
                onOpen={(id) => go({ name: "details", id })}
              />
            )}
            {view.name === "create" && (
              <ItemForm
                onSaved={(item) => go({ name: "details", id: item.id })}
                onBack={() => go({ name: "list" })}
              />
            )}
            {view.name === "details" && (
              <ItemForm
                key={view.id}
                id={view.id}
                onSaved={() => {}}
                onBack={() => go({ name: "list" })}
              />
            )}
          </>
        )}

        {section === "shop" && <AdminShop />}
        {section === "game" && <AdminGame />}
        {section === "calc" && <AdminCalculator />}
      </AppShell>
      {settingsOpen && (
        <SettingsPage
          user={user}
          onBack={() => setSettingsOpen(false)}
          onLogout={() => {
            setSettingsOpen(false);
            onLogout();
          }}
          voice={
            <VoiceSettings
              state={voice.state}
              role="admin"
              requestPermission={voice.requestPermission}
              lastHeard={voice.lastHeard}
            />
          }
        />
      )}
    </>
  );
}
