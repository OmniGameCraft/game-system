import { ReactNode, useEffect, useRef, useState } from "react";
import { Avatar } from "../components/Avatar";
import { Button } from "../components/Button";
import { ConfirmCard } from "../components/ConfirmCard";
import { CrosshairLogo } from "../components/Brand";
import { Icon, IconName } from "../components/Icon";
import { Slider } from "../components/Slider";
import { ToggleRow } from "../components/Toggle";
import { toast } from "../components/Toast";
import { unlockAudio } from "../audio/engine";
import { HAPTIC, vibrate } from "../audio/haptics";
import { startMusic } from "../audio/music";
import { resetSettings, useSettings, wakeLockSupported } from "../audio/settings";
import { playSfx } from "../audio/sfx";
import { getAuthStatus, getHealth, PublicUser } from "../services/api";
import { APP_EDITION, APP_NAME, APP_VERSION, COMPANY, COPYRIGHT_YEAR, CREATORS } from "../version";

// Settings: everything this phone can be set up for, plus help and About.
// It covers the whole screen and slides in from the right; Back (or the
// phone's own back gesture) slides it away and returns to exactly where you
// were. All choices are saved on this phone straight away.
export function SettingsPage({
  user,
  onBack,
  onLogout,
  voice,
}: {
  user: PublicUser;
  onBack: () => void;
  onLogout: () => void;
  voice?: React.ReactNode; // the Voice section body, supplied by App wiring
}): JSX.Element {
  const [s, set] = useSettings();
  const [closing, setClosing] = useState(false);
  const [confirmLogout, setConfirmLogout] = useState(false);
  const [openHelp, setOpenHelp] = useState<string | null>(null);
  const [httpsPort, setHttpsPort] = useState(0);
  const isPlayer = user.role === "player";
  const playerNumber: number | null = (user as any).playerNumber ?? null;
  const name = user.displayName || user.username;
  const backRef = useRef(onBack);
  backRef.current = onBack;
  const closingRef = useRef(false);

  function close() {
    if (closingRef.current) return;
    closingRef.current = true;
    playSfx("close");
    setClosing(true);
    setTimeout(() => backRef.current(), s.reduceMotion ? 0 : 190);
  }
  const closeRef = useRef(close);
  closeRef.current = close;

  // Opening: a soft whoosh, and make sure the music is ready to play so the
  // music controls can be heard straight away.
  useEffect(() => {
    playSfx("open");
    startMusic();
  }, []);

  // The phone's back button / back swipe closes Settings instead of leaving
  // the app. We add one history step while Settings is open.
  useEffect(() => {
    try {
      history.pushState({ gsSettings: true }, "");
    } catch {
      // history not available: only the on-screen Back button works
    }
    const onPop = () => {
      // Landed on another Settings step (can happen in development): ignore.
      if ((history.state as any)?.gsSettings) return;
      closeRef.current();
    };
    window.addEventListener("popstate", onPop);
    return () => {
      window.removeEventListener("popstate", onPop);
      // Closed with the on-screen button: remove the step we added.
      try {
        if ((history.state as any)?.gsSettings) history.back();
      } catch {
        // ignore
      }
    };
  }, []);

  // Esc closes on a computer.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Some features need the secure (https) address; find out if there is one.
  useEffect(() => {
    if (window.isSecureContext) return;
    getAuthStatus()
      .then((a) => setHttpsPort(a.httpsPort ?? 0))
      .catch(() => {});
  }, []);
  const secureUrl = httpsPort > 0 ? `https://${location.hostname}:${httpsPort}${location.pathname}` : null;

  function testSound() {
    unlockAudio();
    if (s.masterMute) {
      toast("Everything is muted. Switch off “Mute everything” to hear sound.");
      return;
    }
    if (!s.sfxOn) {
      toast("Sound effects are off. Switch them on to hear the test.");
      return;
    }
    playSfx("upgrade");
    setTimeout(() => playSfx("success"), 520);
    vibrate(HAPTIC.heal);
  }

  const muted = s.masterMute;

  return (
    <div
      className={`fixed inset-0 z-40 overflow-y-auto overscroll-contain bg-paper ${
        closing ? "animate-slide-out-right" : "animate-slide-in-right"
      }`}
      role="dialog"
      aria-modal="true"
      aria-label="Settings"
    >
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(120%_60%_at_50%_-10%,rgba(125,134,145,0.16),transparent_60%)]" aria-hidden />
      <header
        className="sticky top-0 z-10 border-b border-black/80 bg-gradient-to-b from-[#1b1d21]/95 to-[#121316]/95 shadow-[inset_0_-1px_0_rgba(255,255,255,0.05)] backdrop-blur"
        style={{ paddingTop: "env(safe-area-inset-top)" }}
      >
        <div className="mx-auto flex h-14 max-w-2xl items-center gap-3 px-3">
          <button
            onClick={close}
            data-sound="none"
            aria-label="Back"
            className="icon-btn h-10 w-10 shrink-0 text-ink"
          >
            <Icon name="back" className="h-6 w-6" />
          </button>
          <h1 className="min-w-0 flex-1 truncate font-display text-2xl font-bold">Settings</h1>
          <span className="shrink-0 rounded-full border border-panel-line px-2.5 py-0.5 text-xs font-semibold text-ink/50">
            v{APP_VERSION}
          </span>
        </div>
      </header>

      <main
        className="mx-auto flex max-w-2xl flex-col gap-4 px-4 pt-4 stagger"
        style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 2.5rem)" }}
      >
        {/* ---------------- Sound ---------------- */}
        <Group title="Sound" icon="sound">
          <ToggleRow
            label="Mute everything"
            description="Silence all music and sounds on this phone."
            checked={s.masterMute}
            onChange={(v) => set({ masterMute: v })}
            icon={<Icon name={s.masterMute ? "volumeOff" : "volume"} className="h-5 w-5" />}
          />
          <Divider />
          <ToggleRow
            label="Music"
            description="Calm background music."
            checked={s.musicOn}
            onChange={(v) => set({ musicOn: v })}
            disabled={muted}
            icon={<Icon name="music" className="h-5 w-5" />}
          />
          <Indent>
            <Slider
              label="Music volume"
              value={s.musicVolume}
              onChange={(v) => set({ musicVolume: v })}
              format={(v) => `${v}%`}
              disabled={muted || !s.musicOn}
            />
          </Indent>
          <Divider />
          <ToggleRow
            label="Sound effects"
            description="Shots, reloads, healing, buying, hits and alerts."
            checked={s.sfxOn}
            onChange={(v) => set({ sfxOn: v })}
            disabled={muted}
            icon={<Icon name="bolt" className="h-5 w-5" />}
          />
          <Indent>
            <Slider
              label="Effects volume"
              value={s.sfxVolume}
              onChange={(v) => set({ sfxVolume: v })}
              onCommit={() => playSfx("pickup")}
              format={(v) => `${v}%`}
              disabled={muted || !s.sfxOn}
            />
          </Indent>
          <Divider />
          <ToggleRow
            label="Button clicks"
            description="The soft tick when you tap buttons, switches and tabs."
            checked={s.clickOn}
            onChange={(v) => set({ clickOn: v })}
            disabled={muted}
            icon={<TapIcon />}
          />
          <Indent>
            <Slider
              label="Click volume"
              value={s.clickVolume}
              onChange={(v) => set({ clickVolume: v })}
              onCommit={() => playSfx("click")}
              format={(v) => `${v}%`}
              disabled={muted || !s.clickOn}
            />
          </Indent>
          <div className="flex flex-col gap-2 pt-2">
            <Button variant="ghost" size="md" data-sound="none" onClick={testSound}>
              <Icon name="play" className="h-5 w-5 text-pine" />
              Test sound
            </Button>
            <p className="text-center text-sm text-ink/45">
              No sound on an iPhone? Check the silent switch on the side of the phone.
            </p>
          </div>
        </Group>

        {/* ---------------- Controls ---------------- */}
        <Group title="Controls" icon="target">
          <ToggleRow
            label="Vibration"
            description="Buzz on shots, hits, healing and game alerts (Android phones)."
            checked={s.vibration}
            onChange={(v) => {
              set({ vibration: v });
              if (v) setTimeout(() => vibrate(HAPTIC.hit), 50);
            }}
            icon={<VibrateIcon />}
          />
          {isPlayer && (
            <>
              <Divider />
              <div className="flex flex-col gap-1 px-1 py-2">
                <Slider
                  label="Shake sensitivity"
                  value={s.shakeSensitivity}
                  min={0.6}
                  max={1.4}
                  step={0.05}
                  onChange={(v) => set({ shakeSensitivity: v })}
                  format={shakeWord}
                  leftLabel="Needs a harder shake"
                  rightLabel="Lighter shake"
                />
                <p className="text-sm text-ink/50">
                  How hard you shake the phone to fire. Big guns always need more than small ones.
                </p>
              </div>
              <Divider />
              <ToggleRow
                label="Left-handed weapon screen"
                description="Swap the buttons and ammo counter to the other side."
                checked={s.leftHanded}
                onChange={(v) => set({ leftHanded: v })}
                icon={<HandIcon />}
              />
            </>
          )}
          <Divider />
          <ToggleRow
            label="Keep screen on"
            description={
              wakeLockSupported() ? (
                "Stop the phone dimming and locking while the app is open."
              ) : (
                <>
                  Stop the phone dimming while the app is open.{" "}
                  <span className="text-sun">Needs the secure address on this phone.</span>
                </>
              )
            }
            checked={s.keepScreenOn}
            onChange={(v) => set({ keepScreenOn: v })}
            icon={<ScreenIcon />}
          />
          {!wakeLockSupported() && secureUrl && (
            <a
              href={secureUrl}
              className="ml-[3.25rem] w-fit rounded-md border border-pine/30 bg-pine-soft px-3 py-2 text-sm font-semibold text-pine"
            >
              Open the secure address
            </a>
          )}
        </Group>

        {/* ---------------- Voice hits (supplied by the app) ---------------- */}
        {voice && (
          <Group title="Voice hits" icon="mic">
            {voice}
          </Group>
        )}

        {/* ---------------- Display ---------------- */}
        <Group title="Display" icon="grid">
          <ToggleRow
            label="Larger text"
            description="Make all writing in the app bigger."
            checked={s.textSize === "large"}
            onChange={(v) => set({ textSize: v ? "large" : "normal" })}
            icon={<span className="font-display text-base font-bold">Aa</span>}
          />
          <Divider />
          <ToggleRow
            label="Reduce animations"
            description="Screens appear instantly, without sliding or flashing."
            checked={s.reduceMotion}
            onChange={(v) => set({ reduceMotion: v })}
            icon={<MotionIcon />}
          />
        </Group>

        {/* ---------------- Account ---------------- */}
        <Group title="Account" icon="users">
          <div className="flex items-center gap-4 px-1 py-1">
            <Avatar name={name} size="lg" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-display text-2xl font-bold leading-tight">{name}</p>
              <p className="truncate text-ink/55">
                @{user.username} · {isPlayer ? "Player" : "Admin"}
              </p>
            </div>
            {isPlayer && playerNumber != null && (
              <div className="cell flex shrink-0 flex-col items-center rounded-md px-3 py-1.5" aria-label={`Player number ${playerNumber}`}>
                <span className="text-[0.625rem] font-semibold uppercase tracking-[0.2em] text-steel">Player</span>
                <span className="qty-num text-3xl text-pine">{playerNumber}</span>
              </div>
            )}
          </div>
          {isPlayer && playerNumber != null && (
            <p className="rounded-md bg-ink/[0.04] px-3 py-2 text-sm text-ink/60">
              Your call number is <b className="text-ink">{playerNumber}</b>. When you're hit, someone says “
              {numberWords(playerNumber)}, forty” and you lose 40 HP.
            </p>
          )}
          {confirmLogout ? (
            <ConfirmCard
              title="Log out of this phone?"
              body="You can log back in any time with your username and password."
              confirmLabel="Log out"
              onConfirm={onLogout}
              onCancel={() => setConfirmLogout(false)}
            />
          ) : (
            <Button variant="dangerGhost" size="md" onClick={() => setConfirmLogout(true)}>
              <Icon name="logout" className="h-5 w-5" />
              Log out
            </Button>
          )}
        </Group>

        {/* ---------------- Help ---------------- */}
        <Group title="How to play" icon="help">
          <div className="flex flex-col gap-2">
            {HELP.map((h) => (
              <HelpItem
                key={h.id}
                title={h.title}
                icon={h.icon}
                open={openHelp === h.id}
                onToggle={() => setOpenHelp((o) => (o === h.id ? null : h.id))}
              >
                {h.body}
              </HelpItem>
            ))}
          </div>
        </Group>

        {/* ---------------- About ---------------- */}
        <AboutSection />

        <button
          type="button"
          onClick={() => {
            resetSettings();
            playSfx("success");
            toast("Settings are back to their defaults.", "good");
          }}
          className="mx-auto mt-2 min-h-[2.75rem] rounded-md px-4 text-sm font-semibold text-ink/45 underline-offset-4 hover:underline active:text-ink/70"
        >
          Restore default settings
        </button>
      </main>
    </div>
  );
}

// ---------------------------------------------------------------------------
// About

export function AboutSection(): JSX.Element {
  const [server, setServer] = useState<string | null>(null);
  useEffect(() => {
    getHealth()
      .then((h) => setServer(((h as any).version as string | undefined) ?? null))
      .catch(() => {});
  }, []);
  const mismatch = server !== null && server !== APP_VERSION;

  return (
    <section className="case-frame overflow-hidden">
      <div className="case-strip">About</div>
      <div className="flex flex-col items-center gap-4 px-5 pb-6 pt-6 text-center">
        <div className="relative">
          <div className="absolute inset-[-35%] rounded-full bg-pine/15 blur-2xl" aria-hidden />
          <CrosshairLogo className="relative h-16 w-16" />
        </div>
        <div>
          <p className="font-display text-4xl font-bold leading-none text-ink">{APP_NAME}</p>
          <p className="mt-2 inline-flex items-center gap-2 rounded-full border border-pine/35 bg-pine-soft px-3 py-1 text-sm font-semibold text-pine">
            Version {APP_VERSION} · “{APP_EDITION}”
          </p>
        </div>

        <dl className="grid w-full grid-cols-1 gap-2 text-left sm:grid-cols-2">
          <AboutRow label="Company" value={COMPANY} />
          <AboutRow label="Created by" value={CREATORS.join(" and ")} />
        </dl>

        <p className="flex items-center gap-2 text-sm font-semibold text-olive">
          <Icon name="check" className="h-4 w-4" />
          Works offline on your local Wi-Fi
        </p>
        {server && (
          <p className={`text-xs ${mismatch ? "font-semibold text-sun" : "text-ink/40"}`}>
            {mismatch
              ? `The server is on version ${server}. Ask the Admin to update so everything matches.`
              : `Server version ${server}`}
          </p>
        )}

        <div className="w-full border-t border-panel-line pt-4 text-sm leading-relaxed text-ink/50">
          <p>
            3D models and sounds: free CC0 assets by Quaternius, Kenney, Poly Haven and BigSoundBank. Mixed
            herb models, music and sound effects made in code for {APP_NAME}.
          </p>
          <p className="mt-3 font-semibold text-ink/65">
            © {COPYRIGHT_YEAR} {COMPANY}. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
}

function AboutRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="cell rounded-md px-4 py-3">
      <dt className="text-[0.6875rem] font-semibold uppercase tracking-[0.2em] text-steel">{label}</dt>
      <dd className="mt-0.5 font-display text-lg font-semibold text-ink">{value}</dd>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Help topics

const HERB = { G: "#5FBF4A", R: "#E0483E", Y: "#E8C547" } as const;

function Herbs({ code }: { code: string }) {
  return (
    <span className="flex shrink-0 items-center gap-1" aria-label={code.split("").join(" + ")}>
      {code.split("").map((c, i) => (
        <span
          key={i}
          className="h-3.5 w-3.5 rounded-full shadow-[inset_0_-2px_0_rgba(0,0,0,0.3),0_0_0_1px_rgba(0,0,0,0.6)]"
          style={{ background: HERB[c as keyof typeof HERB] }}
        />
      ))}
    </span>
  );
}

const MIXES: { code: string | null; name: string; effect: string }[] = [
  { code: "G", name: "Green Herb", effect: "Heals 30 HP" },
  { code: null, name: "Med Kit", effect: "Heals 40 HP" },
  { code: "GG", name: "Green + Green", effect: "Heals 60 HP" },
  { code: "GY", name: "Green + Yellow", effect: "Heals 45 HP" },
  { code: "GR", name: "Green + Red", effect: "Max HP +20 (and fills it)" },
  { code: "GRY", name: "Green + Red + Yellow", effect: "Heals 50 HP and max HP +15" },
  { code: "GGY", name: "Green + Green + Yellow", effect: "Restores ALL HP" },
];

const P = ({ children }: { children: ReactNode }) => <p className="leading-relaxed text-ink/75">{children}</p>;

const HELP: { id: string; title: string; icon: IconName; body: ReactNode }[] = [
  {
    id: "case",
    title: "Your case",
    icon: "briefcase",
    body: (
      <>
        <P>
          Everything you carry lives in your case, like a real attaché case. Each item takes up space: a pistol is
          3 × 2 squares, a box of ammo 1 square, a rifle a long 6 × 2.
        </P>
        <P>
          <b className="text-ink">Tap</b> an item to see what you can do with it. <b className="text-ink">Drag</b> it
          with your finger to move it: green means it fits, red means it doesn't. Turn it with{" "}
          <b className="text-ink">Rotate</b> (or hold it still while dragging). <b className="text-ink">Arrange</b>{" "}
          packs everything neatly for you.
        </P>
        <P>Need more room? Buy a Backpack Expansion in the Shop: it adds a row to your case.</P>
      </>
    ),
  },
  {
    id: "heal",
    title: "Healing & mixing herbs",
    icon: "heart",
    body: (
      <>
        <ul className="divide-y divide-panel-line overflow-hidden rounded-md border border-panel-line">
          {MIXES.map((m) => (
            <li key={m.name} className="flex items-center gap-3 bg-panel-deep/60 px-3 py-2.5">
              <span className="flex w-14 shrink-0 justify-center">
                {m.code ? (
                  <Herbs code={m.code} />
                ) : (
                  <span className="flex h-3.5 w-3.5 items-center justify-center rounded-sm bg-ink/80 text-[0.625rem] font-black leading-none text-alert">
                    +
                  </span>
                )}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold leading-tight text-ink/85">{m.name}</span>
                <span className="block text-sm font-bold leading-tight text-olive">{m.effect}</span>
              </span>
            </li>
          ))}
        </ul>
        <P>
          <b className="text-ink">Red and Yellow herbs need a Green Herb</b>: they can't be used alone and can't be
          mixed with each other. To mix, tap a herb → <b className="text-ink">Combine</b> → pick the other herb.
        </P>
        <P>Healing works while the game is on: tap the item and press Use (or shake it in the weapon screen).</P>
      </>
    ),
  },
  {
    id: "shoot",
    title: "Shooting & reloading",
    icon: "target",
    body: (
      <>
        <P>
          Tap a gun → <b className="text-ink">Fire</b>. Then <b className="text-ink">tap the screen or shake the
          phone</b> to shoot. Big guns need a harder shake (a shotgun or sniper much more than a pistol); Fire-rate
          upgrades make it lighter.
        </P>
        <P>
          <b className="text-ink">Swipe down</b> on the screen to reload. The ammo moves from your case into the gun,
          which frees space in your case. When the magazine is empty and you still have ammo, it reloads by itself.
        </P>
        <P>Before the game starts you can practise: shots don't use any ammo.</P>
      </>
    ),
  },
  {
    id: "voice",
    title: "Getting hit (voice calls)",
    icon: "mic",
    body: (
      <>
        <P>
          When someone is hit, say <b className="text-ink">the player number, then the damage</b>, near any phone:
          “three, forty” = Player 3 loses 40 HP.
        </P>
        <P>
          With 10 or more players, say the player as two digits: “zero three, forty”. If several phones hear the
          same call, it only counts once.
        </P>
        <P>At 0 HP you're down: everything you carried drops into the drop box. The Admin can bring you back.</P>
      </>
    ),
  },
  {
    id: "drop",
    title: "The drop box",
    icon: "drop",
    body: (
      <>
        <P>
          Tap an item → <b className="text-ink">Drop</b> to put it in the drop box. Anyone can pick it up from Case →
          Drop box (if it fits in their case).
        </P>
        <P>When the game ends, anything nobody picked up goes back to the player it belongs to.</P>
      </>
    ),
  },
];

function HelpItem({
  title,
  icon,
  open,
  onToggle,
  children,
}: {
  title: string;
  icon: IconName;
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
}) {
  return (
    <div className={`overflow-hidden rounded-md border transition-colors ${open ? "border-pine/40 bg-panel-deep/50" : "border-panel-line"}`}>
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="flex min-h-[3.25rem] w-full items-center gap-3 px-3 text-left active:bg-ink/5"
      >
        <Icon name={icon} className={`h-5 w-5 shrink-0 ${open ? "text-pine" : "text-ink/50"}`} />
        <span className="flex-1 font-semibold text-ink">{title}</span>
        <Icon name="chevron" className={`h-5 w-5 shrink-0 text-ink/40 transition-transform duration-200 ${open ? "rotate-90" : ""}`} />
      </button>
      {open && <div className="flex animate-enter flex-col gap-3 px-3 pb-4 pt-1">{children}</div>}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Layout helpers

function Group({ title, icon, children }: { title: string; icon: IconName; children: ReactNode }) {
  return (
    <section className="case-frame overflow-hidden">
      <div className="case-strip !justify-start">
        <Icon name={icon} className="h-4 w-4 text-pine" />
        {title}
      </div>
      <div className="flex flex-col gap-1 px-3 py-3">{children}</div>
    </section>
  );
}

function Divider() {
  return <div className="mx-1 my-1 h-px bg-panel-line/70" aria-hidden />;
}

function Indent({ children }: { children: ReactNode }) {
  return <div className="pb-1 pl-[3.25rem] pr-1">{children}</div>;
}

function shakeWord(v: number): string {
  if (v <= 0.7) return "Hard";
  if (v < 0.95) return "Firm";
  if (v <= 1.05) return "Normal";
  if (v < 1.3) return "Light";
  return "Lightest";
}

const WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];
function numberWords(n: number): string {
  if (n < 10) return WORDS[n] ?? String(n);
  return String(n)
    .split("")
    .map((d) => WORDS[Number(d)])
    .join(" ");
}

// Small icons only this page needs.
function Svg({ children }: { children: ReactNode }) {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      {children}
    </svg>
  );
}
function TapIcon() {
  return (
    <Svg>
      <path d="M9 11V5.5a1.5 1.5 0 0 1 3 0V10l4.2.8a2 2 0 0 1 1.6 2.2l-.6 4.5A3 3 0 0 1 14.2 20H11a3 3 0 0 1-2.4-1.2L6 15.3a1.5 1.5 0 0 1 2.3-1.9L9 14.3" />
      <path d="M5.5 6.5a5 5 0 0 1 9.5-1" />
    </Svg>
  );
}
function VibrateIcon() {
  return (
    <Svg>
      <rect x="8" y="3.5" width="8" height="17" rx="1.6" />
      <path d="M4.5 8v8M2 10v4M19.5 8v8M22 10v4" />
    </Svg>
  );
}
function HandIcon() {
  return (
    <Svg>
      <path d="M8 13V5.5a1.5 1.5 0 0 1 3 0V12M11 11.5V4a1.5 1.5 0 0 1 3 0v7.5M14 11.5V5.5a1.5 1.5 0 0 1 3 0V14a6 6 0 0 1-6 6h-.6a5 5 0 0 1-4.1-2.2L4 14.6a1.5 1.5 0 0 1 2.4-1.8L8 14.5" />
    </Svg>
  );
}
function ScreenIcon() {
  return (
    <Svg>
      <rect x="6.5" y="2.5" width="11" height="19" rx="2" />
      <path d="M12 8.5v1M12 14.5v1M9.5 12h-1M15.5 12h-1" />
      <circle cx="12" cy="12" r="1.6" />
    </Svg>
  );
}
function MotionIcon() {
  return (
    <Svg>
      <path d="M3 12h4M5 8h3M5 16h3" />
      <circle cx="15" cy="12" r="5.5" />
    </Svg>
  );
}
