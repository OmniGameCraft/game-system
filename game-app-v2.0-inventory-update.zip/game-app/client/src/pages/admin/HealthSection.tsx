import { useEffect, useState } from "react";
import { playSfx } from "../../audio/sfx";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls } from "../../components/Field";
import { Icon } from "../../components/Icon";
import { Section } from "../../components/Section";
import { toast } from "../../components/Toast";
import { adminHp, AdminHpAction, getHits, HitEntry, HpView, Player } from "../../services/api";
import { useLive } from "../../services/live";
import { HitRow } from "./hits";
import { HP_CHANGED } from "./liveEvents";
import { hpColor, HpMeter, hpOf } from "./ui";

const QUICK = [10, 20, 30, 40, 50];

// The Admin's HP controls for one player: damage, heal, set HP / max HP and
// revive. Damage normally comes from voice calls; this is for fixing
// mistakes and for referee calls.
export function HealthSection({ player, onChange }: { player: Player; onChange: (hp: HpView) => void }) {
  const hp = hpOf(player);
  const [amount, setAmount] = useState("20");
  const [busy, setBusy] = useState<AdminHpAction | "full" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HitEntry[] | null>(null);
  const name = player.displayName || player.username;

  // This player's recent HP changes, from the same feed as the Game tab.
  const [tick, setTick] = useState(0);
  useLive([HP_CHANGED, "player:changed"], (payload) => {
    if (!payload || payload.playerId === undefined || payload.playerId === player.id) setTick((t) => t + 1);
  });
  useEffect(() => {
    getHits()
      .then((all) => setHistory(all.filter((h) => h.playerId === player.id).slice(0, 15)))
      .catch(() => setHistory([]));
  }, [player.id, tick]);

  if (!hp) {
    return (
      <Section title="Health">
        <p className="text-ink/70">HP isn't available for this player yet. Make sure the server is up to date.</p>
      </Section>
    );
  }

  async function run(action: AdminHpAction | "full", needsAmount: boolean, min: number) {
    setError(null);
    let n: number | undefined;
    if (needsAmount) {
      n = Number(amount);
      if (amount.trim() === "" || !Number.isInteger(n) || n < min || n > 10_000) {
        setError(min === 0 ? "Enter a whole number, 0 or more." : `Enter a whole number of ${min} or more.`);
        return;
      }
    }
    setBusy(action);
    try {
      // "Heal to full" is just "set HP to max HP".
      const next = action === "full" ? await adminHp(player.id, "set", hp!.maxHp) : await adminHp(player.id, action, n);
      if (next) onChange(next);
      const after = next ?? hp!;
      if (action === "damage") {
        playSfx("hit");
        toast(after.dead ? `${name} is down.` : `${name}: −${n} HP`, "bad");
      } else if (action === "heal" || action === "full") {
        playSfx("heal");
        toast(`${name}: now ${after.hp}/${after.maxHp} HP`, "good");
      } else if (action === "revive") {
        playSfx("success");
        toast(`${name} is back in the game.`, "good");
      } else {
        playSfx("success");
        toast(action === "setMax" ? `${name}: max HP is now ${after.maxHp}` : `${name}: HP set to ${after.hp}`, "info");
      }
    } catch (err) {
      playSfx("error");
      setError(err instanceof Error ? err.message : "Could not change HP.");
    } finally {
      setBusy(null);
    }
  }

  const color = hpColor(hp);
  const amountText = amount.trim() || "…";

  return (
    <>
      <Section title="Health" tone={hp.dead ? "alert" : "pine"}>
        <div className="flex items-end justify-between gap-3">
          <p className={`font-display text-5xl font-bold leading-none tabular-nums ${color.text}`}>
            {hp.hp}
            <span className="text-2xl text-ink/45"> / {hp.maxHp}</span>
          </p>
          {hp.dead ? (
            <Badge tone="bad">
              <Icon name="skull" className="mr-1 h-4 w-4" />
              Down
            </Badge>
          ) : (
            <Badge tone="good">Alive</Badge>
          )}
        </div>
        <HpMeter hp={hp} size="lg" />

        {hp.dead && (
          <div className="flex flex-col gap-3 border-l-4 border-alert bg-alert/10 p-3">
            <p className="text-ink/80">
              {name} is down. They can't fire, heal, mix, pick up or buy until you revive them. Their money is safe.
            </p>
            <Button loading={busy === "revive"} disabled={busy !== null} onClick={() => run("revive", false, 0)}>
              <span className="flex items-center justify-center gap-2">
                <Icon name="shield" /> Revive with full HP
              </span>
            </Button>
          </div>
        )}

        <ErrorBanner message={error} />

        <label htmlFor="hp-amount" className="block">
          <span className="mb-1 block text-base font-semibold text-ink/75">Amount (HP)</span>
          <input
            id="hp-amount"
            type="number"
            inputMode="numeric"
            min={0}
            step={1}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className={inputCls}
          />
        </label>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Quick amounts">
          {QUICK.map((q) => (
            <button
              key={q}
              type="button"
              onClick={() => setAmount(String(q))}
              className={`min-h-[2.75rem] min-w-[3.25rem] rounded-sm border-2 px-3 font-display text-lg font-bold tabular-nums ${
                amount === String(q) ? "border-pine bg-pine-soft text-pine" : "border-panel-line bg-panel-raised text-ink/80"
              }`}
            >
              {q}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="danger"
            loading={busy === "damage"}
            disabled={busy !== null || hp.dead}
            onClick={() => run("damage", true, 1)}
          >
            − Damage
          </Button>
          <Button loading={busy === "heal"} disabled={busy !== null || hp.dead} onClick={() => run("heal", true, 1)}>
            + Heal
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Button variant="ghost" size="md" loading={busy === "set"} disabled={busy !== null} onClick={() => run("set", true, 0)}>
            Set HP to {amountText}
          </Button>
          <Button
            variant="ghost"
            size="md"
            loading={busy === "setMax"}
            disabled={busy !== null}
            onClick={() => run("setMax", true, 1)}
          >
            Set max HP to {amountText}
          </Button>
        </div>
        {!hp.dead && hp.hp < hp.maxHp && (
          <Button
            variant="ghost"
            size="md"
            loading={busy === "full"}
            disabled={busy !== null}
            onClick={() => run("full", false, 0)}
          >
            Heal to full ({hp.maxHp})
          </Button>
        )}
        <p className="text-sm text-ink/55">
          Hits normally come from voice calls while the game is running. Setting HP to 0 puts the player down
          {" "}— with “Death drops” on, their items fall into the drop box.
        </p>
      </Section>

      <Section title="HP history" flush>
        {history === null && <p className="p-4 text-ink/60">Loading…</p>}
        {history?.length === 0 && <p className="p-4 text-ink/60">No HP changes yet.</p>}
        {history && history.length > 0 && (
          <ul className="divide-y divide-panel-line">
            {history.map((h) => (
              <HitRow key={h.id} h={h} showPlayer={false} />
            ))}
          </ul>
        )}
      </Section>
    </>
  );
}
