import { DatabaseSync } from "node:sqlite";
import { resolveHp } from "./health";
import { getRules } from "./settings";

export type Role = "admin" | "player";
export type Status = "active" | "disabled";

export interface User {
  id: number;
  role: Role;
  username: string;
  display_name: string | null;
  password_hash: string;
  status: Status;
  active_session_token: string | null;
  balance: number;
  created_at: string;
  player_number: number | null; // players only: the number referees call out (1–99)
  hp: number | null; // NULL = full (see database/health.ts)
  max_hp: number | null; // NULL = the base HP rule
  dead: number; // 1 = at 0 HP until the Admin revives them
}

export interface PublicUser {
  id: number;
  role: Role;
  username: string;
  displayName: string | null;
  status: Status;
  balance: number;
  createdAt: string;
  playerNumber: number | null; // always null for the Admin
  // Players only (left out for the Admin):
  hp?: number;
  maxHp?: number;
  dead?: boolean;
}

// HP depends on the game rules (base HP, cap), so the database is needed.
export function toPublicUser(u: User, db: DatabaseSync): PublicUser {
  return toPublicUsers(db, [u])[0];
}

// Same for a whole list, reading the rules once.
export function toPublicUsers(db: DatabaseSync, users: User[]): PublicUser[] {
  const rules = users.some((u) => u.role === "player") ? getRules(db) : null;
  return users.map((u) => {
    const out: PublicUser = {
      id: u.id,
      role: u.role,
      username: u.username,
      displayName: u.display_name,
      status: u.status,
      balance: u.balance,
      createdAt: u.created_at,
      playerNumber: u.role === "player" ? u.player_number ?? null : null,
    };
    if (u.role === "player" && rules) {
      const hp = resolveHp(u, rules);
      out.hp = hp.hp;
      out.maxHp = hp.maxHp;
      out.dead = hp.dead;
    }
    return out;
  });
}

export function countByRole(db: DatabaseSync, role: Role): number {
  const row = db
    .prepare("SELECT COUNT(*) AS n FROM users WHERE role = ?")
    .get(role) as { n: number };
  return row.n;
}

export function findByUsername(db: DatabaseSync, username: string): User | undefined {
  return db.prepare("SELECT * FROM users WHERE username = ?").get(username) as
    | User
    | undefined;
}

export function findById(db: DatabaseSync, id: number): User | undefined {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(id) as User | undefined;
}

export function listByRole(db: DatabaseSync, role: Role): User[] {
  return db
    .prepare("SELECT * FROM users WHERE role = ? ORDER BY username COLLATE NOCASE")
    .all(role) as unknown as User[];
}

// ---- Player numbers ---------------------------------------------------------

export const PLAYER_NUMBER_MAX = 99;

export function findByPlayerNumber(db: DatabaseSync, playerNumber: number): User | undefined {
  return db.prepare("SELECT * FROM users WHERE player_number = ?").get(playerNumber) as User | undefined;
}

// The lowest number from 1 to 99 nobody has, or null when all 99 are taken.
export function lowestFreePlayerNumber(db: DatabaseSync): number | null {
  const taken = new Set(
    (
      db.prepare("SELECT player_number AS n FROM users WHERE player_number IS NOT NULL").all() as unknown as Array<{
        n: number;
      }>
    ).map((r) => r.n)
  );
  for (let n = 1; n <= PLAYER_NUMBER_MAX; n++) if (!taken.has(n)) return n;
  return null;
}

// A new player gets the lowest free player number straight away. This is
// synchronous, so two players created at the same moment can't get the
// same number (and a unique index would refuse it anyway).
export function createUser(
  db: DatabaseSync,
  input: { role: Role; username: string; displayName?: string | null; passwordHash: string }
): User {
  const playerNumber = input.role === "player" ? lowestFreePlayerNumber(db) : null;
  const result = db
    .prepare(
      "INSERT INTO users (role, username, display_name, password_hash, player_number) VALUES (?, ?, ?, ?, ?)"
    )
    .run(input.role, input.username, input.displayName ?? null, input.passwordHash, playerNumber);
  return findById(db, Number(result.lastInsertRowid))!;
}

// The fields an Admin can change on the player page. Username and player
// number are re-checked for uniqueness by the caller (excluding this row)
// before this runs, same pattern as createUser above.
export function updateUser(
  db: DatabaseSync,
  id: number,
  fields: { username?: string; displayName?: string | null; status?: Status; playerNumber?: number }
): User {
  if (fields.username !== undefined) {
    db.prepare("UPDATE users SET username = ? WHERE id = ?").run(fields.username, id);
  }
  if (fields.displayName !== undefined) {
    db.prepare("UPDATE users SET display_name = ? WHERE id = ?").run(fields.displayName, id);
  }
  if (fields.status !== undefined) {
    db.prepare("UPDATE users SET status = ? WHERE id = ?").run(fields.status, id);
  }
  if (fields.playerNumber !== undefined) {
    db.prepare("UPDATE users SET player_number = ? WHERE id = ?").run(fields.playerNumber, id);
  }
  return findById(db, id)!;
}

export function setPasswordHash(db: DatabaseSync, id: number, passwordHash: string): void {
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(passwordHash, id);
}

// Records which single session token is currently allowed to act as this
// account. Only ever called for Admin accounts — see routes/auth.ts.
export function setActiveSessionToken(db: DatabaseSync, id: number, token: string | null): void {
  db.prepare("UPDATE users SET active_session_token = ? WHERE id = ?").run(token, id);
}
