import { ReactNode, useEffect, useState } from "react";
import { Icon, IconName } from "../components/Icon";
import { playSfx } from "../audio/sfx";
import { useSettings } from "../audio/settings";
import { getAuthStatus } from "../services/api";
import { speechSupported, VoiceState } from "./listener";
import { useVoiceInfo } from "./voiceApi";

// The body of Settings › Voice hits: the on/off switch, what the
// microphone is doing right now and how to fix it, and how to call a hit.

const WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];

// How a player number is said: 3 -> "three" (or "zero three" with 2 digits).
function sayNumber(n: number, digits: number): string {
  return String(n)
    .padStart(digits, "0")
    .split("")
    .map((d) => WORDS[Number(d)])
    .join(" ");
}

type Tone = "good" | "info" | "warn" | "bad" | "off";

const TONE: Record<Tone, { box: string; icon: IconName }> = {
  good: { box: "border-olive text-olive", icon: "mic" },
  info: { box: "border-ink/30 text-ink/80", icon: "info" },
  warn: { box: "border-sun text-sun", icon: "micOff" },
  bad: { box: "border-alert text-alert", icon: "micOff" },
  off: { box: "border-ink/20 text-ink/60", icon: "micOff" },
};

export function VoiceSettings({
  state,
  role,
  requestPermission,
  lastHeard = null,
}: {
  state: VoiceState;
  role: "admin" | "player";
  requestPermission: () => Promise<void>;
  lastHeard?: string | null; // from useVoiceListener, to check what the phone hears
}): JSX.Element {
  const [settings, update] = useSettings();
  const info = useVoiceInfo();
  const on = role === "admin" ? settings.adminListens : settings.listenForHits;
  const secure = window.isSecureContext;
  const supported = speechSupported();
  const [httpsPort, setHttpsPort] = useState(0);
  const [mic, setMic] = useState<PermissionState | null>(null);
  const [asking, setAsking] = useState(false);
  const [askedOnce, setAskedOnce] = useState(false);

  // The secure address, when this page isn't on it.
  useEffect(() => {
    if (secure) return;
    getAuthStatus()
      .then((s) => setHttpsPort(s.httpsPort ?? 0))
      .catch(() => {});
  }, [secure]);

  // Whether the microphone is allowed (where the browser can tell us).
  useEffect(() => {
    let alive = true;
    let status: PermissionStatus | null = null;
    try {
      navigator.permissions
        ?.query({ name: "microphone" as PermissionName })
        .then((s) => {
          if (!alive) return;
          status = s;
          setMic(s.state);
          s.onchange = () => setMic(s.state);
        })
        .catch(() => {});
    } catch {
      // not available: the listener's state tells us instead
    }
    return () => {
      alive = false;
      if (status) status.onchange = null;
    };
  }, []);

  function toggle() {
    playSfx("toggle");
    update(role === "admin" ? { adminListens: !on } : { listenForHits: !on });
  }

  async function allow() {
    setAsking(true);
    try {
      await requestPermission();
    } finally {
      setAsking(false);
      setAskedOnce(true);
    }
  }

  // What's happening, in one line, plus anything that helps fix it.
  let tone: Tone;
  let text: string;
  let help: ReactNode = null;
  const blocked = state === "denied" || mic === "denied";
  if (!on) {
    tone = "off";
    text =
      role === "admin"
        ? "This phone doesn't listen. The players' phones still hear calls."
        : "Off. This phone won't listen for hit calls.";
  } else if (!secure) {
    tone = "warn";
    text = "The microphone only works on the game's secure (https) address.";
    help =
      httpsPort > 0 ? (
        <a
          href={`https://${location.hostname}:${httpsPort}${location.pathname}`}
          className="chamfer-sm flex min-h-[3rem] items-center justify-center gap-2 bg-pine px-4 py-2 font-display text-lg font-semibold text-pine-ink"
        >
          <Icon name="shield" className="h-5 w-5" /> Open the secure address
        </a>
      ) : (
        <p className="text-sm text-ink/70">Ask the Admin for the secure (https) address of the game.</p>
      );
  } else if (!supported) {
    tone = "bad";
    text = "This browser can't recognise speech. Use Chrome on Android or Safari on iPhone.";
  } else if (blocked) {
    tone = "bad";
    text = "The microphone is blocked for this game.";
    help = (
      <ul className="list-disc space-y-1 pl-5 text-sm text-ink/75">
        <li>Tap “Allow microphone” below and choose Allow.</li>
        <li>
          If nothing pops up: tap the lock (or ⓘ) next to the web address, open Permissions / Site settings and allow the
          Microphone.
        </li>
        <li>iPhone: Settings › Safari › Microphone → Allow, and turn on Siri &amp; Dictation.</li>
      </ul>
    );
  } else if (info && !info.enabled) {
    tone = "info";
    text = "The Admin has turned voice hits off for now.";
  } else if (info && !info.active) {
    tone = "info";
    text = "Ready. This phone starts listening when the game starts.";
  } else if (state === "listening" || state === "starting") {
    tone = "good";
    text = "Listening for hit calls.";
  } else if (state === "error") {
    tone = "warn";
    text = "The microphone stopped. Trying again…";
    help = (
      <p className="text-sm text-ink/70">
        If this keeps happening, this phone may need internet for speech recognition, or another app is using the
        microphone.
      </p>
    );
  } else if (state === "unsupported") {
    tone = "bad";
    text = "This phone can't recognise English speech.";
  } else {
    tone = "info";
    text = "Starting the microphone…";
  }

  const showAllow = on && secure && supported && !(mic === "granted" && (state === "listening" || state === "starting"));
  const digits = info?.digits ?? 1;
  const windowSec = Math.round((info?.windowMs ?? 4000) / 1000);
  const examples: [string, string][] =
    digits === 2
      ? [
          ["zero three, forty", "Player 3 loses 40 HP"],
          ["one two, fifteen", "Player 12 loses 15 HP"],
          ["zero seven, one hundred", "Player 7 loses 100 HP"],
        ]
      : [
          ["three, forty", "Player 3 loses 40 HP"],
          ["five, twenty five", "Player 5 loses 25 HP"],
          ["seven, one hundred", "Player 7 loses 100 HP"],
        ];

  return (
    <div className="flex flex-col gap-4">
      <button
        type="button"
        role="switch"
        aria-checked={on}
        data-sound="none"
        onClick={toggle}
        className="flex min-h-[3.5rem] w-full items-center justify-between gap-4 text-left"
      >
        <span className="min-w-0">
          <span className="block text-lg font-semibold text-ink">
            {role === "admin" ? "This phone listens too" : "Listen for hit calls"}
          </span>
          <span className="block text-sm text-ink/60">
            {role === "admin"
              ? "Your phone also hears calls during the game, like a player's phone."
              : "Hear calls like “three, forty” and take the HP off by itself."}
          </span>
        </span>
        <span
          aria-hidden
          className={`relative h-8 w-14 shrink-0 rounded-full border transition-colors duration-150 ${
            on ? "border-pine bg-pine" : "border-panel-line bg-panel-raised"
          }`}
        >
          <span
            className={`absolute top-[3px] h-6 w-6 rounded-full shadow transition-transform duration-150 ${
              on ? "translate-x-[1.6rem] bg-pine-ink" : "translate-x-[3px] bg-ink/70"
            }`}
          />
        </span>
      </button>

      <div className={`flex items-start gap-3 border-l-4 bg-panel-raised px-4 py-3 ${TONE[tone].box}`} role="status">
        <span className="relative mt-0.5 flex shrink-0">
          {tone === "good" && <span className="absolute inset-0 animate-ping rounded-full bg-olive/40" aria-hidden />}
          <Icon name={TONE[tone].icon} className="relative h-5 w-5" />
        </span>
        <p className="font-semibold leading-snug">{text}</p>
      </div>
      {help}

      {showAllow && (
        <button
          type="button"
          onClick={() => void allow()}
          disabled={asking}
          className="flex min-h-[3rem] items-center justify-center gap-2 rounded-sm border-2 border-panel-line bg-panel-raised px-4 py-2 font-display text-lg font-semibold text-ink active:scale-[0.98] disabled:opacity-60"
        >
          <Icon name="mic" className="h-5 w-5" />
          {asking ? "Asking…" : "Allow microphone"}
        </button>
      )}
      {on && secure && supported && askedOnce && mic === "granted" && (
        <p className="flex items-center gap-2 text-sm font-semibold text-olive">
          <Icon name="check" className="h-4 w-4" /> Microphone allowed.
        </p>
      )}

      {lastHeard && on && (
        <p className="text-sm text-ink/70">
          <span className="font-semibold text-ink/85">Last heard:</span> {lastHeard}
        </p>
      )}

      <div className="flex flex-col gap-2 border-l-4 border-pine bg-panel-raised px-4 py-3">
        <p className="flex items-center gap-2 font-display text-lg font-semibold text-ink">
          <Icon name="help" className="h-5 w-5 text-pine" /> How calls work
        </p>
        <p className="text-ink/85">Say the player number, then the damage:</p>
        <ul className="flex flex-col gap-1.5">
          {examples.map(([say, means]) => (
            <li key={say} className="flex flex-wrap items-baseline gap-x-2">
              <span className="font-display text-lg font-bold text-pine">“{say}”</span>
              <span className="text-ink/70">= {means}</span>
            </li>
          ))}
        </ul>
        {digits === 2 && (
          <p className="text-sm text-ink/75">
            Some players have numbers above 9, so every player number is said with two digits: Player 3 is “zero three”.
          </p>
        )}
        {info?.myNumber != null && (
          <p className="text-sm text-ink/85">
            You are <span className="font-bold text-ink">Player {info.myNumber}</span>. Others call you “
            {sayNumber(info.myNumber, digits)}”.
          </p>
        )}
        <p className="text-sm text-ink/70">
          Words or digits both work (“three four zero” too). If several phones hear the same call within {windowSec}{" "}
          seconds, it only counts once. Calls only count while the game is running.
        </p>
      </div>

      <div className="flex flex-col gap-1.5 text-sm text-ink/60">
        <p>
          When this phone can recognise speech by itself, it does, and that works without internet. Some phones need
          internet for speech recognition: on an offline Wi-Fi they can't hear calls, but other phones nearby still will.
        </p>
        <p>Some Android phones beep each time the microphone restarts. That's normal.</p>
      </div>
    </div>
  );
}
