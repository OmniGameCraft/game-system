import { ReactNode } from "react";
import { Icon, IconName } from "./Icon";
import { useLiveStatus } from "../services/live";

export interface Tab<K extends string> {
  key: K;
  label: string;
  icon: IconName;
}

// The frame around every logged-in screen: a coloured top bar with the
// screen's title, and the main tabs — a bottom bar on phones (easy to reach
// with a thumb) and a sidebar on bigger screens.
export function AppShell<K extends string>({
  title,
  subtitle,
  right,
  tabs,
  active,
  onTab,
  onLogout,
  children,
}: {
  title: string;
  subtitle: string;
  right?: ReactNode;
  tabs: Tab<K>[];
  active: K;
  onTab: (k: K) => void;
  onLogout: () => void;
  children: ReactNode;
}) {
  return (
    <div className="min-h-screen md:flex">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col gap-2 border-r-2 border-pine/10 bg-white p-4 md:flex">
        <p className="px-2 pb-4 text-2xl font-extrabold text-pine">Game System</p>
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => onTab(t.key)}
            aria-current={active === t.key ? "page" : undefined}
            className={`flex items-center gap-3 rounded-xl px-3 py-3 text-left text-lg font-bold ${
              active === t.key ? "bg-pine text-white" : "text-pine hover:bg-pine-soft"
            }`}
          >
            <Icon name={t.icon} />
            {t.label}
          </button>
        ))}
        <button
          onClick={onLogout}
          className="mt-auto flex items-center gap-3 rounded-xl px-3 py-3 text-left font-bold text-ink/60 hover:bg-ink/5"
        >
          <Icon name="logout" />
          Log out
        </button>
      </aside>

      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-20 bg-pine text-white shadow">
          <div className="mx-auto flex max-w-2xl items-center justify-between gap-3 px-4 py-3">
            <div className="min-w-0">
              <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-white/70">
                <span className="truncate">{subtitle}</span>
                <LiveDot />
              </p>
              <p className="truncate text-xl font-extrabold leading-tight">{title}</p>
            </div>
            {right}
          </div>
        </header>
        <main className="mx-auto flex max-w-2xl flex-col gap-4 px-4 pb-32 pt-4 md:pb-10">{children}</main>
      </div>

      <nav
        aria-label="Main"
        className="fixed inset-x-0 bottom-0 z-20 border-t-2 border-pine/10 bg-white md:hidden"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="mx-auto grid max-w-2xl" style={{ gridTemplateColumns: `repeat(${tabs.length}, 1fr)` }}>
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => onTab(t.key)}
              aria-current={active === t.key ? "page" : undefined}
              className={`flex flex-col items-center gap-0.5 py-2 text-sm font-bold ${
                active === t.key ? "text-pine" : "text-ink/45"
              }`}
            >
              <span className={`rounded-full px-5 py-1 ${active === t.key ? "bg-pine-soft" : ""}`}>
                <Icon name={t.icon} />
              </span>
              {t.label}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

// Shows whether live updates are flowing. Green = connected; amber =
// trying to reconnect (the app still works, it just won't update by itself).
function LiveDot() {
  const live = useLiveStatus();
  return (
    <span
      className={`inline-flex shrink-0 items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-bold normal-case tracking-normal ${
        live ? "bg-white/15 text-white" : "bg-sun text-ink"
      }`}
      aria-live="polite"
    >
      <span className={`h-1.5 w-1.5 rounded-full ${live ? "bg-emerald-300" : "bg-ink/60"}`} />
      {live ? "Live" : "Reconnecting…"}
    </span>
  );
}
