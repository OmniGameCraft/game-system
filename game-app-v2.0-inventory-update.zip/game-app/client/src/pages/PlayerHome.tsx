import { lazy, Suspense, useEffect, useState } from "react";
import { useLive } from "../services/live";
import { AppShell, Tab } from "../components/AppShell";
import { Button } from "../components/Button";
import { ErrorBanner } from "../components/ErrorBanner";
import { Icon } from "../components/Icon";
import { Section, SectionAction } from "../components/Section";
import { TransactionList } from "../components/TransactionList";
import { TickNumber } from "../components/TickNumber";
import { GAME_STATUS_LABEL, GameStatus, getMyInventory, getMyTransactions, getShop, PlayerGame, PublicUser, Transaction } from "../services/api";
import { GameLayer, useGame } from "../components/GameLayer";
import { formatDateTime } from "../utils/format";
import { PlayerShop } from "./PlayerShop";
import { SettingsPage } from "./Settings";
import { CaseScreen } from "../inventory/CaseScreen";
import type { Piece } from "../inventory/caseApi";
import { HpBar, HpPill, useHp } from "../services/hp";
import { leaveViewer, prepareViewer } from "../viewer/open";
import { duckMusic } from "../audio/music";
import { useSettings } from "../audio/settings";
import { useVoiceListener } from "../voice/listener";
import { useVoiceInfo } from "../voice/voiceApi";
import { VoiceIndicator } from "../voice/VoiceIndicator";
import { VoiceSettings } from "../voice/VoiceSettings";

// three.js is big, so the weapon screen is only downloaded the first time a
// player opens an item — the rest of the app stays quick on phones.
const ItemViewer = lazy(() => import("../viewer/ItemViewer"));

type TabKey = "home" | "shop" | "case";

const TABS: Tab<TabKey>[] = [
  { key: "home", label: "Home", icon: "home" },
  { key: "shop", label: "Shop", icon: "store" },
  { key: "case", label: "Case", icon: "briefcase" },
];

export function PlayerHome({
  user,
  onLogout,
  onRefresh,
}: {
  user: PublicUser;
  onLogout: () => void;
  onRefresh: () => Promise<void>;
}) {
  const [tab, setTab] = useState<TabKey>("home");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [viewing, setViewing] = useState<Piece | null>(null);
  const name = user.displayName || user.username;
  const game = useGame();
  const hp = useHp();

  // Voice hit calls: this phone listens while the game runs, the Admin has
  // voice hits on, and the player hasn't switched it off in Settings. The
  // hook lives here (always mounted) so listening continues on every tab.
  const [settings] = useSettings();
  const voiceInfo = useVoiceInfo();
  const voice = useVoiceListener({
    enabled: Boolean(voiceInfo?.active && voiceInfo?.enabled && settings.listenForHits),
    playerNumberDigits: voiceInfo?.digits ?? 1,
  });

  function switchTab(t: TabKey) {
    setTab(t);
    window.scrollTo(0, 0);
    onRefresh().catch(() => {});
  }

  // Called inside the tap (phones only allow sound, motion and full screen
  // straight from a tap).
  function openWeapon(p: Piece) {
    prepareViewer(p.kind === "gun" ? "shot" : p.useEffect);
    duckMusic(true);
    setViewing(p);
  }
  function closeWeapon() {
    leaveViewer();
    duckMusic(false);
    setViewing(null);
  }

  return (
    <>
      <AppShell
        title={tab === "home" ? `Hi, ${name}` : tab === "shop" ? "Shop" : "Case"}
        subtitle={tab === "home" ? (user.playerNumber ? `Player ${user.playerNumber}` : "Player") : name}
        tabs={TABS}
        active={tab}
        onTab={switchTab}
        onLogout={onLogout}
        onSettings={() => setSettingsOpen(true)}
        status={
          <>
            {hp && <HpPill hp={hp} />}
            <VoiceIndicator state={voice.state} hideWhenOff onClick={() => setSettingsOpen(true)} />
          </>
        }
        right={
          <div className="chamfer-sm flex shrink-0 items-center gap-1.5 bg-pine px-3 py-1.5 text-pine-ink" aria-label="Your money">
            <Icon name="coin" className="h-5 w-5" />
            <span className="font-display text-xl font-bold tabular-nums">
              <TickNumber value={user.balance} format={(n) => `$${n}`} />
            </span>
          </div>
        }
      >
        <GameLayer game={game} userId={user.id} />
        {tab === "home" && <HomeTab user={user} game={game} onRefresh={onRefresh} onGo={switchTab} onLogout={onLogout} />}
        {tab === "shop" && <PlayerShop balance={user.balance} onBalanceChanged={onRefresh} />}
        {tab === "case" && <CaseScreen onOpenWeapon={openWeapon} />}
      </AppShell>

      {viewing && (
        <Suspense
          fallback={
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-paper text-ink/70">Loading…</div>
          }
        >
          <ItemViewer
            item={viewing}
            onClose={closeWeapon}
            renderCase={() => (
              <CaseScreen
                compact
                onOpenWeapon={(p) => {
                  prepareViewer(p.kind === "gun" ? "shot" : p.useEffect);
                  setViewing(p);
                }}
              />
            )}
          />
        </Suspense>
      )}

      {settingsOpen && (
        <SettingsPage
          user={user}
          onBack={() => setSettingsOpen(false)}
          onLogout={() => {
            setSettingsOpen(false);
            onLogout();
          }}
          voice={
            <VoiceSettings
              state={voice.state}
              role="player"
              requestPermission={voice.requestPermission}
              lastHeard={voice.lastHeard}
            />
          }
        />
      )}
    </>
  );
}

const STATUS_STYLE: Record<GameStatus, string> = {
  not_started: "border-ink/30 text-ink/80",
  active: "border-olive text-olive",
  paused: "border-sun text-sun",
  ended: "border-alert text-alert",
};

function HomeTab({
  user,
  game,
  onRefresh,
  onGo,
  onLogout,
}: {
  user: PublicUser;
  game: PlayerGame | null;
  onRefresh: () => Promise<void>;
  onGo: (t: TabKey) => void;
  onLogout: () => void;
}) {
  const hp = useHp();
  const [transactions, setTransactions] = useState<Transaction[] | null>(null);
  const [shopOpen, setShopOpen] = useState<boolean | null>(null);
  const [itemCount, setItemCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function load() {
    setError(null);
    setLoading(true);
    Promise.all([getMyTransactions(), getShop(), getMyInventory(), onRefresh()])
      .then(([tx, shop, inv]) => {
        setTransactions(tx);
        setShopOpen(shop.open);
        setItemCount(inv.reduce((n, e) => n + e.quantity, 0));
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load."))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);
  useLive(["me:changed", "shop:changed"], load);

  return (
    <>
      <ErrorBanner message={error} />

      {game && (
        <div className={`flex items-center justify-between gap-3 border-l-4 bg-panel px-4 py-3 ${STATUS_STYLE[game.status]}`}>
          <span className="text-base font-semibold text-ink/60">Game</span>
          <span className="flex items-center gap-2 font-display text-xl font-bold">
            {game.status === "active" && <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-olive" aria-hidden />}
            {GAME_STATUS_LABEL[game.status]}
          </span>
        </div>
      )}

      {/* Money readout, styled like an ammo counter */}
      <div className="chamfer relative overflow-hidden bg-panel px-5 pb-5 pt-4">
        <div className="absolute inset-y-0 left-0 w-1.5 bg-pine" aria-hidden />
        <p className="text-base font-semibold text-ink/60">Your money</p>
        <p className="font-display text-6xl font-bold leading-none tabular-nums text-pine">
          <TickNumber value={user.balance} format={(n) => `$${n}`} />
        </p>
      </div>

      {/* Who you are for voice hit calls, and your health */}
      <div className="case-frame flex items-center gap-4 px-4 py-4">
        {user.playerNumber != null && (
          <div className="flex shrink-0 flex-col items-center">
            <span className="text-xs font-semibold uppercase tracking-wider text-ink/55">Player</span>
            <span className="font-display text-5xl font-bold leading-none text-ink">{user.playerNumber}</span>
          </div>
        )}
        <div className="min-w-0 flex-1">
          <p className="mb-1.5 text-base font-semibold text-ink/60">Health</p>
          {hp ? <HpBar hp={hp} size="lg" /> : <p className="text-ink/50">…</p>}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => onGo("shop")}
          className={`chamfer flex flex-col items-start gap-1 p-4 text-left ${shopOpen ? "bg-pine-soft" : "bg-panel"}`}
        >
          <Icon name="store" className={`h-8 w-8 ${shopOpen ? "text-pine" : "text-alert"}`} />
          <span className="font-display text-xl font-bold">Shop</span>
          <span className={`text-sm font-semibold ${shopOpen ? "text-pine" : "text-alert"}`}>
            {shopOpen === null ? "…" : shopOpen ? "Open now" : "Closed"}
          </span>
        </button>
        <button onClick={() => onGo("case")} className="chamfer flex flex-col items-start gap-1 bg-panel p-4 text-left">
          <Icon name="briefcase" className="h-8 w-8 text-pine" />
          <span className="font-display text-xl font-bold">Case</span>
          <span className="text-sm font-semibold text-ink/60">
            {itemCount === null ? "…" : itemCount === 1 ? "1 item" : `${itemCount} items`}
          </span>
        </button>
      </div>

      {game && game.announcements.length > 0 && (
        <Section title="Messages" flush>
          <ul className="divide-y divide-panel-line">
            {game.announcements.slice(0, 5).map((a) => (
              <li key={a.id} className="px-4 py-3">
                <p className="text-lg leading-snug">{a.message}</p>
                <p className="text-sm text-ink/50">
                  {a.playerId ? "Only to you, " : ""}
                  {formatDateTime(a.createdAt)}
                </p>
              </li>
            ))}
          </ul>
        </Section>
      )}

      <Section
        title="Money history"
        flush
        action={
          <SectionAction onClick={load} disabled={loading}>
            <Icon name="refresh" className="h-4 w-4" />
            {loading ? "…" : "Refresh"}
          </SectionAction>
        }
      >
        {transactions ? <TransactionList transactions={transactions} /> : <p className="p-4 text-ink/60">Loading…</p>}
      </Section>

      <Button variant="ghost" onClick={onLogout}>
        Log out
      </Button>
    </>
  );
}
