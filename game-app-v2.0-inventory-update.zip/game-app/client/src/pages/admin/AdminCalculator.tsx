import { Fragment, useEffect, useRef, useState } from "react";
import { playSfx } from "../../audio/sfx";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { inputCls } from "../../components/Field";
import { Icon } from "../../components/Icon";
import { ItemImage } from "../../components/ItemImage";
import { Section, SectionAction } from "../../components/Section";
import { Stepper } from "../../components/Stepper";
import { toast } from "../../components/Toast";
import {
  CalculatorConfig,
  Firepower,
  getCalculator,
  Item,
  listItems,
  saveCalculator,
  updateItem,
} from "../../services/api";
import { useLive } from "../../services/live";
import { DROPS_CHANGED } from "./liveEvents";

// The Admin's calculator. Everything is counted in "handgun rounds": one
// pistol round = 1. From each gun's value it works out what to call for a
// hit, how many shots a boss takes, and whether the team has enough ammo.
// Numbers update as you type; changes save when you leave a box (or tap Save).

const LEVELS = [1, 2, 3, 4, 5];
const MAX_LEVEL = 5;

interface BossDraft {
  id: string;
  name: string;
  rounds: string; // handgun rounds he absorbs before he gets stronger
  phases: number;
  scale: string; // ×stronger each phase
}
interface Draft {
  hp: string; // HP per handgun round
  dmg: string; // % per damage level
  bosses: BossDraft[];
}

function toDraft(c: CalculatorConfig): Draft {
  return {
    hp: String(c.hpPerHandgunRound),
    dmg: String(c.damagePerLevel),
    bosses: c.bosses.map((b) => ({
      id: b.id,
      name: b.name,
      rounds: String(b.handgunRounds),
      phases: b.phases,
      scale: String(b.scalePerPhase),
    })),
  };
}

// A number typed in a box, or NaN when it isn't one yet.
function num(text: string): number {
  const t = text.trim();
  if (t === "") return NaN;
  const v = Number(t);
  return Number.isFinite(v) ? v : NaN;
}

// Checks the whole calculator and returns it ready to save, or a friendly error.
function parseDraft(d: Draft): CalculatorConfig | Error {
  const hp = num(d.hp);
  if (!Number.isInteger(hp) || hp < 1 || hp > 1000)
    return new Error(
      "HP per handgun round must be a whole number from 1 to 1000.",
    );
  const dmg = num(d.dmg);
  if (!Number.isFinite(dmg) || dmg < 0 || dmg > 100)
    return new Error("Damage per level must be a percent from 0 to 100.");
  const bosses = [];
  for (const b of d.bosses) {
    const name = b.name.trim();
    if (!name) return new Error("Give every boss a name.");
    if (name.length > 40)
      return new Error(
        `“${name.slice(0, 20)}…”: boss names can be up to 40 letters.`,
      );
    const rounds = num(b.rounds);
    if (!Number.isInteger(rounds) || rounds < 1 || rounds > 1_000_000)
      return new Error(
        `${name}: handgun rounds must be a whole number from 1 to 1,000,000.`,
      );
    const scale = num(b.scale);
    if (!Number.isFinite(scale) || scale < 1 || scale > 10)
      return new Error(
        `${name}: “stronger each phase” must be from ×1 to ×10.`,
      );
    bosses.push({
      id: b.id,
      name,
      handgunRounds: rounds,
      phases: b.phases,
      scalePerPhase: scale,
    });
  }
  return { hpPerHandgunRound: hp, damagePerLevel: dmg, bosses };
}

const sameConfig = (a: CalculatorConfig, b: CalculatorConfig) =>
  JSON.stringify(a) === JSON.stringify(b);

// A value from a box if it's valid, else the fallback (so the tables never go blank).
function pick(
  text: string,
  fallback: number,
  min: number,
  max: number,
): number {
  const v = num(text);
  return Number.isFinite(v) && v >= min && v <= max ? v : fallback;
}

// "12", "4.5", "1,250" — whole numbers stay whole, others get one decimal.
function fmt(v: number): string {
  if (!Number.isFinite(v)) return "—";
  if (Math.abs(v - Math.round(v)) < 0.05) return Math.round(v).toLocaleString();
  return (Math.round(v * 10) / 10).toLocaleString(undefined, {
    maximumFractionDigits: 1,
  });
}

// Shots to take `hp` handgun rounds off with shots worth `power` each.
const shots = (hp: number, power: number) =>
  power > 0 ? Math.max(1, Math.ceil(hp / power - 1e-9)) : NaN;

const parsedHre = (text: string): number | null | Error => {
  if (text.trim() === "") return null;
  const v = num(text);
  if (!Number.isFinite(v) || v <= 0 || v > 1000)
    return new Error("must be a number above 0, like 1, 1.5 or 5");
  return v;
};
// Same value? (Typed "1.50" and stored 1.5 are the same.)
const sameHre = (a: number | null, b: number | null) =>
  a === null || b === null ? a === b : Math.abs(a - b) < 1e-9;

let bossCounter = 0;
const newBossId = () =>
  `boss-${Date.now().toString(36)}-${(bossCounter++).toString(36)}`;

export function AdminCalculator() {
  const [items, setItems] = useState<Item[] | null>(null);
  const [saved, setSaved] = useState<CalculatorConfig | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [hreText, setHreText] = useState<Record<number, string>>({});
  const [firepower, setFirepower] = useState<Firepower | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState(false);
  const [fpLoading, setFpLoading] = useState(false);
  const [removing, setRemoving] = useState<string | null>(null);

  // Saves run one after another and always read the newest values.
  const latest = useRef({ draft, hreText, items, saved });
  latest.current = { draft, hreText, items, saved };
  const queue = useRef<Promise<unknown>>(Promise.resolve());
  const savedTimer = useRef<number | undefined>(undefined);

  useEffect(() => {
    Promise.all([listItems(), getCalculator()])
      .then(([all, calc]) => {
        setItems(all);
        setSaved(calc.config);
        setDraft(toDraft(calc.config));
        setFirepower(calc.firepower);
        const texts: Record<number, string> = {};
        for (const g of all)
          if (g.kind === "gun")
            texts[g.id] = g.hre == null ? "" : String(g.hre);
        setHreText(texts);
      })
      .catch((err) =>
        setLoadError(
          err instanceof Error ? err.message : "Couldn't load the calculator.",
        ),
      );
    return () => window.clearTimeout(savedTimer.current);
  }, []);

  // Team firepower changes whenever someone buys, fires, reloads or drops
  // something; only that part is re-read, so nothing being typed is lost.
  const fpTimer = useRef<number | undefined>(undefined);
  function refreshFirepower(now = false) {
    window.clearTimeout(fpTimer.current);
    fpTimer.current = window.setTimeout(
      () => {
        setFpLoading(true);
        getCalculator()
          .then((c) => c.firepower && setFirepower(c.firepower))
          .catch(() => {})
          .finally(() => setFpLoading(false));
      },
      now ? 0 : 700,
    );
  }
  useEffect(() => () => window.clearTimeout(fpTimer.current), []);
  useLive(["player:changed", "players:changed", DROPS_CHANGED], () =>
    refreshFirepower(),
  );

  // New or edited guns: keep any value being typed, take the rest from the server.
  useLive(
    ["items:changed"],
    () => {
      listItems()
        .then((all) => {
          const old = latest.current.items ?? [];
          setHreText((prev) => {
            const next: Record<number, string> = {};
            for (const g of all) {
              if (g.kind !== "gun") continue;
              const before = old.find((o) => o.id === g.id);
              const typing =
                before &&
                g.id in prev &&
                prev[g.id] !== (before.hre == null ? "" : String(before.hre));
              next[g.id] = typing
                ? prev[g.id]
                : g.hre == null
                  ? ""
                  : String(g.hre);
            }
            return next;
          });
          setItems(all);
        })
        .catch(() => {});
    },
    false,
  );

  function flashSaved() {
    setJustSaved(true);
    window.clearTimeout(savedTimer.current);
    savedTimer.current = window.setTimeout(() => setJustSaved(false), 2200);
  }

  // Saves the boss/basics part if it changed. Returns false on a problem.
  async function doSaveConfig(): Promise<boolean> {
    const { draft: d, saved: s } = latest.current;
    if (!d || !s) return true;
    const cfg = parseDraft(d);
    if (cfg instanceof Error) {
      setSaveError(cfg.message);
      return false;
    }
    if (sameConfig(cfg, s)) return true;
    const r = await saveCalculator(cfg);
    setSaved(r.config);
    latest.current.saved = r.config;
    if (r.firepower) setFirepower(r.firepower);
    return true;
  }

  // Saves one gun's "1 round = X handgun rounds" onto the item itself.
  async function doSaveHre(id: number): Promise<boolean> {
    const { hreText: texts, items: all } = latest.current;
    const item = all?.find((i) => i.id === id);
    if (!item || !(id in texts)) return true;
    const v = parsedHre(texts[id]);
    if (v instanceof Error) {
      setSaveError(`${item.name}: handgun rounds ${v.message}.`);
      return false;
    }
    if (sameHre(v, item.hre)) return true;
    const updated = await updateItem(id, {
      hre: v === null ? null : Math.round(v * 100) / 100,
    });
    setItems((list) =>
      list ? list.map((i) => (i.id === id ? updated : i)) : list,
    );
    latest.current.items = (latest.current.items ?? []).map((i) =>
      i.id === id ? updated : i,
    );
    return true;
  }

  // Puts a save in line behind any running one.
  function enqueue(job: () => Promise<boolean>, loud = false) {
    queue.current = queue.current.then(async () => {
      setSaving(true);
      setSaveError(null);
      try {
        const ok = await job();
        if (ok) {
          flashSaved();
          if (loud) {
            playSfx("success");
            toast("Calculator saved.", "good");
          }
        } else if (loud) playSfx("error");
      } catch (err) {
        setSaveError(
          err instanceof Error
            ? err.message
            : "Couldn't save. Check the Wi-Fi and try again.",
        );
        if (loud) playSfx("error");
      } finally {
        setSaving(false);
      }
    });
  }

  const saveConfigSoon = () => enqueue(doSaveConfig);
  function saveAll() {
    enqueue(async () => {
      for (const id of Object.keys(latest.current.hreText).map(Number))
        if (!(await doSaveHre(id))) return false;
      return doSaveConfig();
    }, true);
  }

  // Changes from buttons (add/remove boss, phases) save straight away.
  function changeAndSave(next: Draft) {
    setDraft(next);
    latest.current.draft = next;
    saveConfigSoon();
  }

  if (loadError) return <ErrorBanner message={loadError} />;
  if (!items || !draft || !saved)
    return <p className="text-ink/60">Loading…</p>;

  // ---- live numbers (bad boxes fall back to the last saved value) ----
  const hpPer = pick(draft.hp, saved.hpPerHandgunRound, 1, 1000);
  const dmgPct = pick(draft.dmg, saved.damagePerLevel, 0, 100);
  const mult = (level: number) => 1 + (dmgPct / 100) * (level - 1);
  const guns = items
    .filter((i) => i.kind === "gun")
    .map((g) => {
      const v = parsedHre(hreText[g.id] ?? "");
      const hre = v instanceof Error ? (g.hre ?? 1) : (v ?? g.hre ?? 1);
      return { item: g, hre, bad: v instanceof Error };
    })
    .sort((a, b) => a.hre - b.hre || a.item.name.localeCompare(b.item.name));

  const bosses = draft.bosses.map((b) => {
    const rounds = pick(b.rounds, 100, 1, 1_000_000);
    const scale = pick(b.scale, 1.5, 1, 10);
    const phaseHp = Array.from(
      { length: b.phases },
      (_, i) => rounds * scale ** i,
    );
    return { draft: b, phaseHp, total: phaseHp.reduce((s, v) => s + v, 0) };
  });

  // Team ammo, valued with the gun values as typed right now.
  const fpRows = guns.map((g) => {
    const row = firepower?.guns.find((r) => r.itemId === g.item.id);
    const rounds = row?.rounds ?? 0;
    return {
      name: g.item.name,
      imageUrl: g.item.imageUrl,
      rounds,
      hre: g.hre,
      handgunRounds: rounds * g.hre,
    };
  });
  // Guns the server counted that aren't in the item list any more.
  for (const r of firepower?.guns ?? []) {
    if (!guns.some((g) => g.item.id === r.itemId) && r.rounds > 0)
      fpRows.push({
        name: r.name || "Other gun",
        imageUrl: null,
        rounds: r.rounds,
        hre: r.rounds ? r.handgunRounds / r.rounds : 1,
        handgunRounds: r.handgunRounds,
      });
  }
  const teamTotal = fpRows.reduce((s, r) => s + r.handgunRounds, 0);

  const parsed = parseDraft(draft);
  const hreDirty = guns.some((g) => {
    const v = parsedHre(hreText[g.item.id] ?? "");
    return v instanceof Error || !sameHre(v, g.item.hre);
  });
  const dirty =
    parsed instanceof Error || !sameConfig(parsed, saved) || hreDirty;

  const setBoss = (id: string, patch: Partial<BossDraft>) =>
    setDraft((d) =>
      d
        ? {
            ...d,
            bosses: d.bosses.map((b) => (b.id === id ? { ...b, ...patch } : b)),
          }
        : d,
    );

  return (
    <>
      <div className="flex items-start gap-3 border-l-4 border-pine bg-panel px-4 py-3">
        <Icon name="calculator" className="mt-0.5 h-7 w-7 shrink-0 text-pine" />
        <p className="text-ink/80">
          Everything here is counted in{" "}
          <b className="text-ink">handgun rounds</b>: one pistol round = 1. Tell
          it how strong each gun is, and it works out what to call for a hit,
          how many shots a boss takes, and whether the team has enough ammo.
        </p>
      </div>

      {/* ---- 1. Basics ---- */}
      <Section title="The basics">
        <InlineNumber
          id="calc-hp"
          before="1 handgun round hit ="
          after="HP"
          value={draft.hp}
          bad={!Number.isFinite(num(draft.hp)) || num(draft.hp) < 1}
          onChange={(v) => setDraft({ ...draft, hp: v })}
          onBlur={saveConfigSoon}
          hint="How much a pistol hit takes off the HP bar. Every voice call number below comes from this."
        />
        <InlineNumber
          id="calc-dmg"
          before="Each damage upgrade adds"
          after="%"
          value={draft.dmg}
          decimal
          bad={
            !Number.isFinite(num(draft.dmg)) ||
            num(draft.dmg) < 0 ||
            num(draft.dmg) > 100
          }
          onChange={(v) => setDraft({ ...draft, dmg: v })}
          onBlur={saveConfigSoon}
          hint={`So a level ${MAX_LEVEL} gun hits ${fmt((mult(MAX_LEVEL) - 1) * 100)}% harder. The shop's Damage upgrade uses this too.`}
        />
      </Section>

      {/* ---- 2. Gun power ---- */}
      <Section title="Gun power">
        <p className="text-ink/70">
          Set how many handgun rounds one round of each gun is worth. The table
          shows its power at each upgrade level and the HP to call when it hits
          someone.
        </p>
        {guns.length === 0 && (
          <p className="border-l-4 border-sun bg-sun/10 px-3 py-2 text-ink/80">
            No guns yet. Add guns in the Items tab (or from the ready-made item
            pack) and they'll show up here.
          </p>
        )}
        <ul className="flex flex-col gap-3">
          {guns.map(({ item: g, hre, bad }) => {
            const call1 = Math.round(hre * hpPer * mult(1));
            return (
              <li
                key={g.id}
                className="flex flex-col gap-3 border border-panel-line bg-panel-raised p-3"
              >
                <div className="flex items-center gap-3">
                  <ItemImage url={g.imageUrl} name={g.name} size="sm" />
                  <p className="min-w-0 flex-1 truncate font-display text-lg font-bold">
                    {g.name}
                  </p>
                </div>
                <label
                  htmlFor={`hre-${g.id}`}
                  className="flex flex-wrap items-center gap-x-3 gap-y-1"
                >
                  <span className="font-semibold text-ink/70">1 round =</span>
                  <input
                    id={`hre-${g.id}`}
                    type="number"
                    inputMode="decimal"
                    min={0}
                    step="any"
                    placeholder="1"
                    value={hreText[g.id] ?? ""}
                    onChange={(e) =>
                      setHreText((t) => ({ ...t, [g.id]: e.target.value }))
                    }
                    onBlur={() => enqueue(() => doSaveHre(g.id))}
                    className={`${inputCls} !w-24 !py-2 text-center ${bad ? "!border-alert" : ""}`}
                  />
                  <span className="font-semibold text-ink/70">
                    handgun rounds
                  </span>
                </label>
                <LevelTable
                  rows={[
                    {
                      label: "Power",
                      values: LEVELS.map((l) => fmt(hre * mult(l))),
                      tone: "text-ink",
                    },
                    {
                      label: "Call (HP)",
                      values: LEVELS.map((l) =>
                        fmt(Math.round(hre * hpPer * mult(l))),
                      ),
                      tone: "text-pine",
                    },
                  ]}
                />
                <p className="text-sm text-ink/60">
                  One hit at level 1 = <b className="text-ink">{call1} HP</b>.
                  For Player 3 you'd call “three, {call1}”.
                </p>
              </li>
            );
          })}
        </ul>
      </Section>

      {/* ---- 3. Bosses ---- */}
      <Section
        title={`Bosses${draft.bosses.length ? ` (${draft.bosses.length})` : ""}`}
        action={
          <SectionAction
            onClick={() =>
              changeAndSave({
                ...draft,
                bosses: [
                  ...draft.bosses,
                  {
                    id: newBossId(),
                    name: `Boss ${draft.bosses.length + 1}`,
                    rounds: "100",
                    phases: 3,
                    scale: "1.5",
                  },
                ],
              })
            }
          >
            <Icon name="plus" className="h-4 w-4" /> Add boss
          </SectionAction>
        }
      >
        <p className="text-ink/70">
          A boss soaks up a number of handgun rounds, then gets stronger for the
          next phase. See how many shots each gun needs.
        </p>
        {bosses.length === 0 && (
          <button
            type="button"
            onClick={() =>
              changeAndSave({
                ...draft,
                bosses: [
                  {
                    id: newBossId(),
                    name: "Boss 1",
                    rounds: "100",
                    phases: 3,
                    scale: "1.5",
                  },
                ],
              })
            }
            className="flex min-h-[4rem] items-center justify-center gap-2 border-2 border-dashed border-panel-line font-display text-lg font-semibold text-pine active:bg-pine-soft"
          >
            <Icon name="plus" /> Add your first boss
          </button>
        )}
        {bosses.map(({ draft: b, phaseHp, total }) => (
          <div
            key={b.id}
            className="flex flex-col gap-3 border border-panel-line bg-panel-raised p-3"
          >
            <div className="flex items-center gap-2">
              <Icon name="skull" className="h-6 w-6 shrink-0 text-alert" />
              <input
                aria-label="Boss name"
                value={b.name}
                maxLength={40}
                onChange={(e) => setBoss(b.id, { name: e.target.value })}
                onBlur={saveConfigSoon}
                className={`${inputCls} !py-2 font-display font-bold ${b.name.trim() ? "" : "!border-alert"}`}
              />
            </div>

            <InlineNumber
              id={`boss-rounds-${b.id}`}
              before="Takes"
              after="handgun rounds, then gets stronger"
              value={b.rounds}
              bad={!Number.isInteger(num(b.rounds)) || num(b.rounds) < 1}
              onChange={(v) => setBoss(b.id, { rounds: v })}
              onBlur={saveConfigSoon}
            />
            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="font-semibold text-ink/70">Phases</span>
              <Stepper
                label={`Phases for ${b.name}`}
                value={b.phases}
                min={1}
                max={5}
                onChange={(p) =>
                  changeAndSave({
                    ...draft,
                    bosses: draft.bosses.map((x) =>
                      x.id === b.id ? { ...x, phases: p } : x,
                    ),
                  })
                }
              />
            </div>
            {b.phases > 1 && (
              <InlineNumber
                id={`boss-scale-${b.id}`}
                before="Gets ×"
                after="stronger each phase"
                value={b.scale}
                decimal
                bad={
                  !Number.isFinite(num(b.scale)) ||
                  num(b.scale) < 1 ||
                  num(b.scale) > 10
                }
                onChange={(v) => setBoss(b.id, { scale: v })}
                onBlur={saveConfigSoon}
              />
            )}

            {/* how much he can take, phase by phase (in handgun rounds) */}
            <div className="flex flex-wrap gap-2">
              {phaseHp.map((v, i) => (
                <span
                  key={i}
                  className="flex min-w-[4.5rem] flex-col rounded-sm border border-panel-line bg-black/30 px-2.5 py-1"
                >
                  <span className="text-xs font-semibold uppercase tracking-wide text-ink/50">
                    Phase {i + 1}
                  </span>
                  <b className="font-display text-lg leading-tight tabular-nums text-ink">
                    {fmt(v)}
                  </b>
                </span>
              ))}
              <span className="flex flex-col rounded-sm border border-pine/50 bg-pine-soft px-2.5 py-1">
                <span className="text-xs font-semibold uppercase tracking-wide text-ink/60">
                  Total
                </span>
                <span className="leading-tight">
                  <b className="font-display text-lg tabular-nums text-pine">
                    {fmt(total)}
                  </b>
                  <span className="text-sm text-ink/55">
                    {" "}
                    handgun rounds · {fmt(total * hpPer)} HP
                  </span>
                </span>
              </span>
            </div>

            {guns.length > 0 && (
              <div className="flex flex-col gap-2">
                <p className="text-sm font-semibold text-ink/60">
                  Shots needed — at level 1 and at level {MAX_LEVEL} damage
                </p>
                {guns.map(({ item: g, hre }) => (
                  <ShotsCard
                    key={g.id}
                    name={g.name}
                    imageUrl={g.imageUrl}
                    phaseHp={phaseHp}
                    power1={hre * mult(1)}
                    powerMax={hre * mult(MAX_LEVEL)}
                  />
                ))}
              </div>
            )}

            {removing === b.id ? (
              <div className="flex flex-col gap-2 border-l-4 border-alert bg-alert/10 p-3">
                <p className="font-semibold">
                  Remove {b.name.trim() || "this boss"}?
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="ghost"
                    size="md"
                    onClick={() => setRemoving(null)}
                  >
                    Keep
                  </Button>
                  <Button
                    variant="danger"
                    size="md"
                    onClick={() => {
                      setRemoving(null);
                      changeAndSave({
                        ...draft,
                        bosses: draft.bosses.filter((x) => x.id !== b.id),
                      });
                    }}
                  >
                    Remove
                  </Button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setRemoving(b.id)}
                className="min-h-[2.75rem] w-fit px-1 text-sm font-bold text-alert"
              >
                Remove boss
              </button>
            )}
          </div>
        ))}
      </Section>

      {/* ---- 4. Team firepower ---- */}
      <Section
        title="Team firepower"
        action={
          <SectionAction
            onClick={() => refreshFirepower(true)}
            disabled={fpLoading}
          >
            <Icon name="refresh" className="h-4 w-4" />
            {fpLoading ? "…" : "Refresh"}
          </SectionAction>
        }
      >
        <p className="text-ink/70">
          All the ammo every player holds right now (in their case and loaded in
          their guns), in handgun rounds. Counted at level 1 damage, so upgrades
          are a bonus. Updates by itself.
        </p>
        {firepower === null && (
          <p className="text-ink/55">Not available yet.</p>
        )}
        {fpRows.length > 0 && (
          <div className="overflow-hidden rounded-sm border border-panel-line">
            {fpRows.map((r) => (
              <div
                key={r.name}
                className="flex items-center gap-3 border-b border-panel-line px-3 py-2 last:border-b-0"
              >
                <ItemImage url={r.imageUrl} name={r.name} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{r.name}</p>
                  <p className="text-sm text-ink/55">
                    {r.rounds.toLocaleString()} rounds × {fmt(r.hre)}
                  </p>
                </div>
                <p className="shrink-0 font-display text-xl font-bold tabular-nums">
                  {fmt(r.handgunRounds)}
                </p>
              </div>
            ))}
            <div className="flex items-center justify-between gap-3 bg-black/30 px-3 py-2.5">
              <p className="font-display font-bold uppercase tracking-wider text-ink/70">
                Team total
              </p>
              <p className="font-display text-2xl font-bold tabular-nums text-pine">
                {fmt(teamTotal)}
              </p>
            </div>
          </div>
        )}
        {bosses.length === 0 ? (
          <p className="text-sm text-ink/55">
            Add a boss above to see if the team has enough ammo for him.
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {bosses.map(({ draft: b, total }) => {
              const enough = teamTotal >= total - 1e-9;
              const pct =
                total > 0 ? Math.min(100, (teamTotal / total) * 100) : 100;
              return (
                <li
                  key={b.id}
                  className={`flex flex-col gap-2 border-l-4 p-3 ${enough ? "border-olive bg-olive-soft" : "border-alert bg-alert/10"}`}
                >
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <p className="font-display text-lg font-bold">
                      {b.name.trim() || "Boss"}
                    </p>
                    <p className="text-sm text-ink/60">needs {fmt(total)}</p>
                  </div>
                  <div className="h-2.5 overflow-hidden rounded-[2px] bg-black/40">
                    <div
                      className={`h-full transition-[width] duration-500 ${enough ? "bg-olive" : "bg-alert"}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <p
                    className={`flex items-center gap-1.5 font-semibold ${enough ? "text-olive" : "text-alert"}`}
                  >
                    <Icon
                      name={enough ? "check" : "close"}
                      className="h-5 w-5"
                    />
                    {enough
                      ? `Enough ammo ✓ (${fmt(teamTotal - total)} spare)`
                      : `Short by ${fmt(Math.ceil(total - teamTotal))} handgun rounds`}
                  </p>
                </li>
              );
            })}
          </ul>
        )}
      </Section>

      {/* ---- 5. Quick converter ---- */}
      <QuickConverter
        guns={guns.map((g) => ({
          id: g.item.id,
          name: g.item.name,
          hre: g.hre,
        }))}
        hpPer={hpPer}
        mult={mult}
      />

      <ErrorBanner message={saveError} />

      {/* Save bar: floats above the tabs while something isn't saved yet
          (and says "saved" for a moment after). */}
      {(dirty || saving || justSaved) && (
        <div
          className={`sticky bottom-[calc(4.75rem+env(safe-area-inset-bottom))] z-10 flex items-center gap-3 border-2 bg-panel px-3 py-2 shadow-lg md:bottom-4 ${
            dirty || saving ? "border-pine" : "border-olive/60"
          }`}
        >
          <p className="min-w-0 flex-1 text-sm font-semibold">
            {saving ? (
              <span className="text-ink/70">Saving…</span>
            ) : dirty ? (
              <span className="text-sun">Not saved yet</span>
            ) : (
              <span className="flex items-center gap-1 text-olive">
                <Icon name="check" className="h-4 w-4" /> All changes saved
              </span>
            )}
          </p>
          <Button
            size="md"
            className="!w-auto px-6"
            disabled={!dirty || saving}
            onClick={saveAll}
          >
            Save
          </Button>
        </div>
      )}
    </>
  );
}

// "1 handgun round hit = [10] HP" — a number box inside a sentence.
function InlineNumber({
  id,
  before,
  after,
  value,
  onChange,
  onBlur,
  hint,
  bad,
  decimal,
}: {
  id: string;
  before: string;
  after: string;
  value: string;
  onChange: (v: string) => void;
  onBlur?: () => void;
  hint?: string;
  bad?: boolean;
  decimal?: boolean;
}) {
  return (
    <label htmlFor={id} className="block">
      <span className="flex flex-wrap items-center gap-x-3 gap-y-1">
        <span className="font-semibold text-ink/75">{before}</span>
        {/* the box and its unit stay together when the line wraps */}
        <span className="flex items-center gap-2">
          <input
            id={id}
            type="number"
            inputMode={decimal ? "decimal" : "numeric"}
            min={0}
            step={decimal ? "any" : 1}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onBlur={onBlur}
            className={`${inputCls} !w-24 !py-2 text-center ${bad ? "!border-alert" : ""}`}
          />
          <span className="font-semibold text-ink/75">{after}</span>
        </span>
      </span>
      {hint && <span className="mt-1 block text-sm text-ink/55">{hint}</span>}
    </label>
  );
}

// A small table with one column per upgrade level.
function LevelTable({
  rows,
}: {
  rows: { label: string; values: string[]; tone?: string }[];
}) {
  return (
    <div className="grid grid-cols-[auto_repeat(5,minmax(0,1fr))] overflow-hidden rounded-sm border border-panel-line text-center text-sm">
      <div className="bg-black/30 px-2 py-1.5 text-left font-semibold text-ink/50">
        Level
      </div>
      {LEVELS.map((l) => (
        <div
          key={l}
          className="bg-black/30 py-1.5 font-display font-bold text-ink/60"
        >
          {l}
        </div>
      ))}
      {rows.map((r) => (
        <Fragment key={r.label}>
          <div className="whitespace-nowrap border-t border-panel-line px-2 py-1.5 text-left font-semibold text-ink/70">
            {r.label}
          </div>
          {r.values.map((v, i) => (
            <div
              key={i}
              className={`border-t border-panel-line py-1.5 font-display font-bold tabular-nums ${r.tone ?? ""}`}
            >
              {v}
            </div>
          ))}
        </Fragment>
      ))}
    </div>
  );
}

// One gun against one boss: shots per phase and in total, at level 1 and max.
function ShotsCard({
  name,
  imageUrl,
  phaseHp,
  power1,
  powerMax,
}: {
  name: string;
  imageUrl: string | null;
  phaseHp: number[];
  power1: number;
  powerMax: number;
}) {
  const row = (power: number) => {
    const per = phaseHp.map((hp) => shots(hp, power));
    return [...per, per.reduce((s, v) => s + v, 0)];
  };
  const r1 = row(power1);
  const rMax = row(powerMax);
  return (
    <div className="flex flex-col gap-1.5 border border-panel-line bg-black/20 p-2">
      <div className="flex items-center gap-2">
        <ItemImage url={imageUrl} name={name} size="sm" />
        <p className="min-w-0 flex-1 truncate font-semibold">{name}</p>
        <p className="shrink-0 text-sm text-ink/60">
          <b className="font-display text-lg text-ink">
            {fmt(r1[r1.length - 1])}
          </b>{" "}
          shots
        </p>
      </div>
      <div
        className="grid overflow-hidden rounded-sm border border-panel-line text-center text-sm"
        style={{
          gridTemplateColumns: `auto repeat(${phaseHp.length + 1}, minmax(0, 1fr))`,
        }}
      >
        <div className="bg-black/30 px-2 py-1 text-left font-semibold text-ink/50">
          Phase
        </div>
        {phaseHp.map((_, i) => (
          <div
            key={i}
            className="bg-black/30 py-1 font-display font-bold text-ink/60"
          >
            {i + 1}
          </div>
        ))}
        <div className="bg-black/30 py-1 font-display font-bold text-pine">
          All
        </div>
        {(
          [
            ["Lv 1", r1],
            [`Lv ${MAX_LEVEL}`, rMax],
          ] as [string, number[]][]
        ).map(([label, vals]) => (
          <Fragment key={label}>
            <div className="whitespace-nowrap border-t border-panel-line px-2 py-1 text-left font-semibold text-ink/70">
              {label}
            </div>
            {vals.map((v, i) => (
              <div
                key={i}
                className={`border-t border-panel-line py-1 font-display font-bold tabular-nums ${i === vals.length - 1 ? "bg-pine-soft text-pine" : ""}`}
              >
                {fmt(v)}
              </div>
            ))}
          </Fragment>
        ))}
      </div>
    </div>
  );
}

// [N] rounds of [gun] at level [L] = [M] handgun rounds = [H] HP.
function QuickConverter({
  guns,
  hpPer,
  mult,
}: {
  guns: { id: number; name: string; hre: number }[];
  hpPer: number;
  mult: (level: number) => number;
}) {
  const [rounds, setRounds] = useState("10");
  const [gunId, setGunId] = useState<number | null>(null);
  const [level, setLevel] = useState(1);
  const gun = guns.find((g) => g.id === gunId) ?? guns[0];
  const n = num(rounds);
  const hr =
    gun && Number.isFinite(n) && n >= 0 ? n * gun.hre * mult(level) : NaN;

  return (
    <Section title="Quick converter">
      {!gun ? (
        <p className="text-ink/60">Add a gun first.</p>
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
            <input
              aria-label="Rounds"
              type="number"
              inputMode="numeric"
              min={0}
              step={1}
              value={rounds}
              onChange={(e) => setRounds(e.target.value)}
              className={`${inputCls} !w-24 !py-2 text-center`}
            />
            <span className="font-semibold text-ink/75">rounds of</span>
            <select
              aria-label="Gun"
              value={gun.id}
              onChange={(e) => setGunId(Number(e.target.value))}
              className={`${inputCls} !w-auto min-w-[9rem] flex-1 !py-2`}
            >
              {guns.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>
          </div>
          <div
            className="flex flex-col gap-1.5"
            role="group"
            aria-label="Damage level"
          >
            <span className="font-semibold text-ink/75">at damage level</span>
            <div className="grid grid-cols-5 gap-2">
              {LEVELS.map((l) => (
                <button
                  key={l}
                  type="button"
                  aria-pressed={level === l}
                  onClick={() => setLevel(l)}
                  className={`h-11 rounded-sm border-2 font-display text-lg font-bold transition-colors ${
                    level === l
                      ? "border-pine bg-pine text-pine-ink"
                      : "border-panel-line bg-panel-raised text-ink/75"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="border border-panel-line bg-black/30 p-3 text-center">
              <p className="font-display text-3xl font-bold tabular-nums text-ink">
                {fmt(hr)}
              </p>
              <p className="text-sm text-ink/60">handgun rounds</p>
            </div>
            <div className="border border-pine/50 bg-pine-soft p-3 text-center">
              <p className="font-display text-3xl font-bold tabular-nums text-pine">
                {fmt(Math.round(hr * hpPer))}
              </p>
              <p className="text-sm text-ink/60">HP of damage</p>
            </div>
          </div>
        </>
      )}
    </Section>
  );
}
