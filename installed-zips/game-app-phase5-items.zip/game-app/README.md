# Game System (offline LAN game manager)

A phone app for running a real-life game. One computer (or an Android phone
running Termux) is the server. Everyone else opens it in their phone's
browser over the same Wi-Fi. No internet is needed while you play.

The database starts empty. Nothing is pre-made: you create the Admin,
players and items yourself.

**Built so far:** login (Admin + Player), player management, money, items and
inventory. **Coming next:** shop, live updates (Socket.IO), game controls.

## Requirements
- Node.js 22.13 or newer
- Internet **once**, for `npm install`. After that it runs fully offline.

## Install and run
```
npm install
npm run build
npm start
```
The server prints two addresses:
```
Local:  http://localhost:3000
LAN:    http://192.168.1.10:3000   <- give this one to players
```
Phones must be on the same Wi-Fi. Different port: `PORT=4000 npm start`
(Windows PowerShell: `$env:PORT=4000; npm start`).

**Updating from an older version:** just replace the code, run
`npm install` and `npm run build`, then `npm start`. Keep the
`server/data` folder. It holds your database and item pictures, and the
server upgrades the database on its own without losing anything.

### Finding the LAN address yourself
- Windows: `ipconfig` (look for "IPv4 Address")
- macOS: `ipconfig getifaddr en0`
- Linux / Termux: `hostname -I` or `ifconfig`

If a phone can't connect, allow Node.js through the computer's firewall
for private networks.

## First-time setup
1. Open the app and tap **Admin**. The first time, you'll see a setup form.
   Create the Admin account there. The form disappears once an Admin exists.
2. **Players tab → + Create Player.** Give each player their username and
   password. Players can't sign themselves up.
3. **Items tab → + Create Item.** Add weapons, ammo, medkits, whatever your
   game uses:
   - **Category** is free text (for example Weapon, Ammo, Medical). Categories
     you've used before are suggested as you type.
   - **Max per player** is optional. Set it to 1 for "one rifle each".
   - **Picture** is optional. It's shrunk on the phone before uploading.
     PNG, JPG, WEBP or GIF, and transparent backgrounds are kept.
   - **Disable item** stops anyone giving it out. Players keep what they
     already have.
4. Open a player to manage them:
   - **Money:** Add or Remove, with full history.
   - **Inventory:** choose an item and a quantity, then **Give**, **Remove**
     or **Set to exactly** (0 takes it away completely). **Item history**
     shows every change.
5. Players log in and see their money on **Home** and their items in **Bag**.
   For now, they tap **Refresh** to see changes. Live updates come in a
   later phase.

## Development (live reload)
Run `npm run dev:server` and `npm run dev:client` in two terminals, then
open `http://<LAN-IP>:5173`.

## Layout
- `client/`: React + TypeScript + Tailwind (Vite)
- `server/`: Express + TypeScript + SQLite (Node's built-in `node:sqlite`)
- `server/data/game.db`: the database
- `server/data/uploads/items/`: item pictures
