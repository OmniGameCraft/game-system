import { ReactNode, useCallback, useEffect, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import { Icon, IconName } from "../components/Icon";
import { toast } from "../components/Toast";
import { playSfx } from "../audio/sfx";
import { vibrate } from "../audio/haptics";
import { duckMusic } from "../audio/music";
import { useSettings } from "../audio/settings";
import { HpBar, HpState, useHp } from "../services/hp";
import { GameStatus, getAuthStatus } from "../services/api";
import { useLive } from "../services/live";
import { listenForShake, MotionState, motionNeedsTap, motionState, requestMotionPermission, whenMotionReady } from "./motion";
import { ItemScene, UseEffect } from "./scene";
import { loadSound, playSound, unlockAudio } from "./sound";
import {
  CaseNow,
  fetchPieceNow,
  FireResult,
  GunNumbers,
  healWith,
  HpNumbers,
  PlayError,
  reloadGun,
  ReloadResult,
  ShotBatcher,
  ShotToken,
} from "./playApi";
import { AmmoCounter, CaseSheet, ReloadRing, RoundButton, StatusCard, UseButton, ViewerStyles } from "./HudParts";

// The weapon screen: one item, full screen.
//   Top left: Back and Case (small round buttons; mirrored for left-handers).
//   Top right: the ammo counter.  Centre: the 3D gun.  Under it: your HP.
// Guns: tap anywhere or shake to fire, swipe down to reload. Knives swing.
// Healing items get a big Use button (or shake to use). Anything else spins.
//
// Shots show instantly on the phone and are sent to the server in small
// batches; the server's answer corrects the counter. When the Admin opens
// the viewer to preview an item (no piece id), nothing is sent anywhere.

export interface ViewerItem {
  name: string;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: "none" | "shot" | "swing";
  modelFlip: boolean;
  modelUpsideDown: boolean;
  // new (all optional so old callers still work):
  id?: number; // piece id (needed to fire/reload/use)
  kind?: string;
  loaded?: number;
  magazine?: number | null;
  reserve?: number;
  gun?: { reloadMs: number; shakeThreshold: number; cooldownMs: number; damagePct: number } | null;
  usable?: boolean;
  healAmount?: number | null;
  maxHpBonus?: number | null;
  fullHeal?: boolean;
  quantity?: number; // units in this piece (shown on healing items)
}

export interface ViewerProps {
  item: ViewerItem;
  onClose: () => void;
  // The case, shown in a sheet over the gun. Gets a closeCase function, so
  // picking the same gun again in the case can simply close the sheet.
  renderCase?: (api: { closeCase: () => void }) => ReactNode;
}

// A different piece = a fresh screen (new 3D model, new counters).
export default function ItemViewer(props: ViewerProps): JSX.Element {
  return <WeaponScreen key={props.item.id ?? `preview:${props.item.name}`} {...props} />;
}

type Screen = "gun" | "knife" | "heal" | "other";

const DEFAULT_GUN: GunNumbers = { reloadMs: 1500, shakeThreshold: 14, cooldownMs: 250, damagePct: 100 };
const SWING_COOLDOWN = 300;
const SPIN_COOLDOWN = 700;
const HEAL_COOLDOWN = 1000;
const BASE_SHAKE = 14; // m/s², for knives and healing items
const SWIPE_MIN_PX = 80;
const SWIPE_MAX_MS = 700;
const AUTO_RELOAD_DELAY = 380;

// The background: dark gunmetal with a faint case-cell grid, lighter in the
// middle where the gun sits.
const BACKGROUND = "radial-gradient(ellipse at 50% 42%, #2b2e33 0%, #17191c 52%, #07080a 100%)";
const GRID =
  "linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px)";

interface Gesture {
  x0: number;
  y0: number;
  t0: number;
  token: ShotToken | null; // the shot this finger fired, until we know it's not a swipe
  practiceShot: boolean;
  moved: boolean; // started moving down: may be a swipe
  swiped: boolean;
}

interface ReloadRun {
  mode: "server" | "practice" | "show"; // show = Admin preview, animation only
  start: number;
  end: number;
  timer: number;
  timerDone: boolean;
  result: ReloadResult | null;
}

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

function useLandscape(): boolean {
  const get = () => window.innerWidth > window.innerHeight;
  const [landscape, setLandscape] = useState(get);
  useEffect(() => {
    const on = () => setLandscape(get());
    window.addEventListener("resize", on);
    window.addEventListener("orientationchange", on);
    return () => {
      window.removeEventListener("resize", on);
      window.removeEventListener("orientationchange", on);
    };
  }, []);
  return landscape;
}

// "Heals 30 HP", "Max HP +20 · Heals 20 HP", "Restores all HP".
function healDetail(item: ViewerItem): string {
  if (item.fullHeal) return "Restores all HP";
  const parts: string[] = [];
  if (item.maxHpBonus) parts.push(`Max HP +${item.maxHpBonus}`);
  if (item.healAmount) parts.push(`Heals ${item.healAmount} HP`);
  return parts.join(" · ") || "Healing";
}

function healMessage(item: ViewerItem, before: HpNumbers | null, after: HpNumbers | null): string {
  if (!before || !after) return `${item.name}: ${healDetail(item)}`;
  const parts: string[] = [];
  const maxUp = after.maxHp - before.maxHp;
  const gained = after.hp - before.hp;
  if (maxUp > 0) parts.push(`Max HP +${maxUp}`);
  if (item.fullHeal && after.hp >= after.maxHp) parts.push("All HP restored");
  else if (gained > 0) parts.push(`+${gained} HP`);
  return `${item.name}: ${parts.join(" · ") || healDetail(item)}`;
}

// Reads useHp() (live HP from the server). Only mounted for a real player:
// the Admin's preview has no HP.
function HpProbe({ onChange }: { onChange: (hp: HpState | null) => void }) {
  const hp = useHp();
  useEffect(() => {
    onChange(hp ? { hp: hp.hp, maxHp: hp.maxHp, dead: hp.dead } : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hp?.hp, hp?.maxHp, hp?.dead]);
  return null;
}

function WeaponScreen({ item, onClose, renderCase }: ViewerProps) {
  const pieceId = typeof item.id === "number" ? item.id : null;
  const live = pieceId !== null; // a piece from the player's own case
  const effect: UseEffect = item.kind === "gun" ? "shot" : item.kind === "knife" ? "swing" : item.useEffect;
  const healLike =
    Boolean(item.usable) || (!live && item.kind === "healing" && Boolean(item.healAmount || item.maxHpBonus || item.fullHeal));
  const screen: Screen = effect === "shot" ? "gun" : effect === "swing" ? "knife" : healLike ? "heal" : "other";
  const gunLive = live && screen === "gun" && item.kind === "gun"; // fire/reload go to the server
  const healLive = live && screen === "heal";

  const [settings] = useSettings();
  const calm = settings.reduceMotion;
  const sensitivity = clamp(settings.shakeSensitivity || 1, 0.6, 1.4);
  const leftHanded = settings.leftHanded;
  const landscape = useLandscape();

  // ---- state from the server ----
  const [status, setStatus] = useState<GameStatus | null>(null);
  const [practiceFire, setPracticeFire] = useState(true);
  const [serverBlock, setServerBlock] = useState<string | null>(null); // a 409 message
  const [gunNums, setGunNums] = useState<GunNumbers>(item.gun ?? DEFAULT_GUN);
  const [quantity, setQuantity] = useState<number | null>(typeof item.quantity === "number" ? item.quantity : null);
  const [hookHp, setHookHp] = useState<HpState | null>(null);
  const [snapHp, setSnapHp] = useState<HpNumbers | null>(null);
  const [hpOverride, setHpOverride] = useState<HpNumbers | null>(null); // straight from a heal answer
  const hp: HpState | null = hpOverride ?? hookHp ?? snapHp;
  const practice = gunLive && status === "not_started" && practiceFire;

  // ---- ammo (refs: changed many times a second, re-rendered on demand) ----
  const ammo = useRef({
    loaded: item.loaded ?? 0, // the server's last word
    reserve: item.reserve ?? 0,
    magazine: (item.magazine ?? null) as number | null,
    practiceLoaded: null as number | null, // practice magazine, while practising
  });
  const batcherRef = useRef<ShotBatcher | null>(null);
  const [, setTick] = useState(0);
  const rerender = useCallback(() => setTick((t) => (t + 1) % 1_000_000), []);

  // ---- screen state ----
  const [modelState, setModelState] = useState<"loading" | "ready" | "none" | "error">(item.modelUrl ? "loading" : "none");
  const [stageRatio, setStageRatio] = useState<number | null>(null); // portrait stage height / width
  const [reload, setReload] = useState<{ start: number; end: number } | null>(null);
  const [caseOpen, setCaseOpen] = useState(false);
  const [healBusy, setHealBusy] = useState(false);
  const [closing, setClosing] = useState(false);
  const [shotFlash, setShotFlash] = useState(0);
  const [noAmmo, setNoAmmo] = useState(0); // >0 while the "No ammo" flash shows (key)
  const [healGlow, setHealGlow] = useState(0);
  const [hurtFlash, setHurtFlash] = useState(0);
  const [nudge, setNudge] = useState(0);
  const [shots, setShots] = useState(0); // preview only: shots fired
  const [motion, setMotion] = useState<MotionState | null>(motionState());
  const [httpsPort, setHttpsPort] = useState(0);

  // ---- refs ----
  const stageRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<ItemScene | null>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const img2dReload = useRef<Animation | null>(null);
  const soundRef = useRef<AudioBuffer | null>(null);
  const mountedRef = useRef(false);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const caseOpenRef = useRef(false);
  caseOpenRef.current = caseOpen;
  const closingRef = useRef(false);
  const healBusyRef = useRef(false);
  const hpRef = useRef<HpState | null>(hp);
  hpRef.current = hp;
  const reloadRef = useRef<ReloadRun | null>(null);
  const gestures = useRef(new Map<number, Gesture>());
  const lastUse = useRef(0);
  const lastHeal = useRef(0);
  const opSeq = useRef(0); // bumps on every fire/reload answer, to spot stale refreshes
  const dirty = useRef(false); // a refresh arrived mid-action: refresh again when idle
  const timers = useRef({ auto: 0, refresh: 0, noAmmo: 0, close: 0 });
  const lastOfflineToast = useRef(0);

  // ---- derived ----
  const a = ammo.current;
  const practiceCap = (): number => a.magazine ?? Math.max(a.loaded, 12);
  const loadedNow = (): number => {
    if (practice) return a.practiceLoaded ?? practiceCap();
    return Math.max(0, a.loaded - (batcherRef.current?.unconfirmed ?? 0));
  };
  const shownLoaded = loadedNow();

  // Why the main action can't happen right now (big card over the gun).
  let block: { icon: IconName; title: string; text: string; tone: "red" | "amber" | "grey" } | null = null;
  if (live && screen !== "other") {
    if (hp?.dead) block = { icon: "skull", title: "You're down", text: "Wait for the Admin to revive you.", tone: "red" };
    else if (status === "paused")
      block = { icon: "pause", title: "Game paused", text: "Hold your position until the Admin resumes.", tone: "amber" };
    else if (status === "ended") block = { icon: "flag", title: "Game over", text: "Weapons down. Thanks for playing!", tone: "grey" };
    else if (gunLive && status === "not_started" && !practiceFire)
      block = { icon: "flag", title: "Not started yet", text: "You can fire once the Admin starts the game.", tone: "grey" };
    else if (gunLive && serverBlock) block = { icon: "info", title: "Can't fire right now", text: serverBlock, tone: "amber" };
  }

  // Healing: why "Use" is greyed out, if it is.
  let healWhy: string | null = null;
  if (healLive) {
    if (hp?.dead) healWhy = "You're down — you can't heal now.";
    else if (status === "not_started") healWhy = "Healing works once the game starts.";
    else if (status === "paused") healWhy = "The game is paused.";
    else if (status === "ended") healWhy = "The game is over.";
    else if (hp && hp.hp >= hp.maxHp && !item.maxHpBonus) healWhy = "You're already at full health.";
  }

  // =====================================================================
  // Actions
  // =====================================================================

  function refresh() {
    if (!live || timers.current.refresh) return;
    timers.current.refresh = window.setTimeout(() => {
      timers.current.refresh = 0;
      const seq = opSeq.current;
      fetchPieceNow(pieceId!)
        .then((s) => {
          if (mountedRef.current) act.current.applyNow(s, seq);
        })
        .catch(() => {
          // offline for a moment: the next notice or action tries again
        });
    }, 150);
  }

  function applyNow(s: CaseNow, seq: number) {
    setStatus(s.status);
    setPracticeFire(s.practiceFire);
    setServerBlock(null);
    if (s.hp) setSnapHp(s.hp);
    if (!s.piece) {
      pieceGone();
      return;
    }
    if (s.piece.gun) setGunNums(s.piece.gun);
    setQuantity(s.piece.quantity);
    const b = batcherRef.current;
    if (opSeq.current === seq && !reloadRef.current && (!b || b.idle)) {
      a.loaded = s.piece.loaded;
      a.reserve = s.piece.reserve;
      a.magazine = s.piece.magazine;
      dirty.current = false;
      rerender();
    } else {
      dirty.current = true; // shots or a reload are on the way; look again after
    }
  }

  // The piece left the case (dropped from the case sheet, used up, fell to
  // the drop box…): nothing to hold any more.
  function pieceGone() {
    if (healBusyRef.current || closingRef.current) return;
    if (hpRef.current?.dead) return; // the "You're down" card explains it
    closingRef.current = true;
    toast(`${item.name} is no longer in your case.`, "info");
    onCloseRef.current();
  }

  function close() {
    if (closingRef.current) return;
    closingRef.current = true;
    setClosing(true);
    onCloseRef.current();
  }

  function openCase() {
    if (!renderCase) return;
    playSfx("open");
    setCaseOpen(true);
  }

  function closeCase() {
    if (!caseOpenRef.current) return;
    playSfx("close");
    setCaseOpen(false);
    refresh(); // something may have changed in there (reloaded, dropped…)
  }

  function offlineToast() {
    const now = Date.now();
    if (now - lastOfflineToast.current < 5000) return;
    lastOfflineToast.current = now;
    toast("Can't reach the game server. Check the Wi-Fi.", "bad");
  }

  function showNoAmmo() {
    setNoAmmo((k) => k + 1);
    window.clearTimeout(timers.current.noAmmo);
    timers.current.noAmmo = window.setTimeout(() => setNoAmmo(0), 950);
  }

  function blocked(): boolean {
    if (!block) return false;
    setNudge((n) => n + 1);
    vibrate(20);
    return true;
  }

  // 2D picture fallback: the same moves as the 3D model, with CSS.
  function animate2D(kind: "shot" | "swing" | "spin") {
    const el = imgRef.current;
    if (!el || calm || reloadRef.current) return;
    try {
      if (kind === "shot")
        el.animate(
          [
            { transform: "translateX(0) rotate(0)" },
            { transform: "translateX(-18px) rotate(-9deg)", offset: 0.2 },
            { transform: "translateX(0) rotate(0)" },
          ],
          { duration: 220, easing: "ease-out" }
        );
      else if (kind === "swing")
        el.animate(
          [{ transform: "rotate(0)" }, { transform: "rotate(55deg) translateX(20px)", offset: 0.4 }, { transform: "rotate(0)" }],
          { duration: 320, easing: "ease-in-out" }
        );
      else el.animate([{ transform: "rotateY(0)" }, { transform: "rotateY(360deg)" }], { duration: 700, easing: "ease-out" });
    } catch {
      // very old browser: no animation, everything else still works
    }
  }

  function reload2D(ms: number) {
    const el = imgRef.current;
    const stage = stageRef.current;
    if (!el || !stage) return;
    const down = `translateY(${stage.clientHeight}px) rotate(-10deg)`;
    try {
      img2dReload.current?.cancel();
      img2dReload.current = el.animate(
        [
          { transform: "translateY(0) rotate(0)", easing: "cubic-bezier(.55,0,1,.45)" },
          { transform: down, offset: 0.36 },
          { transform: down, offset: 0.58, easing: "cubic-bezier(0,.55,.45,1)" },
          { transform: "translateY(0) rotate(0)" },
        ],
        { duration: ms }
      );
    } catch {
      // no animation support: the ring still shows the reload
    }
  }

  // ---- Fire / swing / spin ----
  function primary(src: "tap" | "shake" | "key", g?: Gesture) {
    if (caseOpenRef.current || closingRef.current) return;
    if (screen === "heal") {
      if (src === "shake") void healNow("shake");
      else {
        sceneRef.current?.trigger(); // a tap just turns it around
        animate2D("spin");
      }
      return;
    }
    if (block) {
      if (src !== "shake") blocked();
      return;
    }
    if (reloadRef.current) return; // hands busy
    const now = performance.now();
    const cooldown = screen === "gun" ? gunNums.cooldownMs : screen === "knife" ? SWING_COOLDOWN : SPIN_COOLDOWN;
    if (now - lastUse.current < cooldown) return;

    if (gunLive && loadedNow() <= 0) {
      lastUse.current = now;
      outOfAmmo();
      return;
    }
    lastUse.current = now;

    // Instant feedback.
    if (soundRef.current) playSound(soundRef.current);
    sceneRef.current?.trigger();
    animate2D(screen === "gun" ? "shot" : screen === "knife" ? "swing" : "spin");
    if (screen === "gun") {
      if (!calm) setShotFlash((k) => k + 1);
      vibrate(40);
    } else if (screen === "knife") vibrate(15);

    if (gunLive) {
      if (practice) a.practiceLoaded = Math.max(0, (a.practiceLoaded ?? 0) - 1);
      // A tap's shot waits a moment in case the finger is starting a swipe.
      const token = batcherRef.current?.add({ hold: src === "tap" && Boolean(g) }) ?? null;
      if (g) {
        g.token = token;
        g.practiceShot = practice;
      }
      if (loadedNow() === 0) scheduleAutoReload();
      rerender();
    } else if (screen === "gun") {
      setShots((n) => n + 1);
    }
  }

  function outOfAmmo() {
    if (practice || a.reserve > 0) {
      requestReload("auto");
      return;
    }
    playSfx("dryfire");
    vibrate(12);
    showNoAmmo();
  }

  // Is a finger in the middle of what may become a swipe down?
  function swipeInProgress(): boolean {
    const now = performance.now();
    for (const g of gestures.current.values()) if (g.moved && !g.swiped && now - g.t0 < SWIPE_MAX_MS) return true;
    return false;
  }

  // Empty magazine with spare rounds: reload by itself, unless a swipe is
  // already doing it.
  function scheduleAutoReload() {
    window.clearTimeout(timers.current.auto);
    timers.current.auto = window.setTimeout(() => act.current.autoReloadCheck(), AUTO_RELOAD_DELAY);
  }

  function autoReloadCheck() {
    timers.current.auto = 0;
    if (!mountedRef.current || reloadRef.current || caseOpenRef.current || loadedNow() > 0) return;
    if (swipeInProgress()) {
      timers.current.auto = window.setTimeout(() => act.current.autoReloadCheck(), 200);
      return;
    }
    if (practice || a.reserve > 0) requestReload("auto");
  }

  // ---- Reload ----
  function requestReload(_why: "swipe" | "auto" | "button" | "key") {
    if (screen !== "gun" || caseOpenRef.current || closingRef.current || reloadRef.current) return;
    if (blocked()) return;
    if (!gunLive) {
      beginReload(gunNums.reloadMs, "show"); // the Admin's preview: animation only
      return;
    }
    if (practice) {
      if (loadedNow() >= practiceCap()) return magazineFull();
      beginReload(gunNums.reloadMs, "practice");
      return;
    }
    if (a.magazine !== null && loadedNow() >= a.magazine) return magazineFull();
    if (a.reserve <= 0) {
      playSfx("dryfire");
      showNoAmmo();
      toast("No spare ammo for this gun.", "bad");
      return;
    }
    beginReload(gunNums.reloadMs, "server");
  }

  function magazineFull() {
    vibrate(10);
    toast("The magazine is already full.", "info");
  }

  function beginReload(ms: number, mode: ReloadRun["mode"]) {
    const start = performance.now();
    const run: ReloadRun = { mode, start, end: start + ms, timer: 0, timerDone: false, result: null };
    reloadRef.current = run;
    setReload({ start, end: run.end });
    window.clearTimeout(timers.current.auto);
    playSfx("reload");
    vibrate(20);
    sceneRef.current?.reload(ms);
    reload2D(ms);
    run.timer = window.setTimeout(() => {
      run.timerDone = true;
      act.current.finishReload(run);
    }, ms);
    if (mode !== "server") return;

    void (async () => {
      try {
        // Send every shot first, so the server reloads from the right count.
        await batcherRef.current?.drain();
        if (reloadRef.current !== run) return;
        const res = await reloadGun(pieceId!);
        opSeq.current++;
        if (reloadRef.current !== run || !mountedRef.current) return;
        run.result = res;
        if (res.reloadMs && Math.abs(res.reloadMs - (run.end - run.start)) > 60) act.current.retimeReload(run, res.reloadMs);
        act.current.finishReload(run);
      } catch (err) {
        if (reloadRef.current !== run || !mountedRef.current) return;
        act.current.failReload(run, err);
      }
    })();
  }

  // The server's reload time differs from what we guessed: follow it.
  function retimeReload(run: ReloadRun, ms: number) {
    run.end = run.start + ms;
    if (!run.timerDone) {
      window.clearTimeout(run.timer);
      run.timer = window.setTimeout(() => {
        run.timerDone = true;
        act.current.finishReload(run);
      }, Math.max(0, run.end - performance.now()));
    }
    setReload({ start: run.start, end: run.end });
    sceneRef.current?.reload(ms);
    try {
      img2dReload.current?.effect?.updateTiming({ duration: ms });
    } catch {
      // fine: the picture just finishes a little early or late
    }
  }

  // Done when the animation has finished AND the server has answered.
  function finishReload(run: ReloadRun) {
    if (reloadRef.current !== run || !run.timerDone) return;
    if (run.mode === "server" && !run.result) return; // still waiting for the server
    reloadRef.current = null;
    setReload(null);
    if (run.result) {
      if (run.result.loaded !== null) a.loaded = run.result.loaded;
      if (run.result.reserve !== null) a.reserve = run.result.reserve;
    }
    if (run.mode === "practice") a.practiceLoaded = practiceCap();
    playSfx("click");
    vibrate(25);
    rerender();
    if (dirty.current) refresh();
  }

  function failReload(run: ReloadRun, err: unknown) {
    window.clearTimeout(run.timer);
    reloadRef.current = null;
    setReload(null);
    sceneRef.current?.cancelReload();
    img2dReload.current?.cancel();
    playSfx("error");
    if (err instanceof PlayError && err.status === 409) setServerBlock(err.message);
    else toast(err instanceof Error ? err.message : "Couldn't reload. Try again.", "bad");
    refresh();
    rerender();
  }

  // ---- Server answers to shots ----
  function onFireResult(r: FireResult) {
    opSeq.current++;
    if (r.loaded !== null) a.loaded = r.loaded;
    if (r.reserve !== null) a.reserve = r.reserve;
    if (r.practice && status !== "not_started") {
      setStatus("not_started");
      setPracticeFire(true);
    } else if (!r.practice && status === "not_started") {
      setStatus("active"); // the game started while practising: real rounds now
    }
    if (serverBlock) setServerBlock(null);
    rerender();
    if (loadedNow() === 0 && !reloadRef.current) scheduleAutoReload();
  }

  function onFireError(err: unknown) {
    opSeq.current++;
    if (err instanceof PlayError && err.status === 409) {
      setServerBlock(err.message);
      playSfx("error");
    } else if (err instanceof PlayError && err.status >= 400 && err.status < 500) {
      if (err.status !== 404) toast(err.message, "bad");
    } else {
      offlineToast();
    }
    refresh();
    rerender();
  }

  function onBatchChange() {
    rerender();
    const b = batcherRef.current;
    if (dirty.current && b?.idle && !reloadRef.current) refresh();
  }

  // ---- Healing ----
  async function healNow(src: "button" | "shake" | "key") {
    if (caseOpenRef.current || closingRef.current || healBusyRef.current) return;
    const now = performance.now();
    if (now - lastHeal.current < HEAL_COOLDOWN) return;
    lastHeal.current = now;
    if (!healLive) {
      // The Admin's preview: show what a player sees.
      playSfx("heal");
      vibrate([15, 50, 15]);
      setHealGlow((k) => k + 1);
      sceneRef.current?.trigger();
      toast(`${item.name}: ${healDetail(item)}`, "good");
      return;
    }
    if (healWhy) {
      vibrate(20);
      if (src === "shake") return; // a shake while it can't be used: just a buzz
      playSfx("error");
      toast(healWhy, "bad");
      return;
    }
    healBusyRef.current = true;
    setHealBusy(true);
    const before = hpRef.current;
    try {
      const res = await healWith(pieceId!);
      if (!mountedRef.current) return;
      // The heal sound and buzz come from the shared HP store when the new
      // HP arrives, so they aren't played twice here.
      setHealGlow((k) => k + 1);
      sceneRef.current?.trigger();
      animate2D("spin");
      let after = res.hp;
      let remaining = res.remaining;
      if (remaining === null || !after) {
        const fresh = await fetchPieceNow(pieceId!).catch(() => null);
        if (fresh) {
          if (remaining === null) remaining = fresh.piece ? fresh.piece.quantity : 0;
          if (!after) after = fresh.hp;
        }
      }
      if (!mountedRef.current) return;
      if (after) setHpOverride(after);
      const msg = healMessage(item, before, after);
      if (remaining === 0) {
        // That was the last one: let the glow play, then go back.
        closingRef.current = true;
        setClosing(true);
        toast(`${msg} — that was your last one.`, "good");
        timers.current.close = window.setTimeout(() => onCloseRef.current(), 1100);
      } else {
        toast(msg, "good");
        if (remaining !== null) setQuantity(remaining);
      }
    } catch (err) {
      if (!mountedRef.current) return;
      playSfx("error");
      vibrate(30);
      toast(err instanceof Error ? err.message : "Couldn't use it. Try again.", "bad");
      refresh();
    } finally {
      healBusyRef.current = false;
      if (mountedRef.current) setHealBusy(false);
    }
  }

  // Long-lived listeners (shake, keys, timers, the batcher) always call the
  // newest version of these, so they never act on old state.
  const act = useRef({
    primary,
    requestReload,
    healNow,
    refresh,
    applyNow,
    finishReload,
    failReload,
    retimeReload,
    autoReloadCheck,
    onFireResult,
    onFireError,
    onBatchChange,
    close,
    closeCase,
  });
  act.current = {
    primary,
    requestReload,
    healNow,
    refresh,
    applyNow,
    finishReload,
    failReload,
    retimeReload,
    autoReloadCheck,
    onFireResult,
    onFireError,
    onBatchChange,
    close,
    closeCase,
  };

  // =====================================================================
  // Effects
  // =====================================================================

  // Mounted flag + clean-up of every timer.
  useEffect(() => {
    mountedRef.current = true;
    const t = timers.current;
    return () => {
      mountedRef.current = false;
      window.clearTimeout(t.auto);
      window.clearTimeout(t.refresh);
      window.clearTimeout(t.noAmmo);
      window.clearTimeout(t.close);
      t.refresh = 0;
      if (reloadRef.current) window.clearTimeout(reloadRef.current.timer);
      reloadRef.current = null;
    };
  }, []);

  // Music steps back while the gun is out.
  useEffect(() => {
    duckMusic(true);
    return () => duckMusic(false);
  }, []);

  // Fresh numbers from the server when the screen opens, and whenever
  // something changes (game started/paused, ammo given, HP…).
  useEffect(() => {
    if (live) act.current.refresh();
  }, [live]);
  useLive(["me:changed", "game:changed"], () => act.current.refresh());

  // The shot batcher for this gun. Closing the screen sends what's left.
  useEffect(() => {
    if (!gunLive || pieceId === null) return;
    const b = new ShotBatcher(pieceId, {
      result: (r) => act.current.onFireResult(r),
      error: (err) => act.current.onFireError(err),
      change: () => act.current.onBatchChange(),
    });
    batcherRef.current = b;
    const onHide = () => {
      if (document.hidden) b.flushNow();
    };
    document.addEventListener("visibilitychange", onHide);
    return () => {
      document.removeEventListener("visibilitychange", onHide);
      b.dispose();
      if (batcherRef.current === b) batcherRef.current = null;
    };
  }, [gunLive, pieceId]);

  // A practice magazine starts full every time practice begins.
  useEffect(() => {
    a.practiceLoaded = practice ? practiceCap() : null;
    rerender();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [practice]);

  // HP changes: red flash when hurt, green glow when healed.
  const prevHp = useRef<number | null>(null);
  useEffect(() => {
    if (!hp) return;
    const before = prevHp.current;
    prevHp.current = hp.hp;
    if (before === null) return;
    if (hp.hp < before) setHurtFlash((k) => k + 1);
    else if (hp.hp > before && performance.now() - lastHeal.current > 1500) setHealGlow((k) => k + 1);
  }, [hp?.hp]);

  // A newer live HP replaces the number from the heal answer.
  useEffect(() => {
    setHpOverride(null);
  }, [hookHp?.hp, hookHp?.maxHp, hookHp?.dead]);

  // 3D model
  useEffect(() => {
    if (!item.modelUrl || !stageRef.current) return;
    const stage = stageRef.current;
    const scene = new ItemScene(stage);
    sceneRef.current = scene;
    setModelState("loading");
    scene
      .load({ modelUrl: item.modelUrl, flip: item.modelFlip, upsideDown: item.modelUpsideDown, effect })
      .then(() => {
        setStageRatio(scene.portraitHeightRatio());
        setModelState("ready");
      })
      .catch(() => setModelState("error"));
    // The stage changes size with rotation, the HP bar appearing, etc.
    const onResize = () => scene.resize();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(onResize) : null;
    ro?.observe(stage);
    window.addEventListener("resize", onResize);
    return () => {
      ro?.disconnect();
      window.removeEventListener("resize", onResize);
      scene.dispose();
      if (sceneRef.current === scene) sceneRef.current = null;
    };
  }, [item.modelUrl, item.modelFlip, item.modelUpsideDown, effect]);

  useEffect(() => {
    sceneRef.current?.setCalm(calm);
  }, [calm, modelState]);

  // Gun / knife sound
  useEffect(() => {
    soundRef.current = null;
    if (!item.soundUrl) return;
    let alive = true;
    loadSound(item.soundUrl)
      .then((b) => {
        if (alive) soundRef.current = b;
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [item.soundUrl]);

  // Shake: iPhones answer the permission question a moment after the tap.
  useEffect(() => {
    let alive = true;
    whenMotionReady().then((s) => alive && setMotion(s));
    return () => {
      alive = false;
    };
  }, []);

  const shakeThreshold = (screen === "gun" ? gunNums.shakeThreshold : BASE_SHAKE) / sensitivity;
  const shakeCooldown =
    screen === "gun" ? gunNums.cooldownMs : screen === "heal" ? HEAL_COOLDOWN : screen === "knife" ? SWING_COOLDOWN : SPIN_COOLDOWN;
  const shakeOn = motion === "granted";
  useEffect(() => {
    if (!shakeOn || caseOpen) return;
    return listenForShake(() => act.current.primary("shake"), { threshold: shakeThreshold, cooldownMs: shakeCooldown });
  }, [shakeOn, caseOpen, shakeThreshold, shakeCooldown]);

  // The secure address, for the "shake needs https" hint.
  useEffect(() => {
    if (motion !== "insecure") return;
    getAuthStatus()
      .then((s) => setHttpsPort(s.httpsPort ?? 0))
      .catch(() => {});
  }, [motion]);

  // Keyboard (desktop): Space/Enter = fire, R = reload, U = use, Esc = back.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;
      if (e.key === "Escape") {
        if (caseOpenRef.current) act.current.closeCase();
        else act.current.close();
        return;
      }
      if (caseOpenRef.current || e.repeat || e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === " " || (e.key === "Enter" && !t?.closest("button, a"))) {
        e.preventDefault();
        unlockAudio();
        act.current.primary("key");
      } else if (e.key === "r" || e.key === "R") act.current.requestReload("key");
      else if (e.key === "u" || e.key === "U") void act.current.healNow("key");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // =====================================================================
  // Pointer: tap = fire, swipe down = reload
  // =====================================================================

  function onPointerDown(e: ReactPointerEvent<HTMLDivElement>) {
    if ((e.target as Element).closest("[data-no-use]")) return;
    if (e.pointerType === "mouse" && e.button !== 0) return;
    unlockAudio();
    const g: Gesture = { x0: e.clientX, y0: e.clientY, t0: performance.now(), token: null, practiceShot: false, moved: false, swiped: false };
    gestures.current.set(e.pointerId, g);
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // not supported: moves still arrive while over the screen
    }
    primary("tap", g);
  }

  function onPointerMove(e: ReactPointerEvent<HTMLDivElement>) {
    const g = gestures.current.get(e.pointerId);
    if (!g || g.swiped || screen !== "gun") return;
    const dx = e.clientX - g.x0;
    const dy = e.clientY - g.y0;
    if (dy > 12) g.moved = true;
    if (dy >= SWIPE_MIN_PX && Math.abs(dx) < dy * 0.7 && performance.now() - g.t0 <= SWIPE_MAX_MS) {
      g.swiped = true;
      // It was a swipe, not a shot: take the shot back if it wasn't sent yet.
      if (g.token?.cancel() && g.practiceShot) a.practiceLoaded = Math.min(practiceCap(), (a.practiceLoaded ?? 0) + 1);
      g.token = null;
      rerender();
      requestReload("swipe");
    }
  }

  function onPointerEnd(e: ReactPointerEvent<HTMLDivElement>) {
    const g = gestures.current.get(e.pointerId);
    gestures.current.delete(e.pointerId);
    g?.token?.release(); // a real shot after all
  }

  // =====================================================================
  // Render
  // =====================================================================

  const show2D = modelState === "none" || modelState === "error";
  const label = screen === "gun" ? "Weapon" : screen === "knife" ? "Melee" : screen === "heal" ? "Healing" : "Item";
  const secureUrl = `https://${location.hostname}:${httpsPort}${location.pathname}`;
  const actionable = screen !== "other";

  let hint: string;
  if (screen === "gun") hint = `${shakeOn ? "Tap or shake" : "Tap"} to fire · Swipe down to reload`;
  else if (screen === "knife") hint = `${shakeOn ? "Tap or shake" : "Tap"} to swing`;
  else if (screen === "heal") hint = shakeOn ? "Tap Use, or shake the phone, to use it" : "Tap Use to use it";
  else if (live && item.kind === "healing") hint = "This can't be used on its own. Tap to turn it.";
  else hint = "Tap to turn it around";

  // Right-hand corner: ammo for guns, a count for healing items.
  let corner: ReactNode = null;
  if (gunLive) {
    corner = (
      <AmmoCounter
        loaded={shownLoaded}
        reserve={a.reserve}
        magazine={practice ? practiceCap() : a.magazine}
        reloading={reload !== null}
        practice={practice}
        onReload={() => requestReload("button")}
      />
    );
  } else if (!live && screen !== "other") {
    corner = (
      <span className="wv-frame pointer-events-auto px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-white/60">
        Preview{screen === "gun" && shots > 0 ? ` · ${shots}` : ""}
      </span>
    );
  } else if (screen === "heal" && quantity !== null) {
    corner = (
      <span className="wv-frame px-3 py-1 font-display text-3xl font-bold tabular-nums text-white" aria-label={`${quantity} left`}>
        <span className="mr-0.5 text-lg text-white/55">×</span>
        {quantity}
      </span>
    );
  }

  return (
    <div
      className={`fixed inset-0 z-50 flex select-none flex-col overflow-hidden text-white ${calm ? "wv-calm" : ""}`}
      style={{ background: BACKGROUND, touchAction: "none", WebkitUserSelect: "none", WebkitTouchCallout: "none" }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerEnd}
      onPointerCancel={onPointerEnd}
      onContextMenu={(e) => e.preventDefault()}
    >
      <ViewerStyles />
      {live && <HpProbe onChange={setHookHp} />}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage: GRID,
          backgroundSize: "36px 36px",
          WebkitMaskImage: "radial-gradient(ellipse at 50% 45%, #000 20%, transparent 75%)",
          maskImage: "radial-gradient(ellipse at 50% 45%, #000 20%, transparent 75%)",
        }}
      />

      {/* Top corners. Landscape: they float over the scene to leave room for the gun. */}
      <div
        className={`${landscape ? "absolute inset-x-0 top-0" : "relative"} pointer-events-none z-30 flex items-start gap-2 ${
          leftHanded ? "flex-row-reverse" : ""
        }`}
        style={{
          paddingTop: "max(0.75rem, env(safe-area-inset-top))",
          paddingLeft: "max(0.75rem, env(safe-area-inset-left))",
          paddingRight: "max(0.75rem, env(safe-area-inset-right))",
        }}
      >
        <div className={`flex flex-1 basis-0 gap-2 ${leftHanded ? "flex-row-reverse" : ""}`}>
          <RoundButton icon="back" label="Back" onClick={close} />
          {renderCase && <RoundButton icon="grid" label="Open your case" onClick={openCase} sound={false} />}
        </div>
        <div className="min-w-0 max-w-[46%] pt-1 text-center">
          <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-white/40">{label}</p>
          <p
            className={`${landscape ? "line-clamp-1" : "line-clamp-2"} break-words font-display text-[15px] font-bold uppercase leading-tight tracking-[0.1em] text-white/90`}
          >
            {item.name}
          </p>
        </div>
        <div className={`flex flex-1 basis-0 ${leftHanded ? "justify-start" : "justify-end"}`}>{corner}</div>
      </div>

      {/* The gun, and the HP bar right under it */}
      <div className="relative z-10 flex min-h-0 flex-1 flex-col items-center justify-center">
        <div
          className="relative w-full min-h-0 overflow-hidden"
          style={{
            flex: "0 1 auto",
            height: landscape ? "100%" : `min(100%, ${Math.round((stageRatio ?? 1) * 100)}vw)`,
            // landscape: leave the top band for the item's name
            marginTop: landscape ? "calc(env(safe-area-inset-top) + 2.75rem)" : undefined,
            transition: "height 200ms ease-out",
          }}
        >
          <div
            aria-hidden
            className="pointer-events-none absolute inset-x-[12%] bottom-[6%] h-[24%] rounded-[50%]"
            style={{ background: "radial-gradient(ellipse at center, rgba(255,255,255,.075), transparent 70%)" }}
          />
          <div ref={stageRef} className="absolute inset-0" />
          {modelState === "loading" && (
            <p className="absolute inset-0 flex items-center justify-center text-sm font-semibold uppercase tracking-[0.2em] text-white/50">
              Loading 3D model…
            </p>
          )}
          {show2D && (
            <div className="absolute inset-0 flex items-center justify-center p-8">
              {item.imageUrl ? (
                <img
                  ref={imgRef}
                  src={item.imageUrl}
                  alt=""
                  draggable={false}
                  onLoad={(e) => {
                    const im = e.currentTarget;
                    if (im.naturalWidth > 0)
                      setStageRatio(Math.min(1.12, Math.max(0.62, (im.naturalHeight / im.naturalWidth) * 1.3)));
                  }}
                  className="max-h-full max-w-full object-contain drop-shadow-[0_18px_30px_rgba(0,0,0,.7)]"
                />
              ) : (
                <p className="font-display text-7xl font-bold text-white/25">{item.name.charAt(0)}</p>
              )}
            </div>
          )}
          {reload && <ReloadRing start={reload.start} end={reload.end} />}
          {noAmmo > 0 && (
            <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center" role="status">
              <p
                key={noAmmo}
                className="wv-pop font-display text-4xl font-bold uppercase tracking-[0.2em] text-[#FF5D5D]"
                style={{ textShadow: "0 0 18px rgba(255,60,60,.55), 0 2px 4px rgba(0,0,0,.8)" }}
              >
                No ammo
              </p>
            </div>
          )}
        </div>

        {live && actionable && (
          <div className="flex w-full shrink-0 justify-center px-4 pt-1">
            <div className="wv-frame w-full max-w-[22rem] px-3 py-2">
              {hp ? <HpBar hp={hp} size="md" /> : <div className="h-6 animate-pulse rounded-sm bg-white/5" />}
            </div>
          </div>
        )}
      </div>

      <footer
        className="relative z-30 flex shrink-0 flex-col items-center gap-2 px-4 pt-3 text-center"
        style={{ paddingBottom: "max(0.9rem, env(safe-area-inset-bottom))" }}
      >
        {screen === "heal" && (
          <>
            <UseButton
              label="Use"
              detail={healDetail(item)}
              disabled={closing || (healLive && healWhy !== null)}
              busy={healBusy}
              onUse={() => void healNow("button")}
            />
            {healWhy && <p className="text-sm font-semibold text-white/60">{healWhy}</p>}
          </>
        )}
        {!block && <p className="text-[13px] font-semibold tracking-wide text-white/55">{hint}</p>}
        {actionable && !shakeOn && motion === "insecure" && httpsPort > 0 && (
          <a data-no-use href={secureUrl} className="rounded-sm bg-white/10 px-3 py-2 text-sm font-semibold text-white/80 underline">
            Shaking needs the secure address. Open it
          </a>
        )}
        {actionable && !shakeOn && motion === "denied" && (
          <p className="text-xs text-white/45">Shake is off: motion access wasn't allowed.</p>
        )}
        {actionable && !shakeOn && motion === null && motionNeedsTap() && (
          <button
            type="button"
            data-no-use
            onClick={() => requestMotionPermission().then(setMotion)}
            className="rounded-sm border border-white/20 px-3 py-2 text-sm font-semibold text-white/80 active:bg-white/10"
          >
            Turn on shake
          </button>
        )}
        {modelState === "error" && <p className="text-xs text-white/45">Couldn't load the 3D model, so here's the picture.</p>}
      </footer>

      {/* Why you can't fire: over everything but the corner buttons */}
      {block && <StatusCard {...block} nudge={nudge} />}

      {/* Full-screen effects */}
      {shotFlash > 0 && (
        <div
          key={`s${shotFlash}`}
          className="pointer-events-none absolute inset-0 z-[35] bg-[#ffd98f]"
          style={{ opacity: 0, animation: "wv-flash 110ms ease-out forwards" }}
        />
      )}
      {hurtFlash > 0 && (
        <div
          key={`h${hurtFlash}`}
          className="pointer-events-none absolute inset-0 z-[36]"
          style={{ opacity: 0, boxShadow: "inset 0 0 140px 40px rgba(255,40,40,.6)", animation: "wv-glow 750ms ease-out forwards" }}
        />
      )}
      {healGlow > 0 && (
        <div
          key={`g${healGlow}`}
          className="pointer-events-none absolute inset-0 z-[36]"
          style={{
            opacity: 0,
            background: "radial-gradient(ellipse at 50% 60%, rgba(157,195,91,.32), transparent 65%)",
            boxShadow: "inset 0 0 120px 30px rgba(157,195,91,.45)",
            animation: "wv-glow 1100ms ease-out forwards",
          }}
        />
      )}

      {caseOpen && renderCase && (
        <CaseSheet onClose={() => act.current.closeCase()}>{renderCase({ closeCase: () => act.current.closeCase() })}</CaseSheet>
      )}
    </div>
  );
}
