import { Role } from "../services/api";

export function RoleSelect({ onSelect }: { onSelect: (role: Role) => void }) {
  return (
    <div className="flex flex-col gap-4">
      <button
        onClick={() => onSelect("admin")}
        className="rounded-2xl border-2 border-pine bg-pine px-6 py-6 text-left text-white"
      >
        <span className="block text-2xl font-bold">Admin</span>
        <span className="text-pine-soft/90 text-base">Run the game</span>
      </button>
      <button
        onClick={() => onSelect("player")}
        className="rounded-2xl border-2 border-pine/30 bg-white px-6 py-6 text-left text-ink"
      >
        <span className="block text-2xl font-bold">Player</span>
        <span className="text-base text-ink/60">Join the game</span>
      </button>
    </div>
  );
}
