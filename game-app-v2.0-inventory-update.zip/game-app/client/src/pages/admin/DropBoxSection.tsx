import { useEffect, useState } from "react";
import { playSfx } from "../../audio/sfx";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ConfirmCard } from "../../components/ConfirmCard";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { ItemImage } from "../../components/ItemImage";
import { Section } from "../../components/Section";
import { toast } from "../../components/Toast";
import { clearDrops, DropEntry, getAdminDrops } from "../../services/api";
import { useLive } from "../../services/live";
import { DROPS_CHANGED } from "./liveEvents";
import { clockTime } from "./ui";

function amountText(d: DropEntry): string | null {
  if (d.kind === "ammo") return `${d.quantity} rounds`;
  if (d.kind === "gun") return d.loaded > 0 ? `${d.loaded} loaded` : null;
  return d.quantity > 1 ? `×${d.quantity}` : null;
}

// Where it came from, in words: "Dropped by Ali" or "Fell when Ali went down".
function originText(d: DropEntry): string {
  const by = d.droppedByName || d.ownerName;
  const base = d.reason === "DEATH" ? `Fell when ${by} went down` : `Dropped by ${by}`;
  return d.droppedByName && d.droppedByName !== d.ownerName ? `${base} · belongs to ${d.ownerName}` : base;
}

// Items on the ground that any player can pick up from their case. The Admin
// can send everything back to whoever owned it.
export function DropBoxSection() {
  const [drops, setDrops] = useState<DropEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);

  function load() {
    getAdminDrops()
      .then((d) => {
        setDrops(d);
        setError(null);
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Couldn't load the drop box."));
  }
  useEffect(load, []);
  useLive([DROPS_CHANGED, "game:changed"], load);

  async function returnAll() {
    setBusy(true);
    setError(null);
    try {
      const r = await clearDrops();
      setConfirming(false);
      playSfx("success");
      toast(
        r.returned !== null
          ? `Returned ${r.returned} item${r.returned === 1 ? "" : "s"} to their owners.`
          : "Everything went back to its owner.",
        "good"
      );
      load();
    } catch (err) {
      playSfx("error");
      setError(err instanceof Error ? err.message : "Couldn't return the items.");
    } finally {
      setBusy(false);
    }
  }

  const count = drops?.length ?? 0;

  return (
    <Section title={`Drop box${drops ? ` (${count})` : ""}`} flush>
      <ErrorBanner message={error} />
      {drops === null && !error && <p className="p-4 text-ink/60">Loading…</p>}
      {drops?.length === 0 && (
        <div className="flex flex-col items-center gap-2 px-4 py-6 text-center">
          <Icon name="drop" className="h-10 w-10 text-ink/30" />
          <p className="text-ink/60">Empty. Items players drop — or lose when they go down — wait here for anyone to pick up.</p>
        </div>
      )}
      {drops && drops.length > 0 && (
        <>
          <ul className="divide-y divide-panel-line">
            {drops.map((d) => {
              const amount = amountText(d);
              return (
                <li key={d.id} className="flex items-center gap-3 px-4 py-3">
                  <ItemImage url={d.imageUrl} name={d.name} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="flex flex-wrap items-baseline gap-x-2">
                      <span className="truncate font-bold">{d.name}</span>
                      {amount && <span className="font-display font-bold tabular-nums text-pine">{amount}</span>}
                    </p>
                    <p className="text-sm text-ink/55">
                      {originText(d)} · {clockTime(d.createdAt)}
                    </p>
                  </div>
                  {d.reason === "DEATH" && (
                    <Badge tone="bad">
                      <Icon name="skull" className="h-4 w-4" />
                    </Badge>
                  )}
                </li>
              );
            })}
          </ul>
          <div className="flex flex-col gap-3 border-t border-panel-line p-4">
            {confirming ? (
              <ConfirmCard
                tone="primary"
                title={`Return all ${count} to their owners?`}
                body="Everything goes back into the case of whoever owned it (into their tray if there's no room). The drop box will be empty."
                confirmLabel="Return all"
                loading={busy}
                onConfirm={returnAll}
                onCancel={() => setConfirming(false)}
              />
            ) : (
              <Button variant="ghost" onClick={() => setConfirming(true)}>
                <span className="flex items-center justify-center gap-2">
                  <Icon name="pickup" /> Return all to owners
                </span>
              </Button>
            )}
          </div>
        </>
      )}
      <p className="border-t border-panel-line px-4 py-3 text-sm text-ink/55">
        Players pick these up from their case. With the rule “Give back unclaimed drops” on, anything left when the game ends goes
        home by itself.
      </p>
    </Section>
  );
}
