import { notifyUnauthorized } from "./authEvents";

export interface Health {
  status: string;
  database: string;
  time: string;
}

export async function getHealth(): Promise<Health> {
  const res = await fetch("/api/health");
  if (!res.ok) throw new Error("Server unavailable");
  return res.json();
}

export type Role = "admin" | "player";

export interface PublicUser {
  id: number;
  role: Role;
  username: string;
  displayName: string | null;
  status: "active" | "disabled";
  balance: number;
  createdAt: string;
}

export type Player = PublicUser;

export interface AuthStatus {
  hasAdmin: boolean;
  hasPlayers: boolean;
  httpsPort?: number; // secure address port, 0 when not running
}

class ApiError extends Error {}

async function parseJsonOrThrow(res: Response): Promise<any> {
  let body: any = null;
  try {
    body = await res.json();
  } catch {
    // no JSON body
  }
  if (!res.ok) {
    throw new ApiError(body?.error || "Something went wrong. Please try again.");
  }
  return body;
}

// Same as parseJsonOrThrow, but for endpoints that require an active Admin
// session. A 401 here doesn't just mean "this one call failed" — it means
// the server no longer considers this device's session valid (most likely
// because the same Admin account logged in elsewhere), so the whole app
// needs to drop back to the login screen, not just show an inline error.
async function parseAdminJsonOrThrow(res: Response): Promise<any> {
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

export async function getAuthStatus(): Promise<AuthStatus> {
  const res = await fetch("/api/auth/status");
  return parseJsonOrThrow(res);
}

export async function getCurrentUser(): Promise<PublicUser | null> {
  const res = await fetch("/api/auth/me");
  if (res.status === 401) return null;
  const body = await parseJsonOrThrow(res);
  return body.user;
}

export async function setupAdmin(input: {
  username: string;
  password: string;
  confirmPassword: string;
}): Promise<PublicUser> {
  const res = await fetch("/api/auth/admin-setup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseJsonOrThrow(res);
  return body.user;
}

export async function login(input: {
  role: Role;
  username: string;
  password: string;
}): Promise<PublicUser> {
  const res = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseJsonOrThrow(res);
  return body.user;
}

export async function logout(): Promise<void> {
  await fetch("/api/auth/logout", { method: "POST" });
}

export async function listPlayers(): Promise<Player[]> {
  const res = await fetch("/api/admin/players");
  const body = await parseAdminJsonOrThrow(res);
  return body.players;
}

export async function createPlayer(input: {
  username: string;
  password: string;
  confirmPassword: string;
  displayName?: string;
}): Promise<Player> {
  const res = await fetch("/api/admin/players", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.player;
}

export async function getPlayer(id: number): Promise<Player> {
  const res = await fetch(`/api/admin/players/${id}`);
  const body = await parseAdminJsonOrThrow(res);
  return body.player;
}

export async function updatePlayer(
  id: number,
  fields: { username?: string; displayName?: string | null; status?: "active" | "disabled" }
): Promise<Player> {
  const res = await fetch(`/api/admin/players/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(fields),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.player;
}

export async function resetPlayerPassword(
  id: number,
  input: { password: string; confirmPassword: string }
): Promise<void> {
  const res = await fetch(`/api/admin/players/${id}/reset-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  if (res.status !== 204) {
    await parseAdminJsonOrThrow(res);
  }
}

export type TransactionType = "ADD" | "REMOVE" | "PURCHASE";

export interface Transaction {
  id: number;
  type: TransactionType;
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  performedBy: number;
  itemId: number | null;
  itemName: string | null;
  quantity: number | null;
  createdAt: string;
}

export async function adjustPlayerMoney(
  id: number,
  input: { type: "ADD" | "REMOVE"; amount: number }
): Promise<{ balance: number; transaction: Transaction }> {
  const res = await fetch(`/api/admin/players/${id}/money`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  return parseAdminJsonOrThrow(res);
}

export async function getPlayerTransactions(id: number): Promise<Transaction[]> {
  const res = await fetch(`/api/admin/players/${id}/transactions`);
  const body = await parseAdminJsonOrThrow(res);
  return body.transactions;
}

// A player's own transaction history — no id parameter, since the server
// derives whose history to return from the session, never from a request
// argument a player could tamper with.
export async function getMyTransactions(): Promise<Transaction[]> {
  const res = await fetch("/api/me/transactions");
  const body = await parseJsonOrThrow(res);
  return body.transactions;
}

// ---- Items & Inventory (Phase 5) ----

export type UseEffect = "none" | "shot" | "swing";

export interface Item {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  maxStack: number | null;
  enabled: boolean;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  createdAt: string;
}

export interface ItemInput {
  name?: string;
  description?: string | null;
  category?: string | null;
  maxStack?: number | null;
  enabled?: boolean;
  useEffect?: UseEffect;
  modelFlip?: boolean;
  modelUpsideDown?: boolean;
}

export async function listItems(): Promise<Item[]> {
  const res = await fetch("/api/admin/items");
  const body = await parseAdminJsonOrThrow(res);
  return body.items;
}

export async function getItem(id: number): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}`);
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function createItem(input: ItemInput): Promise<Item> {
  const res = await fetch("/api/admin/items", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function updateItem(id: number, input: ItemInput): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function uploadItemImage(id: number, dataUrl: string): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}/image`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ image: dataUrl }),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function removeItemImage(id: number): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}/image`, { method: "DELETE" });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

// 3D model (.glb) and sound are sent as the raw file.
export async function uploadItemFile(id: number, kind: "model" | "sound", file: File): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}/${kind}`, {
    method: "POST",
    headers: { "Content-Type": "application/octet-stream" },
    body: file,
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export async function removeItemFile(id: number, kind: "model" | "sound"): Promise<Item> {
  const res = await fetch(`/api/admin/items/${id}/${kind}`, { method: "DELETE" });
  const body = await parseAdminJsonOrThrow(res);
  return body.item;
}

export type InventoryAction = "GIVE" | "REMOVE" | "SET" | "PURCHASE";
export type AdminInventoryAction = Exclude<InventoryAction, "PURCHASE">;

export interface InventoryEntry {
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  quantity: number;
  // Only present in the Admin view:
  enabled?: boolean;
  maxStack?: number | null;
}

export interface InventoryLogEntry {
  id: number;
  itemId: number;
  itemName: string;
  action: InventoryAction;
  quantityBefore: number;
  quantityAfter: number;
  performedBy: number;
  createdAt: string;
}

export interface AdminInventory {
  inventory: InventoryEntry[];
  log: InventoryLogEntry[];
}

export async function getPlayerInventory(id: number): Promise<AdminInventory> {
  const res = await fetch(`/api/admin/players/${id}/inventory`);
  return parseAdminJsonOrThrow(res);
}

export async function changePlayerInventory(
  id: number,
  input: { itemId: number; action: AdminInventoryAction; quantity: number }
): Promise<AdminInventory> {
  const res = await fetch(`/api/admin/players/${id}/inventory`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  return parseAdminJsonOrThrow(res);
}

// The logged-in player's own items; the server decides whose from the session.
export async function getMyInventory(): Promise<InventoryEntry[]> {
  const res = await fetch("/api/me/inventory");
  if (res.status === 401) notifyUnauthorized();
  const body = await parseJsonOrThrow(res);
  return body.inventory;
}

// ---- Shop (Phase 6) ----

export interface Listing {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  price: number;
  stock: number | null; // null = unlimited
  maxPerPurchase: number | null;
  enabled: boolean;
  itemEnabled: boolean;
  maxStack: number | null;
}

export interface Sale {
  id: number;
  playerId: number;
  playerName: string;
  itemName: string;
  quantity: number;
  total: number;
  createdAt: string;
}

export interface AdminShop {
  open: boolean;
  listings: Listing[];
  sales: Sale[];
}

export interface ListingInput {
  price?: number;
  stock?: number | null;
  maxPerPurchase?: number | null;
  enabled?: boolean;
}

export async function getAdminShop(): Promise<AdminShop> {
  const res = await fetch("/api/admin/shop");
  return parseAdminJsonOrThrow(res);
}

export async function setShopOpen(open: boolean): Promise<boolean> {
  const res = await fetch("/api/admin/shop/status", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ open }),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.open;
}

export async function addListing(input: ListingInput & { itemId: number }): Promise<Listing> {
  const res = await fetch("/api/admin/shop/items", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.listing;
}

export async function updateListing(id: number, input: ListingInput): Promise<Listing> {
  const res = await fetch(`/api/admin/shop/items/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const body = await parseAdminJsonOrThrow(res);
  return body.listing;
}

export async function removeListing(id: number): Promise<void> {
  const res = await fetch(`/api/admin/shop/items/${id}`, { method: "DELETE" });
  if (res.status !== 204) await parseAdminJsonOrThrow(res);
}

export interface PlayerListing {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  price: number;
  stock: number | null;
  maxPerPurchase: number | null;
  maxStack: number | null;
  owned: number;
}

async function parsePlayerJsonOrThrow(res: Response): Promise<any> {
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

export async function getShop(): Promise<{ open: boolean; listings: PlayerListing[] }> {
  const res = await fetch("/api/shop");
  return parsePlayerJsonOrThrow(res);
}

export async function buy(input: {
  shopItemId: number;
  quantity: number;
  expectedPrice: number;
}): Promise<{ balance: number; quantity: number; total: number; itemName: string; owned: number }> {
  const res = await fetch("/api/shop/purchase", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  return parsePlayerJsonOrThrow(res);
}

// ---- Ready-made item packs (free CC0 weapons, medkit…) ----

export interface PackItem {
  key: string;
  name: string;
  category: string | null;
  useEffect: UseEffect;
  pictureUrl: string | null;
  hasModel: boolean;
  hasSound: boolean;
  alreadyAdded: boolean;
}

export interface AssetPack {
  id: string;
  title: string;
  credits: string;
  items: PackItem[];
}

export async function listAssetPacks(): Promise<AssetPack[]> {
  const res = await fetch("/api/admin/asset-packs");
  const body = await parseAdminJsonOrThrow(res);
  return body.packs;
}

export async function importFromPack(
  packId: string,
  keys: string[]
): Promise<{ created: string[]; skipped: string[] }> {
  const res = await fetch(`/api/admin/asset-packs/${packId}/import`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ keys }),
  });
  return parseAdminJsonOrThrow(res);
}

// ---- Game controls (Phase 8) ----

export type GameStatus = "not_started" | "active" | "paused" | "ended";

export interface GameEvent {
  id: number;
  type: "STATUS" | "ANNOUNCEMENT";
  status: GameStatus | null;
  message: string | null;
  playerId: number | null;
  playerName: string | null;
  createdAt: string;
}

export interface AdminGame {
  status: GameStatus;
  changedAt: string | null;
  events: GameEvent[];
}

export async function getAdminGame(): Promise<AdminGame> {
  return parseAdminJsonOrThrow(await fetch("/api/admin/game"));
}

export async function setGameStatus(status: GameStatus): Promise<AdminGame> {
  const res = await fetch("/api/admin/game/status", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status }),
  });
  return parseAdminJsonOrThrow(res);
}

export async function sendAnnouncement(message: string, playerId: number | null): Promise<AdminGame> {
  const res = await fetch("/api/admin/game/announcements", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, playerId }),
  });
  return parseAdminJsonOrThrow(res);
}

export async function resetRound(): Promise<AdminGame> {
  const res = await fetch("/api/admin/game/reset-round", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ confirm: "RESET" }),
  });
  return parseAdminJsonOrThrow(res);
}

export interface PlayerGame {
  status: GameStatus;
  changedAt: string | null;
  announcements: GameEvent[];
}

export async function getGame(): Promise<PlayerGame> {
  const res = await fetch("/api/game");
  if (res.status === 401) notifyUnauthorized();
  return parseJsonOrThrow(res);
}

export const GAME_STATUS_LABEL: Record<GameStatus, string> = {
  not_started: "Waiting to start",
  active: "Game on",
  paused: "Paused",
  ended: "Game over",
};
