import { Transaction } from "../services/api";
import { formatDateTime } from "../utils/format";

function describe(t: Transaction): string {
  const item = t.itemName ?? "item";
  if (t.type === "PURCHASE") return `Bought ${t.quantity} × ${item}`;
  if (t.type === "SALE") return `Sold ${t.quantity} × ${item}`;
  if (t.type === "UPGRADE") return `Upgraded ${item}${t.detail ? ` · ${t.detail}` : ""}`;
  return t.type === "ADD" ? "Money added" : "Money removed";
}

export function TransactionList({ transactions }: { transactions: Transaction[] }) {
  if (transactions.length === 0) {
    return <p className="p-4 text-ink/60">No money changes yet.</p>;
  }
  return (
    <ul className="divide-y-2 divide-ink/5">
      {transactions.map((t) => {
        const up = t.type === "ADD" || t.type === "SALE";
        return (
          <li key={t.id} className="flex items-center justify-between gap-3 px-4 py-3">
            <div className="min-w-0">
              <p className="truncate font-semibold text-ink">{describe(t)}</p>
              <p className="text-sm text-ink/55">
                {formatDateTime(t.createdAt)} · balance ${t.balanceAfter}
              </p>
            </div>
            <span className={`shrink-0 text-lg font-display font-bold tabular-nums ${up ? "text-pine" : "text-alert"}`}>
              {t.amount === 0 ? "Free" : `${up ? "+" : "−"}$${t.amount}`}
            </span>
          </li>
        );
      })}
    </ul>
  );
}
