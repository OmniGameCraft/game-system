import { KeyboardEvent, MouseEvent, RefObject, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Icon } from "../components/Icon";
import { toast } from "../components/Toast";
import { playSfx, type SfxName } from "../audio/sfx";
import { vibrate } from "../audio/haptics";
import { useSettings } from "../audio/settings";
import { useLive } from "../services/live";
import {
  arrangeCase,
  caseFrom,
  combinePieces,
  dropPiece,
  getCase,
  getHp,
  hpFrom,
  movePiece,
  pickupDrop,
  reloadGun,
  splitPiece,
  usePiece,
  type CaseState,
  type Drop,
  type HpState,
  type Piece,
} from "./caseApi";
import { CaseGrid, chromeWidth, type Chrome } from "./CaseGrid";
import { CombineSheet } from "./CombineSheet";
import { DropBox } from "./DropBox";
import { HpBar } from "./HpBar";
import { applyHp, useHp } from "./hpStore";
import { ItemActionSheet, type ItemPanel } from "./ItemActionSheet";
import { fits, footprint, nearestFit, neighbour, slotNumbers } from "./layout";
import { mixOf } from "./herbs";
import { PieceArt, PieceView } from "./PieceView";
import { useCaseDrag, type DragView } from "./useCaseDrag";
import "./case.css";

// The player's case: an attaché-case grid (like the reference picture)
// where every item is a piece of its real size. Drag to arrange, tap for the
// item's menu, mix herbs, reload, heal, drop things for your team and pick
// up what others dropped.
//
// `compact` is the version shown inside the weapon screen's "Case" overlay:
// no big health bar (the weapon screen shows its own) and a slimmer frame.

type SheetState = { kind: "item"; id: number; panel: ItemPanel } | { kind: "combine"; id: number } | { kind: "drops" } | null;

const MIN_CELL = 24; // only the narrowest phones with a 9–10 column case go below 34 px
const MAX_CELL = 64;

function useWidth(ref: RefObject<HTMLElement>): number {
  const [w, setW] = useState(0);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const measure = () => setW(el.clientWidth);
    measure();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(measure) : null;
    ro?.observe(el);
    window.addEventListener("resize", measure);
    return () => {
      ro?.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [ref]);
  return w;
}

const message = (e: unknown) => (e instanceof Error && e.message ? e.message : "Something went wrong. Please try again.");

export function CaseScreen({ onOpenWeapon, compact = false }: { onOpenWeapon: (p: Piece) => void; compact?: boolean }) {
  const [state, setStateRaw] = useState<CaseState | null>(null);
  const stateRef = useRef<CaseState | null>(null);
  const setState = (s: CaseState) => {
    stateRef.current = s;
    setStateRaw(s);
  };
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [sheet, setSheet] = useState<SheetState>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [busyDrop, setBusyDrop] = useState<number | null>(null);
  const [busyMix, setBusyMix] = useState<number | null>(null);
  const [reloading, setReloading] = useState<{ id: number; ms: number; n: number } | null>(null);
  const [freshIds, setFreshIds] = useState<Set<number>>(() => new Set());
  const [settleId, setSettleId] = useState<number | null>(null);
  const liveHp = useHp();
  const [{ reduceMotion }] = useSettings();

  const wrapRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const dropBtnRef = useRef<HTMLButtonElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);
  const trayRef = useRef<HTMLElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const floatRef = useRef<HTMLDivElement>(null);
  const timers = useRef<{ fresh?: number; settle?: number; refresh?: number }>({});
  const reloadSeq = useRef(0);
  const width = useWidth(wrapRef);

  // ---- loading, with protection against old answers -------------------
  // `epoch` changes whenever we change something; a read that started
  // before that is out of date and is thrown away (otherwise a piece the
  // player just moved could jump back for a moment).
  const epoch = useRef(0);
  const pending = useRef(0);
  const loadSeq = useRef(0);

  const commit = useCallback((next: CaseState) => {
    const prev = stateRef.current;
    if (prev) {
      const had = new Set([...prev.pieces, ...prev.tray].map((p) => p.id));
      const fresh = [...next.pieces, ...next.tray].filter((p) => !had.has(p.id)).map((p) => p.id);
      if (fresh.length) {
        setFreshIds(new Set(fresh));
        clearTimeout(timers.current.fresh);
        timers.current.fresh = window.setTimeout(() => setFreshIds(new Set()), 700);
      }
    }
    stateRef.current = next;
    setStateRaw(next);
  }, []);

  const load = useCallback(async () => {
    const seq = ++loadSeq.current;
    const ep = epoch.current;
    try {
      const s = await getCase();
      if (seq !== loadSeq.current || ep !== epoch.current || pending.current > 0) return;
      commit(s);
      setError(null);
    } catch (e) {
      if (seq === loadSeq.current) setError(message(e));
    }
  }, [commit]);

  const scheduleLoad = useCallback(() => {
    clearTimeout(timers.current.refresh);
    // Several notices often arrive together (me + drops + hp): read once.
    timers.current.refresh = window.setTimeout(() => void load(), 80);
  }, [load]);

  useEffect(() => {
    void load();
    const onVisible = () => {
      if (document.visibilityState === "visible") scheduleLoad();
    };
    document.addEventListener("visibilitychange", onVisible);
    const t = timers.current;
    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      clearTimeout(t.refresh);
      clearTimeout(t.fresh);
      clearTimeout(t.settle);
    };
  }, [load, scheduleLoad]);

  useLive(["me:changed", "items:changed", "drops:changed", "hp:changed", "rules:changed", "game:changed"], scheduleLoad);

  // Run a change on the server. `optimistic` shows the result straight away;
  // if the server says no, the old layout comes back and the reason shows.
  async function mutate<T>(fn: () => Promise<T>, optimistic?: (s: CaseState) => CaseState): Promise<T> {
    const before = stateRef.current;
    epoch.current++;
    pending.current++;
    if (optimistic && before) setState(optimistic(before));
    try {
      const res = await fn();
      pending.current--;
      epoch.current++;
      const fresh = caseFrom(res);
      if (pending.current === 0) {
        if (fresh) commit(fresh);
        else void load();
      }
      return res;
    } catch (e) {
      pending.current--;
      epoch.current++;
      if (optimistic && before) setState(before);
      if (pending.current === 0) void load();
      throw e;
    }
  }

  // ---- derived ----------------------------------------------------------
  const s = state;
  const hp: HpState | null = liveHp ?? s?.hp ?? null;
  const dead = hp?.dead ?? false;
  const status = s?.game.status ?? "not_started";
  const everything = useMemo(() => (s ? [...s.pieces, ...s.tray] : []), [s]);
  const slots = useMemo(() => slotNumbers(s?.pieces ?? []), [s]);
  const cols = s?.cols ?? 8;
  const rows = s?.rows ?? 4;
  const narrow = width > 0 && width < 420;
  const chrome: Chrome = compact ? { outer: 5, rim: 2, well: 2 } : narrow ? { outer: 7, rim: 2, well: 3 } : { outer: 14, rim: 3, well: 6 };
  // Cells as big as the screen allows, up to 64 px. Never wider than the
  // screen: a phone must never need to scroll sideways.
  const cell = width > 0 ? Math.max(MIN_CELL, Math.floor(Math.min((width - chromeWidth(chrome)) / cols, MAX_CELL))) : 40;
  const trayCell = Math.max(22, Math.round(cell * 0.72));
  const groundWhy = dead
    ? "You're down — wait for the Admin to revive you."
    : status === "paused"
    ? "The game is paused. You can still arrange your case."
    : status === "ended"
    ? "The game is over. You can still arrange your case."
    : null;

  // Forget a selection / close a menu whose piece is gone (used up, dropped…).
  useEffect(() => {
    if (!s) return;
    const ids = new Set(everything.map((p) => p.id));
    if (selectedId !== null && !ids.has(selectedId)) setSelectedId(null);
    if (sheet && sheet.kind !== "drops" && !ids.has(sheet.id)) setSheet(null);
  }, [s]); // eslint-disable-line react-hooks/exhaustive-deps

  // The pause screen covers everything; don't leave a menu floating above it.
  useEffect(() => {
    if (status === "paused") {
      setSheet(null);
      drag.cancel();
    }
  }, [status]); // eslint-disable-line react-hooks/exhaustive-deps

  // ---- feedback helpers ---------------------------------------------------
  function fail(e: unknown) {
    playSfx("error");
    vibrate([30, 50, 30]);
    toast(message(e), "bad");
  }

  function settle(id: number) {
    setSettleId(id);
    clearTimeout(timers.current.settle);
    timers.current.settle = window.setTimeout(() => setSettleId(null), 400);
  }

  function focusPiece(id: number) {
    requestAnimationFrame(() => wrapRef.current?.querySelector<HTMLElement>(`[data-piece="${id}"]`)?.focus({ preventScroll: true }));
  }

  // ---- actions ------------------------------------------------------------
  function localMove(st: CaseState, id: number, x: number | null, y: number | null, rotated: boolean): CaseState {
    const p = [...st.pieces, ...st.tray].find((q) => q.id === id);
    if (!p) return st;
    const moved: Piece = { ...p, x, y, rotated };
    if (x !== null && st.pieces.some((q) => q.id === id)) {
      return { ...st, pieces: st.pieces.map((q) => (q.id === id ? moved : q)) };
    }
    const pieces = st.pieces.filter((q) => q.id !== id);
    const tray = st.tray.filter((q) => q.id !== id);
    return x === null ? { ...st, pieces, tray: [...tray, moved] } : { ...st, pieces: [...pieces, moved], tray };
  }

  function moveTo(p: Piece, x: number | null, y: number | null, rotated: boolean, sound: SfxName = "snap") {
    settle(p.id);
    playSfx(sound);
    vibrate(12);
    mutate(() => movePiece(p.id, x, y, rotated), (st) => localMove(st, p.id, x, y, rotated)).catch(fail);
  }

  function mergeInto(p: Piece, target: Piece) {
    if (target.x === null || target.y === null) return;
    playSfx("snap");
    vibrate(12);
    const add = Math.min(p.quantity, target.stackSize - target.quantity);
    const left = p.quantity - add;
    const upd = (q: Piece): Piece => (q.id === target.id ? { ...q, quantity: q.quantity + add } : q.id === p.id ? { ...q, quantity: left } : q);
    mutate(
      () => movePiece(p.id, target.x, target.y, target.rotated),
      (st) => ({
        ...st,
        pieces: st.pieces.map(upd).filter((q) => q.quantity > 0),
        tray: st.tray.map(upd).filter((q) => q.quantity > 0),
      })
    ).catch(fail);
  }

  // Turn a piece where it lies; if the cells it would need are taken, slide
  // it to the nearest spot where it fits turned.
  function rotateInPlace(p: Piece): boolean {
    const st = stateRef.current;
    if (!st || dead) return false;
    if (p.x === null || p.y === null) {
      fail(new Error("Drag it into the case first, then turn it."));
      return false;
    }
    if (p.w === p.h) return false;
    const fp = footprint(p, !p.rotated);
    if (fits({ x: p.x, y: p.y, ...fp }, st.cols, st.rows, st.pieces, p.id)) {
      moveTo(p, p.x, p.y, !p.rotated, "rotate");
      return true;
    }
    const spot = nearestFit(p, st.cols, st.rows, st.pieces, { x: p.x, y: p.y }, [!p.rotated]);
    if (spot) {
      moveTo(p, spot.x, spot.y, spot.rotated, "rotate");
      toast("Turned and moved to where it fits.", "info");
      return true;
    }
    fail(new Error("No room to turn it. Make some space first."));
    return false;
  }

  async function combine(src: Piece, target: Piece) {
    if (groundWhy) return fail(new Error(groundWhy));
    const m = src.herbCode && target.herbCode ? mixOf(src.herbCode, target.herbCode) : null;
    if (m && !m.ok) return fail(new Error(m.reason));
    setBusyMix(target.id);
    try {
      const res: any = await mutate(() => combinePieces(src.id, target.id));
      playSfx("mix");
      vibrate([20, 40, 20]);
      const name = res?.result?.name ?? res?.item?.name ?? res?.piece?.name ?? (m?.ok ? m.name : "Mixed herb");
      toast(`${name} made`, "good");
      setSheet(null);
      const newId = res?.piece?.id ?? res?.result?.pieceId;
      if (typeof newId === "number") setSelectedId(newId);
    } catch (e) {
      fail(e);
    } finally {
      setBusyMix(null);
    }
  }

  async function use(p: Piece) {
    const before = hp;
    setBusy("use");
    try {
      const res = await mutate(() => usePiece(p.id));
      const after = hpFrom(res) ?? (await getHp().catch(() => null));
      // The shared HP store plays the heal sound and the green glow.
      if (after) applyHp(after);
      else playSfx("heal");
      if (before && after) {
        const gained = after.hp - before.hp;
        const maxGain = after.maxHp - before.maxHp;
        const parts = [gained > 0 ? `Healed ${gained} HP` : null, maxGain > 0 ? `Max HP +${maxGain}` : null].filter(Boolean);
        toast(p.fullHeal ? `Fully healed — ${after.hp} / ${after.maxHp}` : parts.join(" · ") || `Used ${p.name}`, "good");
      } else {
        toast(`Used ${p.name}`, "good");
      }
      setSheet(null);
    } catch (e) {
      fail(e);
    } finally {
      setBusy(null);
    }
  }

  async function drop(p: Piece, n: number) {
    if (groundWhy) return fail(new Error(groundWhy));
    const partial = n < p.quantity;
    setBusy("drop");
    try {
      await mutate(
        () => dropPiece(p.id, partial ? n : undefined),
        (st) => {
          const upd = (q: Piece) => (q.id === p.id ? { ...q, quantity: q.quantity - n } : q);
          return { ...st, pieces: st.pieces.map(upd).filter((q) => q.quantity > 0), tray: st.tray.map(upd).filter((q) => q.quantity > 0) };
        }
      );
      playSfx("drop");
      vibrate(20);
      toast(
        p.kind === "ammo" ? `Dropped ${n} rounds of ${p.name}` : n > 1 ? `Dropped ${n} × ${p.name}` : `Dropped ${p.name} — it's in the drop box`,
        "info"
      );
      setSheet(null);
    } catch (e) {
      fail(e);
    } finally {
      setBusy(null);
    }
  }

  // Weapons and stacks ask first (how many / are you sure); single small
  // things drop straight away (they can be picked up again).
  function requestDrop(p: Piece) {
    if (groundWhy) return fail(new Error(groundWhy));
    if (p.kind === "gun" || p.kind === "knife" || p.quantity > 1) {
      setSelectedId(p.id);
      setSheet({ kind: "item", id: p.id, panel: "drop" });
    } else void drop(p, p.quantity);
  }

  async function pickup(d: Drop, n: number) {
    if (groundWhy) return fail(new Error(groundWhy));
    setBusyDrop(d.id);
    try {
      await mutate(() => pickupDrop(d.id, n < d.quantity ? n : undefined));
      playSfx("pickup");
      vibrate(20);
      toast(d.kind === "ammo" ? `Picked up ${n} rounds of ${d.name}` : n > 1 ? `Picked up ${n} × ${d.name}` : `Picked up ${d.name}`, "good");
    } catch (e) {
      fail(e);
    } finally {
      setBusyDrop(null);
    }
  }

  async function split(p: Piece, n: number) {
    setBusy("split");
    try {
      await mutate(() => splitPiece(p.id, n));
      playSfx("snap");
      vibrate(12);
      toast(`Split into ${p.quantity - n} and ${n}`, "info");
      setSheet(null);
    } catch (e) {
      fail(e);
    } finally {
      setBusy(null);
    }
  }

  async function reload(p: Piece) {
    setBusy("reload");
    try {
      const r = await mutate(() => reloadGun(p.id));
      if (r.loaded <= p.loaded) {
        playSfx("dryfire");
        toast(r.reserve > 0 ? "It's already full." : "No spare rounds for this gun.", "info");
        return;
      }
      playSfx("reload");
      vibrate([15, 70, 15]);
      const n = ++reloadSeq.current;
      const ms = Math.max(300, Math.min(r.reloadMs || 1200, 6000));
      setReloading({ id: p.id, ms, n });
      window.setTimeout(() => {
        setReloading((cur) => (cur?.n === n ? null : cur));
        toast(`Reloaded: ${r.loaded}${p.magazine ? ` / ${p.magazine}` : ""} · ${r.reserve} spare`, "good");
      }, ms);
    } catch (e) {
      fail(e);
    } finally {
      setBusy(null);
    }
  }

  async function arrange() {
    setBusy("arrange");
    try {
      await mutate(() => arrangeCase());
      playSfx("snap");
      vibrate([10, 30, 10]);
      toast("Case arranged", "good");
    } catch (e) {
      fail(e);
    } finally {
      setBusy(null);
    }
  }

  function openItem(p: Piece, panel: ItemPanel = "main") {
    setSelectedId(p.id);
    setSheet({ kind: "item", id: p.id, panel });
  }

  // Must stay synchronous: the weapon screen needs this tap for sound,
  // motion sensors and full screen.
  function openWeapon(p: Piece) {
    setSheet(null);
    onOpenWeapon(p);
  }

  // ---- dragging -------------------------------------------------------------
  function commitDrag(d: DragView) {
    const p = d.piece;
    if (d.over === "drop") return requestDrop(p);
    if (d.over === "tray") {
      if (p.x !== null) {
        moveTo(p, null, null, d.rotated, "drop");
        toast(`${p.name} set aside`, "info");
      }
      return;
    }
    const g = d.ghost;
    if (d.over !== "grid" || !g) return; // let go outside: it goes back
    const target = g.targetId !== undefined ? everything.find((q) => q.id === g.targetId) : undefined;
    if (g.state === "ok") {
      if (p.x === g.box.x && p.y === g.box.y && p.rotated === d.rotated) return;
      moveTo(p, g.box.x, g.box.y, d.rotated);
    } else if (g.state === "merge" && target) mergeInto(p, target);
    else if (g.state === "mix" && target) void combine(p, target);
    else {
      playSfx("error");
      vibrate([25, 40, 25]);
      if (g.label) toast(g.label, "bad");
    }
  }

  const drag = useCaseDrag({
    enabled: !!s && !dead,
    cell,
    cols,
    rows,
    pieces: s?.pieces ?? [],
    gridRef,
    dropRefs: groundWhy ? [] : [dropBtnRef, dropZoneRef],
    trayRef,
    barRef,
    floatRef,
    onLongPress: (p) => openItem(p),
    onCommit: commitDrag,
  });
  const dv = drag.drag;

  function onPieceClick(p: Piece, e: MouseEvent<HTMLButtonElement>) {
    if (drag.consumeClick(e.detail)) return;
    openItem(p);
  }

  const ARROWS = { ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down" } as const;
  const STEP = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] } as const;

  function onPieceKey(p: Piece, e: KeyboardEvent<HTMLButtonElement>) {
    if (e.defaultPrevented || dv) return;
    const st = stateRef.current;
    if (!st) return;
    const dir = ARROWS[e.key as keyof typeof ARROWS];
    if (dir) {
      e.preventDefault();
      if (p.x === null || p.y === null) return;
      if (e.shiftKey) {
        // Shift + arrow moves the piece one cell.
        const [dx, dy] = STEP[dir];
        const fp = footprint(p, p.rotated);
        const box = { x: p.x + dx, y: p.y + dy, ...fp };
        if (!dead && fits(box, st.cols, st.rows, st.pieces, p.id)) moveTo(p, box.x, box.y, p.rotated);
        else playSfx("error");
        return;
      }
      const n = neighbour(st.pieces, p, dir);
      if (n) {
        setSelectedId(n.id);
        focusPiece(n.id);
      }
      return;
    }
    if (e.key === "r" || e.key === "R") {
      e.preventDefault();
      setSelectedId(p.id);
      rotateInPlace(p);
    } else if (e.key === "Delete" || e.key === "Backspace") {
      e.preventDefault();
      requestDrop(p);
    } else if (e.key === "Escape") {
      setSelectedId(null);
    }
  }

  // ---- render -----------------------------------------------------------
  const sheetPiece = sheet && sheet.kind !== "drops" ? everything.find((p) => p.id === sheet.id) ?? null : null;
  const occupied = (s?.pieces ?? []).reduce((n, p) => {
    const fp = footprint(p, p.rotated);
    return n + fp.w * fp.h;
  }, 0);
  const freeCells = Math.max(0, cols * rows - occupied);
  const draggingPlaced = !!dv && dv.piece.x !== null;
  const showTray = !!s && (s.tray.length > 0 || draggingPlaced);
  const hpForBar = hp;

  return (
    <div ref={wrapRef} className={`cs-screen ${compact ? "is-compact" : ""} ${reduceMotion ? "cs-reduce" : ""}`} data-no-use>
      {!s ? (
        error ? (
          <div className="flex flex-col gap-3 rounded-sm border-l-4 border-alert bg-alert/10 px-4 py-4" role="alert">
            <p className="font-semibold">{error}</p>
            <button type="button" className="cs-btn cs-btn-plain self-start" onClick={() => void load()}>
              <Icon name="refresh" className="h-5 w-5" /> Try again
            </button>
          </div>
        ) : (
          <div className="cs-skeleton" aria-busy="true">
            <Icon name="briefcase" className="h-10 w-10 text-white/25" />
            <span>Opening your case…</span>
          </div>
        )
      ) : (
        <>
          <div className="cs-top">
            {!compact && hpForBar && <HpBar hp={hpForBar} size="lg" />}
            <div className="flex flex-wrap items-center gap-2">
              <div className="min-w-0 basis-full min-[480px]:basis-0 min-[480px]:flex-1">
                <p className="truncate font-display text-lg font-bold leading-tight text-white">
                  Case {s.cols} × {s.rows}
                  {s.expansions > 0 && (
                    <span className="text-white/55">
                      {" "}
                      · {s.expansions} expansion{s.expansions === 1 ? "" : "s"}
                    </span>
                  )}
                </p>
                <p className="truncate text-xs font-semibold text-white/45">
                  {freeCells} free space{freeCells === 1 ? "" : "s"}
                  {s.tray.length > 0 ? ` · ${s.tray.length} set aside` : ""}
                </p>
              </div>
              <button
                type="button"
                className="cs-tool flex-1 min-[480px]:flex-none"
                data-sound="none"
                onClick={() => void arrange()}
                disabled={busy === "arrange" || everything.length === 0 || dead}
                aria-label="Arrange the case automatically"
              >
                <Icon name="arrange" className="h-5 w-5" />
                <span>{busy === "arrange" ? "…" : "Arrange"}</span>
              </button>
              <button
                ref={dropBtnRef}
                type="button"
                className={`cs-tool flex-1 min-[480px]:flex-none ${dv ? (dv.over === "drop" ? "is-target" : groundWhy ? "" : "is-armed") : ""}`}
                onClick={() => setSheet({ kind: "drops" })}
                aria-label={`Drop box, ${s.drops.length} item${s.drops.length === 1 ? "" : "s"}`}
              >
                <Icon name="drop" className="h-5 w-5" />
                <span>Drop box</span>
                {s.drops.length > 0 && (
                  <span key={s.drops.length} className="cs-count">
                    {s.drops.length}
                  </span>
                )}
              </button>
            </div>
          </div>

          <StatusBanner dead={dead} status={status} practiceFire={s.rules.practiceFire} compact={compact} />

          {error && (
            <div className="flex items-center justify-between gap-2 rounded-sm border-l-4 border-alert bg-alert/10 px-3 py-2 text-sm" role="alert">
              <span>Couldn't refresh the case. {error}</span>
              <button type="button" className="font-bold text-pine" onClick={() => void load()}>
                Retry
              </button>
            </div>
          )}

          <div className="cs-case-wrap">
            <CaseGrid
              cols={s.cols}
              rows={s.rows}
              cell={cell}
              chrome={chrome}
              compact={compact}
              pieces={s.pieces}
              selectedId={selectedId}
              liftedId={dv?.piece.id ?? null}
              ghost={dv?.over === "grid" ? dv.ghost : null}
              slots={slots}
              freshIds={freshIds}
              settleId={settleId}
              gridRef={gridRef}
              overlay={
                everything.length === 0 ? (
                  <div className="cs-empty">
                    <Icon name="briefcase" className="h-9 w-9" />
                    <p className="font-display text-lg font-bold text-white/80">{dead ? "Your gear went to the drop box" : "Your case is empty"}</p>
                    <p className="text-sm">{dead ? "The Admin can revive you." : "Buy gear in the Shop, or pick something up from the Drop box."}</p>
                  </div>
                ) : null
              }
              onPieceDown={(p, e) => drag.onPieceDown(p, e, cell)}
              onPieceClick={onPieceClick}
              onPieceKey={onPieceKey}
              onBackground={() => setSelectedId(null)}
            />
          </div>

          {showTray && (
            <section
              ref={trayRef}
              className={`cs-tray ${dv?.over === "tray" ? "is-target" : draggingPlaced ? "is-armed" : ""}`}
              aria-label="Doesn't fit in the case"
            >
              <p className="flex items-center gap-2 font-display text-base font-bold text-sun">
                <Icon name="info" className="h-5 w-5" />
                {s.tray.length > 0 ? "Doesn't fit — make room" : "Set aside"}
              </p>
              <p className="text-sm text-ink/65">
                {draggingPlaced
                  ? "Let go here to set it aside for now."
                  : "Drag these into the case when there's space, or drop them in the drop box."}
              </p>
              {s.tray.length > 0 && (
                <div className="mt-1 flex flex-wrap gap-2">
                  {s.tray.map((p) => (
                    <PieceView
                      key={p.id}
                      piece={p}
                      cell={trayCell}
                      placed={false}
                      selected={selectedId === p.id}
                      lifted={dv?.piece.id === p.id}
                      fresh={freshIds.has(p.id)}
                      tabIndex={0}
                      onPointerDown={(e) => drag.onPieceDown(p, e, trayCell)}
                      onClick={(e) => onPieceClick(p, e)}
                      onKeyDown={(e) => onPieceKey(p, e)}
                    />
                  ))}
                </div>
              )}
            </section>
          )}

          {!compact && everything.length > 0 && (
            <p className="cs-hint">
              <span>Drag to move</span>
              <span>Tap for options</span>
              <span>While dragging: 2nd finger or R turns it</span>
            </p>
          )}
        </>
      )}

      <ItemActionSheet
        open={sheet?.kind === "item" && !!sheetPiece}
        piece={sheet?.kind === "item" ? sheetPiece : null}
        panel={sheet?.kind === "item" ? sheet.panel : "main"}
        slot={sheetPiece ? slots.get(sheetPiece.id) : undefined}
        ctx={{ status, dead, practiceFire: s?.rules.practiceFire ?? true, hp, everything }}
        busy={busy}
        reload={reloading}
        onClose={() => setSheet(null)}
        onOpenWeapon={openWeapon}
        onReload={(p) => void reload(p)}
        onUse={(p) => void use(p)}
        onCombine={(p) => setSheet({ kind: "combine", id: p.id })}
        onSplit={(p, n) => void split(p, n)}
        onRotate={(p) => {
          if (rotateInPlace(p)) setSheet(null);
        }}
        onDrop={(p, n) => void drop(p, n)}
      />
      <CombineSheet
        open={sheet?.kind === "combine" && !!sheetPiece}
        piece={sheet?.kind === "combine" ? sheetPiece : null}
        everything={everything}
        busyWith={busyMix}
        blockedReason={groundWhy}
        onPick={(a, b) => void combine(a, b)}
        onBack={() => sheetPiece && setSheet({ kind: "item", id: sheetPiece.id, panel: "main" })}
        onClose={() => setSheet(null)}
      />
      <DropBox
        open={sheet?.kind === "drops"}
        drops={s?.drops ?? []}
        blockedReason={groundWhy}
        busyId={busyDrop}
        onPickup={(d, n) => void pickup(d, n)}
        onClose={() => setSheet(null)}
      />

      {dv &&
        createPortal(
          <div className={`cs-drag-layer ${reduceMotion ? "cs-reduce" : ""}`} data-no-use>
            <div
              ref={floatRef}
              className="cs-float"
              style={{
                ...drag.floatStyle(),
                width: footprint(dv.piece, dv.rotated).w * cell,
                height: footprint(dv.piece, dv.rotated).h * cell,
              }}
            >
              <span key={dv.rotated ? "r" : "n"} className={`cs-float-in ${dv.over === "grid" && dv.ghost?.state === "blocked" ? "is-blocked" : ""}`}>
                <PieceArt piece={dv.piece} cell={cell} rotated={dv.rotated} slot={slots.get(dv.piece.id)} />
              </span>
            </div>
            <div ref={barRef} className="cs-drag-bar">
              <DragStatus dv={dv} />
              <div className="cs-drag-row">
                {!groundWhy && (
                  <div ref={dropZoneRef} className={`cs-drag-target ${dv.over === "drop" ? "is-hot" : ""}`}>
                    <Icon name="drop" className="h-6 w-6" />
                    <span>
                      Drop box
                      <small>let go here to drop</small>
                    </span>
                  </div>
                )}
                {dv.piece.w !== dv.piece.h && (
                  <button type="button" className="cs-drag-rotate" tabIndex={-1} aria-label="Rotate" data-sound="none">
                    <Icon name="rotate" className="h-6 w-6" />
                    <span>
                      Rotate
                      <small>tap with a 2nd finger</small>
                    </span>
                  </button>
                )}
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
}

// One line above the Drop / Rotate bar saying what letting go would do.
function DragStatus({ dv }: { dv: DragView }) {
  let text = "Let go outside the case to put it back";
  let tone = "";
  if (dv.over === "drop") {
    text = "Let go to drop it";
    tone = "is-warn";
  } else if (dv.over === "tray") {
    text = "Let go to set it aside";
    tone = "is-warn";
  } else if (dv.over === "grid" && dv.ghost) {
    const g = dv.ghost;
    if (g.state === "ok") {
      text = "Fits here";
      tone = "is-ok";
    } else if (g.state === "merge") {
      text = `${g.label} to that pile`;
      tone = "is-warn";
    } else if (g.state === "mix") {
      text = g.label ?? "Mix";
      tone = "is-warn";
    } else {
      text = g.label ?? "Doesn't fit there";
      tone = "is-bad";
    }
  }
  return (
    <p className={`cs-drag-status ${tone}`} role="status" aria-live="polite">
      {text}
    </p>
  );
}

function StatusBanner({ dead, status, practiceFire, compact }: { dead: boolean; status: string; practiceFire: boolean; compact: boolean }) {
  if (dead) {
    return (
      <div className="cs-banner cs-banner-dead" role="status">
        <Icon name="skull" className="h-8 w-8 shrink-0" />
        <div>
          <p className="font-display text-xl font-bold uppercase tracking-wider">You're down</p>
          <p className="text-sm text-ink/80">You can look around, but you can't use, mix, drop or pick up items until the Admin revives you.</p>
        </div>
      </div>
    );
  }
  if (status === "paused" || status === "ended") {
    return (
      <div className="cs-banner cs-banner-hold" role="status">
        <Icon name={status === "paused" ? "pause" : "flag"} className="h-6 w-6 shrink-0" />
        <div>
          <p className="font-display text-lg font-bold">{status === "paused" ? "Game paused" : "Game over"}</p>
          <p className="text-sm text-ink/80">
            You can still arrange your case.
            {status === "ended" ? " Anything left in the drop box goes back to its owner." : ""}
          </p>
        </div>
      </div>
    );
  }
  if (status === "not_started" && !compact) {
    return (
      <p className="cs-banner cs-banner-wait" role="status">
        <Icon name="info" className="h-5 w-5 shrink-0" />
        <span>
          Waiting for the game to start. Healing works once it's on.
          {practiceFire ? " Guns fire in practice mode until then — no ammo used." : ""}
        </span>
      </p>
    );
  }
  return null;
}
