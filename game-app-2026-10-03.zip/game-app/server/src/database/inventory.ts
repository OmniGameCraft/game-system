import { DatabaseSync } from "node:sqlite";
import { imageUrlFor, ItemKind, UseEffect } from "./items";
import { clearUpgrades } from "./weapons";

// GIVE/REMOVE/SET are Admin changes; PURCHASE and SELL are written by the shop.
export type InventoryAction = "GIVE" | "REMOVE" | "SET" | "PURCHASE" | "SELL";
export type AdminInventoryAction = Exclude<InventoryAction, "PURCHASE" | "SELL">;

// Sanity cap on how many of one item a single player can hold or be given in
// one go — guards against typos, well inside SQLite/JS integer range.
export const MAX_ITEM_QUANTITY = 1_000_000;

export interface InventoryEntry {
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  enabled: boolean;
  maxStack: number | null;
  quantity: number;
  kind: ItemKind;
  ammoPerPack: number | null;
  ammoForItemId: number | null;
  sellable: boolean;
}

interface InventoryRow {
  item_id: number;
  name: string;
  description: string | null;
  category: string | null;
  image_file: string | null;
  model_file: string | null;
  sound_file: string | null;
  use_effect: UseEffect;
  model_flip: number;
  model_upside_down: number;
  enabled: number;
  max_stack: number | null;
  quantity: number;
  kind: ItemKind;
  ammo_per_pack: number | null;
  ammo_for_item_id: number | null;
  sellable: number;
}

export function listInventoryForPlayer(db: DatabaseSync, playerId: number): InventoryEntry[] {
  const rows = db
    .prepare(
      `SELECT inv.item_id, inv.quantity, i.name, i.description, i.category,
              i.image_file, i.model_file, i.sound_file, i.use_effect,
              i.model_flip, i.model_upside_down, i.enabled, i.max_stack,
              i.kind, i.ammo_per_pack, i.ammo_for_item_id, i.sellable
         FROM inventory inv
         JOIN items i ON i.id = inv.item_id
        WHERE inv.player_id = ?
        ORDER BY i.name COLLATE NOCASE`
    )
    .all(playerId) as unknown as InventoryRow[];
  return rows.map((r) => ({
    itemId: r.item_id,
    name: r.name,
    description: r.description,
    category: r.category,
    imageUrl: imageUrlFor(r.image_file),
    modelUrl: imageUrlFor(r.model_file),
    soundUrl: imageUrlFor(r.sound_file),
    useEffect: r.use_effect,
    modelFlip: r.model_flip === 1,
    modelUpsideDown: r.model_upside_down === 1,
    enabled: r.enabled === 1,
    maxStack: r.max_stack,
    quantity: r.quantity,
    kind: r.kind,
    ammoPerPack: r.ammo_per_pack,
    ammoForItemId: r.ammo_for_item_id,
    sellable: r.sellable === 1,
  }));
}

export interface InventoryLogEntry {
  id: number;
  itemId: number;
  itemName: string;
  action: InventoryAction;
  quantityBefore: number;
  quantityAfter: number;
  performedBy: number;
  createdAt: string;
}

export function listInventoryLog(db: DatabaseSync, playerId: number): InventoryLogEntry[] {
  const rows = db
    .prepare(
      `SELECT l.*, i.name AS item_name
         FROM inventory_log l
         JOIN items i ON i.id = l.item_id
        WHERE l.player_id = ?
        ORDER BY l.id DESC`
    )
    .all(playerId) as unknown as Array<{
    id: number;
    item_id: number;
    item_name: string;
    action: InventoryAction;
    quantity_before: number;
    quantity_after: number;
    performed_by: number;
    created_at: string;
  }>;
  return rows.map((r) => ({
    id: r.id,
    itemId: r.item_id,
    itemName: r.item_name,
    action: r.action,
    quantityBefore: r.quantity_before,
    quantityAfter: r.quantity_after,
    performedBy: r.performed_by,
    createdAt: r.created_at,
  }));
}

// A rule the request broke (message is safe to show the Admin as-is).
export class InventoryRuleError extends Error {}
export class ItemNotFoundError extends Error {}

// Changes how many of one item a player holds and writes the audit row,
// WITHOUT opening a transaction — callers wrap it (changeInventory below,
// and the shop's buy/sell). PURCHASE behaves like GIVE, but the messages are
// written for the player instead of the Admin.
//
// `cost` is money the player paid for the units added (purchases); it is
// added to inventory.spent. Removing units takes away the same share of
// `spent` (average cost) and reports it as `spentRemoved`, which the shop
// uses to price a sale. When the last unit goes, the weapon's upgrades go too.
export function applyInventoryChange(
  db: DatabaseSync,
  input: {
    playerId: number;
    itemId: number;
    action: InventoryAction;
    quantity: number;
    performedBy: number;
    cost?: number;
  }
): { quantity: number; before: number; spentRemoved: number } {
  const { playerId, itemId, action, quantity, performedBy } = input;
  const forPlayer = action === "PURCHASE" || action === "SELL";

  const item = db
    .prepare("SELECT name, enabled, max_stack FROM items WHERE id = ?")
    .get(itemId) as { name: string; enabled: number; max_stack: number | null } | undefined;
  if (!item) throw new ItemNotFoundError("Item not found.");

  const row = db
    .prepare("SELECT quantity, spent FROM inventory WHERE player_id = ? AND item_id = ?")
    .get(playerId, itemId) as { quantity: number; spent: number } | undefined;
  const before = row?.quantity ?? 0;
  const spentBefore = row?.spent ?? 0;
  const after =
    action === "GIVE" || action === "PURCHASE"
      ? before + quantity
      : action === "REMOVE" || action === "SELL"
      ? before - quantity
      : quantity;

  if (after < 0) {
    throw new InventoryRuleError(
      forPlayer
        ? before === 0
          ? `You don't have any ${item.name}.`
          : `You only have ${before} ${item.name}.`
        : before === 0
        ? `This player doesn't have any ${item.name}.`
        : `This player only has ${before} ${item.name}.`
    );
  }
  if (after === before) {
    throw new InventoryRuleError(`This player already has ${before} ${item.name}.`);
  }
  if (after > before) {
    // Anything that increases the count counts as giving.
    if (item.enabled !== 1) {
      throw new InventoryRuleError(
        forPlayer
          ? `${item.name} isn't available right now.`
          : `${item.name} is disabled. Enable it before giving it out.`
      );
    }
    if (item.max_stack !== null && after > item.max_stack) {
      throw new InventoryRuleError(
        forPlayer
          ? `You can carry at most ${item.max_stack} ${item.name}. You have ${before}.`
          : `A player can hold at most ${item.max_stack} ${item.name}. This player has ${before}.`
      );
    }
    if (after > MAX_ITEM_QUANTITY) {
      throw new InventoryRuleError(`A player can hold at most ${MAX_ITEM_QUANTITY} of one item.`);
    }
  }

  // Money tracking: added units bring their cost; removed units take their
  // share of what was spent (exact for the last unit, so nothing is lost
  // to rounding).
  let spentAfter = spentBefore;
  let spentRemoved = 0;
  if (after > before) {
    spentAfter = spentBefore + Math.max(0, Math.floor(input.cost ?? 0));
  } else if (after < before) {
    spentRemoved = after === 0 ? spentBefore : Math.floor((spentBefore * (before - after)) / before);
    spentAfter = spentBefore - spentRemoved;
  }

  if (after === 0) {
    db.prepare("DELETE FROM inventory WHERE player_id = ? AND item_id = ?").run(playerId, itemId);
    clearUpgrades(db, playerId, itemId);
  } else if (before === 0) {
    db.prepare("INSERT INTO inventory (player_id, item_id, quantity, spent) VALUES (?, ?, ?, ?)").run(
      playerId,
      itemId,
      after,
      spentAfter
    );
  } else {
    db.prepare("UPDATE inventory SET quantity = ?, spent = ? WHERE player_id = ? AND item_id = ?").run(
      after,
      spentAfter,
      playerId,
      itemId
    );
  }

  db.prepare(
    `INSERT INTO inventory_log
       (player_id, item_id, action, quantity_before, quantity_after, performed_by)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(playerId, itemId, action, before, after, performedBy);

  return { quantity: after, before, spentRemoved };
}

// Adds money spent on a weapon upgrade to what the player has spent on it.
export function addSpent(db: DatabaseSync, playerId: number, itemId: number, amount: number): void {
  db.prepare("UPDATE inventory SET spent = spent + ? WHERE player_id = ? AND item_id = ?").run(amount, playerId, itemId);
}

export function getHolding(
  db: DatabaseSync,
  playerId: number,
  itemId: number
): { quantity: number; spent: number } | undefined {
  return db
    .prepare("SELECT quantity, spent FROM inventory WHERE player_id = ? AND item_id = ?")
    .get(playerId, itemId) as { quantity: number; spent: number } | undefined;
}

// Admin give/remove/set as one atomic step. Same reasoning as adjustBalance
// in money.ts: everything is synchronous, so no other request can run
// between reading the current quantity and writing — two quick taps can't
// both pass the max-per-player check and overshoot it.
export function changeInventory(
  db: DatabaseSync,
  input: {
    playerId: number;
    itemId: number;
    action: "GIVE" | "REMOVE" | "SET";
    quantity: number;
    performedBy: number;
  }
): { quantity: number } {
  db.exec("BEGIN");
  try {
    const result = applyInventoryChange(db, input);
    db.exec("COMMIT");
    return { quantity: result.quantity };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
