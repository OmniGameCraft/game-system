// Square picture for an item, or the item's first letter when there's no
// picture yet.
export function ItemImage({
  url,
  name,
  size = "md",
}: {
  url: string | null;
  name: string;
  size?: "sm" | "md" | "lg";
}) {
  const box = size === "lg" ? "h-28 w-28 text-4xl" : size === "sm" ? "h-12 w-12 text-lg" : "h-16 w-16 text-2xl";
  if (url) {
    return (
      <img
        src={url}
        alt=""
        className={`${box} shrink-0 rounded-xl border-2 border-ink/10 bg-paper object-contain`}
      />
    );
  }
  return (
    <div
      aria-hidden
      className={`${box} flex shrink-0 items-center justify-center rounded-xl bg-pine-soft font-bold text-pine`}
    >
      {name.trim().charAt(0).toUpperCase() || "?"}
    </div>
  );
}
