import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";

// One live connection per logged-in browser tab. The server only sends short
// "X changed" notices; screens react by re-loading their data through the
// normal API, so nothing private ever travels over this channel.
//
// socket.io-client is bundled into the app, so this works with no internet.

export type LiveEvent =
  | "me:changed"
  | "player:changed"
  | "players:changed"
  | "items:changed"
  | "shop:changed"
  | "game:changed"
  | "session:ended";

let socket: Socket | null = null;
type StatusListener = (connected: boolean) => void;
const statusListeners = new Set<StatusListener>();
let connected = false;

// Screens register here whether or not the connection exists yet (React
// runs a screen's effects before App's), and every notice is dispatched
// from this list.
type Handler = (payload?: any) => void;
const handlers = new Map<LiveEvent | "reconnected", Set<Handler>>();

function dispatch(event: LiveEvent | "reconnected", payload?: any) {
  handlers.get(event)?.forEach((h) => {
    try {
      h(payload);
    } catch {
      // one broken screen shouldn't stop the others updating
    }
  });
}

function setConnected(v: boolean) {
  connected = v;
  statusListeners.forEach((l) => l(v));
}

export function connectLive(): void {
  if (socket) return;
  let everConnected = false;
  socket = io({
    path: "/socket.io",
    withCredentials: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
  });
  socket.on("connect", () => {
    setConnected(true);
    // After a reconnect (Wi-Fi dropped, server restarted) notices may have
    // been missed, so every screen re-loads once.
    if (everConnected) dispatch("reconnected");
    everConnected = true;
  });
  socket.on("disconnect", () => setConnected(false));
  socket.on("connect_error", (err) => {
    setConnected(false);
    // The server refused this session (it expired, or the server was
    // restarted and everyone has to log in again).
    if (err?.message === "unauthorized") dispatch("session:ended", { reason: "expired" });
  });
  socket.onAny((event: string, payload?: any) => dispatch(event as LiveEvent, payload));
}

export function disconnectLive(): void {
  socket?.removeAllListeners();
  socket?.disconnect();
  socket = null;
  setConnected(false);
}

// Calls `handler` whenever one of `events` arrives, and (unless
// `onReconnect` is false) once after the connection comes back.
export function useLive(
  events: LiveEvent[],
  handler: (payload?: any) => void,
  onReconnect = true
): void {
  const ref = useRef(handler);
  ref.current = handler;
  const key = events.join(",");
  useEffect(() => {
    const fn: Handler = (payload) => ref.current(payload);
    const all = (onReconnect ? [...events, "reconnected"] : events) as (LiveEvent | "reconnected")[];
    for (const e of all) {
      if (!handlers.has(e)) handlers.set(e, new Set());
      handlers.get(e)!.add(fn);
    }
    return () => {
      for (const e of all) handlers.get(e)?.delete(fn);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, onReconnect]);
}

export function useLiveStatus(): boolean {
  const [v, setV] = useState(connected);
  useEffect(() => {
    statusListeners.add(setV);
    setV(connected);
    return () => {
      statusListeners.delete(setV);
    };
  }, []);
  return v;
}
