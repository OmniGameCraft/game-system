import { useEffect, useRef, useState } from "react";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { Section, SectionAction } from "../../components/Section";
import { getHits, HitEntry } from "../../services/api";
import { useLive } from "../../services/live";
import { HitRow } from "./hits";
import { HP_CHANGED } from "./liveEvents";

type Filter = "all" | "hits";

// Live list of hits and healing, newest first. A voice call heard by several
// phones shows once, with "heard by 3 phones".
export function HitsFeed({ windowMs }: { windowMs: number }) {
  const [hits, setHits] = useState<HitEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [showAll, setShowAll] = useState(false);
  // Rows that just arrived glow for a moment.
  const [fresh, setFresh] = useState<Set<number>>(new Set());
  const seen = useRef<Set<number> | null>(null);
  const timers = useRef<number[]>([]);

  function load() {
    getHits()
      .then((list) => {
        if (seen.current) {
          const added = list.filter((h) => !seen.current!.has(h.id)).map((h) => h.id);
          if (added.length) {
            setFresh(new Set(added));
            timers.current.push(window.setTimeout(() => setFresh(new Set()), 1600));
          }
        }
        seen.current = new Set(list.map((h) => h.id));
        setHits(list);
        setError(null);
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Couldn't load the hits."));
  }

  useEffect(() => {
    load();
    return () => timers.current.forEach((t) => window.clearTimeout(t));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Other phones that heard the same call only raise its "heard by" count,
  // which doesn't change anyone's HP — so look again a little later too.
  useLive([HP_CHANGED], () => {
    load();
    timers.current.push(window.setTimeout(load, 1500));
    timers.current.push(window.setTimeout(load, windowMs + 500));
    if (timers.current.length > 30) timers.current = timers.current.slice(-30);
  });

  const list = (hits ?? []).filter((h) => (filter === "hits" ? h.kind === "HIT" || h.kind === "DEATH" : h.kind !== "RESET"));
  const shown = showAll ? list : list.slice(0, 12);

  return (
    <Section
      title="Hits & healing"
      action={
        <SectionAction onClick={load}>
          <Icon name="refresh" className="h-4 w-4" />
          Refresh
        </SectionAction>
      }
      flush
    >
      <div className="flex gap-1 border-b border-panel-line p-2" role="tablist" aria-label="Show">
        {(
          [
            ["all", "Everything"],
            ["hits", "Hits only"],
          ] as [Filter, string][]
        ).map(([k, label]) => (
          <button
            key={k}
            role="tab"
            aria-selected={filter === k}
            onClick={() => setFilter(k)}
            className={`chamfer-sm min-h-[2.5rem] flex-1 font-display font-semibold ${filter === k ? "bg-pine text-pine-ink" : "text-ink/65"}`}
          >
            {label}
          </button>
        ))}
      </div>
      <ErrorBanner message={error} />
      {hits === null && !error && <p className="p-4 text-ink/60">Loading…</p>}
      {hits !== null && list.length === 0 && (
        <p className="p-4 text-ink/60">
          Nothing yet. When someone calls “three, forty” near a listening phone, Player 3's hit shows up here straight away.
        </p>
      )}
      {shown.length > 0 && (
        <ul className="divide-y divide-panel-line">
          {shown.map((h) => (
            <HitRow
              key={h.id}
              h={h}
              className={`transition-colors duration-1000 ${fresh.has(h.id) ? (h.kind === "HIT" || h.kind === "DEATH" ? "bg-alert/15" : "bg-olive/15") : ""}`}
            />
          ))}
        </ul>
      )}
      {list.length > 12 && (
        <button
          type="button"
          onClick={() => setShowAll((v) => !v)}
          className="min-h-[3rem] w-full border-t border-panel-line font-semibold text-pine active:bg-pine-soft"
        >
          {showAll ? "Show fewer" : `Show all ${list.length}`}
        </button>
      )}
    </Section>
  );
}
