import { DatabaseSync } from "node:sqlite";
import { transaction } from "../database/db";
import { applyInventoryChange } from "../database/inventory";
import { findItemByName, HerbCode, imageUrlFor, Item } from "../database/items";
import { createItemFromPack, findPackItemByHerbCode } from "../routes/packs";
import { CaseError, ownPiece } from "./grid";
import { gate } from "./play";

// Herb mixing. Herbs have a code: G (green), R (red), Y (yellow), or the
// mix they already are. Mixing two pieces puts all their letters together
// (sorted G, R, Y) and only these results exist — every one has a Green
// Herb in it:
//   G+G = GG    heals 60          G+R = GR    max HP +20 (filled)
//   G+Y = GY    heals 45          G+R+Y = GRY heals 50, max HP +15
//   G+G+Y = GGY restores all HP
// The healing numbers live on each item (the Admin can rebalance them).

export const MIX_RESULTS: readonly HerbCode[] = ["GG", "GR", "GY", "GRY", "GGY"];
const LETTERS = "GRY";

// The letters of two herbs together, in G, R, Y order ("Y" + "G" → "GY").
export function mixLetters(a: string, b: string): string {
  return (a + b)
    .split("")
    .sort((x, y) => LETTERS.indexOf(x) - LETTERS.indexOf(y))
    .join("");
}

// What two herbs make, or null if they don't mix.
export function mixResult(a: HerbCode, b: HerbCode): HerbCode | null {
  const letters = mixLetters(a, b);
  return (MIX_RESULTS as readonly string[]).includes(letters) ? (letters as HerbCode) : null;
}

export function mixError(a: HerbCode, b: HerbCode): string {
  return mixLetters(a, b) === "RY"
    ? "Red and Yellow need a Green Herb to mix."
    : "These herbs don't mix. Every mix needs a Green Herb.";
}

// The catalogue item for a herb code (a healing item first, then an
// enabled one, then the oldest).
export function findHerbItem(db: DatabaseSync, code: HerbCode): Item | undefined {
  return db
    .prepare("SELECT * FROM items WHERE herb_code = ? ORDER BY kind = 'healing' DESC, enabled DESC, id LIMIT 1")
    .get(code) as Item | undefined;
}

// The item a mix makes. If the Admin hasn't added it yet, it's created
// from the item pack right now (exactly like "Add from item pack"), so
// mixing always works.
function resultItem(db: DatabaseSync, code: HerbCode): { item: Item; created: boolean } {
  const existing = findHerbItem(db, code);
  if (existing) return { item: existing, created: false };
  const found = findPackItemByHerbCode(code);
  if (!found || findItemByName(db, found.item.name)) {
    throw new CaseError("Ask the Admin to add the Mixed Herb items first.");
  }
  return { item: createItemFromPack(db, found.pack, found.item), created: true };
}

// What a mix gives, for the "Combine" sheet's preview ("Mixed Herb (G+Y) —
// heals 45 HP"). From the catalogue, or the item pack if it isn't added yet.
export interface MixPreview {
  code: HerbCode;
  name: string;
  imageUrl: string | null;
  healAmount: number | null;
  maxHpBonus: number | null;
  fullHeal: boolean;
}

export function mixPreviews(db: DatabaseSync, codes: Iterable<HerbCode>): Partial<Record<HerbCode, MixPreview>> {
  const out: Partial<Record<HerbCode, MixPreview>> = {};
  for (const code of codes) {
    const item = findHerbItem(db, code);
    if (item) {
      out[code] = {
        code,
        name: item.name,
        imageUrl: imageUrlFor(item.image_file),
        healAmount: item.heal_amount,
        maxHpBonus: item.max_hp_bonus,
        fullHeal: item.full_heal === 1,
      };
      continue;
    }
    const found = findPackItemByHerbCode(code);
    if (!found) continue; // can't be made: the sheet simply won't offer it
    const pi = found.item;
    out[code] = {
      code,
      name: pi.name,
      imageUrl: pi.picture ? `/packs/${found.pack.id}/${pi.picture}` : null,
      healAmount: pi.healAmount ?? null,
      maxHpBonus: pi.maxHpBonus ?? null,
      fullHeal: pi.fullHeal === true,
    };
  }
  return out;
}

export interface CombineResult {
  item: { id: number; name: string; herbCode: HerbCode };
  pieceId: number | null; // the new piece (null when it topped up a stack)
  createdItem: boolean; // the mixed herb was just added to the catalogue
}

// Mixes one unit of each piece into one unit of the result (each logged
// MIX). The result lands where the first herb was when it fits there. The
// money spent on the herbs carries over to the mix (for selling it back).
// Mixing the same piece with itself works when it holds two or more.
export function combine(
  db: DatabaseSync,
  playerId: number,
  input: { pieceId: unknown; withPieceId: unknown }
): CombineResult {
  return transaction(db, () => {
    const a = ownPiece(db, playerId, input.pieceId);
    const b = ownPiece(db, playerId, input.withPieceId);
    gate(db, playerId, "mix");
    if (a.piece.id === b.piece.id && a.piece.quantity < 2) {
      throw new CaseError("Choose another herb to mix it with.");
    }
    const ca = a.item.herb_code;
    const cb = b.item.herb_code;
    if (!ca || !cb) throw new CaseError("Only herbs can be mixed.");
    const code = mixResult(ca, cb);
    if (!code) throw new CaseError(mixError(ca, cb));

    const { item: result, created } = resultItem(db, code);
    const where = a.piece.x !== null && a.piece.y !== null ? { x: a.piece.x, y: a.piece.y } : null;
    let spent = 0;
    for (const used of [a, b]) {
      spent += applyInventoryChange(db, {
        playerId,
        itemId: used.item.id,
        action: "MIX",
        direction: "remove",
        quantity: 1,
        performedBy: playerId,
        pieces: { takeFrom: used.piece.id },
      }).spentRemoved;
    }
    const made = applyInventoryChange(db, {
      playerId,
      itemId: result.id,
      action: "MIX",
      direction: "add",
      quantity: 1,
      performedBy: playerId,
      cost: spent,
      pieces: { placeAt: where },
    });
    return {
      item: { id: result.id, name: result.name, herbCode: code },
      pieceId: made.sync?.created[0] ?? null,
      createdItem: created,
    };
  });
}
