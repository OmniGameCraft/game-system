import { useEffect, useState } from "react";
import { ErrorBanner } from "../../components/ErrorBanner";
import { Icon } from "../../components/Icon";
import { Section, SectionAction } from "../../components/Section";
import { CaseView, getAdminPlayerCase } from "../../services/api";
import { useLive } from "../../services/live";
import { DROPS_CHANGED, RULES_CHANGED } from "./liveEvents";
import { CaseGrid } from "./ui";

// The player's case exactly as they see it, read-only. Players arrange
// their own case; the Admin can watch it update live.
export function CaseSection({ playerId }: { playerId: number }) {
  const [view, setView] = useState<CaseView | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const [tick, setTick] = useState(0);
  useLive(["player:changed", "items:changed", DROPS_CHANGED, RULES_CHANGED], (payload) => {
    if (!payload || payload.playerId === undefined || payload.playerId === playerId) setTick((t) => t + 1);
  });

  useEffect(() => {
    setLoading(true);
    getAdminPlayerCase(playerId)
      .then((v) => {
        setView(v);
        setError(null);
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Couldn't load the case."))
      .finally(() => setLoading(false));
  }, [playerId, tick]);

  const title = view
    ? `Case ${view.cols} × ${view.rows}${view.expansions > 0 ? ` (${view.expansions} expansion${view.expansions === 1 ? "" : "s"})` : ""}`
    : "Case";

  return (
    <Section
      title={title}
      action={
        <SectionAction onClick={() => setTick((t) => t + 1)} disabled={loading}>
          <Icon name="refresh" className="h-4 w-4" />
          {loading ? "…" : "Refresh"}
        </SectionAction>
      }
    >
      <ErrorBanner message={error} />
      {!view && !error && <p className="text-ink/60">Loading…</p>}
      {view && <CaseGrid view={view} />}
      <p className="text-sm text-ink/55">
        Read-only: players move and turn their own items. Items you give that don't fit wait in their tray until they make room.
      </p>
    </Section>
  );
}
