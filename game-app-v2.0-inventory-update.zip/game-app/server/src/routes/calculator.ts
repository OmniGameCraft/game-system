import { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { requireRole } from "../auth/middleware";
import { calculatorSnapshot, CalculatorError, updateCalculator } from "../database/calculator";
import { live } from "../realtime";

// Admin: /api/admin/calculator — the Calc tab (gun power in handgun rounds,
// voice-call damage, bosses, the team's ammo). See database/calculator.ts.
//
// GET → { config: { hpPerHandgunRound, damagePerLevel, bosses }, defaults,
//         limits, maxLevel, guns, firepower }
//   firepower is worked out live from what players hold right now; reload it
//   when players or the drop box change (player:changed, drops:changed).
// PUT body: any of { hpPerHandgunRound, damagePerLevel, bosses, hre }
//   (hre = { [gun item id]: handgun rounds per round, or null for 1 }).
//   Answers with the same as GET.
export function createCalculatorRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  router.get("/", (_req, res) => {
    res.json(calculatorSnapshot(db));
  });

  router.put("/", (req, res) => {
    let update: ReturnType<typeof updateCalculator>;
    try {
      update = updateCalculator(db, req.body);
    } catch (err) {
      if (err instanceof CalculatorError) {
        res.status(400).json({ error: err.message });
        return;
      }
      res.status(500).json({ error: "Could not save the calculator. Nothing was changed." });
      return;
    }
    // A gun's handgun-round value is part of the item (its page shows it).
    if (update.hreChanged) live.itemsChanged();
    // Damage % per upgrade level changed for every gun: the shop's upgrade
    // tab and every player's weapon numbers show it.
    if (update.damagePerLevelChanged) {
      live.shopChanged();
      live.allPlayersChanged();
    }
    res.json(calculatorSnapshot(db));
  });

  return router;
}
