import { DatabaseSync } from "node:sqlite";
import { Item, ItemKind } from "./items";

// Weapon upgrades. Guns have a magazine and a damage upgrade; knives have
// sharpness and length. Each goes from level 1 (as bought) to level 5.
// The Admin sets a base price per upgrade; each next level costs double:
// level 2 = base, 3 = 2×base, 4 = 4×base, 5 = 8×base.
//
// Damage is shown as a level only and changes nothing in the game yet; the
// money spent on it still counts toward the weapon's sell value.

export type Track = "magazine" | "damage" | "sharpness" | "length";
export const TRACKS: Track[] = ["magazine", "damage", "sharpness", "length"];
export const MAX_LEVEL = 5;

export const TRACKS_FOR: Partial<Record<ItemKind, Track[]>> = {
  gun: ["magazine", "damage"],
  knife: ["sharpness", "length"],
};

export function tracksFor(kind: ItemKind): Track[] {
  return TRACKS_FOR[kind] ?? [];
}

export function basePriceFor(item: Item, track: Track): number | null {
  switch (track) {
    case "magazine":
      return item.up_price_magazine;
    case "damage":
      return item.up_price_damage;
    case "sharpness":
      return item.up_price_sharpness;
    case "length":
      return item.up_price_length;
  }
}

// Price to go from `currentLevel` to the next one.
export function upgradeCost(basePrice: number, currentLevel: number): number {
  return basePrice * 2 ** (currentLevel - 1);
}

// Sensible starting values when the Admin hasn't set them.
export const DEFAULT_BASE = { magazine: 12, sharpness: 10, length: 20 };

// The stat a track gives at a level. Magazine grows ~20% per level (always
// at least +1), sharpness ~15% (at least +1), length +1 cm per level.
// Damage has no number yet.
export function statAt(item: Item, track: Track, level: number): number | null {
  if (track === "damage") return null;
  if (track === "length") return (item.base_length ?? DEFAULT_BASE.length) + (level - 1);
  const base = track === "magazine" ? item.base_magazine ?? DEFAULT_BASE.magazine : item.base_sharpness ?? DEFAULT_BASE.sharpness;
  const growth = track === "magazine" ? 0.2 : 0.15;
  let v = base;
  for (let l = 2; l <= level; l++) v = Math.max(v + 1, Math.round(base * (1 + growth * (l - 1))));
  return v;
}

export function levelsFor(db: DatabaseSync, playerId: number, itemId: number): Record<Track, number> {
  const out: Record<Track, number> = { magazine: 1, damage: 1, sharpness: 1, length: 1 };
  for (const r of db
    .prepare("SELECT track, level FROM weapon_upgrades WHERE player_id = ? AND item_id = ?")
    .all(playerId, itemId) as unknown as Array<{ track: Track; level: number }>) {
    out[r.track] = r.level;
  }
  return out;
}

export interface TrackView {
  track: Track;
  level: number;
  maxLevel: number;
  value: number | null; // stat now (null for damage)
  nextValue: number | null; // stat after the next upgrade
  nextCost: number | null; // null = maxed out, or the Admin hasn't priced it yet
  available: boolean;
}

// What a player sees for one weapon they own.
export function weaponView(db: DatabaseSync, playerId: number, item: Item): TrackView[] {
  const levels = levelsFor(db, playerId, item.id);
  return tracksFor(item.kind).map((track) => {
    const level = levels[track];
    const base = basePriceFor(item, track);
    const maxed = level >= MAX_LEVEL;
    return {
      track,
      level,
      maxLevel: MAX_LEVEL,
      value: statAt(item, track, level),
      nextValue: maxed ? null : statAt(item, track, level + 1),
      nextCost: maxed || base === null ? null : upgradeCost(base, level),
      available: !maxed && base !== null,
    };
  });
}

export function clearUpgrades(db: DatabaseSync, playerId: number, itemId: number): void {
  db.prepare("DELETE FROM weapon_upgrades WHERE player_id = ? AND item_id = ?").run(playerId, itemId);
}

export function setLevel(db: DatabaseSync, playerId: number, itemId: number, track: Track, level: number): void {
  db.prepare(
    `INSERT INTO weapon_upgrades (player_id, item_id, track, level) VALUES (?, ?, ?, ?)
     ON CONFLICT(player_id, item_id, track) DO UPDATE SET level = excluded.level`
  ).run(playerId, itemId, track, level);
}

export const TRACK_LABEL: Record<Track, string> = {
  magazine: "Magazine",
  damage: "Damage",
  sharpness: "Sharpness",
  length: "Length",
};
