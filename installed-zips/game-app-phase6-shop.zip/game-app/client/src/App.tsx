import { useEffect, useState } from "react";
import { AdminSetupForm } from "./pages/AdminSetupForm";
import { LoginForm } from "./pages/LoginForm";
import { RoleSelect } from "./pages/RoleSelect";
import { AdminHome } from "./pages/AdminHome";
import { PlayerHome } from "./pages/PlayerHome";
import { setUnauthorizedHandler } from "./services/authEvents";
import {
  AuthStatus,
  getAuthStatus,
  getCurrentUser,
  logout as apiLogout,
  PublicUser,
  Role,
} from "./services/api";

type Screen = { name: "loading" } | { name: "role" } | { name: "login"; role: Role };

export default function App() {
  const [status, setStatus] = useState<AuthStatus | null>(null);
  const [user, setUser] = useState<PublicUser | null | undefined>(undefined); // undefined = not checked yet
  const [screen, setScreen] = useState<Screen>({ name: "loading" });
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    let alive = true;
    Promise.all([getAuthStatus(), getCurrentUser()])
      .then(([s, u]) => {
        if (!alive) return;
        setStatus(s);
        setUser(u);
        setScreen({ name: "role" });
      })
      .catch(() => alive && setLoadError(true));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(() => {
      setUser(null);
      setScreen({ name: "role" });
    });
    return () => setUnauthorizedHandler(null);
  }, []);

  async function handleLogout() {
    await apiLogout().catch(() => {});
    setUser(null);
    setScreen({ name: "role" });
  }

  function handleAuthed(u: PublicUser) {
    setUser(u);
    setStatus((s) => (s ? { ...s, hasAdmin: true } : s));
  }

  async function refreshUser() {
    const u = await getCurrentUser();
    if (u) setUser(u);
  }

  let body: React.ReactNode;

  if (loadError) {
    body = (
      <p className="rounded-xl border-2 border-alert bg-white px-4 py-4 text-alert">
        Can't reach the server. Check your Wi-Fi and try again.
      </p>
    );
  } else if (user === undefined || !status) {
    body = <p className="text-center text-lg text-ink/60">Loading…</p>;
  } else if (user) {
    // Logged-in screens bring their own top bar and navigation.
    return user.role === "admin" ? (
      <AdminHome user={user} onLogout={handleLogout} />
    ) : (
      <PlayerHome user={user} onLogout={handleLogout} onRefresh={refreshUser} />
    );
  } else if (screen.name === "role") {
    body = (
      <RoleSelect
        onSelect={(role) => setScreen({ name: "login", role })}
      />
    );
  } else if (screen.name === "login") {
    const { role } = screen;
    if (role === "admin" && !status.hasAdmin) {
      body = (
        <AdminSetupForm
          onSuccess={handleAuthed}
          onBack={() => setScreen({ name: "role" })}
        />
      );
    } else {
      body = (
        <LoginForm
          role={role}
          hint={
            role === "player" && !status.hasPlayers
              ? "No player accounts exist yet. Ask your Admin to create one."
              : undefined
          }
          onSuccess={handleAuthed}
          onBack={() => setScreen({ name: "role" })}
        />
      );
    }
  } else {
    // Not reachable in normal use (screen only ever holds "role" or "login"
    // once loading finishes), kept so `body` is always assigned.
    body = <p className="text-center text-lg text-ink/60">Loading…</p>;
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-8 px-6 py-10">
      <header className="text-center">
        <h1 className="text-4xl font-extrabold tracking-tight text-pine">Game System</h1>
      </header>
      {body}
    </main>
  );
}
