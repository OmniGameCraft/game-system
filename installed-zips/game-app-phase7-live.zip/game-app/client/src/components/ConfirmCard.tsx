import { Button } from "./Button";

export function ConfirmCard({
  title,
  body,
  confirmLabel,
  onConfirm,
  onCancel,
  loading,
  tone = "danger",
}: {
  title: string;
  body: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
  tone?: "danger" | "primary";
}) {
  return (
    <div
      className={`flex flex-col gap-3 rounded-2xl border-2 p-4 ${
        tone === "danger" ? "border-alert bg-alert/5" : "border-pine bg-pine-soft"
      }`}
    >
      <p className="text-xl font-bold text-ink">{title}</p>
      <p className="text-ink/75">{body}</p>
      <div className="flex gap-3">
        <Button variant="ghost" size="md" onClick={onCancel} disabled={loading}>
          Cancel
        </Button>
        <Button variant={tone === "danger" ? "danger" : "primary"} size="md" onClick={onConfirm} loading={loading}>
          {confirmLabel}
        </Button>
      </div>
    </div>
  );
}
