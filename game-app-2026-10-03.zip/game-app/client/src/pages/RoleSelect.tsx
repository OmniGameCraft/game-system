import { Icon } from "../components/Icon";
import { Role } from "../services/api";

export function RoleSelect({ onSelect }: { onSelect: (role: Role) => void }) {
  return (
    <div className="flex flex-col gap-4">
      <button
        onClick={() => onSelect("player")}
        className="chamfer flex items-center gap-4 bg-pine px-5 py-6 text-left text-pine-ink transition-transform active:scale-[0.98]"
      >
        <Icon name="users" className="h-10 w-10 shrink-0" />
        <span>
          <span className="block font-display text-3xl font-bold">Player</span>
          <span className="text-base font-medium text-pine-ink/75">Join the game</span>
        </span>
      </button>
      <button
        onClick={() => onSelect("admin")}
        className="chamfer flex items-center gap-4 bg-panel px-5 py-6 text-left text-ink transition-transform active:scale-[0.98]"
      >
        <Icon name="flag" className="h-10 w-10 shrink-0 text-pine" />
        <span>
          <span className="block font-display text-3xl font-bold">Admin</span>
          <span className="text-base text-ink/60">Run the game</span>
        </span>
      </button>
    </div>
  );
}
