import { useState } from "react";
import { WeaponLevels } from "../../components/WeaponLevels";
import { CasePieceView, CaseView, HpView, Player } from "../../services/api";

// Small building blocks shared by the Admin screens of the 2.0 update.

// ---- Player number --------------------------------------------------------

// The callout number in a square plate, like the slot numbers in the case.
export function NumberPlate({ n, size = "md" }: { n: number | null | undefined; size?: "sm" | "md" | "lg" }) {
  const box = size === "lg" ? "h-16 w-16 text-4xl" : size === "sm" ? "h-10 w-10 text-lg" : "h-12 w-12 text-2xl";
  const look = n
    ? "border-ink/60 bg-black/40 text-ink shadow-[inset_0_1px_0_rgba(255,255,255,0.12)]"
    : "border-dashed border-ink/25 text-ink/35";
  return (
    <span
      className={`${box} inline-flex shrink-0 items-center justify-center rounded-[3px] border-2 font-display font-bold leading-none tabular-nums ${look}`}
      aria-label={n ? `Player ${n}` : "No player number yet"}
    >
      {n ?? "–"}
    </span>
  );
}

// ---- HP -------------------------------------------------------------------

// A player's HP from the player record, or null when the server didn't send it.
export function hpOf(p: Player): HpView | null {
  if (typeof p.hp !== "number" || typeof p.maxHp !== "number") return null;
  return { hp: p.hp, maxHp: p.maxHp, dead: !!p.dead };
}

// Green when healthy, yellow when hurt, red when nearly down.
export function hpColor(hp: HpView): { bar: string; text: string } {
  if (hp.dead || hp.hp <= 0) return { bar: "bg-alert", text: "text-alert" };
  const pct = hp.maxHp > 0 ? hp.hp / hp.maxHp : 0;
  if (pct > 0.5) return { bar: "bg-olive", text: "text-olive" };
  if (pct > 0.25) return { bar: "bg-sun", text: "text-sun" };
  return { bar: "bg-alert", text: "text-alert" };
}

export function HpMeter({ hp, size = "md" }: { hp: HpView; size?: "sm" | "md" | "lg" }) {
  const pct = hp.maxHp > 0 ? Math.max(0, Math.min(100, (hp.hp / hp.maxHp) * 100)) : 0;
  const height = size === "sm" ? "h-1.5" : size === "lg" ? "h-4" : "h-2.5";
  return (
    <div
      className={`relative w-full overflow-hidden rounded-[2px] bg-black/50 ${height}`}
      role="meter"
      aria-label="Health"
      aria-valuemin={0}
      aria-valuemax={hp.maxHp}
      aria-valuenow={hp.hp}
    >
      <div
        className={`h-full ${hpColor(hp).bar} transition-[width] duration-500 ease-out motion-reduce:transition-none`}
        style={{ width: `${pct}%` }}
      />
      {size === "lg" && (
        // faint tick marks every 10%, like a game health bar
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              "repeating-linear-gradient(90deg, transparent 0 calc(10% - 1px), rgba(0,0,0,0.45) calc(10% - 1px) 10%)",
          }}
        />
      )}
    </div>
  );
}

// ---- Switch ---------------------------------------------------------------

export function Toggle({
  checked,
  onChange,
  label,
  hint,
  disabled,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className="flex min-h-[3.5rem] w-full items-center gap-4 py-2 text-left disabled:opacity-50"
    >
      <span className="min-w-0 flex-1">
        <span className="block text-base font-semibold text-ink">{label}</span>
        {hint && <span className="mt-0.5 block text-sm text-ink/55">{hint}</span>}
      </span>
      <span
        aria-hidden
        className={`relative h-8 w-14 shrink-0 rounded-full border-2 transition-colors ${
          checked ? "border-pine bg-pine" : "border-panel-line bg-panel-raised"
        }`}
      >
        <span
          className={`absolute left-0.5 top-1/2 h-6 w-6 -translate-y-1/2 rounded-full shadow transition-transform motion-reduce:transition-none ${
            checked ? "translate-x-6 bg-pine-ink" : "translate-x-0 bg-ink/70"
          }`}
        />
      </span>
    </button>
  );
}

// ---- Times ----------------------------------------------------------------

// The server stores UTC "YYYY-MM-DD HH:MM:SS"; ISO strings work too.
export function serverDate(iso: string): Date {
  return new Date(iso.includes("T") ? iso : iso.replace(" ", "T") + "Z");
}

export function clockTime(iso: string): string {
  const d = serverDate(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit", second: "2-digit" });
}

// ---- A player's case, read-only ------------------------------------------

const isWeapon = (p: CasePieceView) => p.kind === "gun" || p.kind === "knife";

// The number shown bottom-right on a piece: rounds loaded for guns, how many
// for stacks, nothing for a single item.
function countText(p: CasePieceView): string | null {
  if (p.kind === "gun") return String(p.loaded ?? 0);
  if (p.kind === "ammo" || p.quantity > 1) return String(p.quantity);
  return null;
}

// The picture fills the piece. A turned piece shows its picture turned too.
function PieceImage({ p, w, h }: { p: CasePieceView; w: number; h: number }) {
  if (!p.imageUrl) {
    return (
      <span className="absolute inset-0 flex items-center justify-center font-display text-lg font-bold text-pine/80">
        {p.name.trim().charAt(0).toUpperCase() || "?"}
      </span>
    );
  }
  if (p.rotated && w !== h) {
    return (
      <img
        src={p.imageUrl}
        alt=""
        draggable={false}
        className="pointer-events-none absolute object-contain p-[3px]"
        style={{
          left: "50%",
          top: "50%",
          width: `${(h / w) * 100}%`,
          height: `${(w / h) * 100}%`,
          transform: "translate(-50%, -50%) rotate(90deg)",
        }}
      />
    );
  }
  return (
    <img
      src={p.imageUrl}
      alt=""
      draggable={false}
      className="pointer-events-none absolute inset-0 h-full w-full object-contain p-[3px]"
    />
  );
}

export function CaseGrid({ view }: { view: CaseView }) {
  const [selected, setSelected] = useState<number | null>(null);
  const cols = Math.max(1, view.cols);
  const rows = Math.max(1, view.rows);
  const placed = view.pieces.filter((p) => p.x !== null && p.y !== null && p.x < cols && p.y < rows);
  // Pieces the grid can't show (bad position) are listed with the tray.
  const loose = [...view.tray, ...view.pieces.filter((p) => !placed.includes(p))];

  // Weapons get slot numbers 1, 2, 3… in reading order, like the game's case.
  const slots = new Map<number, number>();
  placed
    .filter(isWeapon)
    .sort((a, b) => a.y! - b.y! || a.x! - b.x!)
    .forEach((p, i) => slots.set(p.id, i + 1));

  const sel = [...placed, ...loose].find((p) => p.id === selected) ?? null;

  const cells = [];
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      cells.push(
        <div
          key={`c${x}-${y}`}
          aria-hidden
          style={{ gridColumn: x + 1, gridRow: y + 1 }}
          className="aspect-square border border-white/[0.07] bg-black/45 shadow-[inset_0_1px_3px_rgba(0,0,0,0.7)]"
        />
      );
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {/* the open attaché case */}
      <div
        className="mx-auto w-full rounded-md border border-white/15 bg-gradient-to-b from-[#202428] to-[#0b0d0f] p-2 shadow-[inset_0_1px_0_rgba(255,255,255,0.10),0_8px_22px_rgba(0,0,0,0.5)]"
        style={{ maxWidth: cols * 46 + 18 }}
      >
        <p className="pb-1.5 text-center font-display text-[11px] font-bold tracking-[0.35em] text-ink/70">ITEMS</p>
        <div
          className="grid rounded-[3px] border border-black/60"
          style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
        >
          {cells}
          {placed.map((p) => {
            // w/h from the server are the item's own size; a turned piece swaps them.
            const fw = p.rotated ? p.h : p.w;
            const fh = p.rotated ? p.w : p.h;
            const w = Math.max(1, Math.min(fw, cols - p.x!));
            const h = Math.max(1, Math.min(fh, rows - p.y!));
            const count = countText(p);
            const slot = slots.get(p.id);
            const on = p.id === selected;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelected(on ? null : p.id)}
                aria-label={`${p.name}${p.quantity > 1 ? `, ${p.quantity}` : ""}`}
                aria-pressed={on}
                style={{ gridColumn: `${p.x! + 1} / span ${w}`, gridRow: `${p.y! + 1} / span ${h}` }}
                className={`relative z-10 m-[2px] min-h-0 min-w-0 overflow-hidden rounded-[3px] border bg-gradient-to-b from-white/[0.12] to-white/[0.03] transition-shadow ${
                  on ? "border-pine shadow-[0_0_12px_rgba(245,165,36,0.6)] ring-1 ring-pine" : "border-white/25"
                }`}
              >
                <PieceImage p={p} w={w} h={h} />
                {slot !== undefined && (
                  <span className="absolute left-[3px] top-[3px] rounded-[2px] border border-white/60 bg-black/40 px-1 text-[10px] font-bold leading-tight text-white">
                    {slot}
                  </span>
                )}
                {count !== null && (
                  <span className="absolute bottom-0 right-1 font-display text-sm font-bold leading-tight text-white [text-shadow:0_1px_2px_#000,0_0_4px_#000]">
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {placed.length === 0 && loose.length === 0 && <p className="text-center text-ink/60">The case is empty.</p>}

      {loose.length > 0 && (
        <div className="flex flex-col gap-2 border-l-4 border-sun bg-sun/10 p-3">
          <p className="text-sm font-bold text-sun">Doesn't fit — waiting in the tray ({loose.length})</p>
          <ul className="flex flex-wrap gap-2">
            {loose.map((p) => (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() => setSelected(p.id === selected ? null : p.id)}
                  className={`flex min-h-[2.75rem] items-center gap-2 rounded-[3px] border bg-black/40 py-1 pl-1 pr-2.5 text-sm font-semibold ${
                    p.id === selected ? "border-pine" : "border-white/20"
                  }`}
                >
                  {p.imageUrl ? (
                    <img src={p.imageUrl} alt="" className="h-8 w-8 object-contain" />
                  ) : (
                    <span className="flex h-8 w-8 items-center justify-center font-display font-bold text-pine">
                      {p.name.charAt(0).toUpperCase()}
                    </span>
                  )}
                  {p.name}
                  {p.quantity > 1 && <span className="font-display font-bold text-ink/70">×{p.quantity}</span>}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {sel && <PieceInfo p={sel} />}
      {!sel && placed.length + loose.length > 0 && (
        <p className="text-center text-sm text-ink/50">Tap an item to see its details.</p>
      )}
    </div>
  );
}

function PieceInfo({ p }: { p: CasePieceView }) {
  const facts: string[] = [];
  if (p.kind === "gun") {
    facts.push(`${p.loaded ?? 0}${p.magazine ? ` / ${p.magazine}` : ""} loaded`);
  } else if (p.kind === "ammo") {
    facts.push(`${p.quantity} rounds${p.stackSize ? ` (up to ${p.stackSize} per space)` : ""}`);
  } else if (p.quantity > 1) {
    facts.push(`×${p.quantity}`);
  }
  facts.push(`Takes ${p.w}×${p.h}${p.rotated ? " (turned)" : ""}`);
  if (p.x === null) facts.push("in the tray");
  return (
    <div className="flex flex-col gap-2 border border-panel-line bg-panel-raised p-3">
      <p className="font-display text-lg font-bold leading-tight">{p.name}</p>
      <p className="text-sm text-ink/70">{facts.join(" · ")}</p>
      {(p.upgrades?.length ?? 0) > 0 && <WeaponLevels upgrades={p.upgrades!} />}
    </div>
  );
}
