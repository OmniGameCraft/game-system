// The player's health for any screen: `useHp()` gives the live numbers,
// `HpBar` / `HpPill` draw them, `DamageFlash` is the full-screen red/green
// flash (HpPill already includes one, so most screens never need it).
//
// useHp() loads GET /api/case/hp once for the whole app and keeps it fresh
// from the "hp:changed" notice (instant, the notice carries the numbers),
// "me:changed" and reconnects. The hit / heal / death sound, buzz and flash
// are played by that one shared copy, so they happen once per change no
// matter how many screens are showing HP.
//
// The code lives in client/src/inventory/ (the 2.0 inventory update's own
// folder); this file is the stable address other screens import from.

export type { HpState } from "../inventory/caseApi";
export { useHp, applyHp, refreshHp, getHpNow } from "../inventory/hpStore";
export { HpBar, HpPill, DamageFlash } from "../inventory/HpBar";
