import { useEffect, useState } from "react";
import { useLive } from "../services/live";
import { AppShell, Tab } from "../components/AppShell";
import { Button } from "../components/Button";
import { ErrorBanner } from "../components/ErrorBanner";
import { Icon } from "../components/Icon";
import { Section, SectionAction } from "../components/Section";
import { TransactionList } from "../components/TransactionList";
import { getMyInventory, getMyTransactions, getShop, PublicUser, Transaction } from "../services/api";
import { PlayerInventory } from "./PlayerInventory";
import { PlayerShop } from "./PlayerShop";

type TabKey = "home" | "shop" | "bag";

const TABS: Tab<TabKey>[] = [
  { key: "home", label: "Home", icon: "home" },
  { key: "shop", label: "Shop", icon: "store" },
  { key: "bag", label: "Bag", icon: "bag" },
];

export function PlayerHome({
  user,
  onLogout,
  onRefresh,
}: {
  user: PublicUser;
  onLogout: () => void;
  onRefresh: () => Promise<void>;
}) {
  const [tab, setTab] = useState<TabKey>("home");
  const name = user.displayName || user.username;

  function switchTab(t: TabKey) {
    setTab(t);
    window.scrollTo(0, 0);
    onRefresh().catch(() => {});
  }

  return (
    <AppShell
      title={tab === "home" ? `Hi, ${name}` : tab === "shop" ? "Shop" : "Bag"}
      subtitle={tab === "home" ? "Player" : name}
      tabs={TABS}
      active={tab}
      onTab={switchTab}
      onLogout={onLogout}
      right={
        <div className="flex shrink-0 items-center gap-1.5 rounded-xl bg-white px-3 py-1.5 text-pine" aria-label="Your money">
          <Icon name="coin" className="h-5 w-5" />
          <span className="text-xl font-extrabold tabular-nums">${user.balance}</span>
        </div>
      }
    >
      {tab === "home" && <HomeTab user={user} onRefresh={onRefresh} onGo={switchTab} onLogout={onLogout} />}
      {tab === "shop" && <PlayerShop balance={user.balance} onBalanceChanged={onRefresh} />}
      {tab === "bag" && <PlayerInventory />}
    </AppShell>
  );
}

function HomeTab({
  user,
  onRefresh,
  onGo,
  onLogout,
}: {
  user: PublicUser;
  onRefresh: () => Promise<void>;
  onGo: (t: TabKey) => void;
  onLogout: () => void;
}) {
  const [transactions, setTransactions] = useState<Transaction[] | null>(null);
  const [shopOpen, setShopOpen] = useState<boolean | null>(null);
  const [itemCount, setItemCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function load() {
    setError(null);
    setLoading(true);
    Promise.all([getMyTransactions(), getShop(), getMyInventory(), onRefresh()])
      .then(([tx, shop, inv]) => {
        setTransactions(tx);
        setShopOpen(shop.open);
        setItemCount(inv.reduce((n, e) => n + e.quantity, 0));
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load."))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);
  useLive(["me:changed", "shop:changed"], load);

  return (
    <>
      <ErrorBanner message={error} />

      <div className="rounded-2xl bg-pine px-5 py-5 text-white shadow">
        <p className="text-base font-semibold text-white/75">Your money</p>
        <p className="text-5xl font-extrabold tabular-nums">${user.balance}</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => onGo("shop")}
          className={`flex flex-col items-start gap-1 rounded-2xl border-2 p-4 text-left shadow-sm ${
            shopOpen ? "border-pine bg-pine-soft" : "border-alert/40 bg-white"
          }`}
        >
          <Icon name="store" className={`h-7 w-7 ${shopOpen ? "text-pine" : "text-alert"}`} />
          <span className="text-lg font-extrabold">Shop</span>
          <span className={`text-sm font-bold ${shopOpen ? "text-pine" : "text-alert"}`}>
            {shopOpen === null ? "…" : shopOpen ? "OPEN" : "CLOSED"}
          </span>
        </button>
        <button onClick={() => onGo("bag")} className="flex flex-col items-start gap-1 rounded-2xl border-2 border-pine/20 bg-white p-4 text-left shadow-sm">
          <Icon name="bag" className="h-7 w-7 text-pine" />
          <span className="text-lg font-extrabold">Bag</span>
          <span className="text-sm font-bold text-ink/60">
            {itemCount === null ? "…" : itemCount === 1 ? "1 item" : `${itemCount} items`}
          </span>
        </button>
      </div>

      <Section
        title="Money history"
        flush
        action={
          <SectionAction onClick={load} disabled={loading}>
            <Icon name="refresh" className="h-4 w-4" />
            {loading ? "…" : "Refresh"}
          </SectionAction>
        }
      >
        {transactions ? <TransactionList transactions={transactions} /> : <p className="p-4 text-ink/60">Loading…</p>}
      </Section>

      <Button variant="ghost" onClick={onLogout}>
        Log out
      </Button>
    </>
  );
}
