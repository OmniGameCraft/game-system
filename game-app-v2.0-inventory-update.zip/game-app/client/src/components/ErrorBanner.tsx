// Something went wrong: red, with a little shake so it's noticed.
export function ErrorBanner({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p
      key={message}
      role="alert"
      className="flex animate-shake items-start gap-3 rounded-md border border-alert/30 border-l-4 border-l-alert bg-alert/10 px-4 py-3 font-medium text-ink"
    >
      <svg viewBox="0 0 24 24" className="mt-0.5 h-5 w-5 shrink-0 text-alert" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" aria-hidden>
        <circle cx="12" cy="12" r="9.5" />
        <path d="M12 7v6M12 16.5h.01" />
      </svg>
      <span className="min-w-0">{message}</span>
    </p>
  );
}
