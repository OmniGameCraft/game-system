import { requestMotionPermission } from "./motion";
import { unlockAudio } from "./sound";

// Must run inside the tap that opens the viewer: phones only allow sound,
// motion data and full screen when they come straight from a tap.
export function prepareViewer(effect: string = "none"): void {
  unlockAudio();
  void requestMotionPermission();
  try {
    const el = document.documentElement as any;
    if (!document.fullscreenElement && el.requestFullscreen) {
      el.requestFullscreen({ navigationUI: "hide" })
        .then(() => {
          // Weapons: turn sideways like holding a real gun (Android only;
          // iPhones ignore this and the gun leans diagonally instead).
          if (effect === "shot") (screen.orientation as any)?.lock?.("landscape").catch(() => {});
        })
        .catch(() => {});
    }
  } catch {
    // full screen not supported (e.g. iPhone): the viewer still covers the page
  }
}

export function leaveViewer(): void {
  try {
    (screen.orientation as any)?.unlock?.();
    if (document.fullscreenElement) void document.exitFullscreen().catch(() => {});
  } catch {
    // ignore
  }
}

// Does this item have anything to show in the viewer? Guns and knives always
// do (ammo, firing, swinging), healing items do when they can be used, and
// anything else when it has a 3D model, a sound or an effect.
export function isUsable(i: {
  modelUrl?: string | null;
  soundUrl?: string | null;
  useEffect?: string;
  kind?: string;
  usable?: boolean;
}): boolean {
  return Boolean(
    i.modelUrl ||
      i.soundUrl ||
      (i.useEffect && i.useEffect !== "none") ||
      i.kind === "gun" ||
      i.kind === "knife" ||
      i.usable
  );
}
