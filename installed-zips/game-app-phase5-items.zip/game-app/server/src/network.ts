import os from "os";

/** IPv4 addresses of this computer on the local network. */
export function getLanAddresses(): string[] {
  const found: string[] = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const nic of list ?? []) {
      if (nic.family === "IPv4" && !nic.internal) found.push(nic.address);
    }
  }
  return found;
}
