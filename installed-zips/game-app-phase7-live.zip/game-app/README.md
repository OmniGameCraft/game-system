# Game System (offline LAN game manager)

A phone app for running a real-life game. One computer (or an Android phone
running Termux) is the server. Everyone else opens it in their phone's
browser over the same Wi-Fi. No internet is needed while you play.

The database starts empty. Nothing is pre-made: you create the Admin,
players and items yourself.

**Built so far:** login (Admin + Player), player management, money, items,
inventory, the shop, live updates, and 3D weapons that fire with sound.
**Coming next:** game controls (start / pause / end the game, announcements).

## Requirements
- Node.js 22.13 or newer
- Internet **once**, for `npm install`. After that it runs fully offline.

## Windows: one-click start
Put `windows/Start Game Server.bat` next to the project zip (or the unpacked
`game-app` folder) and double-click it. The first time, it offers to install
Node.js and needs internet for a couple of minutes. After that it starts
offline in seconds. To update, drop a new `game-app-*.zip` next to it and
double-click again. `check-server.bat` writes your LAN address and firewall
status to `server-check.txt`.

## Install and run (any computer)
```
npm install
npm run build
npm start
```
The server prints its addresses:
```
Local:  http://localhost:3000
LAN:    http://192.168.1.10:3000   <- give this one to players
Secure: https://192.168.1.10:3443  <- use this one for shake-to-fire
```
**Normal vs secure address.** Everything works on the normal `http`
address, except shaking the phone to fire: phones only share motion data
with secure (`https`) pages. The secure address uses a certificate the
server makes for itself, with no internet needed. The first time a phone opens it,
the browser warns that the connection isn't private. Tap **Advanced →
Proceed** once. Turn the secure address off with `HTTPS_PORT=0`.
Phones must be on the same Wi-Fi. Different port: `PORT=4000 npm start`
(Windows PowerShell: `$env:PORT=4000; npm start`).

**Updating from an older version:** just replace the code, run
`npm install` and `npm run build`, then `npm start`. Keep the
`server/data` folder. It holds your database and item pictures, and the
server upgrades the database on its own without losing anything.

### Finding the LAN address yourself
- Windows: `ipconfig` (look for "IPv4 Address")
- macOS: `ipconfig getifaddr en0`
- Linux / Termux: `hostname -I` or `ifconfig`

If a phone can't connect, allow Node.js through the computer's firewall
for private networks.

## First-time setup
1. Open the app and tap **Admin**. The first time, you'll see a setup form.
   Create the Admin account there. The form disappears once an Admin exists.
2. **Players tab → + Create Player.** Give each player their username and
   password. Players can't sign themselves up.
3. **Items tab → + Create Item.** Add weapons, ammo, medkits, whatever your
   game uses:
   - **Category** is free text (for example Weapon, Ammo, Medical). Categories
     you've used before are suggested as you type.
   - **Max per player** is optional. Set it to 1 for "one rifle each".
   - **Picture** is optional. It's shrunk on the phone before uploading.
     PNG, JPG, WEBP or GIF, and transparent backgrounds are kept.
   - **Disable item** stops anyone giving it out. Players keep what they
     already have.
   - **Add from weapon pack** adds ready-made items (pistol, assault
     rifle, shotgun, sniper rifle, knife, first aid kit), each with a
     picture, a 3D model and a sound. They're free CC0 assets that ship
     with the app (see `server/asset-packs/weapons/CREDITS.txt`). Pick the
     ones you want. They aren't put in the shop or given to anyone.
   - **3D model & sound** (on an item's page): upload a `.glb` 3D model and
     a sound (MP3/OGG/WAV/M4A), and choose what a tap does: **Fire** (guns:
     sound, recoil, muzzle flash, vibration), **Swing** (knives), or **Just
     show**. If a model faces the wrong way, tick **Turn around** or
     **Upside down**. **Preview what players see** shows exactly what
     players get.
4. Open a player to manage them:
   - **Money:** Add or Remove, with full history.
   - **Inventory:** choose an item and a quantity, then **Give**, **Remove**
     or **Set to exactly** (0 takes it away completely). **Item history**
     shows every change.
5. **Shop tab.** The shop starts **closed**.
   - **+ Add item to shop:** pick an item and set a price (0 = free), stock
     (empty = unlimited) and an optional per-purchase limit.
   - Tap a shop item to change its price or stock, hide it, or remove it.
   - **Open the shop** when players are allowed to buy, and close it again
     whenever you want. **Recent sales** shows who bought what.
6. Players get three tabs: **Home** (money and history), **Shop** and **Bag**.
   Their money is always shown in the top bar. To buy, a player picks how
   many with − / +, taps **Buy**, then **Confirm**. The server checks
   everything: shop open, stock, limits, money, and the price not having
   changed.
7. **Using weapons.** In the **Bag**, a gun has a **Fire** button, a knife
   has **Swing**, and other items with a 3D model have **View in 3D**. The
   item fills the screen, turning sideways on Android. Tap anywhere, or
   shake the phone (secure address only), to use it.
8. **Live updates.** Everything updates by itself: money, bag, shop
   open/closed, prices and stock on players' phones, and purchases on the
   Admin's screens. The small **Live** badge in the top bar shows the
   connection. If it says **Reconnecting…**, the app still works, but it
   won't update until the Wi-Fi comes back. A player who is disabled, or
   whose password is reset, is signed out immediately.

## Development (live reload)
Run `npm run dev:server` and `npm run dev:client` in two terminals, then
open `http://<LAN-IP>:5173`.

## Layout
- `client/`: React + TypeScript + Tailwind (Vite)
- `server/`: Express + TypeScript + SQLite (Node's built-in `node:sqlite`)
- `server/data/game.db`: the database
- `server/data/uploads/items/`: item pictures, 3D models and sounds
- `server/data/https/`: the self-made certificate for the secure address
- `server/asset-packs/`: ready-made item packs (the free weapon pack)
- `client/src/viewer/`: the full-screen 3D item view (three.js)
