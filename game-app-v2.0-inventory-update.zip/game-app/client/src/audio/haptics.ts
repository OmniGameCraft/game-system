import { getSettings } from "./settings";

// Phone vibration, only when the player has "Vibration" switched on.
// iPhones (Safari) can't vibrate from a web page, so there it does nothing.

export function vibrate(pattern: number | number[]): void {
  if (!getSettings().vibration) return;
  try {
    navigator.vibrate?.(pattern);
  } catch {
    // not supported on this phone
  }
}

// Ready-made patterns so the same event always feels the same.
export const HAPTIC = {
  tap: 8,
  shot: 40,
  reload: [20, 60, 30],
  dry: 15,
  hit: [70, 40, 140],
  heal: [20, 40, 20],
  death: [300, 100, 500],
  gameStart: [120, 60, 120],
  gameStop: [400],
  message: [200, 100, 200],
} satisfies Record<string, number | number[]>;
