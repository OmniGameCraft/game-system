import fs from "fs";
import path from "path";
import selfsigned from "selfsigned";
import { CERT_DIR } from "./config";

// A self-signed certificate made on this computer, so the app can also be
// opened over https on the LAN with no internet and no outside service.
// Phones show a one-time "not private / not secure" warning because nobody
// outside vouches for it; players tap "Advanced → Proceed" once.
// The certificate is remade whenever this computer's LAN address changes.
export function loadOrCreateCertificate(ips: string[]): { key: string; cert: string } {
  const keyFile = path.join(CERT_DIR, "key.pem");
  const certFile = path.join(CERT_DIR, "cert.pem");
  const metaFile = path.join(CERT_DIR, "addresses.json");
  const wanted = [...new Set(["127.0.0.1", ...ips])].sort();

  try {
    const saved = JSON.parse(fs.readFileSync(metaFile, "utf8")) as string[];
    if (JSON.stringify(saved) === JSON.stringify(wanted)) {
      return { key: fs.readFileSync(keyFile, "utf8"), cert: fs.readFileSync(certFile, "utf8") };
    }
  } catch {
    // no certificate yet
  }

  const pems = selfsigned.generate([{ name: "commonName", value: "Game System (local)" }], {
    days: 3650,
    keySize: 2048,
    algorithm: "sha256",
    extensions: [
      { name: "basicConstraints", cA: false },
      { name: "keyUsage", digitalSignature: true, keyEncipherment: true },
      { name: "extKeyUsage", serverAuth: true },
      {
        name: "subjectAltName",
        altNames: [{ type: 2, value: "localhost" }, ...wanted.map((ip) => ({ type: 7, ip }))],
      },
    ],
  });
  fs.mkdirSync(CERT_DIR, { recursive: true });
  fs.writeFileSync(keyFile, pems.private);
  fs.writeFileSync(certFile, pems.cert);
  fs.writeFileSync(metaFile, JSON.stringify(wanted));
  return { key: pems.private, cert: pems.cert };
}
