import { audioContext, busAudible, sfxBus, unlockAudio as unlockEngine } from "../audio/engine";

// Gun sounds through the Web Audio API: decoded once, then each shot starts
// instantly and shots can overlap (an <audio> tag can't do either well).
// They go through the app's sound-effects bus, so the Settings volume and
// mute apply to them like to every other sound.
// Phones only allow sound after a tap, so unlockAudio() is called from the
// tap that opens the viewer.

const cache = new Map<string, Promise<AudioBuffer>>();

export function unlockAudio(): void {
  unlockEngine();
}

export function loadSound(url: string): Promise<AudioBuffer> {
  let p = cache.get(url);
  if (!p) {
    p = fetch(url)
      .then((r) => {
        if (!r.ok) throw new Error("sound not found");
        return r.arrayBuffer();
      })
      .then(
        (data) =>
          new Promise<AudioBuffer>((resolve, reject) =>
            // callback form: older Safari doesn't return a promise
            audioContext().decodeAudioData(data, resolve, reject)
          )
      );
    p.catch(() => cache.delete(url));
    cache.set(url, p);
  }
  return p;
}

export function playSound(buffer: AudioBuffer, volume = 1): void {
  try {
    if (!busAudible("sfx")) return; // muted: don't bother making the sound
    const c = audioContext();
    if (c.state !== "running") unlockEngine();
    const src = c.createBufferSource();
    src.buffer = buffer;
    const gain = c.createGain();
    gain.gain.value = volume;
    // slight random pitch so rapid shots don't sound copy-pasted
    src.playbackRate.value = 0.96 + Math.random() * 0.08;
    src.connect(gain).connect(sfxBus());
    src.onended = () => gain.disconnect();
    src.start();
  } catch {
    // no sound on this phone: the gun still fires silently
  }
}
