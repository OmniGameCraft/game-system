import { DatabaseSync } from "node:sqlite";
import { applyBalanceChange, getTransaction, Transaction } from "./money";
import { applyInventoryChange, MAX_ITEM_QUANTITY } from "./inventory";
import { imageUrlFor } from "./items";
import { gameAllowsPlay } from "./game";

// Highest price the Admin can set for one unit. price × quantity stays far
// inside JS's exact-integer range (1e9 × 1e6 = 1e15 < 9e15).
export const MAX_PRICE = 1_000_000_000;

// ---- Shop open/closed -------------------------------------------------

export function isShopOpen(db: DatabaseSync): boolean {
  const row = db.prepare("SELECT value FROM game_state WHERE key = 'shop_open'").get() as
    | { value: string }
    | undefined;
  return row?.value === "1"; // no row yet = closed
}

export function setShopOpen(db: DatabaseSync, open: boolean): void {
  db.prepare(
    `INSERT INTO game_state (key, value) VALUES ('shop_open', ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  ).run(open ? "1" : "0");
}

// ---- Shop items -------------------------------------------------------

interface ShopRow {
  id: number;
  item_id: number;
  price: number;
  stock: number | null;
  max_per_purchase: number | null;
  enabled: number;
  created_at: string;
  name: string;
  description: string | null;
  category: string | null;
  image_file: string | null;
  item_enabled: number;
  max_stack: number | null;
}

export interface AdminShopItem {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  price: number;
  stock: number | null;
  maxPerPurchase: number | null;
  enabled: boolean;
  itemEnabled: boolean;
  maxStack: number | null;
  soldCount: number;
}

export interface PlayerShopItem {
  id: number;
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  price: number;
  stock: number | null;
  maxPerPurchase: number | null;
  maxStack: number | null;
  owned: number;
}

const SHOP_SELECT = `
  SELECT s.*, i.name, i.description, i.category, i.image_file,
         i.enabled AS item_enabled, i.max_stack
    FROM shop_items s
    JOIN items i ON i.id = s.item_id`;

export function findShopItem(db: DatabaseSync, id: number): ShopRow | undefined {
  return db.prepare(`${SHOP_SELECT} WHERE s.id = ?`).get(id) as ShopRow | undefined;
}

export function findShopItemByItemId(db: DatabaseSync, itemId: number): ShopRow | undefined {
  return db.prepare(`${SHOP_SELECT} WHERE s.item_id = ?`).get(itemId) as ShopRow | undefined;
}

export function listShopForAdmin(db: DatabaseSync): AdminShopItem[] {
  const rows = db.prepare(`${SHOP_SELECT} ORDER BY i.name COLLATE NOCASE`).all() as unknown as ShopRow[];
  const sold = new Map<number, number>();
  for (const r of db
    .prepare("SELECT item_id, SUM(quantity) AS n FROM transactions WHERE type = 'PURCHASE' GROUP BY item_id")
    .all() as unknown as Array<{ item_id: number; n: number }>) {
    sold.set(r.item_id, r.n);
  }
  return rows.map((r) => ({
    id: r.id,
    itemId: r.item_id,
    name: r.name,
    description: r.description,
    category: r.category,
    imageUrl: imageUrlFor(r.image_file),
    price: r.price,
    stock: r.stock,
    maxPerPurchase: r.max_per_purchase,
    enabled: r.enabled === 1,
    itemEnabled: r.item_enabled === 1,
    maxStack: r.max_stack,
    soldCount: sold.get(r.item_id) ?? 0,
  }));
}

// Only what a player may buy right now: shop entry enabled AND the item
// itself enabled. Sold-out entries are still listed (shown as "Sold out").
export function listShopForPlayer(db: DatabaseSync, playerId: number): PlayerShopItem[] {
  const rows = db
    .prepare(`${SHOP_SELECT} WHERE s.enabled = 1 AND i.enabled = 1 ORDER BY i.name COLLATE NOCASE`)
    .all() as unknown as ShopRow[];
  const owned = new Map<number, number>();
  for (const r of db
    .prepare("SELECT item_id, quantity FROM inventory WHERE player_id = ?")
    .all(playerId) as unknown as Array<{ item_id: number; quantity: number }>) {
    owned.set(r.item_id, r.quantity);
  }
  return rows.map((r) => ({
    id: r.id,
    itemId: r.item_id,
    name: r.name,
    description: r.description,
    category: r.category,
    imageUrl: imageUrlFor(r.image_file),
    price: r.price,
    stock: r.stock,
    maxPerPurchase: r.max_per_purchase,
    maxStack: r.max_stack,
    owned: owned.get(r.item_id) ?? 0,
  }));
}

export interface ShopItemFields {
  price?: number;
  stock?: number | null;
  maxPerPurchase?: number | null;
  enabled?: boolean;
}

export function createShopItem(
  db: DatabaseSync,
  itemId: number,
  f: { price: number; stock: number | null; maxPerPurchase: number | null; enabled: boolean }
): number {
  const r = db
    .prepare(
      "INSERT INTO shop_items (item_id, price, stock, max_per_purchase, enabled) VALUES (?, ?, ?, ?, ?)"
    )
    .run(itemId, f.price, f.stock, f.maxPerPurchase, f.enabled ? 1 : 0);
  return Number(r.lastInsertRowid);
}

export function updateShopItem(db: DatabaseSync, id: number, f: ShopItemFields): void {
  if (f.price !== undefined) db.prepare("UPDATE shop_items SET price = ? WHERE id = ?").run(f.price, id);
  if (f.stock !== undefined) db.prepare("UPDATE shop_items SET stock = ? WHERE id = ?").run(f.stock, id);
  if (f.maxPerPurchase !== undefined)
    db.prepare("UPDATE shop_items SET max_per_purchase = ? WHERE id = ?").run(f.maxPerPurchase, id);
  if (f.enabled !== undefined)
    db.prepare("UPDATE shop_items SET enabled = ? WHERE id = ?").run(f.enabled ? 1 : 0, id);
}

export function deleteShopItem(db: DatabaseSync, id: number): void {
  db.prepare("DELETE FROM shop_items WHERE id = ?").run(id);
}

// ---- Sales list for the Admin -----------------------------------------

export interface Sale {
  id: number;
  playerId: number;
  playerName: string;
  itemName: string;
  quantity: number;
  total: number;
  createdAt: string;
}

export function listRecentSales(db: DatabaseSync, limit = 50): Sale[] {
  const rows = db
    .prepare(
      `SELECT t.id, t.player_id, COALESCE(u.display_name, u.username) AS player_name,
              i.name AS item_name, t.quantity, t.amount, t.created_at
         FROM transactions t
         JOIN users u ON u.id = t.player_id
         JOIN items i ON i.id = t.item_id
        WHERE t.type = 'PURCHASE'
        ORDER BY t.id DESC
        LIMIT ?`
    )
    .all(limit) as unknown as Array<{
    id: number;
    player_id: number;
    player_name: string;
    item_name: string;
    quantity: number;
    amount: number;
    created_at: string;
  }>;
  return rows.map((r) => ({
    id: r.id,
    playerId: r.player_id,
    playerName: r.player_name,
    itemName: r.item_name,
    quantity: r.quantity,
    total: r.amount,
    createdAt: r.created_at,
  }));
}

// ---- Purchase ---------------------------------------------------------

// A rule the purchase broke; the message is written for the player.
export class PurchaseError extends Error {
  constructor(message: string, public code: "CLOSED" | "GONE" | "RULE" | "PRICE_CHANGED" = "RULE") {
    super(message);
  }
}

// Everything a purchase touches happens inside ONE database transaction:
//   money down + transaction row, item added + inventory_log row, stock down.
// If any check or write fails, ROLLBACK undoes all of it — a player can
// never lose money without getting the item, or get the item for free.
// The whole function is synchronous, so two players buying the last unit
// at the same moment are handled one after the other, never interleaved.
//
// The price charged always comes from the database. `expectedPrice` is only
// what the player's screen showed: if the Admin changed the price since, the
// purchase is refused so nobody pays a price they didn't see.
export function purchase(
  db: DatabaseSync,
  input: { playerId: number; shopItemId: number; quantity: number; expectedPrice?: number }
): { balance: number; transaction: Transaction; owned: number; stock: number | null } {
  const { playerId, shopItemId, quantity } = input;

  if (!Number.isInteger(quantity) || quantity < 1 || quantity > MAX_ITEM_QUANTITY) {
    throw new PurchaseError("Choose a valid quantity.");
  }

  db.exec("BEGIN");
  try {
    const play = gameAllowsPlay(db);
    if (!play.ok) throw new PurchaseError(`${play.reason} Buying is off for now.`, "CLOSED");
    if (!isShopOpen(db)) throw new PurchaseError("The shop is closed.", "CLOSED");

    const s = findShopItem(db, shopItemId);
    if (!s) throw new PurchaseError("This item is no longer in the shop.", "GONE");
    if (s.enabled !== 1 || s.item_enabled !== 1) {
      throw new PurchaseError(`${s.name} isn't available right now.`, "GONE");
    }
    if (input.expectedPrice !== undefined && input.expectedPrice !== s.price) {
      throw new PurchaseError(
        `The price of ${s.name} just changed to $${s.price}. Check it and try again.`,
        "PRICE_CHANGED"
      );
    }
    if (s.max_per_purchase !== null && quantity > s.max_per_purchase) {
      throw new PurchaseError(`You can buy at most ${s.max_per_purchase} ${s.name} at a time.`);
    }
    if (s.stock !== null) {
      if (s.stock === 0) throw new PurchaseError(`${s.name} is out of stock.`);
      if (quantity > s.stock) throw new PurchaseError(`Only ${s.stock} ${s.name} left in stock.`);
    }

    const total = s.price * quantity;
    const inv = applyInventoryChange(db, {
      playerId,
      itemId: s.item_id,
      action: "PURCHASE",
      quantity,
      performedBy: playerId,
    });
    const money = applyBalanceChange(db, {
      playerId,
      type: "PURCHASE",
      amount: total,
      performedBy: playerId,
      itemId: s.item_id,
      quantity,
    });
    let stock = s.stock;
    if (stock !== null) {
      stock -= quantity;
      db.prepare("UPDATE shop_items SET stock = ? WHERE id = ?").run(stock, s.id);
    }

    db.exec("COMMIT");
    return {
      balance: money.balance,
      transaction: getTransaction(db, money.transactionId),
      owned: inv.quantity,
      stock,
    };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
