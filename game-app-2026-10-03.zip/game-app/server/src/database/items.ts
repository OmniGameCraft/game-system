import { DatabaseSync } from "node:sqlite";

export type UseEffect = "none" | "shot" | "swing";
export type ItemKind = "gun" | "knife" | "ammo" | "healing" | "backpack" | "other";
export const ITEM_KINDS: ItemKind[] = ["gun", "knife", "ammo", "healing", "backpack", "other"];

// Kinds a player may sell back by default (the Admin can switch any item).
export const SELLABLE_BY_DEFAULT: ItemKind[] = ["gun", "knife", "ammo", "healing"];

export interface Item {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  max_stack: number | null;
  enabled: number; // SQLite has no boolean: 1 = enabled, 0 = disabled
  image_file: string | null;
  model_file: string | null;
  sound_file: string | null;
  use_effect: UseEffect;
  model_flip: number;
  model_upside_down: number;
  kind: ItemKind;
  ammo_for_item_id: number | null;
  ammo_per_pack: number | null;
  sellable: number;
  sell_percent: number;
  base_magazine: number | null;
  base_sharpness: number | null;
  base_length: number | null;
  up_price_magazine: number | null;
  up_price_damage: number | null;
  up_price_sharpness: number | null;
  up_price_length: number | null;
  created_at: string;
}

// The Admin's full view of an item. Never sent to players: it contains the
// sell percentage, which players only learn when they choose to sell.
export interface PublicItem {
  id: number;
  name: string;
  description: string | null;
  category: string | null;
  maxStack: number | null;
  enabled: boolean;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  kind: ItemKind;
  ammoForItemId: number | null;
  ammoPerPack: number | null;
  sellable: boolean;
  sellPercent: number;
  baseMagazine: number | null;
  baseSharpness: number | null;
  baseLength: number | null;
  upgradePrices: { magazine: number | null; damage: number | null; sharpness: number | null; length: number | null };
  createdAt: string;
}

export function imageUrlFor(file: string | null): string | null {
  return file ? `/media/items/${file}` : null;
}

export function toPublicItem(i: Item): PublicItem {
  return {
    id: i.id,
    name: i.name,
    description: i.description,
    category: i.category,
    maxStack: i.max_stack,
    enabled: i.enabled === 1,
    imageUrl: imageUrlFor(i.image_file),
    modelUrl: imageUrlFor(i.model_file),
    soundUrl: imageUrlFor(i.sound_file),
    useEffect: i.use_effect,
    modelFlip: i.model_flip === 1,
    modelUpsideDown: i.model_upside_down === 1,
    kind: i.kind,
    ammoForItemId: i.ammo_for_item_id,
    ammoPerPack: i.ammo_per_pack,
    sellable: i.sellable === 1,
    sellPercent: i.sell_percent,
    baseMagazine: i.base_magazine,
    baseSharpness: i.base_sharpness,
    baseLength: i.base_length,
    upgradePrices: {
      magazine: i.up_price_magazine,
      damage: i.up_price_damage,
      sharpness: i.up_price_sharpness,
      length: i.up_price_length,
    },
    createdAt: i.created_at,
  };
}

export function listItems(db: DatabaseSync): Item[] {
  return db.prepare("SELECT * FROM items ORDER BY name COLLATE NOCASE").all() as unknown as Item[];
}

export function findItemById(db: DatabaseSync, id: number): Item | undefined {
  return db.prepare("SELECT * FROM items WHERE id = ?").get(id) as Item | undefined;
}

// The name column is COLLATE NOCASE, so "Rifle" and "rifle" count as the same.
export function findItemByName(db: DatabaseSync, name: string): Item | undefined {
  return db.prepare("SELECT * FROM items WHERE name = ?").get(name) as Item | undefined;
}

export interface ItemFields {
  name?: string;
  description?: string | null;
  category?: string | null;
  maxStack?: number | null;
  enabled?: boolean;
  useEffect?: UseEffect;
  modelFlip?: boolean;
  modelUpsideDown?: boolean;
  kind?: ItemKind;
  ammoForItemId?: number | null;
  ammoPerPack?: number | null;
  sellable?: boolean;
  sellPercent?: number;
  baseMagazine?: number | null;
  baseSharpness?: number | null;
  baseLength?: number | null;
  upPriceMagazine?: number | null;
  upPriceDamage?: number | null;
  upPriceSharpness?: number | null;
  upPriceLength?: number | null;
}

// Field name -> column. Fixed list (never user input), so building the
// UPDATE statement from it is safe.
const COLUMNS: Record<keyof ItemFields, string> = {
  name: "name",
  description: "description",
  category: "category",
  maxStack: "max_stack",
  enabled: "enabled",
  useEffect: "use_effect",
  modelFlip: "model_flip",
  modelUpsideDown: "model_upside_down",
  kind: "kind",
  ammoForItemId: "ammo_for_item_id",
  ammoPerPack: "ammo_per_pack",
  sellable: "sellable",
  sellPercent: "sell_percent",
  baseMagazine: "base_magazine",
  baseSharpness: "base_sharpness",
  baseLength: "base_length",
  upPriceMagazine: "up_price_magazine",
  upPriceDamage: "up_price_damage",
  upPriceSharpness: "up_price_sharpness",
  upPriceLength: "up_price_length",
};

function toDb(v: unknown): string | number | null {
  if (typeof v === "boolean") return v ? 1 : 0;
  return v as string | number | null;
}

export function createItem(db: DatabaseSync, f: ItemFields & { name: string }): Item {
  const result = db.prepare("INSERT INTO items (name) VALUES (?)").run(f.name);
  const id = Number(result.lastInsertRowid);
  const rest: ItemFields = { ...f };
  delete rest.name;
  // New items follow their kind's selling default unless told otherwise.
  if (rest.sellable === undefined && rest.kind) rest.sellable = SELLABLE_BY_DEFAULT.includes(rest.kind);
  return updateItem(db, id, rest);
}

export function updateItem(db: DatabaseSync, id: number, f: ItemFields): Item {
  for (const key of Object.keys(f) as (keyof ItemFields)[]) {
    const v = f[key];
    if (v === undefined) continue;
    db.prepare(`UPDATE items SET ${COLUMNS[key]} = ? WHERE id = ?`).run(toDb(v), id);
  }
  return findItemById(db, id)!;
}

export function setItemImage(db: DatabaseSync, id: number, file: string | null): void {
  db.prepare("UPDATE items SET image_file = ? WHERE id = ?").run(file, id);
}

export function setItemFile(
  db: DatabaseSync,
  id: number,
  column: "model_file" | "sound_file",
  file: string | null
): void {
  // column is one of two fixed names (never user input), so building the
  // statement with it is safe.
  db.prepare(`UPDATE items SET ${column} = ? WHERE id = ?`).run(file, id);
}
