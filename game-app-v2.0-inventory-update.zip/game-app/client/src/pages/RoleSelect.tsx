import { Icon, IconName } from "../components/Icon";
import { BrandHeader } from "../components/Brand";
import { Role } from "../services/api";
import { APP_VERSION } from "../version";

// The start screen: the brand, then two big choices.
export function RoleSelect({ onSelect }: { onSelect: (role: Role) => void }) {
  return (
    <div className="flex flex-col gap-8">
      <BrandHeader />
      <div className="stagger flex flex-col gap-3">
        <RoleCard
          primary
          icon="users"
          title="Player"
          text="Join the game"
          onClick={() => onSelect("player")}
        />
        <RoleCard icon="flag" title="Admin" text="Run the game" onClick={() => onSelect("admin")} />
      </div>
      <p className="text-center text-xs font-medium text-ink/35 animate-fade-in">
        Works offline on your local Wi-Fi · v{APP_VERSION}
      </p>
    </div>
  );
}

function RoleCard({
  primary = false,
  icon,
  title,
  text,
  onClick,
}: {
  primary?: boolean;
  icon: IconName;
  title: string;
  text: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`press group flex items-center gap-4 rounded-xl px-5 py-5 text-left ${
        primary
          ? "border border-pine-light/60 bg-gradient-to-b from-pine-light to-pine text-pine-ink shadow-[inset_0_1px_0_rgba(255,255,255,0.5),0_3px_0_#8a560a,0_14px_30px_-12px_rgba(245,165,36,0.6)]"
          : "case-frame text-ink"
      }`}
    >
      <span
        className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-lg ${
          primary ? "bg-pine-ink/10 shadow-[inset_0_0_0_1px_rgba(28,20,5,0.18)]" : "cell text-pine"
        }`}
      >
        <Icon name={icon} className="h-8 w-8" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block font-display text-3xl font-bold leading-tight">{title}</span>
        <span className={`text-base font-medium ${primary ? "text-pine-ink/75" : "text-ink/60"}`}>{text}</span>
      </span>
      <Icon
        name="chevron"
        className={`h-7 w-7 shrink-0 transition-transform group-active:translate-x-1 ${primary ? "text-pine-ink/70" : "text-pine"}`}
      />
    </button>
  );
}
