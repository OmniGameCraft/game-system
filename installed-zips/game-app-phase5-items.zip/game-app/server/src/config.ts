import path from "path";

// Change these with environment variables, e.g.  PORT=4000 npm start
export const HOST = process.env.HOST ?? "0.0.0.0"; // 0.0.0.0 = reachable from the LAN
export const PORT = Number(process.env.PORT ?? 3000);
export const DB_PATH =
  process.env.DB_PATH ?? path.resolve(__dirname, "../data/game.db");
// Pictures the Admin uploads for items live next to the database file, so
// backing up the data folder backs up everything.
export const ITEM_IMAGE_DIR = path.join(path.dirname(DB_PATH), "uploads", "items");
export const CLIENT_DIST = path.resolve(__dirname, "../../client/dist");
