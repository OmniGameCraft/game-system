import { useEffect, useSyncExternalStore } from "react";

// This phone's own preferences: sound, controls and display. They live in the
// browser (localStorage), so each phone keeps its own choices and nothing has
// to go through the server. If the browser refuses to store them (private
// mode, storage full) the app still works with the defaults for this visit.

export interface AppSettings {
  musicOn: boolean;
  musicVolume: number; // 0–100
  sfxOn: boolean;
  sfxVolume: number; // 0–100
  clickOn: boolean;
  clickVolume: number; // 0–100
  masterMute: boolean;
  vibration: boolean;
  keepScreenOn: boolean;
  listenForHits: boolean;
  adminListens: boolean;
  shakeSensitivity: number; // 0.6–1.4, 1 = normal (higher = less shake needed)
  reduceMotion: boolean;
  textSize: "normal" | "large";
  leftHanded: boolean;
}

const STORAGE_KEY = "game-system:settings:v1";

function systemPrefersReducedMotion(): boolean {
  try {
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch {
    return false;
  }
}

export const DEFAULT_SETTINGS: AppSettings = {
  musicOn: true,
  musicVolume: 40,
  sfxOn: true,
  sfxVolume: 70,
  clickOn: true,
  clickVolume: 60,
  masterMute: false,
  vibration: true,
  keepScreenOn: true,
  listenForHits: true,
  adminListens: false,
  shakeSensitivity: 1,
  // Follows the phone's own "reduce motion" setting until the player picks.
  reduceMotion: systemPrefersReducedMotion(),
  textSize: "normal",
  leftHanded: false,
};

// Anything read from storage is checked: an old or hand-edited value can
// never put the app into a broken state.
function clean(raw: unknown): AppSettings {
  const s: AppSettings = { ...DEFAULT_SETTINGS };
  if (!raw || typeof raw !== "object") return s;
  const r = raw as Record<string, unknown>;
  const bool = (k: keyof AppSettings) => {
    if (typeof r[k] === "boolean") (s as any)[k] = r[k];
  };
  const num = (k: keyof AppSettings, min: number, max: number, round: boolean) => {
    const v = r[k];
    if (typeof v === "number" && Number.isFinite(v)) {
      const c = Math.min(max, Math.max(min, v));
      (s as any)[k] = round ? Math.round(c) : Math.round(c * 100) / 100;
    }
  };
  bool("musicOn");
  bool("sfxOn");
  bool("clickOn");
  bool("masterMute");
  bool("vibration");
  bool("keepScreenOn");
  bool("listenForHits");
  bool("adminListens");
  bool("reduceMotion");
  bool("leftHanded");
  num("musicVolume", 0, 100, true);
  num("sfxVolume", 0, 100, true);
  num("clickVolume", 0, 100, true);
  num("shakeSensitivity", 0.6, 1.4, false);
  if (r.textSize === "normal" || r.textSize === "large") s.textSize = r.textSize;
  return s;
}

function load(): AppSettings {
  try {
    const text = localStorage.getItem(STORAGE_KEY);
    return text ? clean(JSON.parse(text)) : { ...DEFAULT_SETTINGS };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

function save(s: AppSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  } catch {
    // Can't store: the choice still applies until the page is reloaded.
  }
}

// One shared object. It is replaced (never changed in place) on every update,
// so React's useSyncExternalStore can tell when something changed.
let current: AppSettings = load();
const listeners = new Set<(s: AppSettings) => void>();

function emit() {
  applyDocumentSettings();
  listeners.forEach((fn) => {
    try {
      fn(current);
    } catch {
      // one broken listener must not stop the others
    }
  });
}

export function getSettings(): AppSettings {
  return current;
}

export function updateSettings(patch: Partial<AppSettings>): void {
  const next = clean({ ...current, ...patch });
  const changed = (Object.keys(next) as (keyof AppSettings)[]).some((k) => next[k] !== current[k]);
  if (!changed) return;
  current = next;
  save(current);
  emit();
}

export function resetSettings(): void {
  current = { ...DEFAULT_SETTINGS, reduceMotion: systemPrefersReducedMotion() };
  save(current);
  emit();
}

export function subscribeSettings(fn: (s: AppSettings) => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

// React hook: [settings, update]. Every screen using it re-renders when any
// setting changes (also when changed in another tab of the same browser).
export function useSettings(): [AppSettings, (patch: Partial<AppSettings>) => void] {
  const s = useSyncExternalStore(subscribeSettings, getSettings, getSettings);
  return [s, updateSettings];
}

// Another tab of the app changed the settings: follow along.
try {
  window.addEventListener("storage", (e) => {
    if (e.key !== STORAGE_KEY) return;
    current = load();
    emit();
  });
} catch {
  // no window (never happens in the app)
}

// ---- Display settings applied to the whole page ----

// Larger text scales every size in the app, because all sizes are in rem.
// Reduce motion puts a class on <html>; index.css turns animations off for it.
// "motion-ok" means the player switched reduce-motion OFF on purpose, so the
// phone's own setting no longer forces it.
export function applyDocumentSettings(): void {
  try {
    const root = document.documentElement;
    root.style.fontSize = current.textSize === "large" ? "112.5%" : "";
    root.classList.toggle("text-large", current.textSize === "large");
    root.classList.toggle("reduce-motion", current.reduceMotion);
    root.classList.toggle("motion-ok", !current.reduceMotion);
    root.classList.toggle("left-handed", current.leftHanded);
  } catch {
    // no document (never happens in the app)
  }
}

applyDocumentSettings();

// ---- Keep the screen on (Wake Lock) ----
//
// Phones dim and lock the screen after a short while, which is annoying in the
// middle of a game. The Wake Lock API asks the phone to stay awake while the
// app is on screen. The phone drops the lock whenever the app is hidden, so it
// is asked for again each time the app comes back. Only works on the secure
// (https) address and newer phones; elsewhere this quietly does nothing.

export function wakeLockSupported(): boolean {
  try {
    return window.isSecureContext && "wakeLock" in navigator;
  } catch {
    return false;
  }
}

let wakeUsers = 0;
let sentinel: { release: () => Promise<void>; released?: boolean; addEventListener?: any } | null = null;
let wakeRequesting = false;
let wakeListening = false;

function wakeWanted(): boolean {
  return wakeUsers > 0 && current.keepScreenOn && document.visibilityState === "visible";
}

async function syncWakeLock(): Promise<void> {
  if (!wakeLockSupported()) return;
  if (wakeWanted()) {
    if ((sentinel && !sentinel.released) || wakeRequesting) return;
    wakeRequesting = true;
    try {
      const s = await (navigator as any).wakeLock.request("screen");
      sentinel = s;
      s.addEventListener?.("release", () => {
        if (sentinel === s) sentinel = null;
      });
      // Settings may have changed while we waited.
      if (!wakeWanted()) await releaseWake();
    } catch {
      sentinel = null; // refused (battery saver, not visible): try again later
    } finally {
      wakeRequesting = false;
    }
  } else {
    await releaseWake();
  }
}

async function releaseWake(): Promise<void> {
  const s = sentinel;
  sentinel = null;
  try {
    await s?.release();
  } catch {
    // already released
  }
}

function onWakeVisibility() {
  void syncWakeLock();
}

// Turns "keep the screen on" handling on (while someone is logged in). Returns
// a function that turns it off again. Safe to call more than once.
export function enableWakeLock(): () => void {
  wakeUsers++;
  if (!wakeListening) {
    wakeListening = true;
    document.addEventListener("visibilitychange", onWakeVisibility);
    subscribeSettings(onWakeVisibility);
  }
  void syncWakeLock();
  let done = false;
  return () => {
    if (done) return;
    done = true;
    wakeUsers = Math.max(0, wakeUsers - 1);
    void syncWakeLock();
  };
}

// Hook form: keeps the screen on while `active` is true (e.g. logged in).
export function useKeepScreenOn(active: boolean): void {
  useEffect(() => {
    if (!active) return;
    return enableWakeLock();
  }, [active]);
}
