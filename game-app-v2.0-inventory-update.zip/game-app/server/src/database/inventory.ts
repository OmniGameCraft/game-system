import { DatabaseSync } from "node:sqlite";
import { imageUrlFor, ItemKind, UseEffect } from "./items";
import { clearUpgrades } from "./weapons";
import { relayoutPlayer, syncItem, SyncOpts, SyncResult, trayCount } from "../inventory/grid";

// GIVE/REMOVE/SET are Admin changes; PURCHASE and SELL are written by the
// shop. The rest come from the case (2.0):
//   MIX     a herb used up in a mix, or the mixed herb it made
//   USE     a healing item used
//   DROP    put into the drop box;  PICKUP  taken out of it
//   RETURN  given back: unclaimed drops when the game ends, or the rounds
//           inside a gun that was sold or taken away (back into ammo)
//   RELOAD  rounds moved from ammo into a gun's magazine
//   DEATH   everything a downed player held, into the drop box
//   FIRE / EXPAND are allowed by the database but not written (a row per
//   shot would be far too many; backpacks are logged as PURCHASE/GIVE).
export type InventoryAction =
  | "GIVE"
  | "REMOVE"
  | "SET"
  | "PURCHASE"
  | "SELL"
  | "MIX"
  | "USE"
  | "DROP"
  | "PICKUP"
  | "RETURN"
  | "FIRE"
  | "RELOAD"
  | "DEATH"
  | "EXPAND";
export type AdminInventoryAction = "GIVE" | "REMOVE" | "SET";

// Actions that add units (MIX says which way it goes; SET is exact).
const ADDING: InventoryAction[] = ["GIVE", "PURCHASE", "PICKUP", "RETURN", "EXPAND"];
// Actions a player does themselves: error messages talk to them ("You…").
const BY_PLAYER: InventoryAction[] = ["PURCHASE", "SELL", "MIX", "USE", "DROP", "PICKUP", "RELOAD", "FIRE"];

// Sanity cap on how many of one item a single player can hold or be given in
// one go — guards against typos, well inside SQLite/JS integer range.
export const MAX_ITEM_QUANTITY = 1_000_000;

export interface InventoryEntry {
  itemId: number;
  name: string;
  description: string | null;
  category: string | null;
  imageUrl: string | null;
  modelUrl: string | null;
  soundUrl: string | null;
  useEffect: UseEffect;
  modelFlip: boolean;
  modelUpsideDown: boolean;
  enabled: boolean;
  maxStack: number | null;
  quantity: number;
  kind: ItemKind;
  ammoPerPack: number | null;
  ammoForItemId: number | null;
  sellable: boolean;
}

interface InventoryRow {
  item_id: number;
  name: string;
  description: string | null;
  category: string | null;
  image_file: string | null;
  model_file: string | null;
  sound_file: string | null;
  use_effect: UseEffect;
  model_flip: number;
  model_upside_down: number;
  enabled: number;
  max_stack: number | null;
  quantity: number;
  kind: ItemKind;
  ammo_per_pack: number | null;
  ammo_for_item_id: number | null;
  sellable: number;
}

export function listInventoryForPlayer(db: DatabaseSync, playerId: number): InventoryEntry[] {
  const rows = db
    .prepare(
      `SELECT inv.item_id, inv.quantity, i.name, i.description, i.category,
              i.image_file, i.model_file, i.sound_file, i.use_effect,
              i.model_flip, i.model_upside_down, i.enabled, i.max_stack,
              i.kind, i.ammo_per_pack, i.ammo_for_item_id, i.sellable
         FROM inventory inv
         JOIN items i ON i.id = inv.item_id
        WHERE inv.player_id = ?
        ORDER BY i.name COLLATE NOCASE`
    )
    .all(playerId) as unknown as InventoryRow[];
  return rows.map((r) => ({
    itemId: r.item_id,
    name: r.name,
    description: r.description,
    category: r.category,
    imageUrl: imageUrlFor(r.image_file),
    modelUrl: imageUrlFor(r.model_file),
    soundUrl: imageUrlFor(r.sound_file),
    useEffect: r.use_effect,
    modelFlip: r.model_flip === 1,
    modelUpsideDown: r.model_upside_down === 1,
    enabled: r.enabled === 1,
    maxStack: r.max_stack,
    quantity: r.quantity,
    kind: r.kind,
    ammoPerPack: r.ammo_per_pack,
    ammoForItemId: r.ammo_for_item_id,
    sellable: r.sellable === 1,
  }));
}

export interface InventoryLogEntry {
  id: number;
  itemId: number;
  itemName: string;
  action: InventoryAction;
  quantityBefore: number;
  quantityAfter: number;
  performedBy: number;
  createdAt: string;
}

export function listInventoryLog(db: DatabaseSync, playerId: number): InventoryLogEntry[] {
  const rows = db
    .prepare(
      `SELECT l.*, i.name AS item_name
         FROM inventory_log l
         JOIN items i ON i.id = l.item_id
        WHERE l.player_id = ?
        ORDER BY l.id DESC`
    )
    .all(playerId) as unknown as Array<{
    id: number;
    item_id: number;
    item_name: string;
    action: InventoryAction;
    quantity_before: number;
    quantity_after: number;
    performed_by: number;
    created_at: string;
  }>;
  return rows.map((r) => ({
    id: r.id,
    itemId: r.item_id,
    itemName: r.item_name,
    action: r.action,
    quantityBefore: r.quantity_before,
    quantityAfter: r.quantity_after,
    performedBy: r.performed_by,
    createdAt: r.created_at,
  }));
}

// A rule the request broke (message is safe to show the Admin as-is).
export class InventoryRuleError extends Error {}
export class ItemNotFoundError extends Error {}

// Changes how many of one item a player holds and writes the audit row,
// WITHOUT opening a transaction — callers wrap it (changeInventory below,
// the shop's buy/sell and the case actions). Player actions (PURCHASE,
// SELL, MIX, USE…) get messages written for the player instead of the Admin.
//
// `cost` is money the player paid for the units added (purchases); it is
// added to inventory.spent. Removing units takes away the same share of
// `spent` (average cost) and reports it as `spentRemoved`, which the shop
// uses to price a sale. When the last unit goes, the weapon's upgrades go too.
//
// The case follows in the same transaction (see inventory/grid.ts): new
// units are placed (or wait in the tray), removed units leave their pieces,
// and rounds inside a gun that leaves go back into the player's ammo
// (RETURN) unless `pieces.keepRounds` says they travel with it. A backpack
// has no piece: it makes the case bigger (or smaller when it goes).
// `pieces` steers that: which piece to take from, where to put a new one,
// and whether new units must fit (buying, picking up).
export function applyInventoryChange(
  db: DatabaseSync,
  input: {
    playerId: number;
    itemId: number;
    action: InventoryAction;
    quantity: number;
    performedBy: number;
    cost?: number;
    direction?: "add" | "remove"; // MIX only: an ingredient used up, or the result made
    pieces?: SyncOpts;
  }
): { quantity: number; before: number; spentRemoved: number; sync: SyncResult | null } {
  const { playerId, itemId, action, quantity, performedBy } = input;
  const forPlayer = BY_PLAYER.includes(action);
  if (action === "MIX" && !input.direction) throw new Error("A MIX change must say which way it goes.");

  const item = db
    .prepare("SELECT name, enabled, max_stack, kind FROM items WHERE id = ?")
    .get(itemId) as { name: string; enabled: number; max_stack: number | null; kind: ItemKind } | undefined;
  if (!item) throw new ItemNotFoundError("Item not found.");

  const row = db
    .prepare("SELECT quantity, spent FROM inventory WHERE player_id = ? AND item_id = ?")
    .get(playerId, itemId) as { quantity: number; spent: number } | undefined;
  const before = row?.quantity ?? 0;
  const spentBefore = row?.spent ?? 0;
  const adds = action === "MIX" ? input.direction === "add" : ADDING.includes(action);
  const after = action === "SET" ? quantity : adds ? before + quantity : before - quantity;

  if (after < 0) {
    throw new InventoryRuleError(
      forPlayer
        ? before === 0
          ? `You don't have any ${item.name}.`
          : `You only have ${before} ${item.name}.`
        : before === 0
        ? `This player doesn't have any ${item.name}.`
        : `This player only has ${before} ${item.name}.`
    );
  }
  if (after === before) {
    throw new InventoryRuleError(`This player already has ${before} ${item.name}.`);
  }
  if (after > before) {
    // Anything that increases the count counts as giving. Things coming
    // back to a player (RETURN) or picked up off the ground already exist,
    // so a disabled item can still change hands; a RETURN also ignores the
    // per-player limit, since it only gives back what they had.
    if (item.enabled !== 1 && action !== "PICKUP" && action !== "RETURN") {
      throw new InventoryRuleError(
        forPlayer
          ? `${item.name} isn't available right now.`
          : `${item.name} is disabled. Enable it before giving it out.`
      );
    }
    if (item.max_stack !== null && after > item.max_stack && action !== "RETURN") {
      throw new InventoryRuleError(
        forPlayer
          ? `You can carry at most ${item.max_stack} ${item.name}. You have ${before}.`
          : `A player can hold at most ${item.max_stack} ${item.name}. This player has ${before}.`
      );
    }
    if (after > MAX_ITEM_QUANTITY) {
      throw new InventoryRuleError(`A player can hold at most ${MAX_ITEM_QUANTITY} of one item.`);
    }
  }

  // Money tracking: added units bring their cost; removed units take their
  // share of what was spent (exact for the last unit, so nothing is lost
  // to rounding).
  let spentAfter = spentBefore;
  let spentRemoved = 0;
  if (after > before) {
    spentAfter = spentBefore + Math.max(0, Math.floor(input.cost ?? 0));
  } else if (after < before) {
    spentRemoved = after === 0 ? spentBefore : Math.floor((spentBefore * (before - after)) / before);
    spentAfter = spentBefore - spentRemoved;
  }

  if (after === 0) {
    db.prepare("DELETE FROM inventory WHERE player_id = ? AND item_id = ?").run(playerId, itemId);
    clearUpgrades(db, playerId, itemId);
  } else if (before === 0) {
    db.prepare("INSERT INTO inventory (player_id, item_id, quantity, spent) VALUES (?, ?, ?, ?)").run(
      playerId,
      itemId,
      after,
      spentAfter
    );
  } else {
    db.prepare("UPDATE inventory SET quantity = ?, spent = ? WHERE player_id = ? AND item_id = ?").run(
      after,
      spentAfter,
      playerId,
      itemId
    );
  }

  db.prepare(
    `INSERT INTO inventory_log
       (player_id, item_id, action, quantity_before, quantity_after, performed_by)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(playerId, itemId, action, before, after, performedBy);

  // The case follows.
  let sync: SyncResult | null = null;
  if (item.kind === "backpack") {
    relayoutPlayer(db, playerId, { settle: true });
  } else {
    sync = syncItem(db, playerId, itemId, input.pieces);
    if (sync.freedRounds > 0) returnRounds(db, playerId, itemId, sync.freedRounds, performedBy);
  }

  return { quantity: after, before, spentRemoved, sync };
}

// Rounds that were inside a gun go back into the player's ammo for that gun
// (no cost, logged RETURN): the ammo they already hold if any, else the
// gun's first ammo item. A gun with no ammo item at all loses them. Returns
// how many rounds were given back.
export function returnRounds(
  db: DatabaseSync,
  playerId: number,
  gunItemId: number,
  rounds: number,
  performedBy: number
): number {
  if (!Number.isInteger(rounds) || rounds <= 0) return 0;
  const ammo = db
    .prepare(
      `SELECT i.id FROM items i
         LEFT JOIN inventory inv ON inv.item_id = i.id AND inv.player_id = ?
        WHERE i.ammo_for_item_id = ? AND i.kind = 'ammo'
        ORDER BY inv.quantity IS NULL, i.enabled DESC, i.id
        LIMIT 1`
    )
    .get(playerId, gunItemId) as { id: number } | undefined;
  if (!ammo) return 0;
  applyInventoryChange(db, { playerId, itemId: ammo.id, action: "RETURN", quantity: rounds, performedBy });
  return rounds;
}

// Adds money spent on a weapon upgrade to what the player has spent on it.
export function addSpent(db: DatabaseSync, playerId: number, itemId: number, amount: number): void {
  db.prepare("UPDATE inventory SET spent = spent + ? WHERE player_id = ? AND item_id = ?").run(amount, playerId, itemId);
}

export function getHolding(
  db: DatabaseSync,
  playerId: number,
  itemId: number
): { quantity: number; spent: number } | undefined {
  return db
    .prepare("SELECT quantity, spent FROM inventory WHERE player_id = ? AND item_id = ?")
    .get(playerId, itemId) as { quantity: number; spent: number } | undefined;
}

// Admin give/remove/set as one atomic step. Same reasoning as adjustBalance
// in money.ts: everything is synchronous, so no other request can run
// between reading the current quantity and writing — two quick taps can't
// both pass the max-per-player check and overshoot it.
// An Admin change is never refused for lack of room: what doesn't fit in
// the player's case (a big give, or a backpack taken away) waits in their
// tray. `trayed` = how many more pieces are in the tray than before.
export function changeInventory(
  db: DatabaseSync,
  input: {
    playerId: number;
    itemId: number;
    action: AdminInventoryAction;
    quantity: number;
    performedBy: number;
  }
): { quantity: number; trayed: number } {
  db.exec("BEGIN");
  try {
    const trayBefore = trayCount(db, input.playerId);
    const result = applyInventoryChange(db, input);
    const trayed = Math.max(0, trayCount(db, input.playerId) - trayBefore);
    db.exec("COMMIT");
    return { quantity: result.quantity, trayed };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
