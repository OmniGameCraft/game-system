import { FormEvent, useEffect, useState } from "react";
import { useLive } from "../../services/live";
import { Avatar } from "../../components/Avatar";
import { BackButton } from "../../components/BackButton";
import { Badge } from "../../components/Badge";
import { Button } from "../../components/Button";
import { ConfirmCard } from "../../components/ConfirmCard";
import { ErrorBanner } from "../../components/ErrorBanner";
import { PasswordField, TextField } from "../../components/Field";
import { Notice } from "../../components/Notice";
import { Section } from "../../components/Section";
import { getPlayer, Player, resetPlayerPassword, updatePlayer } from "../../services/api";
import { formatDate } from "../../utils/format";
import { InventorySection } from "./InventorySection";
import { MoneySection } from "./MoneySection";

type Tab = "money" | "items" | "account";

export function PlayerDetails({ id, onBack }: { id: number; onBack: () => void }) {
  const [player, setPlayer] = useState<Player | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("money");

  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [editError, setEditError] = useState<string | null>(null);
  const [editNotice, setEditNotice] = useState<string | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);

  const [confirmingStatus, setConfirmingStatus] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);
  const [savingStatus, setSavingStatus] = useState(false);

  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetDone, setResetDone] = useState(false);
  const [savingReset, setSavingReset] = useState(false);

  useEffect(() => {
    getPlayer(id)
      .then((p) => {
        setPlayer(p);
        setUsername(p.username);
        setDisplayName(p.displayName || "");
      })
      .catch((err) => setLoadError(err instanceof Error ? err.message : "Failed to load player."));
  }, [id]);

  // Balance and status update live (e.g. after the player buys something).
  // Only `player` is refreshed, so fields being edited aren't overwritten.
  useLive(["player:changed"], (payload) => {
    if (payload && payload.playerId !== id) return;
    getPlayer(id).then(setPlayer).catch(() => {});
  });

  async function handleSaveEdit(e: FormEvent) {
    e.preventDefault();
    if (!player || savingEdit) return;
    setEditError(null);
    setEditNotice(null);
    setSavingEdit(true);
    try {
      setPlayer(await updatePlayer(player.id, { username, displayName: displayName || null }));
      setEditNotice("Saved.");
    } catch (err) {
      setEditError(err instanceof Error ? err.message : "Could not save changes.");
    } finally {
      setSavingEdit(false);
    }
  }

  async function handleToggleStatus() {
    if (!player) return;
    setStatusError(null);
    setSavingStatus(true);
    try {
      setPlayer(await updatePlayer(player.id, { status: player.status === "active" ? "disabled" : "active" }));
      setConfirmingStatus(false);
    } catch (err) {
      setStatusError(err instanceof Error ? err.message : "Could not update status.");
    } finally {
      setSavingStatus(false);
    }
  }

  async function handleResetPassword(e: FormEvent) {
    e.preventDefault();
    if (!player || savingReset) return;
    setResetError(null);
    setResetDone(false);
    if (newPassword !== confirmNewPassword) {
      setResetError("Passwords do not match.");
      return;
    }
    setSavingReset(true);
    try {
      await resetPlayerPassword(player.id, { password: newPassword, confirmPassword: confirmNewPassword });
      setResetDone(true);
      setNewPassword("");
      setConfirmNewPassword("");
    } catch (err) {
      setResetError(err instanceof Error ? err.message : "Could not reset password.");
    } finally {
      setSavingReset(false);
    }
  }

  if (loadError) {
    return (
      <>
        <BackButton label="Players" onClick={onBack} />
        <ErrorBanner message={loadError} />
      </>
    );
  }
  if (!player) return <p className="text-ink/60">Loading…</p>;

  const name = player.displayName || player.username;
  const active = player.status === "active";

  return (
    <>
      <BackButton label="Players" onClick={onBack} />

      <div className="flex items-center gap-4 rounded-lg border-2 border-pine/20 bg-panel p-4 shadow-sm">
        <Avatar name={name} size="lg" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-2xl font-display font-bold text-ink">{name}</p>
          <p className="truncate text-ink/55">@{player.username}</p>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <Badge tone={active ? "good" : "bad"}>{active ? "Active" : "Disabled"}</Badge>
            <span className="text-lg font-display font-bold tabular-nums text-pine">${player.balance}</span>
          </div>
        </div>
      </div>

      {/* Three clear parts instead of one long page */}
      <div className="grid grid-cols-3 gap-1 rounded-lg bg-pine-soft p-1" role="tablist">
        {(
          [
            ["money", "Money"],
            ["items", "Items"],
            ["account", "Account"],
          ] as [Tab, string][]
        ).map(([k, label]) => (
          <button
            key={k}
            role="tab"
            aria-selected={tab === k}
            onClick={() => setTab(k)}
            className={`min-h-[3rem] rounded-md text-base font-bold ${tab === k ? "bg-pine text-pine-ink shadow" : "text-pine"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "money" && (
        <MoneySection
          playerId={player.id}
          balance={player.balance}
          onBalanceChange={(balance) => setPlayer((p) => (p ? { ...p, balance } : p))}
        />
      )}

      {tab === "items" && <InventorySection playerId={player.id} />}

      {tab === "account" && (
        <>
          <Section title="Profile">
            <form onSubmit={handleSaveEdit} className="flex flex-col gap-4">
              <ErrorBanner message={editError} />
              <Notice message={editNotice} />
              <TextField
                id="edit-username"
                label="Username"
                autoCapitalize="none"
                autoCorrect="off"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
              <TextField id="edit-display-name" label="Display name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
              <p className="text-sm text-ink/55">Account created {formatDate(player.createdAt)}</p>
              <Button type="submit" loading={savingEdit}>
                Save changes
              </Button>
            </form>
          </Section>

          <Section title="Reset password">
            <form onSubmit={handleResetPassword} className="flex flex-col gap-4">
              <ErrorBanner message={resetError} />
              <Notice message={resetDone ? "Password updated. Tell the player their new password." : null} />
              <PasswordField
                id="reset-password"
                label="New password"
                hint="At least 8 characters, with a letter and a number."
                autoComplete="new-password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
              <PasswordField
                id="reset-confirm-password"
                label="Confirm new password"
                autoComplete="new-password"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                required
              />
              <Button type="submit" variant="ghost" loading={savingReset}>
                Set new password
              </Button>
            </form>
          </Section>

          <Section title="Account status" tone={active ? "pine" : "alert"}>
            <ErrorBanner message={statusError} />
            <p className="text-ink/75">
              {active ? "This player can log in and play." : "This player is disabled and can't log in."}
            </p>
            {confirmingStatus ? (
              <ConfirmCard
                title={`${active ? "Disable" : "Enable"} ${name}?`}
                body={active ? `${name} will be logged out and won't be able to log in.` : `${name} will be able to log in again.`}
                confirmLabel={active ? "Disable" : "Enable"}
                tone={active ? "danger" : "primary"}
                onConfirm={handleToggleStatus}
                onCancel={() => setConfirmingStatus(false)}
                loading={savingStatus}
              />
            ) : (
              <Button variant={active ? "dangerGhost" : "primary"} onClick={() => setConfirmingStatus(true)}>
                {active ? "Disable player" : "Enable player"}
              </Button>
            )}
          </Section>
        </>
      )}
    </>
  );
}
