import { useEffect, useState } from "react";
import { Button } from "../../components/Button";
import { ErrorBanner } from "../../components/ErrorBanner";
import { ItemImage } from "../../components/ItemImage";
import { Item, listItems } from "../../services/api";

export function ItemsList({ onCreate, onOpen }: { onCreate: () => void; onOpen: (id: number) => void }) {
  const [items, setItems] = useState<Item[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listItems()
      .then(setItems)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load items."));
  }, []);

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-2xl font-bold text-pine">Items</h2>
      <ErrorBanner message={error} />
      {items === null && !error && <p className="text-ink/60">Loading…</p>}
      {items?.length === 0 && (
        <p className="rounded-xl bg-pine-soft px-4 py-4 text-ink/80">
          No items yet. Create weapons, ammo, gear or anything else your game uses.
        </p>
      )}

      <div className="flex flex-col gap-3">
        {items?.map((item) => (
          <button
            key={item.id}
            onClick={() => onOpen(item.id)}
            className="flex items-center gap-4 rounded-2xl border-2 border-ink/15 bg-white p-3 text-left"
          >
            <ItemImage url={item.imageUrl} name={item.name} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-lg font-semibold text-ink">{item.name}</p>
              <p className="truncate text-sm text-ink/60">
                {item.category || "No category"}
                {item.maxStack !== null && ` · max ${item.maxStack} each`}
              </p>
              <p className={`text-sm font-medium ${item.enabled ? "text-pine" : "text-alert"}`}>
                {item.enabled ? "Enabled" : "Disabled"}
              </p>
            </div>
          </button>
        ))}
      </div>

      <Button onClick={onCreate}>+ Create Item</Button>
    </div>
  );
}
