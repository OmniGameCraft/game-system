import { statText, TRACK_HINT, TRACK_LABEL, TrackView } from "../services/api";

export function LevelPips({ level, max, small = false }: { level: number; max: number; small?: boolean }) {
  return (
    <span className="flex shrink-0 gap-1" aria-label={`Level ${level} of ${max}`}>
      {Array.from({ length: max }, (_, i) => (
        <span
          key={i}
          className={`${small ? "h-2.5 w-3.5" : "h-3 w-5"} ${i < level ? "bg-pine" : "bg-ink/15"} transition-colors duration-300`}
          style={{ clipPath: "polygon(3px 0,100% 0,calc(100% - 3px) 100%,0 100%)" }}
        />
      ))}
    </span>
  );
}

// Compact upgrade summary for a gun or knife: one tile per upgrade (guns have
// four: magazine, damage, reload speed, fire rate; knives two). The numbers
// come straight from the server. Meant to sit full width under the item.
export function WeaponLevels({ upgrades }: { upgrades: TrackView[] }) {
  if (upgrades.length === 0) return null;
  return (
    <ul className="grid grid-cols-2 gap-2">
      {upgrades.map((t) => {
        const stat = statText(t);
        return (
          <li
            key={t.track}
            title={TRACK_HINT[t.track]}
            className="flex min-w-0 flex-col gap-1 border border-panel-line bg-panel-raised px-2.5 py-2 text-sm"
          >
            <span className="flex items-baseline justify-between gap-2">
              <span className="truncate font-semibold text-ink/80">{TRACK_LABEL[t.track] ?? t.track}</span>
              <span className="whitespace-nowrap font-display font-bold text-pine">Lv {t.level}</span>
            </span>
            <LevelPips level={t.level} max={t.maxLevel} small />
            <span className="truncate text-ink/60">{stat ?? "Level only"}</span>
          </li>
        );
      })}
    </ul>
  );
}
