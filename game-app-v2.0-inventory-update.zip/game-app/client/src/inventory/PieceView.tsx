import { CSSProperties, KeyboardEvent, MouseEvent, PointerEvent, Ref, useEffect, useState } from "react";
import type { Piece } from "./caseApi";
import { footprint } from "./layout";
import { HERB_COLOR } from "./herbs";

// How one piece looks: its picture filling the cells it covers (turned 90°
// when the piece is turned), a white number bottom-right (rounds for ammo,
// loaded rounds for guns) and a weapon slot number top-left — like the
// reference attaché case.

// The number in the corner, and whether it shows "full" (green) or "empty" (red).
export function cornerNumber(p: Piece): { text: string; tone: "full" | "empty" | "plain" } | null {
  if (p.kind === "gun") {
    const full = p.magazine !== null && p.magazine > 0 && p.loaded >= p.magazine;
    return { text: String(p.loaded), tone: p.loaded === 0 ? "empty" : full ? "full" : "plain" };
  }
  if (p.kind === "ammo") {
    return { text: String(p.quantity), tone: p.quantity >= p.stackSize ? "full" : "plain" };
  }
  if (p.quantity > 1 || p.stackSize > 1) return { text: String(p.quantity), tone: "plain" };
  return null;
}

// What a screen reader says for a piece: "Shotgun, 4 loaded".
export function pieceLabel(p: Piece, slot?: number): string {
  const parts = [p.name];
  if (p.kind === "gun") parts.push(`${p.loaded} loaded`);
  else if (p.kind === "ammo") parts.push(`${p.quantity} round${p.quantity === 1 ? "" : "s"}`);
  else if (p.quantity > 1) parts.push(`${p.quantity} of them`);
  if (slot) parts.push(`slot ${slot}`);
  if (p.x === null) parts.push("set aside, doesn't fit");
  return parts.join(", ");
}

// ---- pictures that fill their cells ----------------------------------------
// Item pictures are usually square with lots of empty (transparent) space
// around the item, so a shotgun would look tiny in its 6×2 slot. Each picture
// is measured once (where its visible part is) and drawn so that part fills
// the slot. A picture drawn the other way than its slot (e.g. a wide med kit
// in a tall 1×2 slot) is turned to fit, like the items in the reference case.

interface Visible {
  bx: number; // visible part, as fractions of the picture
  by: number;
  bw: number;
  bh: number;
  iw: number; // picture size in pixels
  ih: number;
  failed?: boolean;
}
const measured = new Map<string, Visible>();
const measuring = new Map<string, Promise<Visible>>();

function measure(url: string): Promise<Visible> {
  return new Promise((resolve) => {
    const img = new Image();
    img.decoding = "async";
    img.onload = () => {
      // An SVG without a set size reports 0×0; treat it as a 512 square.
      const iw = img.naturalWidth || 512;
      const ih = img.naturalHeight || 512;
      let v: Visible = { bx: 0, by: 0, bw: 1, bh: 1, iw, ih };
      try {
        const k = Math.min(1, 160 / Math.max(iw, ih));
        const sw = Math.max(1, Math.round(iw * k));
        const sh = Math.max(1, Math.round(ih * k));
        const c = document.createElement("canvas");
        c.width = sw;
        c.height = sh;
        const ctx = c.getContext("2d", { willReadFrequently: true } as CanvasRenderingContext2DSettings);
        if (ctx) {
          ctx.drawImage(img, 0, 0, sw, sh);
          const d = ctx.getImageData(0, 0, sw, sh).data;
          let minX = sw, minY = sh, maxX = -1, maxY = -1;
          for (let y = 0; y < sh; y++) {
            for (let x = 0; x < sw; x++) {
              if (d[(y * sw + x) * 4 + 3] > 24) {
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
              }
            }
          }
          if (maxX >= 0) v = { bx: minX / sw, by: minY / sh, bw: (maxX - minX + 1) / sw, bh: (maxY - minY + 1) / sh, iw, ih };
        }
      } catch {
        // picture from elsewhere or no canvas: use it whole
      }
      resolve(v);
    };
    img.onerror = () => resolve({ bx: 0, by: 0, bw: 1, bh: 1, iw: 1, ih: 1, failed: true });
    img.src = url;
  });
}

function useVisible(url: string): Visible | null {
  const [v, setV] = useState<Visible | null>(() => measured.get(url) ?? null);
  useEffect(() => {
    const hit = measured.get(url);
    if (hit) {
      setV(hit);
      return;
    }
    let alive = true;
    let p = measuring.get(url);
    if (!p) {
      p = measure(url).then((r) => {
        measured.set(url, r);
        measuring.delete(url);
        return r;
      });
      measuring.set(url, p);
    }
    p.then((r) => alive && setV(r));
    return () => {
      alive = false;
    };
  }, [url]);
  return v;
}

function Picture({ url, w, h, fallback }: { url: string; w: number; h: number; fallback: JSX.Element }) {
  const v = useVisible(url);
  if (v?.failed) return fallback;
  if (!v) return <img src={url} alt="" draggable={false} className="cs-img" style={{ opacity: 0 }} />;
  const vw = v.bw * v.iw;
  const vh = v.bh * v.ih;
  const contentAspect = vw / vh;
  const slotAspect = w / h;
  const turn = (contentAspect >= 1.3 && slotAspect <= 0.8) || (contentAspect <= 0.77 && slotAspect >= 1.3);
  const W = turn ? h : w;
  const H = turn ? w : h;
  const pad = Math.max(2, Math.round(Math.min(W, H) * 0.1));
  const cw = Math.max(1, W - 2 * pad);
  const ch = Math.max(1, H - 2 * pad);
  const k = Math.min(cw / vw, ch / vh);
  const style: CSSProperties = {
    width: v.iw * k,
    height: v.ih * k,
    left: pad + (cw - vw * k) / 2 - v.bx * v.iw * k,
    top: pad + (ch - vh * k) / 2 - v.by * v.ih * k,
  };
  return (
    <span
      className="cs-pic-box"
      style={{ width: W, height: H, transform: `translate(-50%, -50%)${turn ? " rotate(90deg)" : ""}` }}
    >
      <img src={url} alt="" draggable={false} className="cs-img" style={style} />
    </span>
  );
}

export function PieceArt({
  piece,
  cell,
  rotated = piece.rotated,
  slot,
  numbers = true,
}: {
  piece: Piece;
  cell: number;
  rotated?: boolean;
  slot?: number;
  numbers?: boolean;
}) {
  const fp = footprint(piece, rotated);
  // The picture is drawn in the item's own shape, then turned as a whole
  // when the piece lies the other way.
  const picStyle: CSSProperties = {
    width: piece.w * cell,
    height: piece.h * cell,
    left: "50%",
    top: "50%",
    transform: `translate(-50%, -50%)${rotated ? " rotate(90deg)" : ""}`,
  };
  const corner = numbers ? cornerNumber(piece) : null;
  const font = Math.max(11, Math.min(20, Math.round(cell * 0.36)));
  return (
    <>
      <span className="cs-pic" style={picStyle}>
        {piece.imageUrl ? (
          <Picture url={piece.imageUrl} w={piece.w * cell} h={piece.h * cell} fallback={<Silhouette piece={piece} big={fp.w * fp.h >= 2 && cell >= 30} />} />
        ) : (
          <Silhouette piece={piece} big={fp.w * fp.h >= 2 && cell >= 30} />
        )}
      </span>
      {slot !== undefined && (
        <span className="cs-slot" style={{ fontSize: Math.max(9, Math.round(font * 0.72)) }}>
          {slot}
        </span>
      )}
      {corner && (
        <span className={`cs-qty cs-qty-${corner.tone}`} style={{ fontSize: font }}>
          {corner.text}
        </span>
      )}
    </>
  );
}

// A simple drawing for items that have no picture yet.
function Silhouette({ piece, big }: { piece: Piece; big: boolean }) {
  const fill = "rgba(214, 220, 226, 0.5)";
  let art: JSX.Element;
  if (piece.herbCode) {
    const letters = piece.herbCode.split("");
    art = (
      <svg viewBox="0 0 40 40" className="cs-sil">
        <path d="M13 30h14l-2 7H15z" fill="#6b4a32" />
        {letters.map((l, i) => {
          const a = letters.length === 1 ? 0 : -30 + (60 / (letters.length - 1)) * i;
          return (
            <path
              key={i}
              d="M20 31C11 26 11 14 20 5c9 9 9 21 0 26z"
              fill={HERB_COLOR[l] ?? "#5BC45A"}
              stroke="rgba(0,0,0,.35)"
              strokeWidth="1"
              transform={`rotate(${a} 20 31)`}
            />
          );
        })}
      </svg>
    );
  } else if (piece.kind === "gun") {
    const long = piece.w / piece.h >= 2.5;
    art = long ? (
      <svg viewBox="0 0 150 50" className="cs-sil">
        <path fill={fill} d="M4 21l28-7h112v7H62l-4 6h-7l-4 9h-9l-3-9L4 35z" />
      </svg>
    ) : (
      <svg viewBox="0 0 100 60" className="cs-sil">
        <path fill={fill} d="M8 12h84v14H46l-4 6h-5l-4 18H17l5-24H8z" />
      </svg>
    );
  } else if (piece.kind === "knife") {
    art = (
      <svg viewBox="0 0 100 30" className="cs-sil">
        <path fill={fill} d="M4 12h32v7H4z" />
        <path fill="rgba(235,240,245,0.7)" d="M38 10h48l10 5-10 5H38z" />
      </svg>
    );
  } else if (piece.kind === "ammo") {
    art = (
      <svg viewBox="0 0 40 40" className="cs-sil">
        <rect x="7" y="12" width="26" height="22" rx="2" fill="rgba(200,160,70,0.65)" />
        <rect x="7" y="12" width="26" height="6" fill="rgba(0,0,0,0.25)" />
        {[12, 18, 24].map((x) => (
          <path key={x} d={`M${x} 12V6a2 2 0 0 1 4 0v6z`} fill="rgba(225,190,110,0.9)" />
        ))}
      </svg>
    );
  } else if (piece.kind === "healing") {
    art = (
      <svg viewBox="0 0 40 40" className="cs-sil">
        <rect x="6" y="10" width="28" height="22" rx="3" fill="rgba(230,235,240,0.75)" />
        <path d="M17 14h6v5h5v6h-5v5h-6v-5h-5v-6h5z" fill="#d94848" />
      </svg>
    );
  } else {
    art = (
      <svg viewBox="0 0 40 40" className="cs-sil">
        <path fill={fill} d="M20 5l14 7v16l-14 7-14-7V12z" />
        <path fill="rgba(0,0,0,0.2)" d="M20 19L6 12v16l14 7z" />
      </svg>
    );
  }
  return (
    <span className="cs-sil-wrap">
      {art}
      {big && <span className="cs-sil-name">{piece.name}</span>}
    </span>
  );
}

// A piece as a button in the grid (placed by its cell) or in the tray.
export function PieceView({
  piece,
  cell,
  slot,
  selected,
  lifted,
  fresh,
  settle,
  placed = true,
  tabIndex,
  onPointerDown,
  onClick,
  onKeyDown,
  buttonRef,
}: {
  piece: Piece;
  cell: number;
  slot?: number;
  selected?: boolean;
  lifted?: boolean; // being dragged: its home spot shows faintly
  fresh?: boolean; // just arrived (bought, picked up, mixed): pops in
  settle?: boolean; // just dropped here by a drag: appears in place, no slide
  placed?: boolean; // false = in the tray (laid out by the strip, not by x/y)
  tabIndex?: number;
  onPointerDown?: (e: PointerEvent<HTMLButtonElement>) => void;
  onClick?: (e: MouseEvent<HTMLButtonElement>) => void;
  onKeyDown?: (e: KeyboardEvent<HTMLButtonElement>) => void;
  buttonRef?: Ref<HTMLButtonElement>;
}) {
  const fp = footprint(piece, piece.rotated);
  const style: CSSProperties = {
    width: fp.w * cell,
    height: fp.h * cell,
  };
  if (placed && piece.x !== null && piece.y !== null) {
    style.transform = `translate(${piece.x * cell}px, ${piece.y * cell}px)`;
    if (settle) style.transition = "none";
  }
  const herbTint = piece.herbCode ? HERB_COLOR[piece.herbCode[piece.herbCode.length - 1]] : null;
  return (
    <button
      ref={buttonRef}
      type="button"
      data-sound="none"
      data-piece={piece.id}
      tabIndex={tabIndex}
      aria-label={pieceLabel(piece, slot)}
      aria-pressed={selected ? true : false}
      className={`cs-piece ${placed ? "is-placed" : "is-tray"} ${selected ? "is-selected" : ""} ${lifted ? "is-lifted" : ""}`}
      style={style}
      onPointerDown={onPointerDown}
      onClick={onClick}
      onKeyDown={onKeyDown}
      onContextMenu={(e) => e.preventDefault()}
    >
      <span
        className={`cs-piece-in ${fresh ? "cs-pop" : ""} ${settle ? "cs-settle" : ""}`}
        style={herbTint ? ({ "--herb": herbTint } as CSSProperties) : undefined}
        data-herb={herbTint ? "" : undefined}
      >
        <PieceArt piece={piece} cell={cell} slot={slot} />
      </span>
    </button>
  );
}
