import { Icon } from "../components/Icon";
import type { VoiceState } from "./listener";

// A tiny pill for the top bar that says whether this phone is listening
// for hit calls. "Starting" looks the same as "Listening": the microphone
// restarts every few seconds on some phones, and a flickering label would
// only worry people.
const LOOK: Record<VoiceState, { text: string; tone: "on" | "off" | "warn" | "bad"; title: string }> = {
  listening: { text: "Listening", tone: "on", title: "Listening for hit calls" },
  starting: { text: "Listening", tone: "on", title: "Starting the microphone…" },
  off: { text: "Mic off", tone: "off", title: "Not listening for hit calls" },
  insecure: { text: "Mic off", tone: "warn", title: "The microphone needs the secure (https) address — see Settings" },
  unsupported: { text: "Mic off", tone: "off", title: "This browser can't recognise speech" },
  denied: { text: "Mic blocked", tone: "bad", title: "The microphone is blocked — see Settings" },
  error: { text: "Mic error", tone: "warn", title: "The microphone stopped — trying again" },
};

const TONE = {
  on: "border-[#9DC35B]/45 bg-[#9DC35B]/10 text-[#B5D77A]",
  off: "border-white/15 bg-white/5 text-white/55",
  warn: "border-[#E9C84A]/45 bg-[#E9C84A]/10 text-[#E9C84A]",
  bad: "border-[#FF5D5D]/50 bg-[#FF5D5D]/10 text-[#FF7A7A]",
};

export function VoiceIndicator({
  state,
  hideWhenOff = false,
  onClick,
}: {
  state: VoiceState;
  hideWhenOff?: boolean; // show nothing while voice hits aren't in use
  onClick?: () => void; // e.g. open Settings › Voice hits
}): JSX.Element {
  if (hideWhenOff && state === "off") return <></>;
  const look = LOOK[state] ?? LOOK.off;
  const on = look.tone === "on";
  const body = (
    <>
      <span className="relative flex h-2 w-2 shrink-0" aria-hidden>
        {on && <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#9DC35B] opacity-70" />}
        <span className={`relative inline-flex h-2 w-2 rounded-full ${on ? "bg-[#9DC35B]" : "bg-current opacity-70"}`} />
      </span>
      <Icon name={on ? "mic" : "micOff"} className="h-3.5 w-3.5 shrink-0" />
      <span className="whitespace-nowrap">{look.text}</span>
    </>
  );
  const cls = `inline-flex h-7 shrink-0 items-center gap-1.5 rounded-full border px-2.5 text-xs font-semibold ${TONE[look.tone]}`;
  if (onClick) {
    return (
      <button type="button" onClick={onClick} className={`${cls} active:scale-95`} title={look.title} aria-label={`Voice hits: ${look.title}`}>
        {body}
      </button>
    );
  }
  return (
    <span className={cls} title={look.title} role="status" aria-label={`Voice hits: ${look.title}`}>
      {body}
    </span>
  );
}
