import { DatabaseSync } from "node:sqlite";
import { transaction } from "../database/db";
import { applyInventoryChange, getHolding, returnRounds } from "../database/inventory";
import { findItemById, imageUrlFor, Item, ItemKind } from "../database/items";
import { clearUpgrades, gunNumbers, levelsFor, MAX_LEVEL, setLevel, Track, tracksFor } from "../database/weapons";
import { CaseError, findPiece, ownPiece, setLoaded, sizeOf } from "./grid";
import { gate } from "./play";

// The drop box: things on the ground that anyone can pick up. A player can
// drop something on purpose (reason DROP); a player who goes down drops
// everything they carry (reason DEATH). Each drop remembers its owner, who
// gets back whatever is still unclaimed when the game ends.
//
// A weapon carries its story with it: rounds still loaded, its upgrade
// levels, and its share of what the owner spent on it (so selling it later
// pays the finder fairly).

type Upgrades = Partial<Record<Track, number>>;

interface DropRow {
  id: number;
  item_id: number;
  quantity: number;
  loaded: number;
  spent: number;
  upgrades: string | null;
  owner_id: number;
  dropped_by: number;
  reason: "DROP" | "DEATH";
  created_at: string;
}

// What players see in the drop box (anyone's drops — nothing private).
export interface DropView {
  id: number;
  itemId: number;
  name: string;
  kind: ItemKind;
  imageUrl: string | null;
  quantity: number;
  loaded: number;
  w: number; // the item's size in the case, unrotated
  h: number;
  ownerId: number;
  ownerName: string;
  reason: "DROP" | "DEATH"; // DEATH = "From Ali (fell)"
  createdAt: string;
  mine: boolean; // the viewer dropped it / owns it
}

// The Admin also sees who dropped it, the upgrades and the money share.
export interface AdminDropView extends DropView {
  droppedById: number;
  droppedByName: string;
  upgrades: Upgrades;
  spent: number;
}

type ListRow = DropRow &
  Pick<Item, "name" | "kind" | "image_file" | "grid_w" | "grid_h"> & { owner_name: string; dropped_by_name: string };

function listRows(db: DatabaseSync): ListRow[] {
  return db
    .prepare(
      `SELECT d.*, i.name, i.kind, i.image_file, i.grid_w, i.grid_h,
              COALESCE(o.display_name, o.username) AS owner_name,
              COALESCE(b.display_name, b.username) AS dropped_by_name
         FROM dropped_items d
         JOIN items i ON i.id = d.item_id
         JOIN users o ON o.id = d.owner_id
         JOIN users b ON b.id = d.dropped_by
        ORDER BY d.id DESC`
    )
    .all() as unknown as ListRow[];
}

function toView(r: ListRow, viewerId: number | null): DropView {
  const { w, h } = sizeOf(r);
  return {
    id: r.id,
    itemId: r.item_id,
    name: r.name,
    kind: r.kind,
    imageUrl: imageUrlFor(r.image_file),
    quantity: r.quantity,
    loaded: r.loaded,
    w,
    h,
    ownerId: r.owner_id,
    ownerName: r.owner_name,
    reason: r.reason,
    createdAt: r.created_at,
    mine: viewerId !== null && r.owner_id === viewerId,
  };
}

// Newest first.
export function listDrops(db: DatabaseSync, viewerId: number | null = null): DropView[] {
  return listRows(db).map((r) => toView(r, viewerId));
}

export function listDropsForAdmin(db: DatabaseSync): AdminDropView[] {
  return listRows(db).map((r) => ({
    ...toView(r, null),
    droppedById: r.dropped_by,
    droppedByName: r.dropped_by_name,
    upgrades: parseUpgrades(r.upgrades, r.kind),
    spent: r.spent,
  }));
}

// ---- Upgrades travel with a weapon -----------------------------------------------

// The player's levels above 1 for a weapon, or null (nothing to carry).
function upgradesOf(db: DatabaseSync, playerId: number, item: Item): Upgrades | null {
  const levels = levelsFor(db, playerId, item.id);
  const out: Upgrades = {};
  for (const t of tracksFor(item.kind)) if (levels[t] > 1) out[t] = levels[t];
  return Object.keys(out).length > 0 ? out : null;
}

// Stored JSON → levels, keeping only real tracks of this kind and real levels.
function parseUpgrades(json: string | null, kind: ItemKind): Upgrades {
  const out: Upgrades = {};
  if (!json) return out;
  try {
    const raw = JSON.parse(json) as Record<string, unknown>;
    for (const t of tracksFor(kind)) {
      const v = raw?.[t];
      if (typeof v === "number" && Number.isInteger(v) && v >= 2 && v <= MAX_LEVEL) out[t] = v;
    }
  } catch {
    // unreadable: the weapon comes without upgrades
  }
  return out;
}

// Someone gets a weapon from the drop box: if they had none of it they get
// its levels; otherwise they keep the higher level of each upgrade.
function applyDroppedUpgrades(db: DatabaseSync, playerId: number, item: Item, dropped: Upgrades, hadNone: boolean) {
  if (hadNone) clearUpgrades(db, playerId, item.id);
  const current = levelsFor(db, playerId, item.id);
  for (const [track, level] of Object.entries(dropped) as Array<[Track, number]>) {
    if (hadNone || level > current[track]) setLevel(db, playerId, item.id, track, level);
  }
}

// ---- Into the drop box ----------------------------------------------------------------

function insertDrop(
  db: DatabaseSync,
  d: {
    itemId: number;
    quantity: number;
    loaded: number;
    spent: number;
    upgrades: Upgrades | null;
    ownerId: number;
    droppedBy: number;
    reason: "DROP" | "DEATH";
  }
): number {
  const r = db
    .prepare(
      `INSERT INTO dropped_items (item_id, quantity, loaded, spent, upgrades, owner_id, dropped_by, reason)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      d.itemId,
      d.quantity,
      d.loaded,
      d.spent,
      d.upgrades ? JSON.stringify(d.upgrades) : null,
      d.ownerId,
      d.droppedBy,
      d.reason
    );
  return Number(r.lastInsertRowid);
}

// "Drop" in the case: some or all of one piece goes into the drop box.
export function dropPiece(
  db: DatabaseSync,
  playerId: number,
  input: { pieceId: unknown; quantity?: unknown }
): { dropId: number; itemName: string; quantity: number } {
  return transaction(db, () => {
    const { piece, item } = ownPiece(db, playerId, input.pieceId);
    gate(db, playerId, "drop");
    const q = input.quantity === undefined || input.quantity === null ? piece.quantity : input.quantity;
    if (typeof q !== "number" || !Number.isInteger(q) || q < 1 || q > piece.quantity) {
      throw new CaseError(
        piece.quantity === 1 ? "Invalid amount." : `Choose how many to drop (1 to ${piece.quantity}).`
      );
    }
    const upgrades = upgradesOf(db, playerId, item); // read before the last one leaves (it clears them)
    const loaded = item.kind === "gun" && q === piece.quantity ? piece.loaded : 0;
    const change = applyInventoryChange(db, {
      playerId,
      itemId: item.id,
      action: "DROP",
      quantity: q,
      performedBy: playerId,
      pieces: { takeFrom: piece.id, keepRounds: true },
    });
    const dropId = insertDrop(db, {
      itemId: item.id,
      quantity: q,
      loaded,
      spent: change.spentRemoved,
      upgrades,
      ownerId: playerId,
      droppedBy: playerId,
      reason: "DROP",
    });
    return { dropId, itemName: item.name, quantity: q };
  });
}

// A player went down: everything in their case (and tray) goes into the
// drop box, inside the same transaction as the hit that downed them.
// Backpacks stay (they're part of the case, not in it); so does money.
// Each gun is its own drop (it keeps its own loaded rounds); everything else
// is one drop per item. Returns how many drops were made.
export function dropAllOnDeath(db: DatabaseSync, playerId: number): number {
  return transaction(db, () => {
    const held = db
      .prepare(
        `SELECT inv.item_id, inv.quantity FROM inventory inv JOIN items i ON i.id = inv.item_id
          WHERE inv.player_id = ? AND i.kind != 'backpack' ORDER BY inv.item_id`
      )
      .all(playerId) as unknown as Array<{ item_id: number; quantity: number }>;
    let made = 0;
    for (const h of held) {
      const item = findItemById(db, h.item_id)!;
      const upgrades = upgradesOf(db, playerId, item);
      const guns =
        item.kind === "gun"
          ? (db
              .prepare("SELECT loaded FROM inventory_pieces WHERE player_id = ? AND item_id = ? ORDER BY id")
              .all(playerId, item.id) as unknown as Array<{ loaded: number }>)
          : [];
      const change = applyInventoryChange(db, {
        playerId,
        itemId: item.id,
        action: "DEATH",
        quantity: h.quantity,
        performedBy: playerId,
        pieces: { keepRounds: true },
      });
      const base = { itemId: item.id, upgrades, ownerId: playerId, droppedBy: playerId, reason: "DEATH" as const };
      if (item.kind === "gun") {
        // The money share is split evenly; the first gun takes any remainder.
        const each = Math.floor(change.spentRemoved / h.quantity);
        for (let i = 0; i < h.quantity; i++) {
          const spent = i === 0 ? change.spentRemoved - each * (h.quantity - 1) : each;
          insertDrop(db, { ...base, quantity: 1, loaded: guns[i]?.loaded ?? 0, spent });
          made++;
        }
      } else {
        insertDrop(db, { ...base, quantity: h.quantity, loaded: 0, spent: change.spentRemoved });
        made++;
      }
    }
    return made;
  });
}

// ---- Out of the drop box --------------------------------------------------------------

// Gives `quantity` of a drop to a player (pick up, or back to its owner)
// and takes it out of the box. Returns the new piece ids.
function giveFromDrop(
  db: DatabaseSync,
  drop: DropRow,
  to: number,
  quantity: number,
  how: { action: "PICKUP" | "RETURN"; performedBy: number; mustFit: boolean }
): number[] {
  const item = findItemById(db, drop.item_id)!;
  const hadNone = !getHolding(db, to, item.id);
  const all = quantity === drop.quantity;
  const spent = all ? drop.spent : Math.floor((drop.spent * quantity) / drop.quantity);
  const change = applyInventoryChange(db, {
    playerId: to,
    itemId: item.id,
    action: how.action,
    quantity,
    performedBy: how.performedBy,
    cost: spent,
    pieces: how.mustFit ? { mustFit: true, noRoom: "Not enough room in your case. Make space first." } : {},
  });
  const created = change.sync?.created ?? [];

  const upgrades = parseUpgrades(drop.upgrades, item.kind);
  if (Object.keys(upgrades).length > 0) applyDroppedUpgrades(db, to, item, upgrades, hadNone);

  // Rounds that were in the gun go back in it (never more than this
  // player's magazine holds; anything extra goes into their ammo).
  const loaded = all ? drop.loaded : 0;
  if (loaded > 0) {
    const gunPiece = item.kind === "gun" && created.length > 0 ? findPiece(db, created[0]) : undefined;
    const fits = gunPiece ? Math.min(loaded, gunNumbers(db, to, item).magazine) : 0;
    if (gunPiece && fits > 0) setLoaded(db, gunPiece.id, fits);
    returnRounds(db, to, item.id, loaded - fits, how.performedBy);
  }

  if (all) db.prepare("DELETE FROM dropped_items WHERE id = ?").run(drop.id);
  else
    db.prepare("UPDATE dropped_items SET quantity = quantity - ?, spent = spent - ? WHERE id = ?").run(
      quantity,
      spent,
      drop.id
    );
  return created;
}

// "Pick up" in the drop box. Everything is synchronous, so when two players
// tap the same drop at once the first one gets it and the second is told
// it's gone.
export function pickup(
  db: DatabaseSync,
  playerId: number,
  input: { dropId: unknown; quantity?: unknown }
): { itemName: string; quantity: number; pieceIds: number[] } {
  return transaction(db, () => {
    gate(db, playerId, "pickup");
    const id = input.dropId;
    const drop =
      typeof id === "number" && Number.isInteger(id) && id > 0
        ? (db.prepare("SELECT * FROM dropped_items WHERE id = ?").get(id) as DropRow | undefined)
        : undefined;
    if (!drop) throw new CaseError("Someone already picked that up.", 409);
    const q = input.quantity === undefined || input.quantity === null ? drop.quantity : input.quantity;
    if (typeof q !== "number" || !Number.isInteger(q) || q < 1) throw new CaseError("Choose how many to pick up.");
    if (q > drop.quantity) throw new CaseError(`There are only ${drop.quantity} left.`, 409);
    const item = findItemById(db, drop.item_id)!;
    const pieceIds = giveFromDrop(db, drop, playerId, q, { action: "PICKUP", performedBy: playerId, mustFit: true });
    return { itemName: item.name, quantity: q, pieceIds };
  });
}

// Every drop goes back to its owner (into their case; the tray if there's
// no room) and the box is empty. Runs when the game ends (if the
// returnDropsOnEnd rule is on) and from the Admin's "Clear drop box".
// `performedBy` = the Admin. Returns how many drops were returned.
export function returnAllToOwners(db: DatabaseSync, performedBy: number): number {
  return transaction(db, () => {
    const drops = db.prepare("SELECT * FROM dropped_items ORDER BY id").all() as unknown as DropRow[];
    for (const d of drops) {
      giveFromDrop(db, d, d.owner_id, d.quantity, { action: "RETURN", performedBy, mustFit: false });
    }
    return drops.length;
  });
}
