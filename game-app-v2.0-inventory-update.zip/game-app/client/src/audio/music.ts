import { audioContext, audioRunning, musicBus, noiseBuffer, onAudioStateChange, prepareAudioUnlock } from "./engine";
import { getSettings, subscribeSettings } from "./settings";

// Calm background music, composed live in code (no music file to download).
//
// What you hear:
//  - soft pad chords that swell in and fade out (warm, low-pass filtered)
//  - a gentle electric-piano arpeggio with a soft echo
//  - a quiet bass note on the strong beats and now and then a high bell
//  - everything in a big soft room (reverb)
//
// It never plays exactly the same way twice: every ~27-second phrase picks one
// of several chord progressions, the arpeggio pattern and how busy it is
// change, and small details (which notes, how loud, bells) are random. It all
// stays in one calm key, so any combination sounds good together.
//
// Low CPU: notes are scheduled a little ahead with a slow timer (the classic
// "lookahead" technique), only a handful of sound nodes exist at any moment,
// and nothing runs while the music is off or the app is in the background.

const BPM = 70;
const BEAT = 60 / BPM; // ≈ 0.86 s
const STEP = BEAT / 2; // eighth note
const STEPS_PER_CHORD = 16; // 2 bars
const CHORDS_PER_PHRASE = 4; // 8 bars ≈ 27 s

interface Chord {
  bass: number; // MIDI note
  pad: number[]; // 4 MIDI notes
}

// A minor / C major, voiced so neighbouring chords move smoothly.
const CHORDS: Record<string, Chord> = {
  Am9: { bass: 45, pad: [55, 60, 64, 71] },
  Fmaj9: { bass: 41, pad: [57, 60, 64, 67] },
  Cadd9: { bass: 48, pad: [55, 60, 62, 64] },
  Cmaj7: { bass: 48, pad: [55, 59, 60, 64] },
  G6: { bass: 43, pad: [55, 59, 62, 64] },
  Gsus2: { bass: 43, pad: [55, 57, 62, 67] },
  Em7: { bass: 40, pad: [52, 55, 59, 62] },
  Dm9: { bass: 50, pad: [53, 57, 60, 64] },
};

const PROGRESSIONS: string[][] = [
  ["Am9", "Fmaj9", "Cadd9", "G6"],
  ["Fmaj9", "G6", "Em7", "Am9"],
  ["Dm9", "Am9", "Fmaj9", "Gsus2"],
  ["Am9", "Em7", "Fmaj9", "Cmaj7"],
  ["Fmaj9", "Cmaj7", "Dm9", "G6"],
];

// Arpeggio patterns over one chord (16 eighth notes). Numbers pick a note
// from the chord (0 = lowest), -1 = rest.
const PATTERNS: number[][] = [
  [0, 2, 4, 2, 3, 1, 2, -1, 0, 2, 4, 5, 4, 2, 1, -1],
  [0, -1, 2, -1, 4, -1, 3, -1, 1, -1, 3, -1, 5, -1, 4, -1],
  [4, 3, 1, 2, 0, -1, -1, 1, 2, 3, 5, -1, 4, -1, 2, -1],
  [0, 1, 2, 4, -1, 4, 2, 1, 0, 1, 2, 5, -1, 5, 3, 1],
  [2, -1, 0, 1, 2, -1, 4, -1, 3, -1, 1, 2, 3, -1, 5, -1],
];

type ArpMode = "flow" | "sparse" | "rest";

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);
const pick = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];

// Chord tones for the arpeggio, in the singing range above the pads.
function arpNotes(ch: Chord): number[] {
  const pcs = new Set([ch.bass % 12, ...ch.pad.map((n) => n % 12)]);
  const out: number[] = [];
  for (let n = 67; n <= 88 && out.length < 6; n++) if (pcs.has(n % 12)) out.push(n);
  return out;
}

// A big soft room: decaying noise that gets darker as it fades, made once.
// One channel only: the reverb is the most expensive part of the music, and
// a mono room costs half as much (phone speakers are nearly mono anyway).
function makeImpulse(c: BaseAudioContext, seconds = 2.6): AudioBuffer {
  const rate = c.sampleRate;
  const len = Math.floor(rate * seconds);
  const pre = Math.floor(rate * 0.012);
  const buf = c.createBuffer(1, len, rate);
  {
    const d = buf.getChannelData(0);
    let lp = 0;
    for (let i = pre; i < len; i++) {
      const t = (i - pre) / (len - pre);
      const white = Math.random() * 2 - 1;
      const k = 0.75 - 0.6 * t; // brighter at first, darker in the tail
      lp += (white - lp) * k;
      d[i] = lp * Math.pow(1 - t, 2.2) * Math.exp(-2.4 * t);
    }
  }
  return buf;
}

// The part that makes the notes. It writes into any audio context, so it can
// also be rendered offline (used to check levels while building the app).
export class MusicGenerator {
  private c: BaseAudioContext;
  private noise: AudioBuffer;
  private pad: GainNode;
  private padFilter: BiquadFilterNode;
  private arp: GainNode;
  private bell: GainNode;
  private bass: GainNode;
  private air: GainNode;
  private lfo: OscillatorNode;
  private nextTime = 0;
  private step = 0; // eighth-note index inside the phrase
  private progression: string[] = PROGRESSIONS[0];
  private lastProgression = -1;
  private mode: ArpMode = "sparse";
  private pattern: number[] = PATTERNS[0];

  constructor(c: BaseAudioContext, out: AudioNode, noise: AudioBuffer) {
    this.c = c;
    this.noise = noise;

    const mix = c.createGain();
    mix.gain.value = 1.7; // overall music level (the Settings slider scales it)
    mix.connect(out);

    const reverb = c.createConvolver();
    reverb.buffer = makeImpulse(c);
    const verbSend = c.createGain();
    verbSend.gain.value = 1;
    const verbReturn = c.createGain();
    verbReturn.gain.value = 0.55;
    verbSend.connect(reverb).connect(verbReturn).connect(mix);

    // Pads: one shared warm filter that slowly opens and closes.
    this.pad = c.createGain();
    this.padFilter = c.createBiquadFilter();
    this.padFilter.type = "lowpass";
    this.padFilter.frequency.value = 950;
    this.padFilter.Q.value = 0.5;
    this.lfo = c.createOscillator();
    this.lfo.frequency.value = 0.035; // one slow breath every ~30 s
    const lfoDepth = c.createGain();
    lfoDepth.gain.value = 420;
    this.lfo.connect(lfoDepth).connect(this.padFilter.frequency);
    this.lfo.start();
    this.pad.connect(this.padFilter);
    const padDry = c.createGain();
    padDry.gain.value = 0.8;
    const padWet = c.createGain();
    padWet.gain.value = 0.5;
    this.padFilter.connect(padDry).connect(mix);
    this.padFilter.connect(padWet).connect(verbSend);

    // Arpeggio: soft top, plus a dotted-eighth echo that fades away.
    this.arp = c.createGain();
    const arpTone = c.createBiquadFilter();
    arpTone.type = "lowpass";
    arpTone.frequency.value = 3200;
    this.arp.connect(arpTone);
    arpTone.connect(mix);
    const echo = c.createDelay(2);
    echo.delayTime.value = STEP * 1.5;
    const feedback = c.createGain();
    feedback.gain.value = 0.3;
    const echoTone = c.createBiquadFilter();
    echoTone.type = "lowpass";
    echoTone.frequency.value = 1800;
    const echoOut = c.createGain();
    echoOut.gain.value = 0.32;
    arpTone.connect(echo);
    echo.connect(echoTone).connect(feedback).connect(echo);
    echoTone.connect(echoOut);
    echoOut.connect(mix);
    echoOut.connect(verbSend);
    const arpWet = c.createGain();
    arpWet.gain.value = 0.5;
    arpTone.connect(arpWet).connect(verbSend);

    // Bells: mostly heard through the room.
    this.bell = c.createGain();
    const bellDry = c.createGain();
    bellDry.gain.value = 0.35;
    this.bell.connect(bellDry).connect(mix);
    this.bell.connect(verbSend);

    // Bass: round and low, no room (keeps it clean on phone speakers).
    this.bass = c.createGain();
    const bassTone = c.createBiquadFilter();
    bassTone.type = "lowpass";
    bassTone.frequency.value = 520;
    this.bass.connect(bassTone).connect(mix);

    // "Air": the faintest brushed pulse on the off-beats.
    this.air = c.createGain();
    const airTone = c.createBiquadFilter();
    airTone.type = "bandpass";
    airTone.frequency.value = 7000;
    airTone.Q.value = 0.7;
    this.air.connect(airTone).connect(mix);
    airTone.connect(verbSend);
  }

  // Start a fresh phrase at time t.
  restart(t: number): void {
    this.nextTime = t;
    this.step = 0;
  }

  // Schedule every note that starts before `until` (seconds, context time).
  scheduleUntil(until: number): void {
    // Fell far behind (the phone was busy): skip ahead instead of playing a
    // burst of late notes all at once.
    if (this.nextTime < this.c.currentTime - 0.2) this.nextTime = this.c.currentTime + 0.05;
    while (this.nextTime < until) {
      this.playStep(this.step, this.nextTime);
      this.nextTime += STEP;
      this.step = (this.step + 1) % (STEPS_PER_CHORD * CHORDS_PER_PHRASE);
    }
  }

  stop(): void {
    try {
      this.lfo.stop();
    } catch {
      // already stopped
    }
  }

  private newPhrase() {
    let i = Math.floor(Math.random() * PROGRESSIONS.length);
    if (i === this.lastProgression) i = (i + 1) % PROGRESSIONS.length;
    this.lastProgression = i;
    this.progression = PROGRESSIONS[i];
    const prev = this.mode;
    const r = Math.random();
    this.mode = r < 0.45 ? "flow" : r < 0.8 ? "sparse" : "rest";
    if (this.mode === "rest" && prev === "rest") this.mode = "sparse";
  }

  private playStep(step: number, t: number) {
    if (step === 0) this.newPhrase();
    const chordIndex = Math.floor(step / STEPS_PER_CHORD);
    const inChord = step % STEPS_PER_CHORD;
    const chord = CHORDS[this.progression[chordIndex]];

    if (inChord === 0) {
      this.pattern = pick(PATTERNS);
      this.padChord(chord, t, STEPS_PER_CHORD * STEP);
    }

    // Bass: beat 1 of each bar, softer on beat 3.
    if (inChord % 8 === 0) this.bassNote(chord.bass, t, 1);
    else if (inChord % 8 === 4 && this.mode !== "rest") this.bassNote(chord.bass, t, 0.55);

    // Arpeggio
    if (this.mode !== "rest") {
      const idx = this.pattern[inChord];
      const playIt = this.mode === "flow" ? Math.random() > 0.08 : inChord % 2 === 0 && Math.random() > 0.35;
      if (idx >= 0 && playIt) {
        const notes = arpNotes(chord);
        let n = notes[Math.min(idx, notes.length - 1)];
        if (Math.random() < 0.06) n += 12; // the odd high note
        const accent = inChord % 4 === 0 ? 1 : 0.72;
        const humanize = (Math.random() - 0.5) * 0.012;
        this.arpNote(n, t + humanize, accent * (0.82 + Math.random() * 0.18));
      }
    }

    // Brushed off-beat pulse while the arpeggio flows.
    if (this.mode === "flow" && inChord % 4 === 2) this.airTick(t, inChord % 8 === 6 ? 1 : 0.6);

    // A high bell now and then (more often when the arpeggio rests).
    const bellChance = this.mode === "rest" ? 0.16 : 0.05;
    if (inChord % 2 === 1 && Math.random() < bellChance) {
      const notes = arpNotes(chord);
      this.bellNote(pick(notes) + 12, t);
    }
  }

  private padChord(ch: Chord, t: number, length: number) {
    const c = this.c;
    const attack = 1.6;
    const release = 2.8;
    for (const n of ch.pad) {
      const f = mtof(n);
      const amp = c.createGain();
      const peak = 0.03;
      amp.gain.setValueAtTime(0, t);
      amp.gain.linearRampToValueAtTime(peak, t + attack);
      amp.gain.setTargetAtTime(peak * 0.75, t + attack, 1.5);
      amp.gain.setTargetAtTime(0, t + length, release / 4);
      amp.connect(this.pad);
      // By then the note has faded to silence (about -60 dB).
      const end = t + length + release * 0.8;
      for (const cents of [-7, 6]) {
        const o = c.createOscillator();
        o.type = "sawtooth";
        o.frequency.value = f;
        o.detune.value = cents + (Math.random() - 0.5) * 3;
        o.connect(amp);
        o.start(t);
        o.stop(end);
        if (cents > 0) o.onended = () => amp.disconnect();
      }
    }
  }

  private arpNote(n: number, t: number, vel: number) {
    const c = this.c;
    const f = mtof(n);
    // Two-operator FM: a sine shaped by another sine gives a soft
    // electric-piano tone that mellows as it fades.
    const car = c.createOscillator();
    car.frequency.value = f;
    const mod = c.createOscillator();
    mod.frequency.value = f;
    const index = c.createGain();
    index.gain.setValueAtTime(f * 1.1, t);
    index.gain.exponentialRampToValueAtTime(f * 0.08, t + 0.7);
    mod.connect(index).connect(car.frequency);
    const amp = c.createGain();
    const peak = 0.075 * vel;
    amp.gain.setValueAtTime(0.0001, t);
    amp.gain.exponentialRampToValueAtTime(peak, t + 0.006);
    amp.gain.exponentialRampToValueAtTime(peak * 0.35, t + 0.35);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + 1.9);
    car.connect(amp).connect(this.arp);
    car.start(t);
    mod.start(t);
    car.stop(t + 2);
    mod.stop(t + 2);
    car.onended = () => {
      amp.disconnect();
      index.disconnect();
    };
  }

  private bellNote(n: number, t: number) {
    const c = this.c;
    const f = mtof(n);
    const amp = c.createGain();
    amp.gain.setValueAtTime(0.0001, t);
    amp.gain.exponentialRampToValueAtTime(0.03, t + 0.01);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + 3);
    amp.connect(this.bell);
    const partials: [number, number][] = [
      [1, 1],
      [2.76, 0.25],
      [5.4, 0.08],
    ];
    partials.forEach(([ratio, g], i) => {
      const o = c.createOscillator();
      o.frequency.value = f * ratio;
      const pg = c.createGain();
      pg.gain.value = g;
      o.connect(pg).connect(amp);
      o.start(t);
      o.stop(t + 3.1);
      if (i === 0) o.onended = () => amp.disconnect();
    });
  }

  private bassNote(n: number, t: number, vel: number) {
    const c = this.c;
    const o = c.createOscillator();
    o.type = "triangle";
    o.frequency.value = mtof(n);
    const amp = c.createGain();
    const peak = 0.16 * vel;
    amp.gain.setValueAtTime(0.0001, t);
    amp.gain.exponentialRampToValueAtTime(peak, t + 0.025);
    amp.gain.exponentialRampToValueAtTime(peak * 0.4, t + 0.6);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + BEAT * 2);
    o.connect(amp).connect(this.bass);
    o.start(t);
    o.stop(t + BEAT * 2 + 0.05);
    o.onended = () => amp.disconnect();
  }

  private airTick(t: number, vel: number) {
    const c = this.c;
    const src = c.createBufferSource();
    src.buffer = this.noise;
    const amp = c.createGain();
    const peak = 0.018 * vel;
    amp.gain.setValueAtTime(0.0001, t);
    amp.gain.exponentialRampToValueAtTime(peak, t + 0.01);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
    src.connect(amp).connect(this.air);
    src.start(t, Math.random() * 0.8, 0.15);
    src.onended = () => amp.disconnect();
  }
}

// ---- Playing it in the app ----

const LOOKAHEAD = 0.6; // seconds of notes scheduled ahead (survives busy moments)
const TICK_MS = 120;
const DUCKED = 0.3; // music level while the weapon screen is open

let gen: MusicGenerator | null = null;
let fade: GainNode | null = null;
let duck: GainNode | null = null;
let timer: ReturnType<typeof setInterval> | null = null;
let stopTimer: ReturnType<typeof setTimeout> | null = null;
let wanted = false;
let playing = false;
let ducked = false;
let installed = false;

function shouldPlay(): boolean {
  const s = getSettings();
  return (
    wanted &&
    s.musicOn &&
    !s.masterMute &&
    s.musicVolume > 0 &&
    document.visibilityState === "visible" &&
    audioRunning()
  );
}

function ensureGraph(): MusicGenerator {
  if (!gen) {
    const c = audioContext();
    duck = c.createGain();
    duck.gain.value = ducked ? DUCKED : 1;
    fade = c.createGain();
    fade.gain.value = 0;
    fade.connect(duck).connect(musicBus());
    gen = new MusicGenerator(c, fade, noiseBuffer());
  }
  return gen;
}

function tick() {
  if (!gen) return;
  gen.scheduleUntil(audioContext().currentTime + LOOKAHEAD);
}

function begin() {
  if (playing && !stopTimer) return; // already playing (or fading in)
  const c = audioContext();
  const g = ensureGraph();
  if (stopTimer) {
    // Was fading out: just fade back in and carry on with the same tune.
    clearTimeout(stopTimer);
    stopTimer = null;
  } else if (!playing) {
    g.restart(c.currentTime + 0.1);
  }
  playing = true;
  const p = fade!.gain;
  const t = c.currentTime;
  p.cancelScheduledValues(t);
  p.setValueAtTime(p.value, t);
  p.linearRampToValueAtTime(1, t + 3);
  if (!timer) timer = setInterval(tick, TICK_MS);
  tick();
}

function end() {
  if (!playing || stopTimer || !fade) return;
  const c = audioContext();
  const p = fade.gain;
  const t = c.currentTime;
  p.cancelScheduledValues(t);
  p.setValueAtTime(p.value, t);
  p.setTargetAtTime(0, t, 0.35);
  stopTimer = setTimeout(() => {
    stopTimer = null;
    playing = false;
    if (timer) clearInterval(timer);
    timer = null;
  }, 1600);
}

function sync() {
  if (shouldPlay()) begin();
  else end();
}

function install() {
  if (installed) return;
  installed = true;
  prepareAudioUnlock();
  subscribeSettings(sync);
  onAudioStateChange(sync);
  document.addEventListener("visibilitychange", sync);
}

// Ask for background music. It actually starts once sound is unlocked (after
// the first tap), and only while music is switched on in Settings.
export function startMusic(): void {
  install();
  wanted = true;
  sync();
}

// Fade the music out (e.g. when logging out).
export function stopMusic(): void {
  wanted = false;
  sync();
}

// Quieter while the weapon screen is open, so shots and reloads stand out.
export function duckMusic(on: boolean): void {
  ducked = on;
  if (!duck) return;
  const c = audioContext();
  const p = duck.gain;
  const t = c.currentTime;
  p.cancelScheduledValues(t);
  p.setValueAtTime(p.value, t);
  p.setTargetAtTime(on ? DUCKED : 1, t, 0.25);
}
