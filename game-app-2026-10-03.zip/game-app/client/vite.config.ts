import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// In dev, phones can open http://<LAN-IP>:5173 and API calls go to the server.
export default defineConfig({
  plugins: [react()],
  // The 3D viewer (three.js) is its own lazily-loaded chunk of ~570 KB.
  build: { chunkSizeWarningLimit: 700 },
  server: {
    host: true,
    port: 5173,
    proxy: {
      "/api": "http://localhost:3000",
      "/media": "http://localhost:3000",
      "/socket.io": { target: "http://localhost:3000", ws: true },
    },
  },
});
