import express, { Router } from "express";
import type { DatabaseSync } from "node:sqlite";
import { randomBytes } from "crypto";
import fs from "fs";
import path from "path";
import { requireRole } from "../auth/middleware";
import { ITEM_IMAGE_DIR } from "../config";
import { MAX_ITEM_QUANTITY } from "../database/inventory";
import {
  GRID_MAX,
  HERB_CODES,
  ITEM_KINDS,
  createItem,
  findItemById,
  findItemByName,
  ItemFields,
  listItems,
  setItemFile,
  setItemImage,
  toPublicItem,
  updateItem,
  withKindDefaults,
} from "../database/items";

const NAME_MAX = 60;
const DESCRIPTION_MAX = 500;
const CATEGORY_MAX = 40;
const IMAGE_MAX_BYTES = 2 * 1024 * 1024;

// Only this route gets a larger JSON body limit (index.ts skips the default
// 100 KB parser for it). It runs after requireRole, so a non-Admin can't
// make the server parse a multi-megabyte body.
export const IMAGE_UPLOAD_PATH = /^\/api\/admin\/items\/\d+\/image$/;
const imageJson = express.json({ limit: "4mb" });

type FieldResult = { ok: true; fields: ItemFields } | { ok: false; error: string };

function optionalText(value: unknown, max: number, label: string): string | null | Error {
  if (value === null || value === undefined) return null;
  if (typeof value !== "string") return new Error(`Invalid ${label}.`);
  const trimmed = value.trim();
  if (trimmed.length > max) return new Error(`${label} can be at most ${max} characters.`);
  return trimmed === "" ? null : trimmed;
}

// Validates whichever item fields are present in the body. For create,
// `requireName` is true. Nothing from the client is written without passing
// through here.
function parseItemFields(body: any, requireName: boolean): FieldResult {
  const fields: ItemFields = {};
  const b = body ?? {};

  if (b.name !== undefined || requireName) {
    if (typeof b.name !== "string" || b.name.trim() === "") {
      return { ok: false, error: "Item name is required." };
    }
    const name = b.name.trim();
    if (name.length > NAME_MAX) {
      return { ok: false, error: `Item name can be at most ${NAME_MAX} characters.` };
    }
    fields.name = name;
  }

  if (b.description !== undefined) {
    const d = optionalText(b.description, DESCRIPTION_MAX, "Description");
    if (d instanceof Error) return { ok: false, error: d.message };
    fields.description = d;
  }

  if (b.category !== undefined) {
    const c = optionalText(b.category, CATEGORY_MAX, "Category");
    if (c instanceof Error) return { ok: false, error: c.message };
    fields.category = c;
  }

  if (b.maxStack !== undefined) {
    if (b.maxStack === null) {
      fields.maxStack = null;
    } else if (
      typeof b.maxStack !== "number" ||
      !Number.isInteger(b.maxStack) ||
      b.maxStack < 1 ||
      b.maxStack > MAX_ITEM_QUANTITY
    ) {
      return {
        ok: false,
        error: `Max per player must be a whole number between 1 and ${MAX_ITEM_QUANTITY}, or empty for no limit.`,
      };
    } else {
      fields.maxStack = b.maxStack;
    }
  }

  if (b.enabled !== undefined) {
    if (typeof b.enabled !== "boolean") return { ok: false, error: "Invalid enabled value." };
    fields.enabled = b.enabled;
  }

  if (b.useEffect !== undefined) {
    if (b.useEffect !== "none" && b.useEffect !== "shot" && b.useEffect !== "swing") {
      return { ok: false, error: "Invalid tap action." };
    }
    fields.useEffect = b.useEffect;
  }
  for (const key of ["modelFlip", "modelUpsideDown"] as const) {
    if (b[key] !== undefined) {
      if (typeof b[key] !== "boolean") return { ok: false, error: "Invalid model setting." };
      fields[key] = b[key];
    }
  }

  // ---- Shop update: type, ammo, selling, weapon stats, upgrade prices ----
  if (b.kind !== undefined) {
    if (!ITEM_KINDS.includes(b.kind)) return { ok: false, error: "Invalid item type." };
    fields.kind = b.kind;
  }
  if (b.sellable !== undefined) {
    if (typeof b.sellable !== "boolean") return { ok: false, error: "Invalid sell setting." };
    fields.sellable = b.sellable;
  }
  if (b.sellPercent !== undefined) {
    if (!isWhole(b.sellPercent, 0, 100)) return { ok: false, error: "Sell-back must be a whole percent from 0 to 100." };
    fields.sellPercent = b.sellPercent;
  }
  if (b.ammoForItemId !== undefined) {
    if (b.ammoForItemId !== null && !isWhole(b.ammoForItemId, 1, Number.MAX_SAFE_INTEGER)) {
      return { ok: false, error: "Choose which gun this ammo is for." };
    }
    fields.ammoForItemId = b.ammoForItemId;
  }
  const wholeOrNull: Array<[keyof ItemFields, string, number, number]> = [
    ["ammoPerPack", "Rounds per pack", 1, 10_000],
    ["baseMagazine", "Magazine size", 1, 10_000],
    ["baseSharpness", "Sharpness", 1, 10_000],
    ["baseLength", "Length", 1, 10_000],
    ["upPriceMagazine", "Magazine upgrade price", 0, 1_000_000_000],
    ["upPriceDamage", "Damage upgrade price", 0, 1_000_000_000],
    ["upPriceSharpness", "Sharpness upgrade price", 0, 1_000_000_000],
    ["upPriceLength", "Length upgrade price", 0, 1_000_000_000],
    // 2.0 Inventory Update
    ["upPriceReload", "Reload speed upgrade price", 0, 1_000_000_000],
    ["upPriceFirerate", "Fire rate upgrade price", 0, 1_000_000_000],
    ["stackSize", "Units per case slot", 1, MAX_ITEM_QUANTITY],
    ["healAmount", "Heals (HP)", 0, 2000],
    ["maxHpBonus", "Max HP bonus", 0, 2000],
    ["baseReloadMs", "Reload time (milliseconds)", 200, 10_000],
    ["shakeForce", "Shake needed", 1, 10],
    ["expandRows", "Rows added to the case", 1, 5],
  ];
  for (const [key, label, min, max] of wholeOrNull) {
    const v = b[key];
    if (v === undefined) continue;
    if (v !== null && !isWhole(v, min, max)) {
      return { ok: false, error: `${label} must be a whole number from ${min} to ${max}, or empty.` };
    }
    (fields as Record<string, unknown>)[key] = v;
  }

  // ---- Inventory update: case size, healing, herbs, calculator ----
  for (const [key, label] of [
    ["gridW", "Width in the case"],
    ["gridH", "Height in the case"],
  ] as const) {
    if (b[key] === undefined) continue;
    if (!isWhole(b[key], 1, GRID_MAX)) {
      return { ok: false, error: `${label} must be a whole number of squares from 1 to ${GRID_MAX}.` };
    }
    fields[key] = b[key];
  }
  if (b.fullHeal !== undefined) {
    if (typeof b.fullHeal !== "boolean") return { ok: false, error: "Invalid full heal setting." };
    fields.fullHeal = b.fullHeal;
  }
  if (b.herbCode !== undefined) {
    const code = typeof b.herbCode === "string" ? b.herbCode.trim().toUpperCase() : b.herbCode;
    if (code === null || code === "") {
      fields.herbCode = null;
    } else if (HERB_CODES.includes(code)) {
      fields.herbCode = code;
    } else {
      return { ok: false, error: "Herb type must be G, R, Y, GG, GR, GY, GRY or GGY, or empty if it isn't a herb." };
    }
  }
  if (b.hre !== undefined) {
    if (b.hre !== null && !(typeof b.hre === "number" && Number.isFinite(b.hre) && b.hre > 0 && b.hre <= 1000)) {
      return {
        ok: false,
        error: "Handgun rounds per round must be a number above 0 (like 1, 1.5 or 5), up to 1000, or empty.",
      };
    }
    // Two decimals is plenty and keeps the calculator's numbers tidy.
    fields.hre = b.hre === null ? null : Math.round(b.hre * 100) / 100 || 0.01;
  }

  return { ok: true, fields };
}

function isWhole(n: unknown, min: number, max: number): n is number {
  return typeof n === "number" && Number.isInteger(n) && n >= min && n <= max;
}

// Decides the file type from the file's own bytes, not from anything the
// client claims. SVG is deliberately not accepted (it can carry scripts).
function detectImageType(buf: Buffer): "png" | "jpg" | "webp" | "gif" | null {
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])))
    return "png";
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (buf.length >= 12 && buf.toString("ascii", 0, 4) === "RIFF" && buf.toString("ascii", 8, 12) === "WEBP")
    return "webp";
  if (buf.length >= 6 && (buf.toString("ascii", 0, 6) === "GIF87a" || buf.toString("ascii", 0, 6) === "GIF89a"))
    return "gif";
  return null;
}

// 3D models (.glb) and sounds are sent as the raw file (not base64 JSON),
// since models can be a few megabytes.
const MODEL_MAX_BYTES = 15 * 1024 * 1024;
const SOUND_MAX_BYTES = 3 * 1024 * 1024;
const modelBody = express.raw({ type: () => true, limit: MODEL_MAX_BYTES });
const soundBody = express.raw({ type: () => true, limit: SOUND_MAX_BYTES });

// A binary glTF file starts with "glTF", version 2, then its total length.
function isGlb(buf: Buffer): boolean {
  return (
    buf.length >= 20 &&
    buf.toString("ascii", 0, 4) === "glTF" &&
    buf.readUInt32LE(4) === 2 &&
    buf.readUInt32LE(8) === buf.length
  );
}

function detectSoundType(buf: Buffer): "mp3" | "ogg" | "wav" | "m4a" | null {
  if (buf.length < 12) return null;
  if (buf.toString("ascii", 0, 3) === "ID3") return "mp3";
  if (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0) return "mp3"; // MPEG frame sync
  if (buf.toString("ascii", 0, 4) === "OggS") return "ogg";
  if (buf.toString("ascii", 0, 4) === "RIFF" && buf.toString("ascii", 8, 12) === "WAVE") return "wav";
  if (buf.toString("ascii", 4, 8) === "ftyp") return "m4a";
  return null;
}

function removeImageFile(file: string | null) {
  if (!file) return;
  fs.promises.unlink(path.join(ITEM_IMAGE_DIR, file)).catch(() => {});
}

export function createItemsRouter(db: DatabaseSync): Router {
  const router = Router();
  router.use(requireRole("admin"));

  // Ammo must point at an existing gun (not at itself).
  function checkAmmoTarget(target: number | null | undefined, selfId: number | null): string | null {
    if (target === undefined || target === null) return null;
    const gun = findItemById(db, target);
    if (!gun || gun.id === selfId || gun.kind !== "gun") return "Ammo must be for one of your guns.";
    return null;
  }

  function getItemOr404(id: number) {
    return Number.isInteger(id) ? findItemById(db, id) ?? null : null;
  }

  router.get("/", (_req, res) => {
    res.json({ items: listItems(db).map(toPublicItem) });
  });

  router.post("/", (req, res) => {
    const parsed = parseItemFields(req.body, true);
    if (!parsed.ok) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    const f = parsed.fields;
    if (findItemByName(db, f.name!)) {
      res.status(409).json({ error: "An item with that name already exists." });
      return;
    }
    const ammoErr = checkAmmoTarget(f.ammoForItemId, null);
    if (ammoErr) {
      res.status(400).json({ error: ammoErr });
      return;
    }
    const item = createItem(db, { ...f, name: f.name! });
    res.status(201).json({ item: toPublicItem(item) });
  });

  router.get("/:id", (req, res) => {
    const item = getItemOr404(Number(req.params.id));
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    res.json({ item: toPublicItem(item) });
  });

  router.patch("/:id", (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    const parsed = parseItemFields(req.body, false);
    if (!parsed.ok) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    if (parsed.fields.name !== undefined) {
      const existing = findItemByName(db, parsed.fields.name);
      if (existing && existing.id !== id) {
        res.status(409).json({ error: "An item with that name already exists." });
        return;
      }
    }
    const ammoErr = checkAmmoTarget(parsed.fields.ammoForItemId, id);
    if (ammoErr) {
      res.status(400).json({ error: ammoErr });
      return;
    }
    res.json({ item: toPublicItem(updateItem(db, id, withKindDefaults(item, parsed.fields))) });
  });

  // Body: { image: "data:image/png;base64,..." } — the client shrinks the
  // picture first, so real uploads are small.
  router.post("/:id/image", imageJson, (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    const image = req.body?.image;
    const match = typeof image === "string" ? /^data:[\w/+.-]*;base64,([A-Za-z0-9+/=]+)$/.exec(image) : null;
    if (!match) {
      res.status(400).json({ error: "Please choose a PNG, JPG, WEBP or GIF picture." });
      return;
    }
    const buf = Buffer.from(match[1], "base64");
    if (buf.length === 0 || buf.length > IMAGE_MAX_BYTES) {
      res.status(400).json({ error: "Picture must be smaller than 2 MB." });
      return;
    }
    const ext = detectImageType(buf);
    if (!ext) {
      res.status(400).json({ error: "Please choose a PNG, JPG, WEBP or GIF picture." });
      return;
    }

    // New random file name each time, so phones never show a stale cached picture.
    const file = `item-${id}-${randomBytes(6).toString("hex")}.${ext}`;
    try {
      fs.mkdirSync(ITEM_IMAGE_DIR, { recursive: true });
      fs.writeFileSync(path.join(ITEM_IMAGE_DIR, file), buf);
    } catch {
      res.status(500).json({ error: "Could not save the picture. Please try again." });
      return;
    }
    setItemImage(db, id, file);
    removeImageFile(item.image_file);
    res.json({ item: toPublicItem(findItemById(db, id)!) });
  });

  // Body: the .glb file itself (Content-Type: application/octet-stream).
  router.post("/:id/model", modelBody, (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    const buf = req.body;
    if (!Buffer.isBuffer(buf) || !isGlb(buf)) {
      res.status(400).json({ error: "Please choose a 3D model in .glb format." });
      return;
    }
    const file = `item-${id}-model-${randomBytes(6).toString("hex")}.glb`;
    try {
      fs.mkdirSync(ITEM_IMAGE_DIR, { recursive: true });
      fs.writeFileSync(path.join(ITEM_IMAGE_DIR, file), buf);
    } catch {
      res.status(500).json({ error: "Could not save the model. Please try again." });
      return;
    }
    setItemFile(db, id, "model_file", file);
    removeImageFile(item.model_file);
    res.json({ item: toPublicItem(findItemById(db, id)!) });
  });

  router.delete("/:id/model", (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    setItemFile(db, id, "model_file", null);
    removeImageFile(item.model_file);
    res.json({ item: toPublicItem(findItemById(db, id)!) });
  });

  // Body: the sound file itself (MP3, OGG, WAV or M4A).
  router.post("/:id/sound", soundBody, (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    const buf = req.body;
    const ext = Buffer.isBuffer(buf) ? detectSoundType(buf) : null;
    if (!ext) {
      res.status(400).json({ error: "Please choose an MP3, OGG, WAV or M4A sound." });
      return;
    }
    const file = `item-${id}-sound-${randomBytes(6).toString("hex")}.${ext}`;
    try {
      fs.mkdirSync(ITEM_IMAGE_DIR, { recursive: true });
      fs.writeFileSync(path.join(ITEM_IMAGE_DIR, file), buf);
    } catch {
      res.status(500).json({ error: "Could not save the sound. Please try again." });
      return;
    }
    setItemFile(db, id, "sound_file", file);
    removeImageFile(item.sound_file);
    res.json({ item: toPublicItem(findItemById(db, id)!) });
  });

  router.delete("/:id/sound", (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    setItemFile(db, id, "sound_file", null);
    removeImageFile(item.sound_file);
    res.json({ item: toPublicItem(findItemById(db, id)!) });
  });

  router.delete("/:id/image", (req, res) => {
    const id = Number(req.params.id);
    const item = getItemOr404(id);
    if (!item) {
      res.status(404).json({ error: "Item not found." });
      return;
    }
    setItemImage(db, id, null);
    removeImageFile(item.image_file);
    res.json({ item: toPublicItem(findItemById(db, id)!) });
  });

  return router;
}
