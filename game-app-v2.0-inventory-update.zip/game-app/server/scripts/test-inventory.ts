// Tests for the case (grid inventory), drop box, herb mixing, firing,
// reloading and healing — the 2.0 "Inventory Update" server code.
//
// Runs against a fresh database in a temporary folder (your real game data
// is never touched):
//   npx tsx server/scripts/test-inventory.ts
// Prints PASS/FAIL for each check and exits with code 1 if anything failed.

import fs from "fs";
import os from "os";
import path from "path";

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "inventory-test-"));
// Must be set before the server code is loaded (config.ts reads it once).
process.env.DB_PATH = path.join(tmp, "game.db");

let passed = 0;
let failed = 0;
let section = "";

function title(name: string) {
  section = name;
  console.log(`\n== ${name}`);
}

function check(name: string, ok: boolean, detail?: unknown) {
  if (ok) {
    passed++;
    console.log(`  PASS  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL  ${name}${detail === undefined ? "" : `  →  ${JSON.stringify(detail)}`}  [${section}]`);
  }
}

function eq(name: string, actual: unknown, expected: unknown) {
  check(name, JSON.stringify(actual) === JSON.stringify(expected), { actual, expected });
}

async function main() {
  const { openDatabase } = await import("../src/database/db");
  const { createUser } = await import("../src/database/users");
  const { findItemByName, updateItem, createItem } = await import("../src/database/items");
  const { changeInventory, getHolding, addSpent } = await import("../src/database/inventory");
  const { adjustBalance } = await import("../src/database/money");
  const { createShopItem, setShopOpen, purchase, sell, NO_ROOM_TO_BUY, findShopItemByItemId } = await import(
    "../src/database/shop"
  );
  const { setGameStatus, resetRound } = await import("../src/database/game");
  const { damage, getHp } = await import("../src/database/health");
  const { updateRules } = await import("../src/database/settings");
  const { gunNumbers, levelsFor, setLevel } = await import("../src/database/weapons");
  const { readPacks, createItemFromPack } = await import("../src/routes/packs");
  const inv = await import("../src/inventory");
  const {
    initInventory,
    canFit,
    caseSize,
    caseView,
    footprint,
    stackSizeOf,
    movePiece,
    splitPiece,
    arrange,
    combine,
    fire,
    reload,
    useHealing,
    dropPiece,
    pickup,
    returnAllToOwners,
    listDrops,
    CaseError,
  } = inv;

  const db = openDatabase();
  initInventory(db);

  // ---- helpers -------------------------------------------------------------
  const admin = createUser(db, { role: "admin", username: "admin", passwordHash: "x" });
  let nextPlayer = 1;
  const newPlayer = () => createUser(db, { role: "player", username: `p${nextPlayer++}`, passwordHash: "x" }).id;
  const item = (name: string) => {
    const it = findItemByName(db, name);
    if (!it) throw new Error(`no item ${name}`);
    return it;
  };
  const id = (name: string) => item(name).id;
  const give = (p: number, name: string, q: number) =>
    changeInventory(db, { playerId: p, itemId: id(name), action: "GIVE", quantity: q, performedBy: admin.id });
  const remove = (p: number, name: string, q: number) =>
    changeInventory(db, { playerId: p, itemId: id(name), action: "REMOVE", quantity: q, performedBy: admin.id });
  const setQty = (p: number, name: string, q: number) =>
    changeInventory(db, { playerId: p, itemId: id(name), action: "SET", quantity: q, performedBy: admin.id });
  type P = { id: number; x: number | null; y: number | null; rotated: number; quantity: number; loaded: number };
  const piecesOf = (p: number, name?: string): P[] =>
    (name
      ? db
          .prepare("SELECT * FROM inventory_pieces WHERE player_id = ? AND item_id = ? ORDER BY id")
          .all(p, id(name))
      : db.prepare("SELECT * FROM inventory_pieces WHERE player_id = ? ORDER BY id").all(p)) as unknown as P[];
  const qtys = (p: number, name: string) => piecesOf(p, name).map((x) => x.quantity);
  const held = (p: number, name: string) => getHolding(db, p, id(name))?.quantity ?? 0;
  const lastLog = (p: number) =>
    db.prepare("SELECT action, quantity_before AS b, quantity_after AS a FROM inventory_log WHERE player_id = ? ORDER BY id DESC LIMIT 1").get(p) as {
      action: string;
      b: number;
      a: number;
    };
  const logCount = (p: number, action: string) =>
    (db.prepare("SELECT COUNT(*) AS n FROM inventory_log WHERE player_id = ? AND action = ?").get(p, action) as { n: number }).n;

  // Runs fn and checks it fails with exactly this message (and status).
  function fails(name: string, fn: () => unknown, message: string | RegExp, status?: number) {
    try {
      fn();
      check(name, false, "no error");
    } catch (e) {
      const m = (e as Error).message;
      let ok = typeof message === "string" ? m === message : message.test(m);
      if (status !== undefined) ok = ok && e instanceof CaseError && e.status === status;
      check(name, ok, { got: m, status: (e as { status?: number }).status });
    }
  }

  // THE invariant, plus a sane layout, for every player.
  function invariant(label: string) {
    const problems: string[] = [];
    const rows = db
      .prepare(
        `SELECT inv.player_id AS p, inv.item_id AS i, inv.quantity AS q, it.kind,
                (SELECT COALESCE(SUM(quantity), 0) FROM inventory_pieces x
                  WHERE x.player_id = inv.player_id AND x.item_id = inv.item_id) AS s
           FROM inventory inv JOIN items it ON it.id = inv.item_id`
      )
      .all() as unknown as Array<{ p: number; i: number; q: number; kind: string; s: number }>;
    for (const r of rows) {
      if (r.kind === "backpack" ? r.s !== 0 : r.s !== r.q) problems.push(`player ${r.p} item ${r.i}: ${r.s} vs ${r.q}`);
    }
    const orphans = db
      .prepare(
        `SELECT COUNT(*) AS n FROM inventory_pieces x
          WHERE NOT EXISTS (SELECT 1 FROM inventory inv WHERE inv.player_id = x.player_id AND inv.item_id = x.item_id)`
      )
      .get() as { n: number };
    if (orphans.n > 0) problems.push(`${orphans.n} pieces without inventory`);
    const players = db.prepare("SELECT DISTINCT player_id AS p FROM inventory_pieces").all() as unknown as Array<{ p: number }>;
    for (const { p } of players) {
      const size = caseSize(db, p);
      const seen = new Map<string, number>();
      for (const pc of db.prepare("SELECT * FROM inventory_pieces WHERE player_id = ?").all(p) as unknown as P[]) {
        const it = db.prepare("SELECT * FROM items WHERE id = (SELECT item_id FROM inventory_pieces WHERE id = ?)").get(pc.id) as never;
        if (pc.quantity > stackSizeOf(it)) problems.push(`piece ${pc.id} over its stack`);
        const kind = (it as { kind: string }).kind;
        if (kind === "gun") {
          const cap = gunNumbers(db, p, it).magazine;
          if (pc.loaded > cap) problems.push(`piece ${pc.id} loaded ${pc.loaded} > ${cap}`);
        } else if (pc.loaded !== 0) problems.push(`piece ${pc.id} (not a gun) has loaded rounds`);
        if (pc.x === null) continue;
        const { w, h } = footprint(it, pc.rotated);
        if (pc.x < 0 || pc.y! < 0 || pc.x + w > size.cols || pc.y! + h > size.rows) problems.push(`piece ${pc.id} out of the case`);
        for (let y = pc.y!; y < pc.y! + h; y++)
          for (let x = pc.x; x < pc.x + w; x++) {
            const k = `${x},${y}`;
            if (seen.has(k)) problems.push(`piece ${pc.id} overlaps piece ${seen.get(k)} at ${k}`);
            seen.set(k, pc.id);
          }
      }
    }
    check(`invariant holds (${label})`, problems.length === 0, problems.slice(0, 5));
  }

  // ---- the catalogue: the whole item pack except the mixed herbs ------------
  title("Item pack");
  const pack = readPacks().find((p) => p.id === "weapons")!;
  const order = [...pack.items].sort((a, b) => Number(a.kind === "ammo") - Number(b.kind === "ammo"));
  for (const pi of order) if (!pi.herbCode || pi.herbCode.length === 1) createItemFromPack(db, pack, pi);
  check("16 pack items imported (mixed herbs left out)", (db.prepare("SELECT COUNT(*) AS n FROM items").get() as { n: number }).n === 16);
  eq("pistol ammo stacks 60 per cell", stackSizeOf(item("Pistol Ammo")), 60);
  eq("guns stack 1", stackSizeOf(item("Pistol")), 1);
  eq("assault rifle is 6×2", footprint(item("Assault Rifle"), false), { w: 6, h: 2 });

  // ---- give / remove / set ----------------------------------------------------
  title("Give, remove, set, stacking");
  const pA = newPlayer();
  give(pA, "Pistol", 1);
  let pistolA = piecesOf(pA, "Pistol")[0];
  eq("pistol placed top-left", [pistolA.x, pistolA.y, pistolA.rotated], [0, 0, 0]);
  give(pA, "Pistol Ammo", 75);
  eq("75 rounds = a full stack + 15", qtys(pA, "Pistol Ammo"), [60, 15]);
  eq("ammo next to the pistol", piecesOf(pA, "Pistol Ammo").map((p) => [p.x, p.y]), [[3, 0], [4, 0]]);
  give(pA, "Pistol Ammo", 50);
  eq("part-full stack topped up first", qtys(pA, "Pistol Ammo"), [60, 60, 5]);
  remove(pA, "Pistol Ammo", 3);
  eq("remove takes from the smallest stack", qtys(pA, "Pistol Ammo"), [60, 60, 2]);
  remove(pA, "Pistol Ammo", 2);
  eq("emptied stack disappears", qtys(pA, "Pistol Ammo"), [60, 60]);
  setQty(pA, "Pistol Ammo", 100);
  eq("set 100: the newest stack gives up 20", qtys(pA, "Pistol Ammo"), [60, 40]);
  eq("inventory says 100", held(pA, "Pistol Ammo"), 100);
  setQty(pA, "Pistol Ammo", 0);
  eq("set 0 removes every piece", piecesOf(pA, "Pistol Ammo").length, 0);
  give(pA, "Backpack Expansion", 1);
  eq("backpack has no piece", piecesOf(pA, "Backpack Expansion").length, 0);
  eq("backpack adds a row", caseSize(db, pA), { cols: 8, rows: 5, expansions: 1 });
  invariant("give/remove/set");

  // ---- rotation, tray, backpacks -----------------------------------------------
  title("Rotation, tray, backpack expansion");
  const pR = newPlayer();
  give(pR, "Assault Rifle", 2);
  eq("two rifles stacked down the left", piecesOf(pR, "Assault Rifle").map((p) => [p.x, p.y]), [[0, 0], [0, 2]]);
  give(pR, "Pistol", 1);
  const pistolR = piecesOf(pR, "Pistol")[0];
  eq("pistol only fits turned: rotated at (6,0)", [pistolR.x, pistolR.y, pistolR.rotated], [6, 0, 1]);
  const viewR = caseView(db, pR).pieces.find((p) => p.id === pistolR.id)!;
  eq("view gives the item's own size (3×2) + rotated; phones swap it", [viewR.w, viewR.h, viewR.rotated], [3, 2, true]);
  const gaveSniper = give(pR, "Sniper Rifle", 1);
  eq("sniper doesn't fit: goes to the tray", [gaveSniper.trayed, piecesOf(pR, "Sniper Rifle")[0].x], [1, null]);
  eq("tray shows in the view", caseView(db, pR).tray.map((p) => p.name), ["Sniper Rifle"]);
  check("a herb would fit, but the tray needs room first → canFit false", !canFit(db, pR, id("Green Herb"), 1));
  give(pR, "Backpack Expansion", 1);
  eq("one expansion: sniper still can't fit", piecesOf(pR, "Sniper Rifle")[0].x, null);
  give(pR, "Backpack Expansion", 1);
  eq("two expansions: case is 8×6", caseSize(db, pR), { cols: 8, rows: 6, expansions: 2 });
  const sniperR = piecesOf(pR, "Sniper Rifle")[0];
  eq("the bigger case pulls the sniper in from the tray", [sniperR.x, sniperR.y], [0, 4]);
  check("canFit true again", canFit(db, pR, id("Green Herb"), 1));
  const shrink = setQty(pR, "Backpack Expansion", 0);
  eq("expansions gone: case back to 8×4", caseSize(db, pR).rows, 4);
  eq("the Admin is told a piece went to the tray", shrink.trayed, 1);
  eq("sniper back to the tray", piecesOf(pR, "Sniper Rifle")[0].x, null);
  invariant("rotation/tray");

  // ---- move, merge, split, arrange ----------------------------------------------
  title("Move, merge, split, arrange");
  const pM = newPlayer();
  give(pM, "Pistol Ammo", 90);
  let [a60, a30] = piecesOf(pM, "Pistol Ammo");
  eq("ammo 60 at (0,0) and 30 at (1,0)", [a60.x, a60.y, a30.x, a30.y], [0, 0, 1, 0]);
  movePiece(db, pM, { pieceId: a30.id, x: 7, y: 3, rotated: false });
  eq("moved to (7,3)", [piecesOf(pM, "Pistol Ammo")[1].x, piecesOf(pM, "Pistol Ammo")[1].y], [7, 3]);
  fails("drop onto a full stack", () => movePiece(db, pM, { pieceId: a30.id, x: 0, y: 0, rotated: false }), "That stack is full.");
  fails("outside the case", () => movePiece(db, pM, { pieceId: a30.id, x: 8, y: 0, rotated: false }), "That doesn't fit there.");
  fails("bad coordinates", () => movePiece(db, pM, { pieceId: a30.id, x: "1", y: 0, rotated: false }), "Choose a square in your case.");
  fails("someone else's piece", () => movePiece(db, pA, { pieceId: a30.id, x: 2, y: 2, rotated: false }), "That isn't in your case any more.", 404);
  const split1 = splitPiece(db, pM, { pieceId: a60.id, quantity: 20 });
  eq("split 20 off the 60", qtys(pM, "Pistol Ammo"), [40, 30, 20]);
  const s20 = piecesOf(pM, "Pistol Ammo").find((p) => p.id === split1.newPieceId)!;
  eq("split stack goes to the first free cell", [s20.x, s20.y], [1, 0]);
  fails("split too many", () => splitPiece(db, pM, { pieceId: a60.id, quantity: 40 }), "Choose how many to move to the new stack (1 to 39).");
  const m1 = movePiece(db, pM, { pieceId: split1.newPieceId, x: 7, y: 3, rotated: false });
  eq("dropping 20 onto 30 merges all of it", [m1.merged, m1.moved, qtys(pM, "Pistol Ammo")], [true, 20, [40, 50]]);
  const m2 = movePiece(db, pM, { pieceId: a60.id, x: 7, y: 3, rotated: false });
  eq("dropping 40 onto 50 merges only 10 (stack of 60)", [m2.merged, m2.moved, qtys(pM, "Pistol Ammo")], [true, 10, [30, 60]]);
  give(pM, "Pistol", 1);
  const pistolM = piecesOf(pM, "Pistol")[0];
  fails("pistol hanging off the right edge", () => movePiece(db, pM, { pieceId: pistolM.id, x: 6, y: 0, rotated: false }), "That doesn't fit there.");
  movePiece(db, pM, { pieceId: pistolM.id, x: 6, y: 0, rotated: true });
  eq("turned, it fits at (6,0)", (({ x, y, rotated }) => [x, y, rotated])(piecesOf(pM, "Pistol")[0]), [6, 0, 1]);
  fails("spot taken", () => movePiece(db, pM, { pieceId: a60.id, x: 7, y: 1, rotated: false }), "That spot is taken.");
  movePiece(db, pM, { pieceId: pistolM.id, x: null, y: null, rotated: true });
  eq("moved to the tray", piecesOf(pM, "Pistol")[0].x, null);
  give(pM, "Knife", 2);
  give(pM, "Med Kit", 1);
  splitPiece(db, pM, { pieceId: piecesOf(pM, "Pistol Ammo")[1].id, quantity: 25 });
  const before = piecesOf(pM).length;
  const arr = arrange(db, pM);
  eq("arrange: nothing left in the tray", arr.trayed, 0);
  eq("arrange merged the part-full ammo (30+35+25 → 60+30)", qtys(pM, "Pistol Ammo").sort((x, y) => y - x), [60, 30]);
  check("arrange removed the extra stack", piecesOf(pM).length === before - 1);
  const pm = piecesOf(pM, "Pistol")[0];
  eq("biggest piece (the pistol) first, top-left", [pm.x, pm.y], [0, 0]);
  invariant("move/merge/split/arrange");

  const pS = newPlayer();
  give(pS, "Sniper Rifle", 2);
  give(pS, "Pistol Ammo", 240);
  eq("full case: snipers + 4 ammo cells", piecesOf(pS).filter((p) => p.x !== null).length, 6);
  fails("split with no room", () => splitPiece(db, pS, { pieceId: piecesOf(pS, "Pistol Ammo")[0].id, quantity: 10 }), "No room to split that. Make space first.");
  const over = give(pS, "Pistol Ammo", 60);
  eq("Admin give overflows to the tray", over.trayed, 1);
  const arr2 = arrange(db, pS);
  eq("arrange never makes it worse (still 1 in the tray)", arr2.trayed, 1);
  invariant("full case");

  // ---- shop: room checks ---------------------------------------------------------
  title("Shop purchase room checks");
  setShopOpen(db, true);
  for (const [name, price] of [
    ["Shotgun", 100],
    ["Pistol Ammo", 10],
    ["Backpack Expansion", 5],
    ["Green Herb", 3],
    ["Pistol", 50],
  ] as const) {
    createShopItem(db, id(name), { price, stock: null, maxPerPurchase: null, enabled: true });
  }
  const shop = (name: string) => findShopItemByItemId(db, id(name))!.id;
  const pB = newPlayer();
  adjustBalance(db, { playerId: pB, type: "ADD", amount: 100000, performedBy: admin.id });
  give(pB, "Pistol", 1);
  purchase(db, { playerId: pB, shopItemId: shop("Shotgun"), quantity: 1 });
  eq("bought shotgun placed at (0,2)", (({ x, y }) => [x, y])(piecesOf(pB, "Shotgun")[0]), [0, 2]);
  const bal = (db.prepare("SELECT balance FROM users WHERE id = ?").get(pB) as { balance: number }).balance;
  fails("second shotgun doesn't fit", () => purchase(db, { playerId: pB, shopItemId: shop("Shotgun"), quantity: 1 }), NO_ROOM_TO_BUY);
  fails("900 rounds don't fit", () => purchase(db, { playerId: pB, shopItemId: shop("Pistol Ammo"), quantity: 30 }), NO_ROOM_TO_BUY);
  eq("refused purchases cost nothing", (db.prepare("SELECT balance FROM users WHERE id = ?").get(pB) as { balance: number }).balance, bal);
  eq("…and added nothing", held(pB, "Shotgun"), 1);
  purchase(db, { playerId: pB, shopItemId: shop("Pistol Ammo"), quantity: 3 });
  eq("90 rounds bought: 60 + 30", qtys(pB, "Pistol Ammo"), [60, 30]);
  fails("too many backpacks", () => purchase(db, { playerId: pB, shopItemId: shop("Backpack Expansion"), quantity: 7 }), "Your case can only grow 5 more rows, so buy at most 5.");
  purchase(db, { playerId: pB, shopItemId: shop("Backpack Expansion"), quantity: 5 });
  eq("five backpacks: 8×9", caseSize(db, pB), { cols: 8, rows: 9, expansions: 5 });
  fails("case at its biggest", () => purchase(db, { playerId: pB, shopItemId: shop("Backpack Expansion"), quantity: 1 }), "Your case is already as big as it can get.");
  purchase(db, { playerId: pB, shopItemId: shop("Shotgun"), quantity: 1 });
  eq("with the bigger case a second shotgun fits", held(pB, "Shotgun"), 2);
  fails("tray must fit before buying more (pR's sniper)", () => purchase(db, { playerId: pR, shopItemId: shop("Green Herb"), quantity: 1 }), NO_ROOM_TO_BUY);
  const pV = newPlayer();
  give(pV, "Backpack Expansion", 2);
  give(pV, "Sniper Rifle", 3);
  eq("three snipers fill a 6-row case", piecesOf(pV, "Sniper Rifle").map((p) => p.y), [0, 2, 4]);
  updateItem(db, id("Backpack Expansion"), { sellable: true });
  fails("can't sell a backpack the case still needs", () => sell(db, { playerId: pV, itemId: id("Backpack Expansion"), quantity: 1 }), "Your things wouldn't fit in a smaller case. Make room first, then sell it.");
  eq("…and nothing changed", [held(pV, "Backpack Expansion"), caseSize(db, pV).rows, piecesOf(pV).every((p) => p.x !== null)], [2, 6, true]);
  remove(pV, "Sniper Rifle", 1);
  sell(db, { playerId: pV, itemId: id("Backpack Expansion"), quantity: 1 });
  eq("with room made, it sells", [held(pV, "Backpack Expansion"), caseSize(db, pV).rows], [1, 5]);
  invariant("shop");

  // ---- practice firing (game not started) -------------------------------------------
  title("Practice firing before the game starts");
  const pP = newPlayer();
  give(pP, "Pistol", 1);
  give(pP, "Pistol Ammo", 30);
  give(pP, "Knife", 1);
  const gunP = piecesOf(pP, "Pistol")[0].id;
  const f0 = fire(db, pP, gunP, 3);
  eq("practice shot: pretend magazine 12 → 9", [f0.practice, f0.loaded, f0.reserve, f0.fired], [true, 9, 30, 3]);
  eq("nothing real was used", [piecesOf(pP, "Pistol")[0].loaded, held(pP, "Pistol Ammo")], [0, 30]);
  const r0 = reload(db, pP, gunP);
  eq("practice reload is free and full", [r0.practice, r0.loaded, r0.reserve, held(pP, "Pistol Ammo")], [true, 12, 30, 30]);
  const k0 = fire(db, pP, piecesOf(pP, "Knife")[0].id, 1);
  eq("knife swings", k0.practice, true);
  updateRules(db, { practiceFire: false });
  fails("practice off: can't fire yet", () => fire(db, pP, gunP, 1), "The game hasn't started yet.", 409);
  updateRules(db, { practiceFire: true });
  fails("healing waits for the game", () => useHealing(db, pP, gunP), "Healing works once the game starts.", 409);

  // ---- herb mixing ------------------------------------------------------------------------
  title("Herb mixing");
  const pX = newPlayer();
  give(pX, "Green Herb", 10);
  give(pX, "Red Herb", 4);
  give(pX, "Yellow Herb", 6);
  const herb = (name: string, skip = 0) => piecesOf(pX, name)[skip].id;
  const firstG = piecesOf(pX, "Green Herb")[0];
  const gg = combine(db, pX, { pieceId: firstG.id, withPieceId: herb("Green Herb", 1) });
  eq("G+G = GG, auto-added to the catalogue", [gg.item.herbCode, gg.item.name, gg.createdItem], ["GG", "Mixed Herb (G+G)", true]);
  const ggPiece = piecesOf(pX, "Mixed Herb (G+G)")[0];
  eq("the mix lands where the first herb was", [ggPiece.x, ggPiece.y], [firstG.x, firstG.y]);
  eq("one of each herb used, one mix made", [held(pX, "Green Herb"), held(pX, "Mixed Herb (G+G)")], [8, 1]);
  eq("logged MIX three times", logCount(pX, "MIX"), 3);
  eq("GG heals 60 (from the pack)", item("Mixed Herb (G+G)").heal_amount, 60);
  const gr = combine(db, pX, { pieceId: herb("Red Herb"), withPieceId: herb("Green Herb") });
  eq("R+G = GR (order doesn't matter)", gr.item.herbCode, "GR");
  const gy = combine(db, pX, { pieceId: herb("Green Herb"), withPieceId: herb("Yellow Herb") });
  eq("G+Y = GY", gy.item.herbCode, "GY");
  const gry = combine(db, pX, { pieceId: piecesOf(pX, "Mixed Herb (G+R)")[0].id, withPieceId: herb("Yellow Herb") });
  eq("GR+Y = GRY", gry.item.herbCode, "GRY");
  combine(db, pX, { pieceId: herb("Green Herb"), withPieceId: herb("Yellow Herb") });
  const gry2 = combine(db, pX, { pieceId: piecesOf(pX, "Mixed Herb (G+Y)")[0].id, withPieceId: herb("Red Herb") });
  eq("GY+R = GRY", [gry2.item.herbCode, gry2.createdItem], ["GRY", false]);
  combine(db, pX, { pieceId: herb("Green Herb"), withPieceId: herb("Green Herb", 1) });
  const ggy = combine(db, pX, { pieceId: piecesOf(pX, "Mixed Herb (G+G)")[0].id, withPieceId: herb("Yellow Herb") });
  eq("GG+Y = GGY", ggy.item.herbCode, "GGY");
  combine(db, pX, { pieceId: herb("Green Herb"), withPieceId: herb("Yellow Herb") });
  const ggy2 = combine(db, pX, { pieceId: piecesOf(pX, "Mixed Herb (G+Y)")[0].id, withPieceId: herb("Green Herb") });
  eq("GY+G = GGY", ggy2.item.herbCode, "GGY");
  eq("all five mixed herbs exist now", ["GG", "GR", "GY", "GRY", "GGY"].map((c) => Boolean(db.prepare("SELECT 1 FROM items WHERE herb_code = ?").get(c))), [true, true, true, true, true]);
  give(pX, "Red Herb", 2);
  give(pX, "Yellow Herb", 2);
  give(pX, "Green Herb", 2);
  give(pX, "Mixed Herb (G+G)", 1);
  give(pX, "Mixed Herb (G+R)", 1);
  give(pX, "Mixed Herb (G+Y)", 1);
  const bad = (a: string, b: string) => () =>
    combine(db, pX, { pieceId: herb(a), withPieceId: a === b ? herb(b, 1) : herb(b) });
  const NO_MIX = "These herbs don't mix. Every mix needs a Green Herb.";
  fails("R+Y", bad("Red Herb", "Yellow Herb"), "Red and Yellow need a Green Herb to mix.");
  fails("R+R", bad("Red Herb", "Red Herb"), NO_MIX);
  fails("Y+Y", bad("Yellow Herb", "Yellow Herb"), NO_MIX);
  fails("G+GG = GGG", bad("Green Herb", "Mixed Herb (G+G)"), NO_MIX);
  fails("GG+R = GGR", bad("Mixed Herb (G+G)", "Red Herb"), NO_MIX);
  fails("GR+R = GRR", bad("Mixed Herb (G+R)", "Red Herb"), NO_MIX);
  fails("GY+Y = GYY", bad("Mixed Herb (G+Y)", "Yellow Herb"), NO_MIX);
  fails("GG+GR (4 herbs)", bad("Mixed Herb (G+G)", "Mixed Herb (G+R)"), NO_MIX);
  fails("GRY+G (4 herbs)", bad("Mixed Herb (G+R+Y)", "Green Herb"), NO_MIX);
  give(pX, "Knife", 1);
  fails("not a herb", () => combine(db, pX, { pieceId: herb("Green Herb"), withPieceId: piecesOf(pX, "Knife")[0].id }), "Only herbs can be mixed.");
  fails("a single herb with itself", () => combine(db, pX, { pieceId: herb("Green Herb"), withPieceId: herb("Green Herb") }), "Choose another herb to mix it with.");
  const cv = caseView(db, pX);
  const gView = cv.pieces.find((p) => p.herbCode === "G")!;
  check("the case lists what a green herb can mix with", gView.mixWith.length > 0 && gView.mixWith.every((m) => ["GG", "GR", "GY", "GGY"].includes(m.result)));
  eq("mix preview: G+Y heals 45", cv.mixes.GY && [cv.mixes.GY.name, cv.mixes.GY.healAmount], ["Mixed Herb (G+Y)", 45]);
  eq("Red herb isn't usable alone; GGY is", [cv.pieces.find((p) => p.herbCode === "R")!.usable, cv.pieces.find((p) => p.herbCode === "GGY")!.usable], [false, true]);
  invariant("mixing");

  // ---- game on: reload & fire --------------------------------------------------------------
  title("Reload frees case space, fire");
  setGameStatus(db, "active", admin.id);
  const pL = newPlayer();
  give(pL, "Pistol", 1);
  give(pL, "Pistol Ammo", 28);
  splitPiece(db, pL, { pieceId: piecesOf(pL, "Pistol Ammo")[0].id, quantity: 1 });
  eq("ammo in two boxes: 27 and 1", qtys(pL, "Pistol Ammo"), [27, 1]);
  const gunL = piecesOf(pL, "Pistol")[0].id;
  const rl = reload(db, pL, gunL);
  eq("reload: 12 in, 16 left", [rl.loaded, rl.reserve, rl.reloaded, rl.practice], [12, 16, 12, false]);
  eq("the 1-round box was used up first (slot freed)", qtys(pL, "Pistol Ammo"), [16]);
  eq("logged RELOAD", lastLog(pL), { action: "RELOAD", b: 28, a: 16 });
  eq("reload time from the server (pistol 1.4 s)", rl.reloadMs, 1400);
  const f1 = fire(db, pL, gunL, 5);
  eq("fire 5", [f1.loaded, f1.fired, f1.empty], [7, 5, false]);
  const f2 = fire(db, pL, gunL, 10);
  eq("fire beyond loaded: only 7 go off, empty", [f2.loaded, f2.fired, f2.empty], [0, 7, true]);
  const f3 = fire(db, pL, gunL, 1);
  eq("empty magazine", [f3.loaded, f3.fired, f3.empty], [0, 0, true]);
  reload(db, pL, gunL);
  const full = reload(db, pL, gunL);
  eq("reload when full does nothing", [full.reloaded, full.loaded, full.reserve], [0, 12, 4]);
  fire(db, pL, gunL, 10);
  fire(db, pL, gunL, 2);
  eq("last 4 rounds in", reload(db, pL, gunL).loaded, 4);
  fire(db, pL, gunL, 4);
  fails("no ammo left", () => reload(db, pL, gunL), "No ammo left for the Pistol.");
  give(pL, "Green Herb", 1);
  fails("a herb can't be fired", () => fire(db, pL, piecesOf(pL, "Green Herb")[0].id, 1), "Green Herb can't be fired.");
  invariant("reload/fire");

  title("Selling a loaded gun gives the rounds back");
  give(pL, "Pistol Ammo", 30);
  reload(db, pL, gunL);
  eq("12 loaded, 18 carried", [piecesOf(pL, "Pistol")[0].loaded, held(pL, "Pistol Ammo")], [12, 18]);
  sell(db, { playerId: pL, itemId: id("Pistol"), quantity: 1 });
  eq("gun sold, its 12 rounds are back in the ammo", [held(pL, "Pistol"), held(pL, "Pistol Ammo")], [0, 30]);
  eq("logged RETURN", lastLog(pL), { action: "RETURN", b: 18, a: 30 });
  give(pL, "Pistol", 1);
  reload(db, pL, piecesOf(pL, "Pistol")[0].id);
  remove(pL, "Pistol", 1);
  eq("Admin removing a loaded gun also returns its rounds", held(pL, "Pistol Ammo"), 30);
  invariant("sell");

  // ---- healing --------------------------------------------------------------------------------
  title("Using healing items");
  const pH = newPlayer();
  for (const n of ["Green Herb", "Med Kit", "Red Herb"]) give(pH, n, 2);
  for (const n of ["GG", "GR", "GY", "GRY", "GGY"]) give(pH, `Mixed Herb (${n.split("").join("+")})`, 1);
  const use = (name: string) => useHealing(db, pH, piecesOf(pH, name)[0].id).change;
  const hpNow = () => getHp(db, pH);
  damage(db, pH, 50, { source: "test" });
  eq("green herb heals 30 (50 → 80)", [use("Green Herb").hp, hpNow().hp], [80, 80]);
  eq("med kit heals 40, never above max (→ 100)", use("Med Kit").hp, 100);
  fails("already full", () => use("Green Herb"), "You're already at full health.");
  eq("…and the herb wasn't used", held(pH, "Green Herb"), 1);
  fails("red herb alone", () => use("Red Herb"), "Mix it with a Green Herb first.");
  const grc = use("Mixed Herb (G+R)");
  eq("G+R: max HP +20 and filled (120/120)", [grc.hp, grc.maxHp, grc.maxDelta], [120, 120, 20]);
  const gryc = use("Mixed Herb (G+R+Y)");
  eq("G+R+Y: heals 50, max +15 (135/135)", [gryc.hp, gryc.maxHp], [135, 135]);
  damage(db, pH, 100, { source: "test" });
  eq("G+G+Y restores all HP (35 → 135)", use("Mixed Herb (G+G+Y)").hp, 135);
  damage(db, pH, 90, { source: "test" });
  eq("G+G heals 60 (45 → 105)", use("Mixed Herb (G+G)").hp, 105);
  eq("G+Y heals 45, capped at max (→ 135)", use("Mixed Herb (G+Y)").hp, 135);
  eq("each use logged USE", logCount(pH, "USE"), 7);
  eq("hp_log kinds", (db.prepare("SELECT kind FROM hp_log WHERE player_id = ? AND kind != 'HIT' ORDER BY id").all(pH) as unknown as Array<{ kind: string }>).map((r) => r.kind), ["HEAL", "HEAL", "MAX_UP", "MAX_UP", "FULL", "HEAL", "HEAL"]);
  invariant("healing");

  // ---- paused -----------------------------------------------------------------------------------
  title("Paused game");
  setGameStatus(db, "paused", admin.id);
  const PAUSED = "The game is paused. Wait for the Admin to continue it.";
  fails("no firing", () => fire(db, pP, gunP, 1), PAUSED, 409);
  fails("no reloading", () => reload(db, pP, gunP), PAUSED, 409);
  fails("no healing", () => useHealing(db, pH, piecesOf(pH, "Green Herb")[0].id), PAUSED, 409);
  fails("no dropping", () => dropPiece(db, pH, { pieceId: piecesOf(pH, "Green Herb")[0].id }), PAUSED, 409);
  fails("no mixing", () => combine(db, pX, { pieceId: herb("Green Herb"), withPieceId: herb("Yellow Herb") }), PAUSED, 409);
  movePiece(db, pH, { pieceId: piecesOf(pH, "Green Herb")[0].id, x: 7, y: 3, rotated: false });
  check("arranging the case still works", piecesOf(pH, "Green Herb")[0].x === 7);
  setGameStatus(db, "active", admin.id);

  // ---- death → drop box ----------------------------------------------------------------------------
  title("Death drops everything");
  const pD = newPlayer();
  adjustBalance(db, { playerId: pD, type: "ADD", amount: 500, performedBy: admin.id });
  give(pD, "Pistol", 1);
  give(pD, "Pistol Ammo", 100);
  give(pD, "Green Herb", 2);
  give(pD, "Backpack Expansion", 1);
  setLevel(db, pD, id("Pistol"), "magazine", 3);
  setLevel(db, pD, id("Pistol"), "damage", 2);
  addSpent(db, pD, id("Pistol"), 300);
  const rD = reload(db, pD, piecesOf(pD, "Pistol")[0].id);
  eq("magazine level 3 holds 17", rD.loaded, 17);
  const death = damage(db, pD, 100, { source: "test" });
  eq("down, and the case went to the drop box", [death.died, death.dropped], [true, true]);
  eq("case empty", piecesOf(pD).length, 0);
  eq("backpack and money stay", [held(pD, "Backpack Expansion"), (db.prepare("SELECT balance FROM users WHERE id = ?").get(pD) as { balance: number }).balance], [1, 500]);
  const dropsD = listDrops(db, pD).filter((d) => d.ownerId === pD);
  const gunDrop = dropsD.find((d) => d.name === "Pistol")!;
  const ammoDrop = dropsD.find((d) => d.name === "Pistol Ammo")!;
  eq("three drops (pistol, ammo, herbs)", dropsD.length, 3);
  eq("pistol keeps its 17 rounds", [gunDrop.loaded, gunDrop.reason, gunDrop.mine, gunDrop.w, gunDrop.h], [17, "DEATH", true, 3, 2]);
  eq("ammo in one drop", ammoDrop.quantity, 83);
  const gunRow = db.prepare("SELECT upgrades, spent FROM dropped_items WHERE id = ?").get(gunDrop.id) as { upgrades: string; spent: number };
  eq("upgrades and money share travel with it", [JSON.parse(gunRow.upgrades), gunRow.spent], [{ magazine: 3, damage: 2 }, 300]);
  eq("logged DEATH", logCount(pD, "DEATH"), 3);
  fails("downed player can't pick up", () => pickup(db, pD, { dropId: ammoDrop.id }), "You're down. Ask the Admin to revive you.", 409);
  fails("downed player can't buy", () => purchase(db, { playerId: pD, shopItemId: shop("Green Herb"), quantity: 1 }), /You're down/);
  invariant("death");

  title("Picking up");
  const pE = newPlayer();
  const got = pickup(db, pE, { dropId: gunDrop.id });
  eq("picked up the pistol", got.itemName, "Pistol");
  const lv = levelsFor(db, pE, id("Pistol"));
  eq("had none: gets the dropped levels", [lv.magazine, lv.damage, lv.reload], [3, 2, 1]);
  eq("rounds still in it", piecesOf(pE, "Pistol")[0].loaded, 17);
  eq("money share moves to the finder", getHolding(db, pE, id("Pistol"))!.spent, 300);
  fails("second pickup of the same drop", () => pickup(db, pE, { dropId: gunDrop.id }), "Someone already picked that up.", 409);
  const pF = newPlayer();
  give(pF, "Pistol", 1);
  setLevel(db, pF, id("Pistol"), "magazine", 2);
  setLevel(db, pF, id("Pistol"), "damage", 4);
  setLevel(db, pF, id("Pistol"), "reload", 3);
  const eDrop = dropPiece(db, pE, { pieceId: piecesOf(pE, "Pistol")[0].id });
  eq("dropping the last pistol clears the dropper's levels", levelsFor(db, pE, id("Pistol")).magazine, 1);
  eq("logged DROP", lastLog(pE), { action: "DROP", b: 1, a: 0 });
  pickup(db, pF, { dropId: eDrop.dropId });
  const lf = levelsFor(db, pF, id("Pistol"));
  eq("already had one: keeps the higher level of each", [lf.magazine, lf.damage, lf.reload], [3, 4, 3]);
  eq("now holds two pistols, one loaded 17", piecesOf(pF, "Pistol").map((p) => p.loaded), [0, 17]);
  const part = pickup(db, pE, { dropId: ammoDrop.id, quantity: 50 });
  eq("partial pickup", [part.quantity, held(pE, "Pistol Ammo"), listDrops(db).find((d) => d.id === ammoDrop.id)!.quantity], [50, 50, 33]);
  fails("more than is there", () => pickup(db, pE, { dropId: ammoDrop.id, quantity: 34 }), "There are only 33 left.", 409);
  fails("no room in the case", () => pickup(db, pS, { dropId: ammoDrop.id, quantity: 1 }), "Not enough room in your case. Make space first.");
  const ten = dropPiece(db, pE, { pieceId: piecesOf(pE, "Pistol Ammo")[0].id, quantity: 10 });
  eq("drop part of a stack", [ten.quantity, held(pE, "Pistol Ammo")], [10, 40]);
  fails("drop more than the piece has", () => dropPiece(db, pE, { pieceId: piecesOf(pE, "Pistol Ammo")[0].id, quantity: 41 }), "Choose how many to drop (1 to 40).");
  invariant("pickup");

  // ---- game end → drops go home ---------------------------------------------------------------
  title("Game end returns unclaimed drops to their owners");
  const leftBefore = listDrops(db).length;
  check("drops waiting before the end", leftBefore >= 3);
  setGameStatus(db, "ended", admin.id);
  eq("drop box empty", listDrops(db).length, 0);
  eq("downed owner got their ammo and herbs back", [held(pD, "Pistol Ammo"), held(pD, "Green Herb")], [33, 2]);
  eq("pE got their 10 rounds back", held(pE, "Pistol Ammo"), 50);
  check("logged RETURN", logCount(pD, "RETURN") === 2 && logCount(pE, "RETURN") === 1);
  fails("no pickups after the game", () => pickup(db, pE, { dropId: 1 }), "The game is over.", 409);
  invariant("game end");

  title("Admin clears the drop box");
  setGameStatus(db, "active", admin.id);
  dropPiece(db, pE, { pieceId: piecesOf(pE, "Pistol Ammo")[0].id, quantity: 5 });
  eq("returned 1 drop", returnAllToOwners(db, admin.id), 1);
  eq("back in the case", held(pE, "Pistol Ammo"), 50);
  updateRules(db, { returnDropsOnEnd: false });
  dropPiece(db, pE, { pieceId: piecesOf(pE, "Pistol Ammo")[0].id, quantity: 5 });
  setGameStatus(db, "ended", admin.id);
  eq("rule off: drops stay in the box at the end", listDrops(db).length, 1);
  updateRules(db, { returnDropsOnEnd: true });
  returnAllToOwners(db, admin.id);
  setGameStatus(db, "active", admin.id);
  invariant("clear");

  // ---- the Admin changes things -------------------------------------------------------------------
  title("Rules and items change");
  updateRules(db, { caseCols: 4 });
  invariant("case 4 columns wide");
  check("pieces that didn't fit went to the tray", piecesOf(pS).some((p) => p.x === null));
  updateRules(db, { caseCols: 8 });
  invariant("back to 8 columns");

  const loadedBefore = piecesOf(pF, "Pistol").map((p) => p.loaded);
  const ammoBefore = held(pF, "Pistol Ammo");
  updateItem(db, id("Pistol"), { baseMagazine: 6 });
  eq("magazine now 8 at level 3", gunNumbers(db, pF, item("Pistol")).magazine, 8);
  eq("loaded rounds trimmed to 8", piecesOf(pF, "Pistol").map((p) => p.loaded), loadedBefore.map((l) => Math.min(l, 8)));
  eq("the extra 9 went back into ammo", held(pF, "Pistol Ammo") - ammoBefore, 9);
  updateItem(db, id("Pistol"), { baseMagazine: 12 });

  updateItem(db, id("Pistol Ammo"), { stackSize: 20 });
  check("ammo stacks re-split to 20", piecesOf(pM, "Pistol Ammo").every((p) => p.quantity <= 20));
  invariant("smaller ammo stacks");
  updateItem(db, id("Pistol Ammo"), { stackSize: 60 });
  updateItem(db, id("Med Kit"), { gridW: 2, gridH: 2 });
  invariant("bigger med kit");

  const box = createItem(db, { name: "Test Box", kind: "other" });
  const pK = newPlayer();
  give(pK, "Test Box", 2);
  eq("two boxes, two pieces", piecesOf(pK, "Test Box").length, 2);
  updateItem(db, box.id, { kind: "backpack" });
  eq("turned into a backpack: pieces gone, case grows", [piecesOf(pK, "Test Box").length, caseSize(db, pK).rows], [0, 6]);
  updateItem(db, box.id, { kind: "other" });
  eq("and back: pieces again, case shrinks", [piecesOf(pK, "Test Box").length, caseSize(db, pK).rows], [2, 4]);
  invariant("item edits");

  // ---- old saves -----------------------------------------------------------------------------------
  title("Old save without pieces");
  const pO = newPlayer();
  for (const [name, q] of [["Pistol", 1], ["Pistol Ammo", 100], ["Green Herb", 3]] as const) {
    db.prepare("INSERT INTO inventory (player_id, item_id, quantity) VALUES (?, ?, ?)").run(pO, id(name), q);
  }
  check("no pieces yet", piecesOf(pO).length === 0);
  initInventory(db);
  eq("server start lays the case out", [held(pO, "Pistol Ammo"), qtys(pO, "Pistol Ammo"), qtys(pO, "Green Herb")], [100, [60, 40], [1, 1, 1]]);
  eq("pistol first, top-left", (({ x, y }) => [x, y])(piecesOf(pO, "Pistol")[0]), [0, 0]);
  invariant("old save");

  // ---- HTTP view sanity -------------------------------------------------------------------------------
  title("Case view");
  const v = caseView(db, pF);
  const pv = v.pieces.find((p) => p.kind === "gun")!;
  check(
    "piece has every field the phone needs",
    ["id", "itemId", "name", "kind", "imageUrl", "modelUrl", "soundUrl", "useEffect", "modelFlip", "modelUpsideDown", "x", "y", "w", "h", "rotated", "quantity", "stackSize", "loaded", "magazine", "ammoItemId", "reserve", "herbCode", "healAmount", "maxHpBonus", "fullHeal", "usable", "upgrades", "gun"].every((k) => k in pv),
    Object.keys(pv)
  );
  eq("gun numbers", pv.gun && Object.keys(pv.gun), ["reloadMs", "shakeThreshold", "cooldownMs", "damagePct"]);
  eq("four gun upgrade tracks", pv.upgrades.map((u) => u.track), ["magazine", "damage", "reload", "firerate"]);
  eq("ammo link and reserve", [pv.ammoItemId, pv.reserve], [id("Pistol Ammo"), held(pF, "Pistol Ammo")]);
  eq("weapon slot badge", pv.slot, 1);
  check("view has case size, hp, game, rules", v.cols === 8 && v.rows === 4 && v.hp.hp > 0 && v.game.status === "active" && v.rules.practiceFire === true);

  // ---- new round --------------------------------------------------------------------------------------
  title("New round");
  resetRound(db);
  eq("no pieces or drops left", [
    (db.prepare("SELECT COUNT(*) AS n FROM inventory_pieces").get() as { n: number }).n,
    (db.prepare("SELECT COUNT(*) AS n FROM dropped_items").get() as { n: number }).n,
  ], [0, 0]);
  eq("everyone back to full HP", getHp(db, pD), { hp: 100, maxHp: 100, dead: false });
  invariant("reset");

  db.close();
}

main()
  .catch((err) => {
    failed++;
    console.error(`\nCRASH in "${section}":`, err);
  })
  .finally(() => {
    try {
      fs.rmSync(tmp, { recursive: true, force: true });
    } catch {
      // leave it
    }
    console.log(`\n${passed} passed, ${failed} failed`);
    process.exit(failed > 0 ? 1 : 0);
  });
