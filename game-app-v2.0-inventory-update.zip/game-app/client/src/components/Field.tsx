import { InputHTMLAttributes, useState } from "react";

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: string;
}

// Inputs are dark wells sunk into the panel; the edge lights up amber while
// you type in one.
const inputCls =
  "w-full rounded-md border border-panel-line bg-panel-deep px-4 py-3 text-lg text-ink shadow-[inset_0_2px_5px_rgba(0,0,0,0.65)] outline-none transition-[border-color,box-shadow] duration-150 focus:border-pine focus:shadow-[inset_0_2px_5px_rgba(0,0,0,0.65),0_0_0_3px_rgba(245,165,36,0.22)] disabled:opacity-50";

export function TextField({ label, hint, id, ...rest }: FieldProps) {
  return (
    <label htmlFor={id} className="block">
      <span className="mb-1.5 block text-base font-semibold text-ink/75">{label}</span>
      <input id={id} className={inputCls} {...rest} />
      {hint && <span className="mt-1 block text-sm text-ink/55">{hint}</span>}
    </label>
  );
}

export function PasswordField({ label, hint, id, ...rest }: FieldProps) {
  const [visible, setVisible] = useState(false);
  return (
    <label htmlFor={id} className="block">
      <span className="mb-1.5 block text-base font-semibold text-ink/75">{label}</span>
      <div className="relative">
        <input id={id} type={visible ? "text" : "password"} className={`${inputCls} pr-20`} {...rest} />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          className="absolute inset-y-0 right-1.5 my-1.5 rounded-md px-3 text-sm font-semibold text-pine active:bg-pine-soft"
          aria-label={visible ? "Hide password" : "Show password"}
        >
          {visible ? "Hide" : "Show"}
        </button>
      </div>
      {hint && <span className="mt-1 block text-sm text-ink/55">{hint}</span>}
    </label>
  );
}

export { inputCls };
