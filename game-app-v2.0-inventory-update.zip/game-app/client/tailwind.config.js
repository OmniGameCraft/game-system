/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      // "Attaché case" palette, taken from the reference picture: deep
      // charcoal and black surfaces, neutral steel lines, white bold numbers,
      // and a signal-amber accent for main actions and the selected thing.
      // The old names are kept so every screen picks the theme up:
      //   paper = page, panel = surfaces, ink = text, pine = amber accent,
      //   olive = good news / healing, alert = danger red, sun = caution yellow,
      //   steel = the case's metal rim and frames.
      colors: {
        paper: "#0B0C0E",
        panel: {
          DEFAULT: "#15171A",
          raised: "#1E2125",
          line: "#32363C",
          deep: "#08090A",
        },
        steel: { DEFAULT: "#8D949C", light: "#C8CDD3", dark: "#4A5057" },
        ink: "#ECEEF0",
        pine: {
          DEFAULT: "#F5A524",
          soft: "rgba(245, 165, 36, 0.14)",
          ink: "#1C1405",
          deep: "#B8750F",
          light: "#FFC861",
        },
        olive: { DEFAULT: "#8FCC5C", soft: "rgba(143, 204, 92, 0.15)" },
        sun: "#E9C84A",
        alert: "#FF5A4F",
      },
      boxShadow: {
        // A thin light edge on top + dark edge below: looks like pressed metal.
        bevel: "inset 0 1px 0 rgba(255,255,255,0.08), inset 0 -1px 0 rgba(0,0,0,0.5)",
        "bevel-lg":
          "inset 0 1px 0 rgba(255,255,255,0.10), inset 0 -2px 0 rgba(0,0,0,0.55), 0 8px 24px -10px rgba(0,0,0,0.9)",
        glow: "0 0 0 2px #F5A524, 0 0 18px 2px rgba(245,165,36,0.45)",
        "glow-good": "0 0 0 2px #8FCC5C, 0 0 18px 2px rgba(143,204,92,0.45)",
        "glow-bad": "0 0 0 2px #FF5A4F, 0 0 18px 2px rgba(255,90,79,0.45)",
        lift: "0 12px 32px -8px rgba(0,0,0,0.85)",
      },
      // Short, smooth animations. All of them are switched off by the
      // "Reduce animations" setting (see index.css).
      //
      // Entrance animations use fill-mode "backwards", never "both" or
      // "forwards": an element that keeps a transform after animating would
      // trap any full-screen (position: fixed) layer inside it, such as the
      // 3D viewer or a pop-up, in that element's box.
      keyframes: {
        // weapon viewer (kept from 1.x)
        shotflash: { "0%": { opacity: "0.35" }, "100%": { opacity: "0" } },
        recoil: {
          "0%": { transform: "translateX(0) rotate(0)" },
          "20%": { transform: "translateX(-18px) rotate(-9deg)" },
          "100%": { transform: "translateX(0) rotate(0)" },
        },
        swing: {
          "0%": { transform: "rotate(0)" },
          "40%": { transform: "rotate(55deg) translateX(20px)" },
          "100%": { transform: "rotate(0)" },
        },
        gameon: {
          "0%": { transform: "scale(0.6)", opacity: "0" },
          "15%": { transform: "scale(1.08)", opacity: "1" },
          "25%": { transform: "scale(1)" },
          "80%": { opacity: "1" },
          "100%": { opacity: "0" },
        },
        spinonce: { "0%": { transform: "rotateY(0)" }, "100%": { transform: "rotateY(360deg)" } },

        // 2.0
        "fade-in": { "0%": { opacity: "0" }, "100%": { opacity: "1" } },
        "fade-out": { "0%": { opacity: "1" }, "100%": { opacity: "0" } },
        // whole pages (tab switch): moves with `top`, not a transform, so
        // full-screen layers inside the page stay full-screen
        "page-in": {
          "0%": { opacity: "0", top: "10px" },
          "100%": { opacity: "1", top: "0" },
        },
        // cards and lists: a quick fade with a small rise
        enter: {
          "0%": { opacity: "0", transform: "translateY(10px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        // bottom sheets
        "slide-up": { "0%": { transform: "translateY(100%)" }, "100%": { transform: "translateY(0)" } },
        "slide-down": { "0%": { transform: "translateY(0)" }, "100%": { transform: "translateY(100%)" } },
        // full pages (Settings) pushed in from the right
        "slide-in-right": {
          "0%": { transform: "translateX(100%)", opacity: "0.6" },
          "100%": { transform: "translateX(0)", opacity: "1" },
        },
        "slide-out-right": {
          "0%": { transform: "translateX(0)", opacity: "1" },
          "100%": { transform: "translateX(100%)", opacity: "0.6" },
        },
        pop: {
          "0%": { transform: "scale(0.82)", opacity: "0" },
          "60%": { transform: "scale(1.05)", opacity: "1" },
          "100%": { transform: "scale(1)", opacity: "1" },
        },
        shake: {
          "0%, 100%": { transform: "translateX(0)" },
          "15%": { transform: "translateX(-7px)" },
          "30%": { transform: "translateX(6px)" },
          "45%": { transform: "translateX(-5px)" },
          "60%": { transform: "translateX(4px)" },
          "75%": { transform: "translateX(-2px)" },
        },
        // red edges of the screen flash when you're hit
        damage: {
          "0%": { opacity: "0" },
          "12%": { opacity: "1" },
          "100%": { opacity: "0" },
        },
        // green glow when you heal
        heal: {
          "0%": { opacity: "0", transform: "scale(0.96)" },
          "30%": { opacity: "1", transform: "scale(1)" },
          "100%": { opacity: "0", transform: "scale(1.02)" },
        },
        // a number that just changed gives a little bump
        tick: {
          "0%": { transform: "translateY(-35%)", opacity: "0.2" },
          "60%": { transform: "translateY(4%)", opacity: "1" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
        shimmer: { "0%": { backgroundPosition: "-200% 0" }, "100%": { backgroundPosition: "200% 0" } },
        "toast-in": {
          "0%": { transform: "translateY(-120%) scale(0.96)", opacity: "0" },
          "100%": { transform: "translateY(0) scale(1)", opacity: "1" },
        },
        "toast-out": {
          "0%": { transform: "translateY(0) scale(1)", opacity: "1" },
          "100%": { transform: "translateY(-60%) scale(0.96)", opacity: "0" },
        },
        "glow-pulse": {
          "0%, 100%": { boxShadow: "0 0 0 2px rgba(245,165,36,0.95), 0 0 10px 1px rgba(245,165,36,0.35)" },
          "50%": { boxShadow: "0 0 0 2px rgba(245,165,36,1), 0 0 20px 4px rgba(245,165,36,0.55)" },
        },
        "ping-soft": {
          "0%": { transform: "scale(1)", opacity: "0.7" },
          "80%, 100%": { transform: "scale(2.2)", opacity: "0" },
        },
      },
      animation: {
        shotflash: "shotflash 110ms ease-out forwards",
        recoil: "recoil 220ms ease-out",
        swing: "swing 320ms ease-in-out",
        "spin-once": "spinonce 700ms ease-out",
        gameon: "gameon 2.2s ease-out forwards",

        "fade-in": "fade-in 180ms ease-out backwards",
        "fade-out": "fade-out 160ms ease-in both",
        "page-in": "page-in 200ms cubic-bezier(0.2, 0.8, 0.2, 1) backwards",
        enter: "enter 200ms cubic-bezier(0.2, 0.8, 0.2, 1) backwards",
        "slide-up": "slide-up 260ms cubic-bezier(0.2, 0.9, 0.25, 1) backwards",
        "slide-down": "slide-down 200ms ease-in both",
        "slide-in-right": "slide-in-right 260ms cubic-bezier(0.2, 0.9, 0.25, 1) backwards",
        "slide-out-right": "slide-out-right 200ms ease-in both",
        pop: "pop 260ms cubic-bezier(0.2, 0.9, 0.3, 1.2) backwards",
        shake: "shake 380ms ease-in-out",
        damage: "damage 600ms ease-out forwards",
        heal: "heal 900ms ease-out forwards",
        tick: "tick 260ms cubic-bezier(0.2, 0.9, 0.3, 1.2)",
        shimmer: "shimmer 1.6s linear infinite",
        "toast-in": "toast-in 240ms cubic-bezier(0.2, 0.9, 0.3, 1.1) backwards",
        "toast-out": "toast-out 180ms ease-in both",
        "glow-pulse": "glow-pulse 1.6s ease-in-out infinite",
        "ping-soft": "ping-soft 1.6s cubic-bezier(0, 0, 0.2, 1) infinite",
      },
      // Bundled with the app (npm @fontsource), never fetched from the internet.
      fontFamily: {
        sans: ["Barlow", "system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"],
        display: ["Chakra Petch", "Barlow", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
